package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.History;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptJobManager;

class PopupPseudoWebWindow
  implements WebWindow
{
  private final WebClient webClient_;
  private Object scriptObject_;
  private Page enclosedPage_;
  private int innerHeight_ = 605;
  private int outerHeight_ = this.innerHeight_ + 150;
  private int innerWidth_ = 1256;
  private int outerWidth_ = this.innerWidth_ + 8;
  
  PopupPseudoWebWindow(WebClient webClient)
  {
    this.webClient_ = webClient;
    this.webClient_.initialize(this);
  }
  
  public Page getEnclosedPage()
  {
    return this.enclosedPage_;
  }
  
  public String getName()
  {
    throw new RuntimeException("Not supported");
  }
  
  public WebWindow getParentWindow()
  {
    throw new RuntimeException("Not supported");
  }
  
  public Object getScriptObject()
  {
    return this.scriptObject_;
  }
  
  public JavaScriptJobManager getJobManager()
  {
    throw new RuntimeException("Not supported");
  }
  
  public WebWindow getTopWindow()
  {
    throw new RuntimeException("Not supported");
  }
  
  public WebClient getWebClient()
  {
    return this.webClient_;
  }
  
  public History getHistory()
  {
    throw new RuntimeException("Not supported");
  }
  
  public void setEnclosedPage(Page page)
  {
    this.enclosedPage_ = page;
    this.webClient_.initialize(page);
  }
  
  public void setName(String name)
  {
    throw new RuntimeException("Not supported");
  }
  
  public void setScriptObject(Object scriptObject)
  {
    this.scriptObject_ = scriptObject;
  }
  
  public boolean isClosed()
  {
    return false;
  }
  
  public int getInnerWidth()
  {
    return this.innerWidth_;
  }
  
  public void setInnerWidth(int innerWidth)
  {
    this.innerWidth_ = innerWidth;
  }
  
  public int getOuterWidth()
  {
    return this.outerWidth_;
  }
  
  public void setOuterWidth(int outerWidth)
  {
    this.outerWidth_ = outerWidth;
  }
  
  public int getInnerHeight()
  {
    return this.innerHeight_;
  }
  
  public void setInnerHeight(int innerHeight)
  {
    this.innerHeight_ = innerHeight;
  }
  
  public int getOuterHeight()
  {
    return this.outerHeight_;
  }
  
  public void setOuterHeight(int outerHeight)
  {
    this.outerHeight_ = outerHeight;
  }
}
