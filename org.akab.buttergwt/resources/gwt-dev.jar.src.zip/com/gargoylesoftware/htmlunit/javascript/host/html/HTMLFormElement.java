package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.HttpMethod;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.FormFieldWithNameHistory;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeEvent;
import com.gargoylesoftware.htmlunit.html.HtmlButton;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlImage;
import com.gargoylesoftware.htmlunit.html.HtmlImageInput;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.html.HtmlTextArea;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Event;
import com.gargoylesoftware.htmlunit.javascript.host.NodeList.EffectOnCache;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.lang3.StringUtils;

@JsxClass(domClasses={HtmlForm.class})
public class HTMLFormElement
  extends HTMLElement
  implements Function
{
  private HTMLCollection elements_;
  
  public void setHtmlElement(HtmlElement htmlElement)
  {
    super.setHtmlElement(htmlElement);
    HtmlForm htmlForm = getHtmlForm();
    htmlForm.setScriptObject(this);
  }
  
  @JsxGetter
  public String getName()
  {
    return getHtmlForm().getNameAttribute();
  }
  
  @JsxSetter
  public void setName(String name)
  {
    WebAssert.notNull("name", name);
    getHtmlForm().setNameAttribute(name);
  }
  
  @JsxGetter
  public HTMLCollection getElements()
  {
    if (this.elements_ == null)
    {
      final HtmlForm htmlForm = getHtmlForm();
      
      this.elements_ = new HTMLCollection(htmlForm, false, "HTMLFormElement.elements")
      {
        private boolean filterChildrenOfNestedForms_;
        
        protected List<Object> computeElements()
        {
          List<Object> response = super.computeElements();
          Iterator<Object> iter;
          if (this.filterChildrenOfNestedForms_) {
            for (iter = response.iterator(); iter.hasNext();)
            {
              HtmlElement field = (HtmlElement)iter.next();
              if (field.getEnclosingForm() != htmlForm) {
                iter.remove();
              }
            }
          }
          response.addAll(htmlForm.getLostChildren());
          return response;
        }
        
        protected Object getWithPreemption(String name)
        {
          return HTMLFormElement.this.getWithPreemption(name);
        }
        
        public NodeList.EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
        {
          return NodeList.EffectOnCache.NONE;
        }
        
        protected boolean isMatching(DomNode node)
        {
          if ((node instanceof HtmlForm))
          {
            this.filterChildrenOfNestedForms_ = true;
            return false;
          }
          return ((node instanceof HtmlInput)) || ((node instanceof HtmlButton)) || ((node instanceof HtmlTextArea)) || ((node instanceof HtmlSelect));
        }
      };
    }
    return this.elements_;
  }
  
  @JsxGetter
  public int getLength()
  {
    int all = getElements().getLength();
    int images = getHtmlForm().getElementsByAttribute("input", "type", "image").size();
    return all - images;
  }
  
  @JsxGetter
  public String getAction()
  {
    String action = getHtmlForm().getActionAttribute();
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_169)) {
      try
      {
        action = ((HtmlPage)getHtmlForm().getPage()).getFullyQualifiedUrl(action).toExternalForm();
      }
      catch (MalformedURLException e) {}
    }
    return action;
  }
  
  @JsxSetter
  public void setAction(String action)
  {
    WebAssert.notNull("action", action);
    getHtmlForm().setActionAttribute(action);
  }
  
  @JsxGetter
  public String getMethod()
  {
    return getHtmlForm().getMethodAttribute();
  }
  
  @JsxSetter
  public void setMethod(String method)
  {
    WebAssert.notNull("method", method);
    getHtmlForm().setMethodAttribute(method);
  }
  
  @JsxGetter
  public String getTarget()
  {
    return getHtmlForm().getTargetAttribute();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getOnsubmit()
  {
    return getEventHandlerProp("onsubmit");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOnsubmit(Object onsubmit)
  {
    setEventHandlerProp("onsubmit", onsubmit);
  }
  
  @JsxSetter
  public void setTarget(String target)
  {
    WebAssert.notNull("target", target);
    getHtmlForm().setTargetAttribute(target);
  }
  
  @JsxGetter
  public String getEncoding()
  {
    String encoding = getHtmlForm().getEnctypeAttribute();
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_FORM_ENCODING_NORMALIZED)) && 
      (!"application/x-www-form-urlencoded".equals(encoding)) && (!"multipart/form-data".equals(encoding))) {
      return "application/x-www-form-urlencoded";
    }
    return encoding;
  }
  
  @JsxSetter
  public void setEncoding(String encoding)
  {
    WebAssert.notNull("encoding", encoding);
    getHtmlForm().setEnctypeAttribute(encoding);
  }
  
  private HtmlForm getHtmlForm()
  {
    return (HtmlForm)getDomNodeOrDie();
  }
  
  @JsxFunction
  public void submit()
  {
    HtmlPage page = (HtmlPage)getDomNodeOrDie().getPage();
    WebClient webClient = page.getWebClient();
    
    String action = getHtmlForm().getActionAttribute().trim();
    if (StringUtils.startsWithIgnoreCase(action, "javascript:"))
    {
      String js = action.substring("javascript:".length());
      webClient.getJavaScriptEngine().execute(page, js, "Form action", 0);
    }
    else
    {
      WebRequest request = getHtmlForm().getWebRequest(null);
      String target = page.getResolvedTarget(getTarget());
      boolean isHashJump = (HttpMethod.GET == request.getHttpMethod()) && (action.endsWith("#"));
      webClient.download(page.getEnclosingWindow(), target, request, isHashJump, "JS form.submit()");
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object item(Object index, Object subIndex)
  {
    if ((index instanceof Number)) {
      return getElements().item(index);
    }
    String name = Context.toString(index);
    Object response = getWithPreemption(name);
    if (((subIndex instanceof Number)) && ((response instanceof HTMLCollection))) {
      return ((HTMLCollection)response).item(subIndex);
    }
    return response;
  }
  
  @JsxFunction
  public void reset()
  {
    getHtmlForm().reset();
  }
  
  protected Object getWithPreemption(final String name)
  {
    List<HtmlElement> elements = findElements(name);
    if (elements.isEmpty()) {
      return NOT_FOUND;
    }
    if (elements.size() == 1) {
      return getScriptableFor(elements.get(0));
    }
    HTMLCollection collection = new HTMLCollection(getHtmlForm(), elements)
    {
      protected List<Object> computeElements()
      {
        return new ArrayList(HTMLFormElement.this.findElements(name));
      }
    };
    return collection;
  }
  
  private List<HtmlElement> findElements(String name)
  {
    List<HtmlElement> elements = new ArrayList();
    addElements(name, getHtmlForm().getHtmlElementDescendants(), elements);
    addElements(name, getHtmlForm().getLostChildren(), elements);
    if (elements.isEmpty()) {
      for (DomNode node : getHtmlForm().getChildren()) {
        if ((node instanceof HtmlImage))
        {
          HtmlImage img = (HtmlImage)node;
          if ((name.equals(img.getId())) || (name.equals(img.getNameAttribute()))) {
            elements.add(img);
          }
        }
      }
    }
    return elements;
  }
  
  private void addElements(String name, Iterable<HtmlElement> nodes, List<HtmlElement> addTo)
  {
    for (HtmlElement node : nodes) {
      if (isAccessibleByIdOrName(node, name)) {
        addTo.add(node);
      }
    }
  }
  
  private boolean isAccessibleByIdOrName(HtmlElement element, String name)
  {
    if (((element instanceof FormFieldWithNameHistory)) && (!(element instanceof HtmlImageInput)))
    {
      if (element.getEnclosingForm() != getHtmlForm()) {
        return false;
      }
      FormFieldWithNameHistory elementWithNames = (FormFieldWithNameHistory)element;
      if ((name.equals(elementWithNames.getOriginalName())) || (name.equals(element.getId()))) {
        return true;
      }
      if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.FORMFIELD_REACHABLE_BY_NEW_NAMES)) {
        return false;
      }
      if ((name.equals(element.getAttribute("name"))) || (elementWithNames.getPreviousNames().contains(name))) {
        return true;
      }
    }
    return false;
  }
  
  public Object get(int index, Scriptable start)
  {
    if (getDomNodeOrNull() == null) {
      return NOT_FOUND;
    }
    return getElements().get(index, ((HTMLFormElement)start).getElements());
  }
  
  public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
  {
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_80)) {
      throw Context.reportRuntimeError("Not a function.");
    }
    if (args.length > 0)
    {
      Object arg = args[0];
      if ((arg instanceof String)) {
        return ScriptableObject.getProperty(this, (String)arg);
      }
      if ((arg instanceof Number)) {
        return ScriptableObject.getProperty(this, ((Number)arg).intValue());
      }
    }
    return Context.getUndefinedValue();
  }
  
  public Scriptable construct(Context cx, Scriptable scope, Object[] args)
  {
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_81)) {
      throw Context.reportRuntimeError("Not a function.");
    }
    return null;
  }
  
  public boolean dispatchEvent(Event event)
  {
    boolean result = super.dispatchEvent(event);
    if (event.getType().equals("submit")) {
      submit();
    }
    return result;
  }
}
