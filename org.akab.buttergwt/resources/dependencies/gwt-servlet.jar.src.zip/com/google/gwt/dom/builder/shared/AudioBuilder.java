package com.google.gwt.dom.builder.shared;

public abstract interface AudioBuilder
  extends MediaBuilder<AudioBuilder>
{}
