package com.google.gwt.dev.asm.commons;

import com.google.gwt.dev.asm.MethodVisitor;
import com.google.gwt.dev.asm.tree.InsnList;
import com.google.gwt.dev.asm.tree.MethodNode;
import com.google.gwt.dev.asm.tree.TryCatchBlockNode;
import java.util.Collections;
import java.util.Comparator;

public class TryCatchBlockSorter
  extends MethodNode
{
  public TryCatchBlockSorter(MethodVisitor mv, int access, String name, String desc, String signature, String[] exceptions)
  {
    this(262144, mv, access, name, desc, signature, exceptions);
  }
  
  protected TryCatchBlockSorter(int api, MethodVisitor mv, int access, String name, String desc, String signature, String[] exceptions)
  {
    super(api, access, name, desc, signature, exceptions);
    this.mv = mv;
  }
  
  public void visitEnd()
  {
    Comparator<TryCatchBlockNode> comp = new Comparator()
    {
      public int compare(TryCatchBlockNode t1, TryCatchBlockNode t2)
      {
        int len1 = blockLength(t1);
        int len2 = blockLength(t2);
        return len1 - len2;
      }
      
      private int blockLength(TryCatchBlockNode block)
      {
        int startidx = TryCatchBlockSorter.this.instructions.indexOf(block.start);
        int endidx = TryCatchBlockSorter.this.instructions.indexOf(block.end);
        return endidx - startidx;
      }
    };
    Collections.sort(this.tryCatchBlocks, comp);
    if (this.mv != null) {
      accept(this.mv);
    }
  }
}
