package com.google.gwt.activity.shared;

import com.google.gwt.event.shared.EventBus;
import com.google.gwt.user.client.ui.AcceptsOneWidget;

public abstract interface Activity
{
  public abstract String mayStop();
  
  public abstract void onCancel();
  
  public abstract void onStop();
  
  public abstract void start(AcceptsOneWidget paramAcceptsOneWidget, EventBus paramEventBus);
}
