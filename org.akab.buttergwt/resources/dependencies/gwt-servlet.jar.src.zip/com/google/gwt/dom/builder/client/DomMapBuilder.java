package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.MapBuilder;
import com.google.gwt.dom.client.MapElement;

public class DomMapBuilder
  extends DomElementBuilderBase<MapBuilder, MapElement>
  implements MapBuilder
{
  DomMapBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public MapBuilder name(String name)
  {
    ((MapElement)assertCanAddAttribute()).setName(name);
    return this;
  }
}
