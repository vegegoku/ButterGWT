package com.google.gwt.core.shared.impl;

import com.google.gwt.core.shared.SerializableThrowable;

public class ThrowableTypeResolver
{
  public static void resolveDesignatedType(SerializableThrowable throwable, Throwable designated)
  {
    throwable.setDesignatedType(designated.getClass().getName(), true);
  }
}
