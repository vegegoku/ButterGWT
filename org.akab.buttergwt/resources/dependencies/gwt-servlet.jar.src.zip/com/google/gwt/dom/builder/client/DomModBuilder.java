package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ModBuilder;
import com.google.gwt.dom.client.ModElement;
import com.google.gwt.safehtml.shared.SafeUri;

public class DomModBuilder
  extends DomElementBuilderBase<ModBuilder, ModElement>
  implements ModBuilder
{
  DomModBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public ModBuilder cite(SafeUri cite)
  {
    ((ModElement)assertCanAddAttribute()).setCite(cite);
    return this;
  }
  
  public ModBuilder cite(String cite)
  {
    ((ModElement)assertCanAddAttribute()).setCite(cite);
    return this;
  }
  
  public ModBuilder dateTime(String dateTime)
  {
    ((ModElement)assertCanAddAttribute()).setDateTime(dateTime);
    return this;
  }
}
