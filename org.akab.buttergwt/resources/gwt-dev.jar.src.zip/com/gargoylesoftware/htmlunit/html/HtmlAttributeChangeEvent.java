package com.gargoylesoftware.htmlunit.html;

import java.util.EventObject;

public class HtmlAttributeChangeEvent
  extends EventObject
{
  private final String name_;
  private final String value_;
  
  public HtmlAttributeChangeEvent(HtmlElement element, String name, String value)
  {
    super(element);
    this.name_ = name;
    this.value_ = value;
  }
  
  public HtmlElement getHtmlElement()
  {
    return (HtmlElement)getSource();
  }
  
  public String getName()
  {
    return this.name_;
  }
  
  public String getValue()
  {
    return this.value_;
  }
}
