package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.HeadingBuilder;
import com.google.gwt.dom.client.HeadingElement;

public class DomHeadingBuilder
  extends DomElementBuilderBase<HeadingBuilder, HeadingElement>
  implements HeadingBuilder
{
  DomHeadingBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
