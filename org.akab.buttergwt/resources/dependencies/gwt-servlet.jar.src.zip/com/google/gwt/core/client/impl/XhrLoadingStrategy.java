package com.google.gwt.core.client.impl;

import com.google.gwt.xhr.client.ReadyStateChangeHandler;
import com.google.gwt.xhr.client.XMLHttpRequest;

public class XhrLoadingStrategy
  extends LoadingStrategyBase
{
  static final String HTTP_GET = "GET";
  static final int HTTP_STATUS_NON_HTTP = 0;
  static final int HTTP_STATUS_OK = 200;
  
  public static class XhrDownloadStrategy
    implements LoadingStrategyBase.DownloadStrategy
  {
    public void tryDownload(final LoadingStrategyBase.RequestData request)
    {
      final XMLHttpRequest xhr = XMLHttpRequest.create();
      
      xhr.open("GET", request.getUrl());
      
      xhr.setOnReadyStateChange(new ReadyStateChangeHandler()
      {
        public void onReadyStateChange(XMLHttpRequest ignored)
        {
          if (xhr.getReadyState() == 4)
          {
            xhr.clearOnReadyStateChange();
            if (((xhr.getStatus() == 200) || (xhr.getStatus() == 0)) && (xhr.getResponseText() != null) && (xhr.getResponseText().length() != 0)) {
              request.tryInstall(xhr.getResponseText());
            } else {
              request.onLoadError(new AsyncFragmentLoader.HttpDownloadFailure(request.getUrl(), xhr.getStatus(), xhr.getStatusText()), true);
            }
          }
        }
      });
      xhr.send();
    }
  }
  
  public XhrLoadingStrategy()
  {
    super(new XhrDownloadStrategy());
  }
}
