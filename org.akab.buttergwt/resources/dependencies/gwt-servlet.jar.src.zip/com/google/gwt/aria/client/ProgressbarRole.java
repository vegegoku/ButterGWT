package com.google.gwt.aria.client;

public abstract interface ProgressbarRole
  extends RangeRole
{}
