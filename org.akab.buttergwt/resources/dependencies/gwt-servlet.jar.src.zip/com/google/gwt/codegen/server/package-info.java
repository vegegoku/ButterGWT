package com.google.gwt.codegen.server;

import com.google.gwt.util.PreventSpuriousRebuilds;

@PreventSpuriousRebuilds
abstract interface package-info {}
