package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class CheckboxRoleImpl
  extends RoleImpl
  implements CheckboxRole
{
  CheckboxRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaCheckedState(Element element)
  {
    return State.CHECKED.get(element);
  }
  
  public void removeAriaCheckedState(Element element)
  {
    State.CHECKED.remove(element);
  }
  
  public void setAriaCheckedState(Element element, CheckedValue value)
  {
    State.CHECKED.set(element, new CheckedValue[] { value });
  }
}
