package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import java.util.Map;
import org.w3c.dom.Node;

public class HtmlNoScript
  extends HtmlElement
{
  public static final String TAG_NAME = "noscript";
  
  HtmlNoScript(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public DomNode appendChild(Node node)
  {
    WebClient webClient = getPage().getWebClient();
    if ((!webClient.getOptions().isJavaScriptEnabled()) || (webClient.getBrowserVersion().hasFeature(BrowserVersionFeatures.NOSCRIPT_BODY_AS_TEXT))) {
      return super.appendChild(node);
    }
    return null;
  }
}
