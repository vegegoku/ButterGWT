package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class ButtonRoleImpl
  extends RoleImpl
  implements ButtonRole
{
  ButtonRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaPressedState(Element element)
  {
    return State.PRESSED.get(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaPressedState(Element element)
  {
    State.PRESSED.remove(element);
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaPressedState(Element element, PressedValue value)
  {
    State.PRESSED.set(element, new PressedValue[] { value });
  }
}
