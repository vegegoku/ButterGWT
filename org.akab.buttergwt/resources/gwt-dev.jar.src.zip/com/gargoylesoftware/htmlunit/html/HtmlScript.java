package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.PostponedAction;
import com.gargoylesoftware.htmlunit.javascript.host.Document;
import com.gargoylesoftware.htmlunit.javascript.host.Event;
import com.gargoylesoftware.htmlunit.javascript.host.EventHandler;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLScriptElement;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.Map;
import net.sourceforge.htmlunit.corejs.javascript.BaseFunction;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class HtmlScript
  extends HtmlElement
{
  private static final Log LOG = LogFactory.getLog(HtmlScript.class);
  public static final String TAG_NAME = "script";
  private static final String SLASH_SLASH_COLON = "//:";
  private boolean executed_;
  
  HtmlScript(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public final String getCharsetAttribute()
  {
    return getAttribute("charset");
  }
  
  public final String getTypeAttribute()
  {
    return getAttribute("type");
  }
  
  public final String getLanguageAttribute()
  {
    return getAttribute("language");
  }
  
  public final String getSrcAttribute()
  {
    return getAttribute("src");
  }
  
  public final String getEventAttribute()
  {
    return getAttribute("event");
  }
  
  public final String getHtmlForAttribute()
  {
    return getAttribute("for");
  }
  
  public final String getDeferAttribute()
  {
    return getAttribute("defer");
  }
  
  protected boolean isDeferred()
  {
    return getDeferAttribute() != ATTRIBUTE_NOT_DEFINED;
  }
  
  public boolean mayBeDisplayed()
  {
    return false;
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    String oldValue = getAttributeNS(namespaceURI, qualifiedName);
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
    if ((namespaceURI == null) && ("src".equals(qualifiedName)) && 
      (isDirectlyAttachedToPage()))
    {
      boolean alwaysReexecute = hasFeature(BrowserVersionFeatures.JS_SCRIPT_ALWAYS_REEXECUTE_ON_SRC_CHANGE);
      if (alwaysReexecute)
      {
        resetExecuted();
        PostponedAction action = new PostponedAction(getPage())
        {
          public void execute()
          {
            HtmlScript.this.executeScriptIfNeeded();
          }
        };
        JavaScriptEngine engine = getPage().getWebClient().getJavaScriptEngine();
        engine.addPostponedAction(action);
      }
      else if ((oldValue.isEmpty()) && (getFirstChild() == null))
      {
        PostponedAction action = new PostponedAction(getPage())
        {
          public void execute()
          {
            HtmlScript.this.executeScriptIfNeeded();
          }
        };
        JavaScriptEngine engine = getPage().getWebClient().getJavaScriptEngine();
        engine.addPostponedAction(action);
      }
    }
  }
  
  protected void onAllChildrenAddedToPage(boolean postponed)
  {
    if ((getOwnerDocument() instanceof XmlPage)) {
      return;
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Script node added: " + asXml());
    }
    PostponedAction action = new PostponedAction(getPage())
    {
      public void execute()
      {
        HTMLDocument jsDoc = (HTMLDocument)((Window)HtmlScript.this.getPage().getEnclosingWindow().getScriptObject()).getDocument();
        
        jsDoc.setExecutingDynamicExternalPosponed((HtmlScript.this.getStartLineNumber() == -1) && (HtmlScript.this.getSrcAttribute() != DomElement.ATTRIBUTE_NOT_DEFINED));
        try
        {
          boolean onReady = HtmlScript.this.hasFeature(BrowserVersionFeatures.JS_SCRIPT_SUPPORTS_ONREADYSTATECHANGE);
          if (onReady)
          {
            if (!HtmlScript.this.isDeferred()) {
              if ("//:".equals(HtmlScript.this.getSrcAttribute()))
              {
                HtmlScript.this.setAndExecuteReadyState("complete");
                HtmlScript.this.executeScriptIfNeeded();
              }
              else
              {
                HtmlScript.this.setAndExecuteReadyState("loading");
                HtmlScript.this.executeScriptIfNeeded();
                HtmlScript.this.setAndExecuteReadyState("loaded");
              }
            }
          }
          else {
            HtmlScript.this.executeScriptIfNeeded();
          }
        }
        finally
        {
          jsDoc.setExecutingDynamicExternalPosponed(false);
        }
      }
    };
    if ((postponed) && (StringUtils.isBlank(getTextContent())))
    {
      JavaScriptEngine engine = getPage().getWebClient().getJavaScriptEngine();
      engine.addPostponedAction(action);
    }
    else
    {
      try
      {
        action.execute();
      }
      catch (RuntimeException e)
      {
        throw e;
      }
      catch (Exception e)
      {
        throw new RuntimeException(e);
      }
    }
  }
  
  private void executeInlineScriptIfNeeded()
  {
    if (!isExecutionNeeded()) {
      return;
    }
    String src = getSrcAttribute();
    if (src != ATTRIBUTE_NOT_DEFINED) {
      return;
    }
    String forr = getHtmlForAttribute();
    String event = getEventAttribute();
    if (event.endsWith("()")) {
      event = event.substring(0, event.length() - 2);
    }
    boolean supportsEventFor = hasFeature(BrowserVersionFeatures.JS_SCRIPT_SUPPORTS_FOR_AND_EVENT);
    String scriptCode = getScriptCode();
    if ((supportsEventFor) && (event != ATTRIBUTE_NOT_DEFINED) && (forr != ATTRIBUTE_NOT_DEFINED))
    {
      if ("window".equals(forr))
      {
        Window window = (Window)getPage().getEnclosingWindow().getScriptObject();
        BaseFunction function = new EventHandler(this, event, scriptCode);
        window.attachEvent(event, function);
      }
      else
      {
        try
        {
          HtmlElement elt = ((HtmlPage)getPage()).getHtmlElementById(forr);
          elt.setEventHandler(event, scriptCode);
        }
        catch (ElementNotFoundException e)
        {
          LOG.warn("<script for='" + forr + "' ...>: no element found with id \"" + forr + "\". Ignoring.");
        }
      }
    }
    else if ((forr == ATTRIBUTE_NOT_DEFINED) || ("onload".equals(event)))
    {
      String url = getPage().getUrl().toExternalForm();
      int line1 = getStartLineNumber();
      int line2 = getEndLineNumber();
      int col1 = getStartColumnNumber();
      int col2 = getEndColumnNumber();
      String desc = "script in " + url + " from (" + line1 + ", " + col1 + ") to (" + line2 + ", " + col2 + ")";
      
      this.executed_ = true;
      ((HtmlPage)getPage()).executeJavaScriptIfPossible(scriptCode, desc, line1);
    }
  }
  
  private String getScriptCode()
  {
    Iterable<DomNode> textNodes = getChildren();
    StringBuilder scriptCode = new StringBuilder();
    for (DomNode node : textNodes) {
      if ((node instanceof DomText))
      {
        DomText domText = (DomText)node;
        scriptCode.append(domText.getData());
      }
    }
    return scriptCode.toString();
  }
  
  public void executeScriptIfNeeded()
  {
    if (!isExecutionNeeded()) {
      return;
    }
    HtmlPage page = (HtmlPage)getPage();
    BrowserVersion browser = page.getWebClient().getBrowserVersion();
    
    String src = getSrcAttribute();
    if (src.equals("//:")) {
      return;
    }
    if (src != ATTRIBUTE_NOT_DEFINED)
    {
      if (src.startsWith("javascript:"))
      {
        if (browser.hasFeature(BrowserVersionFeatures.HTMLSCRIPT_SRC_JAVASCRIPT))
        {
          String code = StringUtils.removeStart(src, "javascript:").trim();
          int len = code.length();
          if ((len > 2) && (
            ((code.charAt(0) == '\'') && (code.charAt(len - 1) == '\'')) || ((code.charAt(0) == '"') && (code.charAt(len - 1) == '"'))))
          {
            code = code.substring(1, len - 1);
            if (LOG.isDebugEnabled()) {
              LOG.debug("Executing JavaScript: " + code);
            }
            page.executeJavaScriptIfPossible(code, code, getStartLineNumber());
          }
        }
      }
      else
      {
        if (LOG.isDebugEnabled()) {
          LOG.debug("Loading external JavaScript: " + src);
        }
        try
        {
          this.executed_ = true;
          HtmlPage.JavaScriptLoadResult result = page.loadExternalJavaScriptFile(src, getCharsetAttribute());
          if (result == HtmlPage.JavaScriptLoadResult.SUCCESS) {
            executeEventIfBrowserHasFeature("load", BrowserVersionFeatures.EVENT_ONLOAD_EXTERNAL_JAVASCRIPT);
          } else if (result == HtmlPage.JavaScriptLoadResult.DOWNLOAD_ERROR) {
            executeEventIfBrowserHasFeature("error", BrowserVersionFeatures.EVENT_ONERROR_EXTERNAL_JAVASCRIPT);
          }
        }
        catch (FailingHttpStatusCodeException e)
        {
          executeEventIfBrowserHasFeature("error", BrowserVersionFeatures.EVENT_ONERROR_EXTERNAL_JAVASCRIPT);
          throw e;
        }
      }
    }
    else if (getFirstChild() != null) {
      executeInlineScriptIfNeeded();
    }
  }
  
  private void executeEventIfBrowserHasFeature(String type, BrowserVersionFeatures feature)
  {
    if (hasFeature(feature))
    {
      HTMLScriptElement script = (HTMLScriptElement)getScriptObject();
      Event event = new Event(this, type);
      script.executeEvent(event);
    }
  }
  
  private boolean isExecutionNeeded()
  {
    if (this.executed_) {
      return false;
    }
    if (!isDirectlyAttachedToPage()) {
      return false;
    }
    SgmlPage page = getPage();
    if (!page.getWebClient().getOptions().isJavaScriptEnabled()) {
      return false;
    }
    HtmlPage htmlPage = getHtmlPageOrNull();
    if ((htmlPage != null) && (htmlPage.isParsingHtmlSnippet())) {
      return false;
    }
    for (DomNode o = this; o != null; o = o.getParentNode()) {
      if (((o instanceof HtmlInlineFrame)) || ((o instanceof HtmlNoFrames))) {
        return false;
      }
    }
    if ((page.getEnclosingWindow() != null) && (page.getEnclosingWindow().getEnclosedPage() != page)) {
      return false;
    }
    if (!isJavaScript(getTypeAttribute(), getLanguageAttribute()))
    {
      String t = getTypeAttribute();
      String l = getLanguageAttribute();
      LOG.warn("Script is not JavaScript (type: " + t + ", language: " + l + "). Skipping execution.");
      return false;
    }
    DomNode root = this;
    while (root.getParentNode() != null) {
      root = root.getParentNode();
    }
    if (root != getPage()) {
      return false;
    }
    return true;
  }
  
  boolean isJavaScript(String typeAttribute, String languageAttribute)
  {
    BrowserVersion browserVersion = getPage().getWebClient().getBrowserVersion();
    if (browserVersion.hasFeature(BrowserVersionFeatures.HTMLSCRIPT_TRIM_TYPE)) {
      typeAttribute = typeAttribute.trim();
    }
    if (StringUtils.isNotEmpty(typeAttribute))
    {
      if (("text/javascript".equalsIgnoreCase(typeAttribute)) || ("text/ecmascript".equalsIgnoreCase(typeAttribute))) {
        return true;
      }
      boolean appJavascriptSupported = browserVersion.hasFeature(BrowserVersionFeatures.HTMLSCRIPT_APPLICATION_JAVASCRIPT);
      if ((appJavascriptSupported) && (("application/javascript".equalsIgnoreCase(typeAttribute)) || ("application/ecmascript".equalsIgnoreCase(typeAttribute)) || ("application/x-javascript".equalsIgnoreCase(typeAttribute)))) {
        return true;
      }
      return false;
    }
    if (StringUtils.isNotEmpty(languageAttribute)) {
      return StringUtils.startsWithIgnoreCase(languageAttribute, "javascript");
    }
    return true;
  }
  
  protected void setAndExecuteReadyState(String state)
  {
    if (hasFeature(BrowserVersionFeatures.EVENT_ONREADY_STATE_CHANGE))
    {
      setReadyState(state);
      HTMLScriptElement script = (HTMLScriptElement)getScriptObject();
      Event event = new Event(this, "readystatechange");
      script.executeEvent(event);
    }
  }
  
  public String asText()
  {
    return "";
  }
  
  protected boolean isEmptyXmlTagExpanded()
  {
    return true;
  }
  
  protected void printChildrenAsXml(String indent, PrintWriter printWriter)
  {
    DomCharacterData textNode = (DomCharacterData)getFirstChild();
    if (textNode == null) {
      return;
    }
    String data = textNode.getData();
    if (data.contains("//<![CDATA["))
    {
      printWriter.println(data);
    }
    else
    {
      printWriter.println("//<![CDATA[");
      printWriter.println(data);
      printWriter.println("//]]>");
    }
  }
  
  public void resetExecuted()
  {
    this.executed_ = false;
  }
  
  public void processImportNode(Document doc)
  {
    super.processImportNode(doc);
    
    this.executed_ = true;
  }
  
  public String toString()
  {
    StringWriter writer = new StringWriter();
    PrintWriter printWriter = new PrintWriter(writer);
    
    printWriter.print(ClassUtils.getShortClassName(getClass()));
    printWriter.print("[<");
    printOpeningTagContentAsXml(printWriter);
    printWriter.print(">");
    printWriter.print(getScriptCode());
    printWriter.print("]");
    printWriter.flush();
    return writer.toString();
  }
}
