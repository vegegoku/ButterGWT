package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlObject;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.ActiveXObjectImpl;
import com.gargoylesoftware.htmlunit.javascript.host.FormChild;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass(domClasses={HtmlObject.class})
public class HTMLObjectElement
  extends FormChild
{
  private SimpleScriptable wrappedActiveX_;
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getAlt()
  {
    String alt = getDomNodeOrDie().getAttribute("alt");
    return alt;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setAlt(String alt)
  {
    getDomNodeOrDie().setAttribute("alt", alt);
  }
  
  @JsxGetter
  public String getBorder()
  {
    String border = getDomNodeOrDie().getAttribute("border");
    return border;
  }
  
  @JsxSetter
  public void setBorder(String border)
  {
    getDomNodeOrDie().setAttribute("border", border);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getClassid()
  {
    String classid = getDomNodeOrDie().getAttribute("classid");
    return classid;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setClassid(String classid)
  {
    getDomNodeOrDie().setAttribute("classid", classid);
    if ((classid.indexOf(':') != -1) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_86)) && (getWindow().getWebWindow().getWebClient().getOptions().isActiveXNative()) && (System.getProperty("os.name").contains("Windows"))) {
      try
      {
        this.wrappedActiveX_ = new ActiveXObjectImpl(classid);
        this.wrappedActiveX_.setParentScope(getParentScope());
      }
      catch (Exception e)
      {
        Context.throwAsScriptRuntimeEx(e);
      }
    }
  }
  
  public Object get(String name, Scriptable start)
  {
    if (this.wrappedActiveX_ != null) {
      return this.wrappedActiveX_.get(name, start);
    }
    return super.get(name, start);
  }
  
  public void put(String name, Scriptable start, Object value)
  {
    if (this.wrappedActiveX_ != null) {
      this.wrappedActiveX_.put(name, start, value);
    } else {
      super.put(name, start, value);
    }
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
