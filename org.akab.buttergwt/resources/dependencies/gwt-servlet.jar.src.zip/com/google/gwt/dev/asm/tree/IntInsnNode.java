package com.google.gwt.dev.asm.tree;

import com.google.gwt.dev.asm.MethodVisitor;
import java.util.Map;

public class IntInsnNode
  extends AbstractInsnNode
{
  public int operand;
  
  public IntInsnNode(int opcode, int operand)
  {
    super(opcode);
    this.operand = operand;
  }
  
  public void setOpcode(int opcode)
  {
    this.opcode = opcode;
  }
  
  public int getType()
  {
    return 1;
  }
  
  public void accept(MethodVisitor mv)
  {
    mv.visitIntInsn(this.opcode, this.operand);
  }
  
  public AbstractInsnNode clone(Map<LabelNode, LabelNode> labels)
  {
    return new IntInsnNode(this.opcode, this.operand);
  }
}
