package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ElementBuilderBase;
import com.google.gwt.dom.builder.shared.ElementBuilderImpl;
import com.google.gwt.dom.builder.shared.InputBuilder;
import com.google.gwt.dom.builder.shared.StylesBuilder;
import com.google.gwt.dom.client.ButtonElement;
import com.google.gwt.dom.client.Document;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.InputElement;
import com.google.gwt.dom.client.QuoteElement;
import com.google.gwt.dom.client.Style;
import com.google.gwt.dom.client.TableSectionElement;
import com.google.gwt.safehtml.shared.SafeHtml;

class DomBuilderImpl
  extends ElementBuilderImpl
{
  private DomAnchorBuilder anchorBuilder;
  private DomAreaBuilder areaBuilder;
  private DomAudioBuilder audioBuilder;
  private DomBaseBuilder baseBuilder;
  private DomBodyBuilder bodyBuilder;
  private DomBRBuilder brBuilder;
  private DomButtonBuilder buttonBuilder;
  private DomCanvasBuilder canvasBuilder;
  private final DomDivBuilder divBuilder = new DomDivBuilder(this);
  private DomDListBuilder dListBuilder;
  private final DomElementBuilder elementBuilder = new DomElementBuilder(this);
  private DomFieldSetBuilder fieldSetBuilder;
  private DomFormBuilder formBuilder;
  private DomFrameBuilder frameBuilder;
  private DomFrameSetBuilder frameSetBuilder;
  private DomHeadBuilder headBuilder;
  private DomHeadingBuilder headingBuilder;
  private DomHRBuilder hrBuilder;
  private DomIFrameBuilder iFrameBuilder;
  private DomImageBuilder imageBuilder;
  private final DomInputBuilder inputBuilder = new DomInputBuilder(this);
  private DomLabelBuilder labelBuilder;
  private DomLegendBuilder legendBuilder;
  private final DomLIBuilder liBuilder = new DomLIBuilder(this);
  private DomLinkBuilder linkBuilder;
  private DomMapBuilder mapBuilder;
  private DomMetaBuilder metaBuilder;
  private DomOListBuilder oListBuilder;
  private final DomOptionBuilder optionBuilder = new DomOptionBuilder(this);
  private DomOptGroupBuilder optGroupBuilder;
  private DomParagraphBuilder paragraphBuilder;
  private DomParamBuilder paramBuilder;
  private DomPreBuilder preBuilder;
  private DomQuoteBuilder quoteBuilder;
  private DomScriptBuilder scriptBuilder;
  private DomSelectBuilder selectBuilder;
  private DomSourceBuilder sourceBuilder;
  private final DomSpanBuilder spanBuilder = new DomSpanBuilder(this);
  private final StylesBuilder stylesBuilder = new DomStylesBuilder(this);
  private DomStyleBuilder styleBuilder;
  private DomTableBuilder tableBuilder;
  private final DomTableCellBuilder tableCellBuilder = new DomTableCellBuilder(this);
  private DomTableCaptionBuilder tableCaptionBuilder;
  private DomTableColBuilder tableColBuilder;
  private DomTableColBuilder tableColGroupBuilder;
  private final DomTableRowBuilder tableRowBuilder = new DomTableRowBuilder(this);
  private DomTableSectionBuilder tableSectionBuilder;
  private DomTextAreaBuilder textAreaBuilder;
  private DomUListBuilder uListBuilder;
  private DomVideoBuilder videoBuilder;
  private Element rootElement;
  private Element currentElement;
  
  public DomAnchorBuilder startAnchor()
  {
    if (this.anchorBuilder == null) {
      this.anchorBuilder = new DomAnchorBuilder(this);
    }
    start(Document.get().createAnchorElement(), this.anchorBuilder);
    return this.anchorBuilder;
  }
  
  public DomAreaBuilder startArea()
  {
    if (this.areaBuilder == null) {
      this.areaBuilder = new DomAreaBuilder(this);
    }
    start(Document.get().createAreaElement(), this.areaBuilder);
    return this.areaBuilder;
  }
  
  public DomAudioBuilder startAudio()
  {
    if (this.audioBuilder == null) {
      this.audioBuilder = new DomAudioBuilder(this);
    }
    start(Document.get().createAudioElement(), this.audioBuilder);
    return this.audioBuilder;
  }
  
  public DomBaseBuilder startBase()
  {
    if (this.baseBuilder == null) {
      this.baseBuilder = new DomBaseBuilder(this);
    }
    start(Document.get().createBaseElement(), this.baseBuilder);
    return this.baseBuilder;
  }
  
  public DomQuoteBuilder startBlockQuote()
  {
    return startQuote(Document.get().createBlockQuoteElement());
  }
  
  public DomBodyBuilder startBody()
  {
    if (this.bodyBuilder == null) {
      this.bodyBuilder = new DomBodyBuilder(this);
    }
    start(Document.get().createElement("body"), this.bodyBuilder);
    return this.bodyBuilder;
  }
  
  public DomBRBuilder startBR()
  {
    if (this.brBuilder == null) {
      this.brBuilder = new DomBRBuilder(this);
    }
    start(Document.get().createBRElement(), this.brBuilder);
    return this.brBuilder;
  }
  
  public InputBuilder startButtonInput()
  {
    return startInput(Document.get().createButtonInputElement());
  }
  
  public DomCanvasBuilder startCanvas()
  {
    if (this.canvasBuilder == null) {
      this.canvasBuilder = new DomCanvasBuilder(this);
    }
    start(Document.get().createCanvasElement(), this.canvasBuilder);
    return this.canvasBuilder;
  }
  
  public InputBuilder startCheckboxInput()
  {
    return startInput(Document.get().createCheckInputElement());
  }
  
  public DomTableColBuilder startCol()
  {
    if (this.tableColBuilder == null) {
      this.tableColBuilder = new DomTableColBuilder(this, false);
    }
    start(Document.get().createColElement(), this.tableColBuilder);
    return this.tableColBuilder;
  }
  
  public DomTableColBuilder startColGroup()
  {
    if (this.tableColGroupBuilder == null) {
      this.tableColGroupBuilder = new DomTableColBuilder(this, true);
    }
    start(Document.get().createColGroupElement(), this.tableColGroupBuilder);
    return this.tableColGroupBuilder;
  }
  
  public DomDivBuilder startDiv()
  {
    start(Document.get().createDivElement(), this.divBuilder);
    return this.divBuilder;
  }
  
  public DomDListBuilder startDList()
  {
    if (this.dListBuilder == null) {
      this.dListBuilder = new DomDListBuilder(this);
    }
    start(Document.get().createDLElement(), this.dListBuilder);
    return this.dListBuilder;
  }
  
  public DomFieldSetBuilder startFieldSet()
  {
    if (this.fieldSetBuilder == null) {
      this.fieldSetBuilder = new DomFieldSetBuilder(this);
    }
    start(Document.get().createFieldSetElement(), this.fieldSetBuilder);
    return this.fieldSetBuilder;
  }
  
  public InputBuilder startFileInput()
  {
    return startInput(Document.get().createFileInputElement());
  }
  
  public DomFormBuilder startForm()
  {
    if (this.formBuilder == null) {
      this.formBuilder = new DomFormBuilder(this);
    }
    start(Document.get().createFormElement(), this.formBuilder);
    return this.formBuilder;
  }
  
  public DomFrameBuilder startFrame()
  {
    if (this.frameBuilder == null) {
      this.frameBuilder = new DomFrameBuilder(this);
    }
    start(Document.get().createFrameElement(), this.frameBuilder);
    return this.frameBuilder;
  }
  
  public DomFrameSetBuilder startFrameSet()
  {
    if (this.frameSetBuilder == null) {
      this.frameSetBuilder = new DomFrameSetBuilder(this);
    }
    start(Document.get().createFrameSetElement(), this.frameSetBuilder);
    return this.frameSetBuilder;
  }
  
  public DomHeadingBuilder startH1()
  {
    return startHeading(1);
  }
  
  public DomHeadingBuilder startH2()
  {
    return startHeading(2);
  }
  
  public DomHeadingBuilder startH3()
  {
    return startHeading(3);
  }
  
  public DomHeadingBuilder startH4()
  {
    return startHeading(4);
  }
  
  public DomHeadingBuilder startH5()
  {
    return startHeading(5);
  }
  
  public DomHeadingBuilder startH6()
  {
    return startHeading(6);
  }
  
  public DomHeadBuilder startHead()
  {
    if (this.headBuilder == null) {
      this.headBuilder = new DomHeadBuilder(this);
    }
    start(Document.get().createHeadElement(), this.headBuilder);
    return this.headBuilder;
  }
  
  public InputBuilder startHiddenInput()
  {
    return startInput(Document.get().createHiddenInputElement());
  }
  
  public DomHRBuilder startHR()
  {
    if (this.hrBuilder == null) {
      this.hrBuilder = new DomHRBuilder(this);
    }
    start(Document.get().createHRElement(), this.hrBuilder);
    return this.hrBuilder;
  }
  
  public DomIFrameBuilder startIFrame()
  {
    if (this.iFrameBuilder == null) {
      this.iFrameBuilder = new DomIFrameBuilder(this);
    }
    start(Document.get().createIFrameElement(), this.iFrameBuilder);
    return this.iFrameBuilder;
  }
  
  public DomImageBuilder startImage()
  {
    if (this.imageBuilder == null) {
      this.imageBuilder = new DomImageBuilder(this);
    }
    start(Document.get().createImageElement(), this.imageBuilder);
    return this.imageBuilder;
  }
  
  public InputBuilder startImageInput()
  {
    return startInput(Document.get().createImageInputElement());
  }
  
  public DomInputBuilder startInput(InputElement input)
  {
    start(input, this.inputBuilder);
    return this.inputBuilder;
  }
  
  public DomLabelBuilder startLabel()
  {
    if (this.labelBuilder == null) {
      this.labelBuilder = new DomLabelBuilder(this);
    }
    start(Document.get().createLabelElement(), this.labelBuilder);
    return this.labelBuilder;
  }
  
  public DomLegendBuilder startLegend()
  {
    if (this.legendBuilder == null) {
      this.legendBuilder = new DomLegendBuilder(this);
    }
    start(Document.get().createLegendElement(), this.legendBuilder);
    return this.legendBuilder;
  }
  
  public DomLIBuilder startLI()
  {
    start(Document.get().createLIElement(), this.liBuilder);
    return this.liBuilder;
  }
  
  public DomLinkBuilder startLink()
  {
    if (this.linkBuilder == null) {
      this.linkBuilder = new DomLinkBuilder(this);
    }
    start(Document.get().createLinkElement(), this.linkBuilder);
    return this.linkBuilder;
  }
  
  public DomMapBuilder startMap()
  {
    if (this.mapBuilder == null) {
      this.mapBuilder = new DomMapBuilder(this);
    }
    start(Document.get().createMapElement(), this.mapBuilder);
    return this.mapBuilder;
  }
  
  public DomMetaBuilder startMeta()
  {
    if (this.metaBuilder == null) {
      this.metaBuilder = new DomMetaBuilder(this);
    }
    start(Document.get().createMetaElement(), this.metaBuilder);
    return this.metaBuilder;
  }
  
  public DomOListBuilder startOList()
  {
    if (this.oListBuilder == null) {
      this.oListBuilder = new DomOListBuilder(this);
    }
    start(Document.get().createOLElement(), this.oListBuilder);
    return this.oListBuilder;
  }
  
  public DomOptGroupBuilder startOptGroup()
  {
    if (this.optGroupBuilder == null) {
      this.optGroupBuilder = new DomOptGroupBuilder(this);
    }
    start(Document.get().createOptGroupElement(), this.optGroupBuilder);
    return this.optGroupBuilder;
  }
  
  public DomOptionBuilder startOption()
  {
    start(Document.get().createOptionElement(), this.optionBuilder);
    return this.optionBuilder;
  }
  
  public DomParagraphBuilder startParagraph()
  {
    if (this.paragraphBuilder == null) {
      this.paragraphBuilder = new DomParagraphBuilder(this);
    }
    start(Document.get().createPElement(), this.paragraphBuilder);
    return this.paragraphBuilder;
  }
  
  public DomParamBuilder startParam()
  {
    if (this.paramBuilder == null) {
      this.paramBuilder = new DomParamBuilder(this);
    }
    start(Document.get().createParamElement(), this.paramBuilder);
    return this.paramBuilder;
  }
  
  public InputBuilder startPasswordInput()
  {
    return startInput(Document.get().createPasswordInputElement());
  }
  
  public DomPreBuilder startPre()
  {
    if (this.preBuilder == null) {
      this.preBuilder = new DomPreBuilder(this);
    }
    start(Document.get().createPreElement(), this.preBuilder);
    return this.preBuilder;
  }
  
  public DomButtonBuilder startPushButton()
  {
    return startButton(Document.get().createPushButtonElement());
  }
  
  public DomQuoteBuilder startQuote()
  {
    return startQuote(Document.get().createQElement());
  }
  
  public InputBuilder startRadioInput(String name)
  {
    return startInput(Document.get().createRadioInputElement(name));
  }
  
  public DomButtonBuilder startResetButton()
  {
    return startButton(Document.get().createResetButtonElement());
  }
  
  public InputBuilder startResetInput()
  {
    return startInput(Document.get().createSubmitInputElement());
  }
  
  public DomScriptBuilder startScript()
  {
    if (this.scriptBuilder == null) {
      this.scriptBuilder = new DomScriptBuilder(this);
    }
    start(Document.get().createScriptElement(), this.scriptBuilder);
    return this.scriptBuilder;
  }
  
  public DomSelectBuilder startSelect()
  {
    if (this.selectBuilder == null) {
      this.selectBuilder = new DomSelectBuilder(this);
    }
    start(Document.get().createSelectElement(), this.selectBuilder);
    return this.selectBuilder;
  }
  
  public DomSourceBuilder startSource()
  {
    if (this.sourceBuilder == null) {
      this.sourceBuilder = new DomSourceBuilder(this);
    }
    start(Document.get().createSourceElement(), this.sourceBuilder);
    return this.sourceBuilder;
  }
  
  public DomSpanBuilder startSpan()
  {
    start(Document.get().createSpanElement(), this.spanBuilder);
    return this.spanBuilder;
  }
  
  public DomStyleBuilder startStyle()
  {
    if (this.styleBuilder == null) {
      this.styleBuilder = new DomStyleBuilder(this);
    }
    start(Document.get().createStyleElement(), this.styleBuilder);
    return this.styleBuilder;
  }
  
  public DomButtonBuilder startSubmitButton()
  {
    return startButton(Document.get().createSubmitButtonElement());
  }
  
  public InputBuilder startSubmitInput()
  {
    return startInput(Document.get().createSubmitInputElement());
  }
  
  public DomTableBuilder startTable()
  {
    if (this.tableBuilder == null) {
      this.tableBuilder = new DomTableBuilder(this);
    }
    start(Document.get().createTableElement(), this.tableBuilder);
    return this.tableBuilder;
  }
  
  public DomTableCaptionBuilder startTableCaption()
  {
    if (this.tableCaptionBuilder == null) {
      this.tableCaptionBuilder = new DomTableCaptionBuilder(this);
    }
    start(Document.get().createCaptionElement(), this.tableCaptionBuilder);
    return this.tableCaptionBuilder;
  }
  
  public DomTableSectionBuilder startTBody()
  {
    return startTableSection(Document.get().createTBodyElement());
  }
  
  public DomTableCellBuilder startTD()
  {
    start(Document.get().createTDElement(), this.tableCellBuilder);
    return this.tableCellBuilder;
  }
  
  public DomTextAreaBuilder startTextArea()
  {
    if (this.textAreaBuilder == null) {
      this.textAreaBuilder = new DomTextAreaBuilder(this);
    }
    start(Document.get().createTextAreaElement(), this.textAreaBuilder);
    return this.textAreaBuilder;
  }
  
  public DomTableSectionBuilder startTFoot()
  {
    return startTableSection(Document.get().createTFootElement());
  }
  
  public DomTableCellBuilder startTH()
  {
    start(Document.get().createTHElement(), this.tableCellBuilder);
    return this.tableCellBuilder;
  }
  
  public DomTableSectionBuilder startTHead()
  {
    return startTableSection(Document.get().createTHeadElement());
  }
  
  public DomTableRowBuilder startTR()
  {
    start(Document.get().createTRElement(), this.tableRowBuilder);
    return this.tableRowBuilder;
  }
  
  public DomUListBuilder startUList()
  {
    if (this.uListBuilder == null) {
      this.uListBuilder = new DomUListBuilder(this);
    }
    start(Document.get().createULElement(), this.uListBuilder);
    return this.uListBuilder;
  }
  
  public DomVideoBuilder startVideo()
  {
    if (this.videoBuilder == null) {
      this.videoBuilder = new DomVideoBuilder(this);
    }
    start(Document.get().createVideoElement(), this.videoBuilder);
    return this.videoBuilder;
  }
  
  public StylesBuilder style()
  {
    return this.stylesBuilder;
  }
  
  public DomElementBuilder trustedStart(String tagName)
  {
    assertValidTagName(tagName);
    start(Document.get().createElement(tagName), this.elementBuilder);
    return this.elementBuilder;
  }
  
  protected void doCloseStartTagImpl() {}
  
  protected void doCloseStyleAttributeImpl() {}
  
  protected void doEndStartTagImpl()
  {
    popElement();
  }
  
  protected void doEndTagImpl(String tagName)
  {
    popElement();
  }
  
  protected Element doFinishImpl()
  {
    return this.rootElement;
  }
  
  protected void doHtmlImpl(SafeHtml html)
  {
    getCurrentElement().setInnerSafeHtml(html);
  }
  
  protected void doOpenStyleImpl() {}
  
  protected void doTextImpl(String text)
  {
    getCurrentElement().setInnerText(text);
  }
  
  protected void lockCurrentElement()
  {
    super.lockCurrentElement();
  }
  
  Element assertCanAddAttribute()
  {
    assertCanAddAttributeImpl();
    return getCurrentElement();
  }
  
  Style assertCanAddStyleProperty()
  {
    assertCanAddStylePropertyImpl();
    return getCurrentElement().getStyle();
  }
  
  Element getCurrentElement()
  {
    if (this.currentElement == null) {
      throw new IllegalStateException("There are no elements on the stack.");
    }
    return this.currentElement;
  }
  
  InputBuilder startTextInput()
  {
    return startInput(Document.get().createTextInputElement());
  }
  
  private void popElement()
  {
    this.currentElement = getCurrentElement().getParentElement();
  }
  
  private void start(Element element, ElementBuilderBase<?> builder)
  {
    onStart(element.getTagName(), builder);
    if (this.rootElement == null) {
      this.rootElement = element;
    } else {
      getCurrentElement().appendChild(element);
    }
    this.currentElement = element;
  }
  
  private DomButtonBuilder startButton(ButtonElement button)
  {
    if (this.buttonBuilder == null) {
      this.buttonBuilder = new DomButtonBuilder(this);
    }
    start(button, this.buttonBuilder);
    return this.buttonBuilder;
  }
  
  private DomHeadingBuilder startHeading(int level)
  {
    if (this.headingBuilder == null) {
      this.headingBuilder = new DomHeadingBuilder(this);
    }
    start(Document.get().createHElement(level), this.headingBuilder);
    return this.headingBuilder;
  }
  
  private DomQuoteBuilder startQuote(QuoteElement quote)
  {
    if (this.quoteBuilder == null) {
      this.quoteBuilder = new DomQuoteBuilder(this);
    }
    start(quote, this.quoteBuilder);
    return this.quoteBuilder;
  }
  
  private DomTableSectionBuilder startTableSection(TableSectionElement section)
  {
    if (this.tableSectionBuilder == null) {
      this.tableSectionBuilder = new DomTableSectionBuilder(this);
    }
    start(section, this.tableSectionBuilder);
    return this.tableSectionBuilder;
  }
}
