package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.DListBuilder;
import com.google.gwt.dom.client.DListElement;

public class DomDListBuilder
  extends DomElementBuilderBase<DListBuilder, DListElement>
  implements DListBuilder
{
  DomDListBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
