package com.google.gwt.dev.asm.util;

import com.google.gwt.dev.asm.Label;
import java.util.Map;

public abstract interface ASMifiable
{
  public abstract void asmify(StringBuffer paramStringBuffer, String paramString, Map<Label, String> paramMap);
}
