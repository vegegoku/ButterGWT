package com.google.gwt.core.client;

public class JsArray<T extends JavaScriptObject>
  extends JavaScriptObject
{
  public final native T get(int paramInt);
  
  public final String join()
  {
    return join(",");
  }
  
  public final native String join(String paramString);
  
  public final native int length();
  
  public final native void push(T paramT);
  
  public final native void set(int paramInt, T paramT);
  
  public final native void setLength(int paramInt);
  
  public final native T shift();
  
  public final native void unshift(T paramT);
}
