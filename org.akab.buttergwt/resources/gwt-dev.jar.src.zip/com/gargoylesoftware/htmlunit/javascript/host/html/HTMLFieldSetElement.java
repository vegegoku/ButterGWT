package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlFieldSet;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.FormChild;

@JsxClass(domClasses={HtmlFieldSet.class})
public class HTMLFieldSetElement
  extends FormChild
{
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getAlign()
  {
    return getAlign(false);
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setAlign(String align)
  {
    setAlign(align, false);
  }
  
  public Object getWithFallback(String name)
  {
    if ("align".equals(name)) {
      return NOT_FOUND;
    }
    return super.getWithFallback(name);
  }
}
