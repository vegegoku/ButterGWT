package com.gargoylesoftware.htmlunit.javascript.background;

import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.HtmlPage;

class JavaScriptStringJob
  extends JavaScriptExecutionJob
{
  private final String script_;
  
  public JavaScriptStringJob(int initialDelay, Integer period, String label, WebWindow window, String script)
  {
    super(initialDelay, period, label, window);
    this.script_ = script;
  }
  
  protected void runJavaScript(HtmlPage page)
  {
    if (this.script_ == null) {
      return;
    }
    page.executeJavaScriptIfPossible(this.script_, "JavaScriptStringJob", 1);
  }
}
