package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.JavaScriptObject;

public class LoadingStrategyBase
  implements AsyncFragmentLoader.LoadingStrategy
{
  protected static native void gwtInstallCode(String paramString);
  
  protected static native String gwtStartLoadingFragment(int paramInt, AsyncFragmentLoader.LoadTerminatedHandler paramLoadTerminatedHandler);
  
  protected static abstract interface DownloadStrategy
  {
    public abstract void tryDownload(LoadingStrategyBase.RequestData paramRequestData);
  }
  
  private static final class FragmentReloadTracker
    extends JavaScriptObject
  {
    public static FragmentReloadTracker create()
    {
      return (FragmentReloadTracker)JavaScriptObject.createArray();
    }
    
    public native int get(int paramInt);
    
    public native void put(int paramInt1, int paramInt2);
  }
  
  protected static class RequestData
  {
    private static final int MAX_LOG_LENGTH = 200;
    private LoadingStrategyBase.DownloadStrategy downloadStrategy;
    private AsyncFragmentLoader.LoadTerminatedHandler errorHandler = null;
    private int fragment;
    private int maxRetryCount;
    private String originalUrl;
    private int retryCount;
    private String url;
    
    public RequestData(String url, AsyncFragmentLoader.LoadTerminatedHandler errorHandler, int fragment, LoadingStrategyBase.DownloadStrategy downloadStrategy, int maxRetryCount)
    {
      this.url = url;
      this.originalUrl = url;
      this.errorHandler = errorHandler;
      this.maxRetryCount = maxRetryCount;
      this.retryCount = 0;
      this.fragment = fragment;
      this.downloadStrategy = downloadStrategy;
    }
    
    public AsyncFragmentLoader.LoadTerminatedHandler getErrorHandler()
    {
      return this.errorHandler;
    }
    
    public int getFragment()
    {
      return this.fragment;
    }
    
    public int getRetryCount()
    {
      return this.retryCount;
    }
    
    public String getUrl()
    {
      return this.url;
    }
    
    public void onLoadError(Throwable e, boolean mayRetry)
    {
      if (mayRetry)
      {
        this.retryCount += 1;
        if (this.retryCount <= this.maxRetryCount)
        {
          char connector = this.originalUrl.contains("?") ? '&' : '?';
          this.url = (this.originalUrl + connector + "autoRetry=" + this.retryCount);
          this.downloadStrategy.tryDownload(this);
          return;
        }
      }
      this.errorHandler.loadTerminated(e);
    }
    
    public void tryDownload()
    {
      this.downloadStrategy.tryDownload(this);
    }
    
    public void tryInstall(String code)
    {
      try
      {
        LoadingStrategyBase.gwtInstallCode(code);
      }
      catch (RuntimeException e)
      {
        String textIntro = code;
        if ((textIntro != null) && (textIntro.length() > 200)) {
          textIntro = textIntro.substring(0, 200) + "...";
        }
        onLoadError(new AsyncFragmentLoader.HttpInstallFailure(this.url, textIntro, e), false);
      }
    }
  }
  
  public static int MAX_AUTO_RETRY_COUNT = 3;
  private DownloadStrategy downloadStrategy;
  private final FragmentReloadTracker manualRetryNumbers = FragmentReloadTracker.create();
  
  public LoadingStrategyBase(DownloadStrategy downloadStrategy)
  {
    this.downloadStrategy = downloadStrategy;
  }
  
  public void startLoadingFragment(int fragment, AsyncFragmentLoader.LoadTerminatedHandler loadErrorHandler)
  {
    String url = gwtStartLoadingFragment(fragment, loadErrorHandler);
    if (url == null) {
      return;
    }
    int manualRetry = getManualRetryNum(fragment);
    if (manualRetry > 0)
    {
      char connector = url.contains("?") ? '&' : '?';
      url = url + connector + "manualRetry=" + manualRetry;
    }
    RequestData request = new RequestData(url, loadErrorHandler, fragment, this.downloadStrategy, getMaxAutoRetryCount());
    
    request.tryDownload();
  }
  
  protected int getMaxAutoRetryCount()
  {
    return MAX_AUTO_RETRY_COUNT;
  }
  
  private int getManualRetryNum(int fragment)
  {
    int ser = this.manualRetryNumbers.get(fragment);
    this.manualRetryNumbers.put(fragment, ser + 1);
    return ser;
  }
}
