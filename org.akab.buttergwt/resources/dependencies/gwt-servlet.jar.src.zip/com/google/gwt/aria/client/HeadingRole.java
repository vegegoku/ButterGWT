package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface HeadingRole
  extends SectionheadRole
{
  public abstract String getAriaLevelProperty(Element paramElement);
  
  public abstract void removeAriaLevelProperty(Element paramElement);
  
  public abstract void setAriaLevelProperty(Element paramElement, int paramInt);
}
