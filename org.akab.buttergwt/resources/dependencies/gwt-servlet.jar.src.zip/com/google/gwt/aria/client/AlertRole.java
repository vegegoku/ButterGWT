package com.google.gwt.aria.client;

public abstract interface AlertRole
  extends RegionRole
{}
