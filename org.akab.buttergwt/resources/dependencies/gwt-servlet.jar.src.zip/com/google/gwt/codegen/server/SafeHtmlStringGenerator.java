package com.google.gwt.codegen.server;

import com.google.gwt.safehtml.shared.SafeHtmlBuilder;

class SafeHtmlStringGenerator
  extends StringGenerator
{
  private static final String SAFE_HTML_BUILDER_FQCN = SafeHtmlBuilder.class.getCanonicalName();
  
  SafeHtmlStringGenerator(StringBuilder buf)
  {
    super(buf);
    buf.append("new " + SAFE_HTML_BUILDER_FQCN + "()");
  }
  
  protected void afterExpression(StringGenerator.Type type)
  {
    this.buf.append(')');
  }
  
  protected void beforeExpression(StringGenerator.Type type)
  {
    switch (type)
    {
    case LITERAL: 
      this.buf.append(".appendHtmlConstant(");
      break;
    case PRIMITIVE: 
    case SAFE: 
      this.buf.append(".append(");
      break;
    case OTHER: 
      this.buf.append(".appendEscaped(");
    }
  }
  
  protected void finishOutput()
  {
    this.buf.append(".toSafeHtml()");
  }
  
  protected void forceStringPrefix()
  {
    this.buf.append("String.valueOf(");
  }
  
  protected void forceStringSuffix()
  {
    this.buf.append(")");
  }
}
