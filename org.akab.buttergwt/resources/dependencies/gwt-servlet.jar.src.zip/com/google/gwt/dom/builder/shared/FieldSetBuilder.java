package com.google.gwt.dom.builder.shared;

public abstract interface FieldSetBuilder
  extends ElementBuilderBase<FieldSetBuilder>
{}
