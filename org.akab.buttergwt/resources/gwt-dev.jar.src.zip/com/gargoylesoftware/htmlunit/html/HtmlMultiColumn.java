package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlMultiColumn
  extends HtmlElement
{
  public static final String TAG_NAME = "multicol";
  
  HtmlMultiColumn(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
}
