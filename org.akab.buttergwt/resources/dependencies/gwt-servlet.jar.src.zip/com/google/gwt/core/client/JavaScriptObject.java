package com.google.gwt.core.client;

import com.google.gwt.core.client.impl.Impl;

public class JavaScriptObject
{
  public static native JavaScriptObject createArray();
  
  public static native JavaScriptObject createArray(int paramInt);
  
  public static native JavaScriptObject createFunction();
  
  public static native JavaScriptObject createObject();
  
  private static native String toStringSimple(JavaScriptObject paramJavaScriptObject);
  
  private static native String toStringVerbose(JavaScriptObject paramJavaScriptObject);
  
  public final <T extends JavaScriptObject> T cast()
  {
    return this;
  }
  
  public final boolean equals(Object other)
  {
    return super.equals(other);
  }
  
  public final int hashCode()
  {
    return Impl.getHashCode(this);
  }
  
  public native String toSource();
  
  public final String toString()
  {
    return JavaScriptObject.class.desiredAssertionStatus() ? toStringVerbose(this) : toStringSimple(this);
  }
}
