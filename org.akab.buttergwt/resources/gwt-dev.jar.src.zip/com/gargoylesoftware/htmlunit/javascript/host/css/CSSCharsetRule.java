package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass
public class CSSCharsetRule
  extends CSSRule
{
  @Deprecated
  public CSSCharsetRule() {}
  
  protected CSSCharsetRule(CSSStyleSheet stylesheet, org.w3c.dom.css.CSSCharsetRule rule)
  {
    super(stylesheet, rule);
  }
  
  @JsxGetter
  public String getEncoding()
  {
    return getCharsetRule().getEncoding();
  }
  
  @JsxSetter
  public void setEncoding(String encoding)
  {
    getCharsetRule().setEncoding(encoding);
  }
  
  private org.w3c.dom.css.CSSCharsetRule getCharsetRule()
  {
    return (org.w3c.dom.css.CSSCharsetRule)getRule();
  }
}
