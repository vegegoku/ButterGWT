package com.google.gwt.aria.client;

public enum InvalidValue
  implements AriaAttributeType
{
  GRAMMAR,  FALSE,  SPELLING,  TRUE;
  
  private InvalidValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case GRAMMAR: 
      return "grammar";
    case FALSE: 
      return "false";
    case SPELLING: 
      return "spelling";
    case TRUE: 
      return "true";
    }
    return null;
  }
}
