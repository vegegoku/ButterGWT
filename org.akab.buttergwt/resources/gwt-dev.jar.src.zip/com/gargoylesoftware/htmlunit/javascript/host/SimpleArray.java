package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.ScriptableWithFallbackGetter;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.util.ArrayList;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass(isJSObject=false)
public class SimpleArray
  extends SimpleScriptable
  implements ScriptableWithFallbackGetter
{
  private final List<Object> elements_ = new ArrayList();
  
  @JsxFunction
  public Object item(int index)
  {
    return this.elements_.get(index);
  }
  
  public Object getWithFallback(String name)
  {
    Object response = namedItem(name);
    if (response != null) {
      return response;
    }
    return Context.getUndefinedValue();
  }
  
  public final Object get(int index, Scriptable start)
  {
    SimpleArray array = (SimpleArray)start;
    List<Object> elements = array.elements_;
    if ((index >= 0) && (index < elements.size())) {
      return elements.get(index);
    }
    return null;
  }
  
  @JsxFunction
  public Object namedItem(String name)
  {
    for (Object element : this.elements_) {
      if (name.equals(getItemName(element))) {
        return element;
      }
    }
    return null;
  }
  
  protected String getItemName(Object element)
  {
    return null;
  }
  
  @JsxGetter
  public int getLength()
  {
    return this.elements_.size();
  }
  
  void add(Object element)
  {
    this.elements_.add(element);
  }
}
