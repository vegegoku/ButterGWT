package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class RadioRoleImpl
  extends RoleImpl
  implements RadioRole
{
  RadioRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaCheckedState(Element element)
  {
    return State.CHECKED.get(element);
  }
  
  public String getAriaPosinsetProperty(Element element)
  {
    return Property.POSINSET.get(element);
  }
  
  public String getAriaSelectedState(Element element)
  {
    return State.SELECTED.get(element);
  }
  
  public String getAriaSetsizeProperty(Element element)
  {
    return Property.SETSIZE.get(element);
  }
  
  public void removeAriaCheckedState(Element element)
  {
    State.CHECKED.remove(element);
  }
  
  public void removeAriaPosinsetProperty(Element element)
  {
    Property.POSINSET.remove(element);
  }
  
  public void removeAriaSelectedState(Element element)
  {
    State.SELECTED.remove(element);
  }
  
  public void removeAriaSetsizeProperty(Element element)
  {
    Property.SETSIZE.remove(element);
  }
  
  public void setAriaCheckedState(Element element, CheckedValue value)
  {
    State.CHECKED.set(element, new CheckedValue[] { value });
  }
  
  public void setAriaPosinsetProperty(Element element, int value)
  {
    Property.POSINSET.set(element, new Integer[] { Integer.valueOf(value) });
  }
  
  public void setAriaSelectedState(Element element, SelectedValue value)
  {
    State.SELECTED.set(element, new SelectedValue[] { value });
  }
  
  public void setAriaSetsizeProperty(Element element, int value)
  {
    Property.SETSIZE.set(element, new Integer[] { Integer.valueOf(value) });
  }
}
