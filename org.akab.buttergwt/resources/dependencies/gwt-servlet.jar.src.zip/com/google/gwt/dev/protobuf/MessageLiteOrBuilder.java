package com.google.gwt.dev.protobuf;

public abstract interface MessageLiteOrBuilder
{
  public abstract MessageLite getDefaultInstanceForType();
  
  public abstract boolean isInitialized();
}
