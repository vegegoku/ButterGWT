package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.BaseBuilder;
import com.google.gwt.dom.client.BaseElement;

public class DomBaseBuilder
  extends DomElementBuilderBase<BaseBuilder, BaseElement>
  implements BaseBuilder
{
  DomBaseBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public BaseBuilder href(String href)
  {
    ((BaseElement)assertCanAddAttribute()).setHref(href);
    return this;
  }
  
  public BaseBuilder target(String target)
  {
    ((BaseElement)assertCanAddAttribute()).setTarget(target);
    return this;
  }
}
