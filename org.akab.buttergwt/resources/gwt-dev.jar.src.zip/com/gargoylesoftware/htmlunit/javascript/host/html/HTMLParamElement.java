package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlParameter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={HtmlParameter.class})
public class HTMLParamElement
  extends HTMLElement
{
  protected boolean isEndTagForbidden()
  {
    return true;
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "none";
    }
    return "inline";
  }
}
