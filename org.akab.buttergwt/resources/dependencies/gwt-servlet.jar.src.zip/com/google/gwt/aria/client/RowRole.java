package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface RowRole
  extends GroupRole, WidgetRole
{
  public abstract String getAriaLevelProperty(Element paramElement);
  
  public abstract String getAriaSelectedState(Element paramElement);
  
  public abstract void removeAriaLevelProperty(Element paramElement);
  
  public abstract void removeAriaSelectedState(Element paramElement);
  
  public abstract void setAriaLevelProperty(Element paramElement, int paramInt);
  
  public abstract void setAriaSelectedState(Element paramElement, SelectedValue paramSelectedValue);
}
