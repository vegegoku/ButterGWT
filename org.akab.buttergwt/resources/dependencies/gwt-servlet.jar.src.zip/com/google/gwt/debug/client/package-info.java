package com.google.gwt.debug.client;

import com.google.gwt.util.PreventSpuriousRebuilds;

@PreventSpuriousRebuilds
abstract interface package-info {}
