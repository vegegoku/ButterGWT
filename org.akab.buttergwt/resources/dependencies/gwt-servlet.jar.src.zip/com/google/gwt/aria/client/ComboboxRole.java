package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface ComboboxRole
  extends SelectRole
{
  public abstract String getAriaAutocompleteProperty(Element paramElement);
  
  public abstract String getAriaRequiredProperty(Element paramElement);
  
  public abstract void removeAriaAutocompleteProperty(Element paramElement);
  
  public abstract void removeAriaRequiredProperty(Element paramElement);
  
  public abstract void setAriaAutocompleteProperty(Element paramElement, AutocompleteValue paramAutocompleteValue);
  
  public abstract void setAriaRequiredProperty(Element paramElement, boolean paramBoolean);
}
