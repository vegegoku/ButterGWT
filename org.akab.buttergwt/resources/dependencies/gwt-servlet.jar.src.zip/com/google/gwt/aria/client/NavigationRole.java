package com.google.gwt.aria.client;

public abstract interface NavigationRole
  extends LandmarkRole
{}
