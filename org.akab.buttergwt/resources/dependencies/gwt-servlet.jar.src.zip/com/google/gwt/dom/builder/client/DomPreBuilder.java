package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.PreBuilder;
import com.google.gwt.dom.client.PreElement;

public class DomPreBuilder
  extends DomElementBuilderBase<PreBuilder, PreElement>
  implements PreBuilder
{
  DomPreBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
