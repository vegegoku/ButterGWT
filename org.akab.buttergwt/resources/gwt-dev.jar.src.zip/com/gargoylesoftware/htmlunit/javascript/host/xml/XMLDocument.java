package com.gargoylesoftware.htmlunit.javascript.host.xml;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.StringWebResponse;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomCDataSection;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Attr;
import com.gargoylesoftware.htmlunit.javascript.host.Document;
import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCollection;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
public class XMLDocument
  extends Document
{
  private static final Log LOG = LogFactory.getLog(XMLDocument.class);
  private boolean async_ = true;
  private boolean preserveWhiteSpace_;
  private XMLDOMParseError parseError_;
  private Map<String, String> properties_ = new HashMap();
  
  public XMLDocument()
  {
    this(null);
  }
  
  public XMLDocument(WebWindow enclosingWindow)
  {
    if (enclosingWindow != null) {
      try
      {
        XmlPage page = new XmlPage((WebResponse)null, enclosingWindow);
        setDomNode(page);
      }
      catch (IOException e)
      {
        throw Context.reportRuntimeError("IOException: " + e);
      }
    }
  }
  
  @JsxSetter
  public void setAsync(boolean async)
  {
    this.async_ = async;
  }
  
  @JsxGetter
  public boolean getAsync()
  {
    return this.async_;
  }
  
  @JsxFunction
  public boolean load(String xmlSource)
  {
    if ((this.async_) && 
      (LOG.isDebugEnabled())) {
      LOG.debug("XMLDocument.load(): 'async' is true, currently treated as false.");
    }
    try
    {
      HtmlPage htmlPage = (HtmlPage)getWindow().getWebWindow().getEnclosedPage();
      WebRequest request = new WebRequest(htmlPage.getFullyQualifiedUrl(xmlSource));
      WebResponse webResponse = getWindow().getWebWindow().getWebClient().loadWebResponse(request);
      XmlPage page = new XmlPage(webResponse, getWindow().getWebWindow(), false);
      setDomNode(page);
      return true;
    }
    catch (IOException e)
    {
      XMLDOMParseError parseError = getParseError();
      parseError.setErrorCode(-1);
      parseError.setFilepos(1);
      parseError.setLine(1);
      parseError.setLinepos(1);
      parseError.setReason(e.getMessage());
      parseError.setSrcText("xml");
      parseError.setUrl(xmlSource);
      if (LOG.isDebugEnabled()) {
        LOG.debug("Error parsing XML from '" + xmlSource + "'", e);
      }
    }
    return false;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public boolean loadXML(String strXML)
  {
    try
    {
      WebWindow webWindow = getWindow().getWebWindow();
      
      WebResponse webResponse = new StringWebResponse(strXML, webWindow.getEnclosedPage().getUrl());
      
      XmlPage page = new XmlPage(webResponse, webWindow);
      setDomNode(page);
      return true;
    }
    catch (IOException e)
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("Error parsing XML\n" + strXML, e);
      }
    }
    return false;
  }
  
  public SimpleScriptable makeScriptableFor(DomNode domNode)
  {
    SimpleScriptable scriptable;
    if (((domNode instanceof DomElement)) && (!(domNode instanceof HtmlElement)))
    {
      scriptable = new Element();
    }
    else
    {
      SimpleScriptable scriptable;
      if ((domNode instanceof DomAttr))
      {
        SimpleScriptable scriptable;
        if (getPage().getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_XML_ATTRIBUTE_HAS_TEXT_PROPERTY)) {
          scriptable = new XMLAttr();
        } else {
          scriptable = new Attr();
        }
      }
      else
      {
        return super.makeScriptableFor(domNode);
      }
    }
    SimpleScriptable scriptable;
    scriptable.setPrototype(getPrototype(scriptable.getClass()));
    scriptable.setParentScope(getParentScope());
    scriptable.setDomNode(domNode);
    return scriptable;
  }
  
  protected void initParentScope(DomNode domNode, SimpleScriptable scriptable)
  {
    scriptable.setParentScope(getParentScope());
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public XMLDOMParseError getParseError()
  {
    if (this.parseError_ == null)
    {
      this.parseError_ = new XMLDOMParseError();
      this.parseError_.setPrototype(getPrototype(this.parseError_.getClass()));
      this.parseError_.setParentScope(getParentScope());
    }
    return this.parseError_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getXml()
  {
    XMLSerializer seralizer = new XMLSerializer();
    seralizer.setParentScope(getWindow());
    seralizer.setPrototype(getPrototype(seralizer.getClass()));
    return seralizer.serializeToString(getDocumentElement());
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public boolean getPreserveWhiteSpace()
  {
    return this.preserveWhiteSpace_;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void setPreserveWhiteSpace(boolean preserveWhiteSpace)
  {
    this.preserveWhiteSpace_ = preserveWhiteSpace;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void setProperty(String name, String value)
  {
    this.properties_.put(name, value);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getProperty(String name)
  {
    return (String)this.properties_.get(name);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public HTMLCollection selectNodes(final String expression)
  {
    boolean attributeChangeSensitive = expression.contains("@");
    String description = "XMLDocument.selectNodes('" + expression + "')";
    final SgmlPage page = getPage();
    HTMLCollection collection = new HTMLCollection(page.getDocumentElement(), attributeChangeSensitive, description)
    {
      protected List<Object> computeElements()
      {
        List<Object> list = new ArrayList(page.getByXPath(expression));
        return list;
      }
    };
    return collection;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Object selectSingleNode(String expression)
  {
    HTMLCollection collection = selectNodes(expression);
    if (collection.getLength() > 0) {
      return collection.get(0, collection);
    }
    return null;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public HTMLCollection getElementsByTagName(final String tagName)
  {
    DomNode firstChild = getDomNodeOrDie().getFirstChild();
    if (firstChild == null) {
      return HTMLCollection.emptyCollection(getWindow());
    }
    HTMLCollection collection = new HTMLCollection(getDomNodeOrDie(), false, "XMLDocument.getElementsByTagName")
    {
      protected boolean isMatching(DomNode node)
      {
        return node.getNodeName().equals(tagName);
      }
    };
    return collection;
  }
  
  @JsxFunction
  public Object getElementById(String id)
  {
    XmlPage xmlPage = (XmlPage)getDomNodeOrDie();
    Object domElement = xmlPage.getFirstByXPath("//*[@id = \"" + id + "\"]");
    if (domElement == null) {
      return null;
    }
    if ((domElement instanceof HtmlElement)) {
      return ((HtmlElement)domElement).getScriptObject();
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("getElementById(" + id + "): no HTML DOM node found with this ID");
    }
    return null;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Object nodeFromID(String id)
  {
    return null;
  }
  
  @JsxFunction
  public Object createProcessingInstruction(String target, String data)
  {
    DomNode node = ((XmlPage)getPage()).createProcessingInstruction(target, data);
    return getScriptableFor(node);
  }
  
  @JsxFunction
  public Object createCDATASection(String data)
  {
    DomCDataSection node = ((XmlPage)getPage()).createCDATASection(data);
    return getScriptableFor(node);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Object createNode(Object type, String name, Object namespaceURI)
  {
    switch ((short)(int)Context.toNumber(type))
    {
    case 1: 
      return createElementNS((String)namespaceURI, name);
    case 2: 
      return createAttribute(name);
    }
    throw Context.reportRuntimeError("xmlDoc.createNode(): Unsupported type " + (short)(int)Context.toNumber(type));
  }
}
