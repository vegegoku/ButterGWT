package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ImageBuilder;
import com.google.gwt.dom.client.ImageElement;

public class DomImageBuilder
  extends DomElementBuilderBase<ImageBuilder, ImageElement>
  implements ImageBuilder
{
  DomImageBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public ImageBuilder alt(String alt)
  {
    ((ImageElement)assertCanAddAttribute()).setAlt(alt);
    return this;
  }
  
  public ImageBuilder height(int height)
  {
    ((ImageElement)assertCanAddAttribute()).setHeight(height);
    return this;
  }
  
  public ImageBuilder isMap()
  {
    ((ImageElement)assertCanAddAttribute()).setIsMap(true);
    return this;
  }
  
  public ImageBuilder src(String src)
  {
    ((ImageElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
  
  public ImageBuilder width(int width)
  {
    ((ImageElement)assertCanAddAttribute()).setWidth(width);
    return this;
  }
}
