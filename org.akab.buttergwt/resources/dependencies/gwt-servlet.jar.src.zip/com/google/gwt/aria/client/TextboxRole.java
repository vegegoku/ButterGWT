package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface TextboxRole
  extends InputRole
{
  public abstract String getAriaActivedescendantProperty(Element paramElement);
  
  public abstract String getAriaAutocompleteProperty(Element paramElement);
  
  public abstract String getAriaMultilineProperty(Element paramElement);
  
  public abstract String getAriaReadonlyProperty(Element paramElement);
  
  public abstract String getAriaRequiredProperty(Element paramElement);
  
  public abstract void removeAriaActivedescendantProperty(Element paramElement);
  
  public abstract void removeAriaAutocompleteProperty(Element paramElement);
  
  public abstract void removeAriaMultilineProperty(Element paramElement);
  
  public abstract void removeAriaReadonlyProperty(Element paramElement);
  
  public abstract void removeAriaRequiredProperty(Element paramElement);
  
  public abstract void setAriaActivedescendantProperty(Element paramElement, Id paramId);
  
  public abstract void setAriaAutocompleteProperty(Element paramElement, AutocompleteValue paramAutocompleteValue);
  
  public abstract void setAriaMultilineProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaReadonlyProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaRequiredProperty(Element paramElement, boolean paramBoolean);
}
