package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.UListBuilder;
import com.google.gwt.dom.client.UListElement;

public class DomUListBuilder
  extends DomElementBuilderBase<UListBuilder, UListElement>
  implements UListBuilder
{
  DomUListBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
