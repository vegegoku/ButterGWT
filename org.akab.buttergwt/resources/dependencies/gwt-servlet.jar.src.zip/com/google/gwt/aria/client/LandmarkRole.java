package com.google.gwt.aria.client;

public abstract interface LandmarkRole
  extends RegionRole
{}
