package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.LinkBuilder;
import com.google.gwt.dom.client.LinkElement;

public class DomLinkBuilder
  extends DomElementBuilderBase<LinkBuilder, LinkElement>
  implements LinkBuilder
{
  DomLinkBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public LinkBuilder disabled()
  {
    ((LinkElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public LinkBuilder href(String href)
  {
    ((LinkElement)assertCanAddAttribute()).setHref(href);
    return this;
  }
  
  public LinkBuilder hreflang(String hreflang)
  {
    ((LinkElement)assertCanAddAttribute()).setHreflang(hreflang);
    return this;
  }
  
  public LinkBuilder media(String media)
  {
    ((LinkElement)assertCanAddAttribute()).setMedia(media);
    return this;
  }
  
  public LinkBuilder rel(String rel)
  {
    ((LinkElement)assertCanAddAttribute()).setRel(rel);
    return this;
  }
  
  public LinkBuilder target(String target)
  {
    ((LinkElement)assertCanAddAttribute()).setTarget(target);
    return this;
  }
  
  public LinkBuilder type(String type)
  {
    ((LinkElement)assertCanAddAttribute()).setType(type);
    return this;
  }
}
