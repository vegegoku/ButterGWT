package org.aopalliance.intercept;

public abstract interface MethodInterceptor
  extends Interceptor
{
  public abstract Object invoke(MethodInvocation paramMethodInvocation)
    throws Throwable;
}
