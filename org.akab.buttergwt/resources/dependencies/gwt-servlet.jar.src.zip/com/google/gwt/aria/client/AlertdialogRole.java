package com.google.gwt.aria.client;

public abstract interface AlertdialogRole
  extends AlertRole, DialogRole
{}
