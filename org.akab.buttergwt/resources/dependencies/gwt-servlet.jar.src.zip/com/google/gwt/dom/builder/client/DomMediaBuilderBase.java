package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.MediaBuilder;
import com.google.gwt.dom.client.MediaElement;

public class DomMediaBuilderBase<R extends MediaBuilder<?>, E extends MediaElement>
  extends DomElementBuilderBase<R, E>
  implements MediaBuilder<R>
{
  DomMediaBuilderBase(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public R autoplay()
  {
    ((MediaElement)assertCanAddAttribute()).setAutoplay(true);
    return (MediaBuilder)getReturnBuilder();
  }
  
  public R controls()
  {
    ((MediaElement)assertCanAddAttribute()).setControls(true);
    return (MediaBuilder)getReturnBuilder();
  }
  
  public R loop()
  {
    ((MediaElement)assertCanAddAttribute()).setLoop(true);
    return (MediaBuilder)getReturnBuilder();
  }
  
  public R muted()
  {
    ((MediaElement)assertCanAddAttribute()).setMuted(true);
    return (MediaBuilder)getReturnBuilder();
  }
  
  public R preload(String preload)
  {
    ((MediaElement)assertCanAddAttribute()).setPreload(preload);
    return (MediaBuilder)getReturnBuilder();
  }
  
  public R src(String url)
  {
    ((MediaElement)assertCanAddAttribute()).setSrc(url);
    return (MediaBuilder)getReturnBuilder();
  }
}
