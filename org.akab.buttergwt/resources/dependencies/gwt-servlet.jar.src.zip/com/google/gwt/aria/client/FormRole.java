package com.google.gwt.aria.client;

public abstract interface FormRole
  extends LandmarkRole
{}
