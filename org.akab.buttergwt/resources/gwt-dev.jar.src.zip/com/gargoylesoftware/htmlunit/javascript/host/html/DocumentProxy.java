package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptableProxy;
import com.gargoylesoftware.htmlunit.javascript.host.Document;
import com.gargoylesoftware.htmlunit.javascript.host.Window;

public class DocumentProxy
  extends SimpleScriptableProxy<Document>
{
  private final WebWindow webWindow_;
  
  public DocumentProxy(WebWindow webWindow)
  {
    this.webWindow_ = webWindow;
  }
  
  public Document getDelegee()
  {
    Window w = (Window)this.webWindow_.getScriptObject();
    return w.getDocument();
  }
}
