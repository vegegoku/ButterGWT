package com.google.gwt.animation.client.testing;

import com.google.gwt.animation.client.AnimationScheduler;
import com.google.gwt.animation.client.AnimationScheduler.AnimationCallback;
import com.google.gwt.animation.client.AnimationScheduler.AnimationHandle;
import com.google.gwt.dom.client.Element;
import java.util.ArrayList;
import java.util.List;

public class StubAnimationScheduler
  extends AnimationScheduler
{
  public class StubAnimationHandle
    extends AnimationScheduler.AnimationHandle
  {
    private final AnimationScheduler.AnimationCallback callback;
    
    public StubAnimationHandle(AnimationScheduler.AnimationCallback callback)
    {
      this.callback = callback;
    }
    
    public void cancel()
    {
      StubAnimationScheduler.this.callbacks.remove(this.callback);
    }
  }
  
  private final List<AnimationScheduler.AnimationCallback> callbacks = new ArrayList();
  
  public List<AnimationScheduler.AnimationCallback> getAnimationCallbacks()
  {
    return this.callbacks;
  }
  
  public StubAnimationHandle requestAnimationFrame(AnimationScheduler.AnimationCallback callback, Element element)
  {
    this.callbacks.add(callback);
    return new StubAnimationHandle(callback);
  }
}
