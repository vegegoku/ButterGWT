package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface LinkRole
  extends CommandRole
{
  public abstract String getAriaExpandedState(Element paramElement);
  
  public abstract void removeAriaExpandedState(Element paramElement);
  
  public abstract void setAriaExpandedState(Element paramElement, ExpandedValue paramExpandedValue);
}
