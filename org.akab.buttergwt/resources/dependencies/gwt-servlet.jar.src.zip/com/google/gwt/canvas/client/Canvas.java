package com.google.gwt.canvas.client;

import com.google.gwt.canvas.dom.client.Context;
import com.google.gwt.canvas.dom.client.Context2d;
import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.BodyElement;
import com.google.gwt.dom.client.CanvasElement;
import com.google.gwt.dom.client.Document;
import com.google.gwt.dom.client.PartialSupport;
import com.google.gwt.user.client.Element;
import com.google.gwt.user.client.ui.FocusWidget;
import com.google.gwt.user.client.ui.RootPanel;

@PartialSupport
public class Canvas
  extends FocusWidget
{
  private static CanvasElementSupportDetector detector;
  
  public static Canvas createIfSupported()
  {
    if (detector == null) {
      detector = (CanvasElementSupportDetector)GWT.create(CanvasElementSupportDetector.class);
    }
    if (!detector.isSupportedCompileTime()) {
      return null;
    }
    CanvasElement element = Document.get().createCanvasElement();
    if (!CanvasElementSupportDetector.isSupportedRunTime(element)) {
      return null;
    }
    return new Canvas(element);
  }
  
  public static Canvas wrap(CanvasElement element)
  {
    if (!isSupported(element)) {
      return null;
    }
    assert (Document.get().getBody().isOrHasChild(element));
    Canvas canvas = new Canvas(element);
    
    canvas.onAttach();
    RootPanel.detachOnWindowClose(canvas);
    
    return canvas;
  }
  
  public static boolean isSupported()
  {
    return isSupported(Document.get().createCanvasElement());
  }
  
  private static boolean isSupported(CanvasElement element)
  {
    if (detector == null) {
      detector = (CanvasElementSupportDetector)GWT.create(CanvasElementSupportDetector.class);
    }
    if (!detector.isSupportedCompileTime()) {
      return false;
    }
    if (!CanvasElementSupportDetector.isSupportedRunTime(element)) {
      return false;
    }
    return true;
  }
  
  private Canvas(CanvasElement element)
  {
    setElement(element);
  }
  
  public CanvasElement getCanvasElement()
  {
    return (CanvasElement)getElement().cast();
  }
  
  public Context getContext(String contextId)
  {
    return getCanvasElement().getContext(contextId);
  }
  
  public Context2d getContext2d()
  {
    return getCanvasElement().getContext2d();
  }
  
  public int getCoordinateSpaceHeight()
  {
    return getCanvasElement().getHeight();
  }
  
  public int getCoordinateSpaceWidth()
  {
    return getCanvasElement().getWidth();
  }
  
  public void setCoordinateSpaceHeight(int height)
  {
    getCanvasElement().setHeight(height);
  }
  
  public void setCoordinateSpaceWidth(int width)
  {
    getCanvasElement().setWidth(width);
  }
  
  public String toDataUrl()
  {
    return getCanvasElement().toDataUrl();
  }
  
  public String toDataUrl(String type)
  {
    return getCanvasElement().toDataUrl(type);
  }
  
  private static class CanvasElementSupportDetector
  {
    static native boolean isSupportedRunTime(CanvasElement paramCanvasElement);
    
    boolean isSupportedCompileTime()
    {
      return false;
    }
  }
  
  private static class CanvasElementSupportDetectedMaybe
    extends Canvas.CanvasElementSupportDetector
  {
    private CanvasElementSupportDetectedMaybe()
    {
      super();
    }
    
    boolean isSupportedCompileTime()
    {
      return true;
    }
  }
  
  private static class CanvasElementSupportDetectedNo
    extends Canvas.CanvasElementSupportDetector
  {
    private CanvasElementSupportDetectedNo()
    {
      super();
    }
    
    boolean isSupportedCompileTime()
    {
      return false;
    }
  }
}
