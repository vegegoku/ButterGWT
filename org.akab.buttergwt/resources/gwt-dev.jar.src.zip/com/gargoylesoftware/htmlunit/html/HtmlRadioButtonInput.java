package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.ScriptResult;
import com.gargoylesoftware.htmlunit.SgmlPage;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class HtmlRadioButtonInput
  extends HtmlInput
{
  private static final String DEFAULT_VALUE = "on";
  private boolean defaultCheckedState_;
  private boolean forceChecked_;
  
  HtmlRadioButtonInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, addValueIfNeeded(page, attributes));
    if (getAttribute("value") == "on") {
      setDefaultValue(ATTRIBUTE_NOT_DEFINED, false);
    }
    this.defaultCheckedState_ = hasAttribute("checked");
  }
  
  private static Map<String, DomAttr> addValueIfNeeded(SgmlPage page, Map<String, DomAttr> attributes)
  {
    for (String key : attributes.keySet()) {
      if ("value".equalsIgnoreCase(key)) {
        return attributes;
      }
    }
    DomAttr newAttr = new DomAttr(page, null, "value", "on", true);
    attributes.put("value", newAttr);
    
    return attributes;
  }
  
  public void reset()
  {
    if (this.defaultCheckedState_) {
      setAttribute("checked", "checked");
    } else {
      removeAttribute("checked");
    }
  }
  
  public Page setChecked(boolean isChecked)
  {
    HtmlForm form = getEnclosingForm();
    boolean changed = isChecked() != isChecked;
    
    Page page = getPage();
    if (isChecked)
    {
      if (form != null) {
        form.setCheckedRadioButton(this);
      } else if ((page != null) && (page.isHtmlPage())) {
        setCheckedForPage((HtmlPage)page);
      }
    }
    else {
      removeAttribute("checked");
    }
    if ((changed) && (!hasFeature(BrowserVersionFeatures.EVENT_ONCHANGE_LOSING_FOCUS)))
    {
      ScriptResult scriptResult = fireEvent("change");
      if (scriptResult != null) {
        page = scriptResult.getNewPage();
      }
    }
    return page;
  }
  
  protected boolean doClickStateUpdate()
    throws IOException
  {
    HtmlForm form = getEnclosingForm();
    boolean changed = isChecked() != true;
    
    Page page = getPage();
    if (form != null) {
      form.setCheckedRadioButton(this);
    } else if ((page != null) && (page.isHtmlPage())) {
      setCheckedForPage((HtmlPage)page);
    }
    super.doClickStateUpdate();
    return changed;
  }
  
  private void setCheckedForPage(HtmlPage htmlPage)
  {
    List<HtmlRadioButtonInput> pageInputs = htmlPage.getByXPath("//input[lower-case(@type)='radio' and @name='" + getNameAttribute() + "']");
    
    List<HtmlRadioButtonInput> formInputs = htmlPage.getByXPath("//form//input[lower-case(@type)='radio' and @name='" + getNameAttribute() + "']");
    
    pageInputs.removeAll(formInputs);
    
    boolean foundInPage = false;
    for (HtmlRadioButtonInput input : pageInputs) {
      if (input == this)
      {
        input.setAttribute("checked", "checked");
        foundInPage = true;
      }
      else
      {
        input.removeAttribute("checked");
      }
    }
    if ((!foundInPage) && (!formInputs.contains(this))) {
      setAttribute("checked", "checked");
    }
  }
  
  protected void doClickFireChangeEvent()
    throws IOException
  {
    if (!hasFeature(BrowserVersionFeatures.EVENT_ONCHANGE_LOSING_FOCUS)) {
      executeOnChangeHandlerIfAppropriate(this);
    }
  }
  
  public String asText()
  {
    return super.asText();
  }
  
  protected void preventDefault()
  {
    setChecked(!isChecked());
  }
  
  public void setDefaultValue(String defaultValue)
  {
    super.setDefaultValue(defaultValue);
    setValueAttribute(defaultValue);
  }
  
  public void setDefaultChecked(boolean defaultChecked)
  {
    this.defaultCheckedState_ = defaultChecked;
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_DEFAULT_CHECKED_UPDATES_CHECKED)) {
      setChecked(isDefaultChecked());
    }
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_CHECKED_TO_FALSE_WHEN_CLONE))
    {
      reset();
      this.forceChecked_ = true;
    }
  }
  
  public boolean isDefaultChecked()
  {
    return this.defaultCheckedState_;
  }
  
  protected boolean isStateUpdateFirst()
  {
    return true;
  }
  
  protected void onAddedToPage()
  {
    super.onAddedToPage();
    if (this.forceChecked_) {
      return;
    }
    setChecked(isChecked());
  }
  
  protected void onAddedToDocumentFragment()
  {
    super.onAddedToDocumentFragment();
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_CHECKED_TO_FALSE_WHEN_CLONE)) {
      this.forceChecked_ = true;
    }
  }
  
  public DomNode cloneNode(boolean deep)
  {
    HtmlRadioButtonInput clone = (HtmlRadioButtonInput)super.cloneNode(deep);
    clone.forceChecked_ = false;
    if ((wasCreatedByJavascript()) && (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_CHECKED_TO_FALSE_WHEN_CLONE)))
    {
      clone.removeAttribute("checked");
      clone.forceChecked_ = true;
    }
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_DEFAULT_VALUE_WHEN_CLONE)) {
      clone.setDefaultValue(getValueAttribute(), false);
    }
    return clone;
  }
  
  Object getInternalValue()
  {
    return Boolean.valueOf(isChecked());
  }
  
  void handleFocusLostValueChanged()
  {
    boolean fireOnChange = hasFeature(BrowserVersionFeatures.EVENT_ONCHANGE_LOSING_FOCUS);
    if (fireOnChange) {
      executeOnChangeHandlerIfAppropriate(this);
    }
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ((hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_DEFAULT_CHECKED_UPDATES_CHECKED)) && ("value".equals(qualifiedName))) {
      setDefaultValue(attributeValue, false);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
}
