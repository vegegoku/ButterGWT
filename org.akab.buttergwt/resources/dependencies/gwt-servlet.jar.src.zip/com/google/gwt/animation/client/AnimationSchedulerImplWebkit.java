package com.google.gwt.animation.client;

import com.google.gwt.dom.client.Element;

class AnimationSchedulerImplWebkit
  extends AnimationSchedulerImpl
{
  private class AnimationHandleImpl
    extends AnimationScheduler.AnimationHandle
  {
    private final double requestId;
    
    public AnimationHandleImpl(double requestId)
    {
      this.requestId = requestId;
    }
    
    public void cancel()
    {
      AnimationSchedulerImplWebkit.this.cancelAnimationFrameImpl(this.requestId);
    }
  }
  
  public AnimationScheduler.AnimationHandle requestAnimationFrame(AnimationScheduler.AnimationCallback callback, Element element)
  {
    double requestId = requestAnimationFrameImpl(callback, element);
    return new AnimationHandleImpl(requestId);
  }
  
  protected native boolean isNativelySupported();
  
  private native void cancelAnimationFrameImpl(double paramDouble);
  
  private native double requestAnimationFrameImpl(AnimationScheduler.AnimationCallback paramAnimationCallback, Element paramElement);
}
