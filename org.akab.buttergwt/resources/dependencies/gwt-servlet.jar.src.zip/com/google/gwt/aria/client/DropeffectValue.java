package com.google.gwt.aria.client;

public enum DropeffectValue
  implements AriaAttributeType
{
  COPY,  MOVE,  LINK,  EXECUTE,  POPUP,  NONE;
  
  private DropeffectValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case COPY: 
      return "copy";
    case MOVE: 
      return "move";
    case LINK: 
      return "link";
    case EXECUTE: 
      return "execute";
    case POPUP: 
      return "popup";
    case NONE: 
      return "none";
    }
    return null;
  }
}
