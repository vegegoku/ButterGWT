package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.xml.sax.Attributes;

public final class InputElementFactory
  implements ElementFactory
{
  private static final Log LOG = LogFactory.getLog(InputElementFactory.class);
  public static final InputElementFactory instance = new InputElementFactory();
  
  public HtmlElement createElement(SgmlPage page, String tagName, Attributes attributes)
  {
    return createElementNS(page, null, tagName, attributes);
  }
  
  public HtmlElement createElementNS(SgmlPage page, String namespaceURI, String qualifiedName, Attributes attributes)
  {
    return createElementNS(page, namespaceURI, qualifiedName, attributes, false);
  }
  
  public HtmlElement createElementNS(SgmlPage page, String namespaceURI, String qualifiedName, Attributes attributes, boolean asdf)
  {
    Map<String, DomAttr> attributeMap = DefaultElementFactory.setAttributes(page, attributes);
    if (attributeMap == null) {
      attributeMap = new HashMap();
    }
    String type = null;
    if (attributes != null) {
      type = attributes.getValue("type");
    }
    if (type == null)
    {
      type = "";
    }
    else
    {
      type = type.toLowerCase(Locale.ENGLISH);
      ((DomAttr)attributeMap.get("type")).setValue(type);
    }
    HtmlInput result;
    HtmlInput result;
    if (type.isEmpty())
    {
      DomAttr newAttr = new DomAttr(page, null, "type", "text", true);
      attributeMap.put("type", newAttr);
      result = new HtmlTextInput(namespaceURI, qualifiedName, page, attributeMap);
    }
    else
    {
      HtmlInput result;
      if ("submit".equals(type))
      {
        result = new HtmlSubmitInput(namespaceURI, qualifiedName, page, attributeMap);
      }
      else
      {
        HtmlInput result;
        if ("checkbox".equals(type))
        {
          result = new HtmlCheckBoxInput(namespaceURI, qualifiedName, page, attributeMap);
        }
        else
        {
          HtmlInput result;
          if ("radio".equals(type))
          {
            result = new HtmlRadioButtonInput(namespaceURI, qualifiedName, page, attributeMap);
          }
          else
          {
            HtmlInput result;
            if ("text".equals(type))
            {
              result = new HtmlTextInput(namespaceURI, qualifiedName, page, attributeMap);
            }
            else
            {
              HtmlInput result;
              if ("hidden".equals(type))
              {
                result = new HtmlHiddenInput(namespaceURI, qualifiedName, page, attributeMap);
              }
              else
              {
                HtmlInput result;
                if ("password".equals(type))
                {
                  result = new HtmlPasswordInput(namespaceURI, qualifiedName, page, attributeMap);
                }
                else
                {
                  HtmlInput result;
                  if ("image".equals(type))
                  {
                    result = new HtmlImageInput(namespaceURI, qualifiedName, page, attributeMap);
                  }
                  else
                  {
                    HtmlInput result;
                    if ("reset".equals(type))
                    {
                      result = new HtmlResetInput(namespaceURI, qualifiedName, page, attributeMap);
                    }
                    else
                    {
                      HtmlInput result;
                      if ("button".equals(type))
                      {
                        result = new HtmlButtonInput(namespaceURI, qualifiedName, page, attributeMap);
                      }
                      else
                      {
                        HtmlInput result;
                        if ("file".equals(type))
                        {
                          result = new HtmlFileInput(namespaceURI, qualifiedName, page, attributeMap);
                        }
                        else
                        {
                          LOG.info("Bad input type: \"" + type + "\", creating a text input");
                          result = new HtmlTextInput(namespaceURI, qualifiedName, page, attributeMap);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    return result;
  }
}
