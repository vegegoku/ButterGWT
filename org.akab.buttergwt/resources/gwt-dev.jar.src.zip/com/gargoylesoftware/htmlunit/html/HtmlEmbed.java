package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Map;
import org.apache.commons.io.IOUtils;

public class HtmlEmbed
  extends HtmlElement
{
  public static final String TAG_NAME = "embed";
  
  HtmlEmbed(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public void saveAs(File file)
    throws IOException
  {
    HtmlPage page = (HtmlPage)getPage();
    WebClient webclient = page.getWebClient();
    
    URL url = page.getFullyQualifiedUrl(getAttribute("src"));
    WebRequest request = new WebRequest(url);
    request.setAdditionalHeader("Referer", page.getUrl().toExternalForm());
    WebResponse webResponse = webclient.loadWebResponse(request);
    FileOutputStream fos = new FileOutputStream(file);
    IOUtils.copy(webResponse.getContentAsStream(), fos);
    fos.close();
  }
}
