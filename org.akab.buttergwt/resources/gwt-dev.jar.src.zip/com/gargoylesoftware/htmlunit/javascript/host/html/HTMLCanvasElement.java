package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlCanvas;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.canvas.CanvasRenderingContext2D;
import com.gargoylesoftware.htmlunit.javascript.host.css.ComputedCSSStyleDeclaration;

@JsxClass(domClasses={HtmlCanvas.class}, browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class HTMLCanvasElement
  extends HTMLElement
{
  @JsxGetter
  public int getWidth()
  {
    return getCurrentStyle().getCalculatedWidth(false, false);
  }
  
  @JsxSetter
  public void setWidth(String width)
  {
    getDomNodeOrDie().setAttribute("width", width);
  }
  
  @JsxGetter
  public int getHeight()
  {
    return getCurrentStyle().getCalculatedHeight(false, false);
  }
  
  @JsxSetter
  public void setHeight(String height)
  {
    getDomNodeOrDie().setAttribute("height", height);
  }
  
  @JsxFunction
  public Object getContext(String contextId)
  {
    if ("2d".equals(contextId))
    {
      CanvasRenderingContext2D context = new CanvasRenderingContext2D();
      context.setParentScope(getParentScope());
      context.setPrototype(getPrototype(context.getClass()));
      return context;
    }
    return null;
  }
  
  @JsxFunction
  public String toDataURL(String type)
  {
    return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAACWCAYAAABkW7XSAAAAxUlEQVR4nO3BMQEAAADCoPVPbQhfoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOA1v9QAATX68/0AAAAASUVORK5CYII=";
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
