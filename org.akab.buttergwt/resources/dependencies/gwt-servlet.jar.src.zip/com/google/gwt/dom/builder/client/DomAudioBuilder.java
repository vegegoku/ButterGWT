package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.AudioBuilder;
import com.google.gwt.dom.client.AudioElement;

public class DomAudioBuilder
  extends DomMediaBuilderBase<AudioBuilder, AudioElement>
  implements AudioBuilder
{
  DomAudioBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
