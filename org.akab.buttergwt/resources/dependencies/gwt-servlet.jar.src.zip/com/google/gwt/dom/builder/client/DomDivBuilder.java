package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.DivBuilder;
import com.google.gwt.dom.client.DivElement;

public class DomDivBuilder
  extends DomElementBuilderBase<DivBuilder, DivElement>
  implements DivBuilder
{
  DomDivBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
