package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomDocumentType;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.NamedNodeMap;

@JsxClass(domClasses={DomDocumentType.class})
public class DocumentType
  extends Node
{
  @JsxGetter
  public String getName()
  {
    return ((DomDocumentType)getDomNodeOrDie()).getName();
  }
  
  public String getNodeName()
  {
    return getName();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPublicId()
  {
    return ((DomDocumentType)getDomNodeOrDie()).getPublicId();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getSystemId()
  {
    return ((DomDocumentType)getDomNodeOrDie()).getSystemId();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getInternalSubset()
  {
    String subset = ((DomDocumentType)getDomNodeOrDie()).getInternalSubset();
    if (StringUtils.isNotEmpty(subset)) {
      return subset;
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCTYPE_INTERNALSUBSET_EMPTY_STRING)) {
      return "";
    }
    return null;
  }
  
  @JsxGetter
  public Object getEntities()
  {
    NamedNodeMap entities = ((DomDocumentType)getDomNodeOrDie()).getEntities();
    if (null != entities) {
      return entities;
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCTYPE_ENTITIES_NULL)) {
      return null;
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCTYPE_ENTITIES_EMPTY_STRING)) {
      return "";
    }
    return Context.getUndefinedValue();
  }
  
  @JsxGetter
  public Object getNotations()
  {
    NamedNodeMap notations = ((DomDocumentType)getDomNodeOrDie()).getNotations();
    if (null != notations) {
      return notations;
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCTYPE_NOTATIONS_NULL)) {
      return null;
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCTYPE_NOTATIONS_EMPTY_STRING)) {
      return "";
    }
    return Context.getUndefinedValue();
  }
}
