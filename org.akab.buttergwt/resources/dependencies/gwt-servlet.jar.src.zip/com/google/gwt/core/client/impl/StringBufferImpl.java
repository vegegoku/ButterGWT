package com.google.gwt.core.client.impl;

public abstract class StringBufferImpl
{
  public static String reverseString(String s)
  {
    int length = s.length();
    if (length <= 1) {
      return s;
    }
    char[] buffer = new char[length];
    
    buffer[0] = s.charAt(length - 1);
    for (int i = 1; i < length; i++)
    {
      buffer[i] = s.charAt(length - 1 - i);
      if (Character.isSurrogatePair(buffer[i], buffer[(i - 1)])) {
        swap(buffer, i - 1, i);
      }
    }
    return new String(buffer);
  }
  
  private static void swap(char[] buffer, int f, int s)
  {
    char tmp = buffer[f];
    buffer[f] = buffer[s];
    buffer[s] = tmp;
  }
  
  public abstract void append(Object paramObject, boolean paramBoolean);
  
  public abstract void append(Object paramObject, double paramDouble);
  
  public abstract void append(Object paramObject, float paramFloat);
  
  public abstract void append(Object paramObject, int paramInt);
  
  public abstract void append(Object paramObject1, Object paramObject2);
  
  public abstract void append(Object paramObject, String paramString);
  
  public abstract void appendNonNull(Object paramObject, String paramString);
  
  public abstract Object createData();
  
  public abstract int length(Object paramObject);
  
  public abstract void replace(Object paramObject, int paramInt1, int paramInt2, String paramString);
  
  public abstract void reverse(Object paramObject);
  
  public abstract String toString(Object paramObject);
}
