package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.QuoteBuilder;
import com.google.gwt.dom.client.QuoteElement;
import com.google.gwt.safehtml.shared.SafeUri;

public class DomQuoteBuilder
  extends DomElementBuilderBase<QuoteBuilder, QuoteElement>
  implements QuoteBuilder
{
  DomQuoteBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public QuoteBuilder cite(SafeUri cite)
  {
    ((QuoteElement)assertCanAddAttribute()).setCite(cite);
    return this;
  }
  
  public QuoteBuilder cite(String cite)
  {
    ((QuoteElement)assertCanAddAttribute()).setCite(cite);
    return this;
  }
}
