package com.google.gwt.core.client;

public abstract interface AsyncProvider<T, F>
{
  public abstract void get(Callback<? super T, ? super F> paramCallback);
}
