package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlButtonInput
  extends HtmlInput
{
  HtmlButtonInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public void reset() {}
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ((hasFeature(BrowserVersionFeatures.HTMLINPUT_SET_VALUE_UPDATES_DEFAULT_VALUE)) && ("value".equals(qualifiedName))) {
      setDefaultValue(attributeValue, false);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
}
