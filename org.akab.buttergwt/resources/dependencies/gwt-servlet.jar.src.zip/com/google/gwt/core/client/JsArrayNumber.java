package com.google.gwt.core.client;

public class JsArrayNumber
  extends JavaScriptObject
{
  public final native double get(int paramInt);
  
  public final String join()
  {
    return join(",");
  }
  
  public final native String join(String paramString);
  
  public final native int length();
  
  public final native void push(double paramDouble);
  
  public final native void set(int paramInt, double paramDouble);
  
  public final native void setLength(int paramInt);
  
  public final native double shift();
  
  public final native void unshift(double paramDouble);
}
