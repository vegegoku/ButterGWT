package com.google.gwt.canvas.dom.client;

import com.google.gwt.core.client.JavaScriptObject;

public class CanvasPixelArray
  extends JavaScriptObject
{
  public final native int get(int paramInt);
  
  public final native int getLength();
  
  public final native void set(int paramInt1, int paramInt2);
}
