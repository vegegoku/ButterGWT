package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface TreeRole
  extends SelectRole
{
  public abstract String getAriaMultiselectableProperty(Element paramElement);
  
  public abstract String getAriaRequiredProperty(Element paramElement);
  
  public abstract void removeAriaMultiselectableProperty(Element paramElement);
  
  public abstract void removeAriaRequiredProperty(Element paramElement);
  
  public abstract void setAriaMultiselectableProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaRequiredProperty(Element paramElement, boolean paramBoolean);
}
