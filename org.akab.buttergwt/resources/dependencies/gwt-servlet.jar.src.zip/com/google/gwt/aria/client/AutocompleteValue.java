package com.google.gwt.aria.client;

public enum AutocompleteValue
  implements AriaAttributeType
{
  INLINE,  LIST,  BOTH,  NONE;
  
  private AutocompleteValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case INLINE: 
      return "inline";
    case LIST: 
      return "list";
    case BOTH: 
      return "both";
    case NONE: 
      return "none";
    }
    return null;
  }
}
