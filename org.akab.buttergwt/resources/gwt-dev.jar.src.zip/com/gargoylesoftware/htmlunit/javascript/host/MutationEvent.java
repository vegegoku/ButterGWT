package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass
public class MutationEvent
  extends Event
{}
