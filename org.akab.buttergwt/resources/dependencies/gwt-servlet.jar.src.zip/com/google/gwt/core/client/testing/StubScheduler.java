package com.google.gwt.core.client.testing;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.core.client.Scheduler.RepeatingCommand;
import com.google.gwt.core.client.Scheduler.ScheduledCommand;
import java.util.ArrayList;
import java.util.List;

public class StubScheduler
  extends Scheduler
{
  private final List<Scheduler.RepeatingCommand> repeatingCommands = new ArrayList();
  private final List<Scheduler.ScheduledCommand> scheduledCommands = new ArrayList();
  
  public List<Scheduler.RepeatingCommand> getRepeatingCommands()
  {
    return this.repeatingCommands;
  }
  
  public boolean executeCommands()
  {
    boolean repeatingRemaining = executeRepeatingCommands();
    boolean scheduledRemaining = executeScheduledCommands();
    return (repeatingRemaining) || (scheduledRemaining);
  }
  
  public boolean executeRepeatingCommands()
  {
    List<Scheduler.RepeatingCommand> commands = new ArrayList(this.repeatingCommands);
    this.repeatingCommands.clear();
    for (Scheduler.RepeatingCommand command : commands)
    {
      boolean reschedule;
      try
      {
        reschedule = command.execute();
      }
      catch (Throwable e)
      {
        reschedule = false;
        GWT.reportUncaughtException(e);
      }
      if (reschedule) {
        this.repeatingCommands.add(command);
      }
    }
    return !this.repeatingCommands.isEmpty();
  }
  
  public List<Scheduler.ScheduledCommand> getScheduledCommands()
  {
    return this.scheduledCommands;
  }
  
  public boolean executeScheduledCommands()
  {
    List<Scheduler.ScheduledCommand> commands = new ArrayList(this.scheduledCommands);
    this.scheduledCommands.clear();
    for (Scheduler.ScheduledCommand command : commands) {
      try
      {
        command.execute();
      }
      catch (Throwable e)
      {
        GWT.reportUncaughtException(e);
      }
    }
    return !this.scheduledCommands.isEmpty();
  }
  
  public void scheduleDeferred(Scheduler.ScheduledCommand cmd)
  {
    this.scheduledCommands.add(cmd);
  }
  
  public void scheduleEntry(Scheduler.RepeatingCommand cmd)
  {
    this.repeatingCommands.add(cmd);
  }
  
  public void scheduleEntry(Scheduler.ScheduledCommand cmd)
  {
    this.scheduledCommands.add(cmd);
  }
  
  public void scheduleFinally(Scheduler.RepeatingCommand cmd)
  {
    this.repeatingCommands.add(cmd);
  }
  
  public void scheduleFinally(Scheduler.ScheduledCommand cmd)
  {
    this.scheduledCommands.add(cmd);
  }
  
  public void scheduleFixedDelay(Scheduler.RepeatingCommand cmd, int delayMs)
  {
    this.repeatingCommands.add(cmd);
  }
  
  public void scheduleFixedPeriod(Scheduler.RepeatingCommand cmd, int delayMs)
  {
    this.repeatingCommands.add(cmd);
  }
  
  public void scheduleIncremental(Scheduler.RepeatingCommand cmd)
  {
    this.repeatingCommands.add(cmd);
  }
}
