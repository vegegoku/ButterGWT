package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.html.DomProcessingInstruction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={DomProcessingInstruction.class})
public final class ProcessingInstruction
  extends Node
{
  @JsxGetter
  public String getTarget()
  {
    return ((DomProcessingInstruction)getDomNodeOrDie()).getTarget();
  }
  
  @JsxGetter
  public String getData()
  {
    return ((DomProcessingInstruction)getDomNodeOrDie()).getData();
  }
  
  @JsxSetter
  public void setData(String data)
  {
    ((DomProcessingInstruction)getDomNodeOrDie()).setData(data);
  }
}
