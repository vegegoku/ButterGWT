package com.google.gwt.dom.builder.shared;

public abstract interface HeadBuilder
  extends ElementBuilderBase<HeadBuilder>
{}
