package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import java.net.URL;

public class XHtmlPage
  extends HtmlPage
{
  public XHtmlPage(URL originatingUrl, WebResponse webResponse, WebWindow webWindow)
  {
    super(originatingUrl, webResponse, webWindow);
  }
  
  public boolean hasCaseSensitiveTagNames()
  {
    return true;
  }
}
