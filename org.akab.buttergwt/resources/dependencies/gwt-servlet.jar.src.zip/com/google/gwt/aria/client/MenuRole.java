package com.google.gwt.aria.client;

public abstract interface MenuRole
  extends ListRole, SelectRole
{}
