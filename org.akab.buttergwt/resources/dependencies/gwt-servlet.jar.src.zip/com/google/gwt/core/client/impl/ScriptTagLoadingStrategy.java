package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.Callback;
import com.google.gwt.core.client.ScriptInjector;
import com.google.gwt.core.client.ScriptInjector.FromUrl;

public class ScriptTagLoadingStrategy
  extends LoadingStrategyBase
{
  protected static class ScriptTagDownloadStrategy
    implements LoadingStrategyBase.DownloadStrategy
  {
    public void tryDownload(final LoadingStrategyBase.RequestData request)
    {
      ScriptTagLoadingStrategy.setAsyncCallback(request.getFragment(), request);
      
      ScriptInjector.fromUrl(request.getUrl()).setRemoveTag(true).setCallback(new Callback()
      {
        public void onFailure(Exception reason)
        {
          ScriptTagLoadingStrategy.cleanup(request);
        }
        
        public void onSuccess(Void result)
        {
          ScriptTagLoadingStrategy.cleanup(request);
        }
      }).inject();
    }
  }
  
  private static void asyncCallback(LoadingStrategyBase.RequestData request, String code)
  {
    boolean firstTimeCalled = clearAsyncCallback(request.getFragment());
    if (firstTimeCalled) {
      request.tryInstall(code);
    }
  }
  
  private static void cleanup(LoadingStrategyBase.RequestData request)
  {
    boolean neverCalled = clearAsyncCallback(request.getFragment());
    if (neverCalled) {
      request.onLoadError(new AsyncFragmentLoader.HttpDownloadFailure(request.getUrl(), 404, "Script Tag Failure - no status available"), true);
    }
  }
  
  private static native boolean clearAsyncCallback(int paramInt);
  
  private static native void setAsyncCallback(int paramInt, LoadingStrategyBase.RequestData paramRequestData);
  
  public ScriptTagLoadingStrategy()
  {
    super(new ScriptTagDownloadStrategy());
  }
}
