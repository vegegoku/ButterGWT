package com.google.gwt.animation.client;

import com.google.gwt.core.client.GWT;

abstract class AnimationSchedulerImpl
  extends AnimationScheduler
{
  static final AnimationScheduler INSTANCE;
  
  protected abstract boolean isNativelySupported();
  
  static
  {
    AnimationScheduler impl = (AnimationScheduler)GWT.create(AnimationScheduler.class);
    if (((impl instanceof AnimationSchedulerImpl)) && 
      (!((AnimationSchedulerImpl)impl).isNativelySupported())) {
      impl = new AnimationSchedulerImplTimer();
    }
    INSTANCE = impl;
  }
}
