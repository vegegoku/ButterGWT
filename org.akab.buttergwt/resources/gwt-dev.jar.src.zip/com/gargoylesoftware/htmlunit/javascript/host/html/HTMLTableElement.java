package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlTable;
import com.gargoylesoftware.htmlunit.html.HtmlTableRow;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.RowContainer;
import java.util.ArrayList;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(domClasses={HtmlTable.class})
public class HTMLTableElement
  extends RowContainer
{
  private HTMLCollection tBodies_;
  
  @JsxGetter
  public Object getCaption()
  {
    List<HtmlElement> captions = getDomNodeOrDie().getHtmlElementsByTagName("caption");
    if (captions.isEmpty()) {
      return null;
    }
    return getScriptableFor(captions.get(0));
  }
  
  @JsxSetter
  public void setCaption(Object o)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_105)) {
      throw Context.reportRuntimeError("Can't set caption");
    }
    if (!(o instanceof HTMLTableCaptionElement)) {
      throw Context.reportRuntimeError("Not a caption");
    }
    deleteCaption();
    
    HTMLTableCaptionElement caption = (HTMLTableCaptionElement)o;
    getDomNodeOrDie().appendChild(caption.getDomNodeOrDie());
  }
  
  @JsxGetter
  public Object getTFoot()
  {
    List<HtmlElement> tfoots = getDomNodeOrDie().getHtmlElementsByTagName("tfoot");
    if (tfoots.isEmpty()) {
      return null;
    }
    return getScriptableFor(tfoots.get(0));
  }
  
  @JsxSetter
  public void setTFoot(Object o)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_106)) {
      throw Context.reportRuntimeError("Can't set tFoot");
    }
    if ((!(o instanceof HTMLTableSectionElement)) || (!"TFOOT".equals(((HTMLTableSectionElement)o).getTagName()))) {
      throw Context.reportRuntimeError("Not a tFoot");
    }
    deleteTFoot();
    
    HTMLTableSectionElement tfoot = (HTMLTableSectionElement)o;
    getDomNodeOrDie().appendChild(tfoot.getDomNodeOrDie());
  }
  
  @JsxGetter
  public Object getTHead()
  {
    List<HtmlElement> theads = getDomNodeOrDie().getHtmlElementsByTagName("thead");
    if (theads.isEmpty()) {
      return null;
    }
    return getScriptableFor(theads.get(0));
  }
  
  @JsxSetter
  public void setTHead(Object o)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_107)) {
      throw Context.reportRuntimeError("Can't set tHead");
    }
    if ((!(o instanceof HTMLTableSectionElement)) || (!"THEAD".equals(((HTMLTableSectionElement)o).getTagName()))) {
      throw Context.reportRuntimeError("Not a tHead");
    }
    deleteTHead();
    
    HTMLTableSectionElement thead = (HTMLTableSectionElement)o;
    getDomNodeOrDie().appendChild(thead.getDomNodeOrDie());
  }
  
  @JsxGetter
  public Object getTBodies()
  {
    if (this.tBodies_ == null)
    {
      final HtmlTable table = (HtmlTable)getDomNodeOrDie();
      this.tBodies_ = new HTMLCollection(table, false, "HTMLTableElement.tBodies")
      {
        protected List<Object> computeElements()
        {
          return new ArrayList(table.getBodies());
        }
      };
    }
    return this.tBodies_;
  }
  
  @JsxFunction
  public Object createCaption()
  {
    return getScriptableFor(getDomNodeOrDie().appendChildIfNoneExists("caption"));
  }
  
  @JsxFunction
  public Object createTFoot()
  {
    return getScriptableFor(getDomNodeOrDie().appendChildIfNoneExists("tfoot"));
  }
  
  @JsxFunction
  public Object createTHead()
  {
    return getScriptableFor(getDomNodeOrDie().appendChildIfNoneExists("thead"));
  }
  
  @JsxFunction
  public void deleteCaption()
  {
    getDomNodeOrDie().removeChild("caption", 0);
  }
  
  @JsxFunction
  public void deleteTFoot()
  {
    getDomNodeOrDie().removeChild("tfoot", 0);
  }
  
  @JsxFunction
  public void deleteTHead()
  {
    getDomNodeOrDie().removeChild("thead", 0);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void refresh() {}
  
  protected boolean isContainedRow(HtmlTableRow row)
  {
    DomNode parent = row.getParentNode();
    return (parent != null) && (parent.getParentNode() == getDomNodeOrDie());
  }
  
  public Object insertRow(int index)
  {
    List<?> rowContainers = getDomNodeOrDie().getByXPath("//tbody | //thead | //tfoot");
    if ((rowContainers.isEmpty()) || (index == 0))
    {
      HtmlElement tBody = getDomNodeOrDie().appendChildIfNoneExists("tbody");
      return ((RowContainer)getScriptableFor(tBody)).insertRow(0);
    }
    return super.insertRow(index);
  }
  
  @JsxGetter(propertyName="width")
  public String getWidth_js()
  {
    return getDomNodeOrDie().getAttribute("width");
  }
  
  @JsxSetter
  public void setWidth(String width)
  {
    getDomNodeOrDie().setAttribute("width", width);
  }
  
  @JsxGetter
  public String getCellSpacing()
  {
    return getDomNodeOrDie().getAttribute("cellspacing");
  }
  
  @JsxSetter
  public void setCellSpacing(String cellSpacing)
  {
    getDomNodeOrDie().setAttribute("cellspacing", cellSpacing);
  }
  
  @JsxGetter
  public String getCellPadding()
  {
    return getDomNodeOrDie().getAttribute("cellpadding");
  }
  
  @JsxSetter
  public void setCellPadding(String cellPadding)
  {
    getDomNodeOrDie().setAttribute("cellpadding", cellPadding);
  }
  
  @JsxGetter
  public String getBorder()
  {
    String border = getDomNodeOrDie().getAttribute("border");
    return border;
  }
  
  @JsxSetter
  public void setBorder(String border)
  {
    getDomNodeOrDie().setAttribute("border", border);
  }
  
  @JsxGetter
  public String getBgColor()
  {
    return getDomNodeOrDie().getAttribute("bgColor");
  }
  
  @JsxSetter
  public void setBgColor(String bgColor)
  {
    setColorAttribute("bgColor", bgColor);
  }
  
  public String getDefaultStyleDisplay()
  {
    return "table";
  }
}
