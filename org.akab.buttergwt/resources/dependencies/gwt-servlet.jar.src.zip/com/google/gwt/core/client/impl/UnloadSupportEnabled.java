package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.GwtScriptOnly;
import com.google.gwt.core.client.JavaScriptObject;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

@GwtScriptOnly
public class UnloadSupportEnabled
  extends UnloadSupport
{
  public native void exportUnloadModule();
  
  static class TimerDisposable
    implements Disposable
  {
    int timerId;
    private Map<Integer, Disposable> timeoutMap;
    private boolean timeout;
    
    public TimerDisposable(Map<Integer, Disposable> timeoutMap, boolean isTimeout)
    {
      this.timeoutMap = timeoutMap;
      this.timeout = isTimeout;
    }
    
    public void dispose()
    {
      this.timeoutMap.remove(Integer.valueOf(this.timerId));
      if (this.timeout) {
        UnloadSupport.clearTimeout0(this.timerId);
      } else {
        UnloadSupport.clearInterval0(this.timerId);
      }
    }
  }
  
  private Map<Integer, Disposable> timeouts = new HashMap();
  private Map<Integer, Disposable> intervals = new HashMap();
  private Set<Disposable> disposables = new LinkedHashSet();
  
  public boolean isUnloadSupported()
  {
    return true;
  }
  
  public int setInterval(JavaScriptObject func, int time)
  {
    if (!Impl.isModuleUnloaded())
    {
      TimerDisposable disposable = new TimerDisposable(this.intervals, false);
      int timerId = setInterval0(func, time);
      this.intervals.put(Integer.valueOf(timerId), disposable);
      disposable.timerId = timerId;
      scheduleDispose(disposable);
      return timerId;
    }
    return -1;
  }
  
  void clearInterval(int timerId)
  {
    if (timerId != -1) {
      dispose((Disposable)this.intervals.get(Integer.valueOf(timerId)));
    }
  }
  
  void clearTimeout(int timerId)
  {
    if (timerId != -1) {
      dispose((Disposable)this.timeouts.get(Integer.valueOf(timerId)));
    }
  }
  
  void dispose(Disposable d)
  {
    if (d != null)
    {
      try
      {
        d.dispose();
      }
      catch (Throwable e)
      {
        GWT.reportUncaughtException(e);
      }
      this.disposables.remove(d);
    }
  }
  
  void disposeAll()
  {
    LinkedHashSet<Disposable> copy = new LinkedHashSet(this.disposables);
    for (Disposable d : copy) {
      dispose(d);
    }
  }
  
  void scheduleDispose(Disposable d)
  {
    this.disposables.add(d);
  }
  
  int setTimeout(JavaScriptObject func, int time)
  {
    if (!Impl.isModuleUnloaded())
    {
      TimerDisposable disposable = new TimerDisposable(this.timeouts, true);
      int timerId = UnloadSupport.setTimeout0(func, time, disposable);
      this.timeouts.put(Integer.valueOf(timerId), disposable);
      disposable.timerId = timerId;
      scheduleDispose(disposable);
      return timerId;
    }
    return -1;
  }
}
