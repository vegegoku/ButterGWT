package com.gargoylesoftware.htmlunit.javascript.configuration;

public enum BrowserName
{
  FF,  IE,  CHROME;
  
  private BrowserName() {}
}
