package com.google.gwt.dev.util;

import java.io.Serializable;

public abstract class StringKey
  implements Comparable<StringKey>, Serializable
{
  private final int hashCode;
  private final String value;
  
  protected StringKey(String value)
  {
    this.value = value;
    this.hashCode = (getClass().getName().hashCode() * 13 + (value == null ? 0 : value.hashCode()));
  }
  
  public final int compareTo(StringKey o)
  {
    if (getClass() == o.getClass())
    {
      if (this.value == null) {
        return o.value == null ? 0 : -1;
      }
      if (o.value == null) {
        return this.value == null ? 0 : 1;
      }
      return this.value.compareTo(o.value);
    }
    return getClass().getName().compareTo(o.getClass().getName());
  }
  
  public final boolean equals(Object o)
  {
    if (o == null) {
      return false;
    }
    return compareTo((StringKey)o) == 0;
  }
  
  public final String get()
  {
    return this.value;
  }
  
  public final int hashCode()
  {
    return this.hashCode;
  }
  
  public String toString()
  {
    return this.value;
  }
}
