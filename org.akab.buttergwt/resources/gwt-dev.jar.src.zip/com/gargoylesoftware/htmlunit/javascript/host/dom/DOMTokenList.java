package com.gargoylesoftware.htmlunit.javascript.host.dom;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.Node;
import java.util.Arrays;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.NamedNodeMap;

@JsxClass
public final class DOMTokenList
  extends SimpleScriptable
{
  private static final String WHITESPACE_CHARS = " \t\r\n\f";
  private String attributeName_;
  
  public DOMTokenList() {}
  
  public DOMTokenList(Node node, String attributeName)
  {
    setDomNode(node.getDomNodeOrDie(), false);
    setParentScope(node.getParentScope());
    setPrototype(getPrototype(getClass()));
    this.attributeName_ = attributeName;
  }
  
  @JsxGetter
  public int getLength()
  {
    String value = getDefaultValue(null);
    return StringUtils.split(value, " \t\r\n\f").length;
  }
  
  public String getDefaultValue(Class<?> hint)
  {
    DomAttr attr = (DomAttr)getDomNodeOrDie().getAttributes().getNamedItem(this.attributeName_);
    if (attr != null)
    {
      String value = attr.getValue();
      return value;
    }
    return "";
  }
  
  @JsxFunction
  public void add(String token)
  {
    if (!contains(token))
    {
      String value = getDefaultValue(null);
      if ((value.length() != 0) && (!isWhitespache(value.charAt(value.length() - 1)))) {
        value = value + " ";
      }
      value = value + token;
      updateAttribute(value);
    }
  }
  
  @JsxFunction
  public void remove(String token)
  {
    if (StringUtils.isEmpty(token)) {
      throw Context.reportRuntimeError("Empty imput not allowed");
    }
    if (StringUtils.containsAny(token, " \t\r\n\f")) {
      throw Context.reportRuntimeError("Empty imput not allowed");
    }
    String value = getDefaultValue(null);
    int pos = position(value, token);
    while (pos != -1)
    {
      int from = pos;
      int to = pos + token.length();
      while ((from > 0) && (isWhitespache(value.charAt(from - 1)))) {
        from -= 1;
      }
      while ((to < value.length() - 1) && (isWhitespache(value.charAt(to)))) {
        to += 1;
      }
      StringBuilder result = new StringBuilder();
      if (from > 0)
      {
        result.append(value.substring(0, from));
        result.append(" ");
      }
      result.append(value.substring(to));
      
      value = result.toString();
      updateAttribute(value);
      
      pos = position(value, token);
    }
  }
  
  @JsxFunction
  public boolean toggle(String token)
  {
    if (contains(token))
    {
      remove(token);
      return false;
    }
    add(token);
    return true;
  }
  
  @JsxFunction
  public boolean contains(String token)
  {
    if (StringUtils.isEmpty(token)) {
      throw Context.reportRuntimeError("Empty imput not allowed");
    }
    if (StringUtils.containsAny(token, " \t\r\n\f")) {
      throw Context.reportRuntimeError("Empty imput not allowed");
    }
    return position(getDefaultValue(null), token) > -1;
  }
  
  @JsxFunction
  public Object item(int index)
  {
    if (index < 0) {
      return null;
    }
    String value = getDefaultValue(null);
    List<String> values = Arrays.asList(StringUtils.split(value, " \t\r\n\f"));
    if (index < values.size()) {
      return values.get(index);
    }
    return null;
  }
  
  private void updateAttribute(String value)
  {
    HtmlElement domNode = (HtmlElement)getDomNodeOrDie();
    DomAttr attr = (DomAttr)domNode.getAttributes().getNamedItem(this.attributeName_);
    if (null == attr)
    {
      attr = domNode.getPage().createAttribute(this.attributeName_);
      domNode.setAttributeNode(attr);
    }
    attr.setValue(value);
  }
  
  private int position(String value, String token)
  {
    int pos = value.indexOf(token);
    if (pos < 0) {
      return -1;
    }
    if ((pos != 0) && (!isWhitespache(value.charAt(pos - 1)))) {
      return -1;
    }
    int end = pos + token.length();
    if ((end != value.length()) && (!isWhitespache(value.charAt(end)))) {
      return -1;
    }
    return pos;
  }
  
  private boolean isWhitespache(int ch)
  {
    return " \t\r\n\f".indexOf(ch) > -1;
  }
}
