package com.google.gwt.cell.client;

public abstract interface ValueUpdater<C>
{
  public abstract void update(C paramC);
}
