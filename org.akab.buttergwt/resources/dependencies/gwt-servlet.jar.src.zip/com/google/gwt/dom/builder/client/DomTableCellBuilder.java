package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TableCellBuilder;
import com.google.gwt.dom.client.TableCellElement;

public class DomTableCellBuilder
  extends DomElementBuilderBase<TableCellBuilder, TableCellElement>
  implements TableCellBuilder
{
  DomTableCellBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public TableCellBuilder align(String align)
  {
    ((TableCellElement)assertCanAddAttribute()).setAlign(align);
    return this;
  }
  
  public TableCellBuilder ch(String ch)
  {
    ((TableCellElement)assertCanAddAttribute()).setCh(ch);
    return this;
  }
  
  public TableCellBuilder chOff(String chOff)
  {
    ((TableCellElement)assertCanAddAttribute()).setChOff(chOff);
    return this;
  }
  
  public TableCellBuilder colSpan(int colSpan)
  {
    ((TableCellElement)assertCanAddAttribute()).setColSpan(colSpan);
    return this;
  }
  
  public TableCellBuilder headers(String headers)
  {
    ((TableCellElement)assertCanAddAttribute()).setHeaders(headers);
    return this;
  }
  
  public TableCellBuilder rowSpan(int rowSpan)
  {
    ((TableCellElement)assertCanAddAttribute()).setRowSpan(rowSpan);
    return this;
  }
  
  public TableCellBuilder vAlign(String vAlign)
  {
    ((TableCellElement)assertCanAddAttribute()).setVAlign(vAlign);
    return this;
  }
}
