package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlLabel;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.FormChild;

@JsxClass(domClasses={HtmlLabel.class})
public class HTMLLabelElement
  extends FormChild
{
  @JsxGetter
  public String getHtmlFor()
  {
    return ((HtmlLabel)getDomNodeOrDie()).getForAttribute();
  }
  
  @JsxSetter
  public void setHtmlFor(String id)
  {
    ((HtmlLabel)getDomNodeOrDie()).setAttribute("for", id);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getAccessKey()
  {
    return super.getAccessKey();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setAccessKey(String accessKey)
  {
    super.setAccessKey(accessKey);
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
