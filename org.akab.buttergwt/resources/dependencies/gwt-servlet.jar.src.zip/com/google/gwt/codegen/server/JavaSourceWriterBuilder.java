package com.google.gwt.codegen.server;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class JavaSourceWriterBuilder
{
  private final String className;
  private final String packageName;
  private final AbortablePrintWriter printWriter;
  private final List<String> annotations = new ArrayList();
  private boolean isClass = true;
  private String classComment;
  private final Set<String> imports = new TreeSet();
  private final Set<String> interfaceNames = new LinkedHashSet();
  private String superClassName;
  
  public JavaSourceWriterBuilder(AbortablePrintWriter printWriter, String packageName, String className)
  {
    this.printWriter = printWriter;
    this.packageName = packageName;
    this.className = className;
  }
  
  public void addAnnotationDeclaration(String declaration)
  {
    this.annotations.add(declaration);
  }
  
  public void addImplementedInterface(String intfName)
  {
    this.interfaceNames.add(intfName);
  }
  
  public void addImport(String typeName)
  {
    this.imports.add(typeName);
  }
  
  public SourceWriter createSourceWriter()
  {
    return new JavaSourceWriter(this.printWriter, this.packageName, this.imports, this.isClass, this.classComment, this.annotations, this.className, this.superClassName, this.interfaceNames);
  }
  
  public Iterable<String> getAnnotationDeclarations()
  {
    return this.annotations;
  }
  
  public String getClassName()
  {
    return this.className;
  }
  
  public String getFullyQualifiedClassName()
  {
    return getPackageName() + "." + getClassName();
  }
  
  public Iterable<String> getInterfaceNames()
  {
    return this.interfaceNames;
  }
  
  public String getPackageName()
  {
    return this.packageName;
  }
  
  public String getSuperclassName()
  {
    return this.superClassName;
  }
  
  public void makeInterface()
  {
    this.isClass = false;
  }
  
  public void setJavaDocCommentForClass(String comment)
  {
    this.classComment = comment;
  }
  
  public void setSuperclass(String superclassName)
  {
    this.superClassName = superclassName;
  }
}
