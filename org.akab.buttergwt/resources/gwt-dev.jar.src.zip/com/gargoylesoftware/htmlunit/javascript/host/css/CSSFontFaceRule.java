package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

@JsxClass
public class CSSFontFaceRule
  extends CSSRule
{
  private static final Pattern REPLACEMENT_1 = Pattern.compile("font-family: ([^;]*);");
  private static final Pattern REPLACEMENT_2 = Pattern.compile("src: url\\(([^;]*)\\);");
  
  @Deprecated
  public CSSFontFaceRule() {}
  
  protected CSSFontFaceRule(CSSStyleSheet stylesheet, org.w3c.dom.css.CSSFontFaceRule rule)
  {
    super(stylesheet, rule);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public short getType()
  {
    return 5;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCssText()
  {
    String cssText = super.getCssText();
    cssText = StringUtils.replace(cssText, "{", "{\n  ");
    cssText = StringUtils.replace(cssText, "}", ";\n}");
    cssText = StringUtils.replace(cssText, "; ", ";\n  ");
    cssText = REPLACEMENT_1.matcher(cssText).replaceFirst("font-family: \"$1\";");
    cssText = REPLACEMENT_2.matcher(cssText).replaceFirst("src: url(\"$1\");");
    return cssText;
  }
}
