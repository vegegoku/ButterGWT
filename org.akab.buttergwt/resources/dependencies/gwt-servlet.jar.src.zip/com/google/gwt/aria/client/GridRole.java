package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface GridRole
  extends CompositeRole, RegionRole
{
  public abstract String getAriaLevelProperty(Element paramElement);
  
  public abstract String getAriaMultiselectableProperty(Element paramElement);
  
  public abstract String getAriaReadonlyProperty(Element paramElement);
  
  public abstract void removeAriaLevelProperty(Element paramElement);
  
  public abstract void removeAriaMultiselectableProperty(Element paramElement);
  
  public abstract void removeAriaReadonlyProperty(Element paramElement);
  
  public abstract void setAriaLevelProperty(Element paramElement, int paramInt);
  
  public abstract void setAriaMultiselectableProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaReadonlyProperty(Element paramElement, boolean paramBoolean);
}
