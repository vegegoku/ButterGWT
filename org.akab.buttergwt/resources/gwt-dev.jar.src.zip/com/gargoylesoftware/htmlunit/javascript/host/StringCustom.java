package com.gargoylesoftware.htmlunit.javascript.host;

import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.ScriptRuntime;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

public final class StringCustom
{
  public static String trimLeft(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    String string = Context.toString(thisObj);
    int start = 0;
    int length = string.length();
    while ((start < length) && (ScriptRuntime.isJSWhitespaceOrLineTerminator(string.charAt(start)))) {
      start++;
    }
    if (start == 0) {
      return string;
    }
    return string.substring(start, length);
  }
  
  public static String trimRight(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    String string = Context.toString(thisObj);
    int length = string.length();
    int end = length;
    while ((end > 0) && (ScriptRuntime.isJSWhitespaceOrLineTerminator(string.charAt(end - 1)))) {
      end--;
    }
    if (end == length) {
      return string;
    }
    return string.substring(0, end);
  }
}
