package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;
import java.util.HashMap;
import java.util.Map;

public final class Roles
{
  private static final AlertdialogRole ALERTDIALOG;
  private static final AlertRole ALERT;
  private static final ApplicationRole APPLICATION;
  private static final ArticleRole ARTICLE;
  private static final BannerRole BANNER;
  private static final ButtonRole BUTTON;
  private static final CheckboxRole CHECKBOX;
  private static final ColumnheaderRole COLUMNHEADER;
  private static final ComboboxRole COMBOBOX;
  private static final ComplementaryRole COMPLEMENTARY;
  private static final ContentinfoRole CONTENTINFO;
  private static final DefinitionRole DEFINITION;
  private static final DialogRole DIALOG;
  private static final DirectoryRole DIRECTORY;
  private static final DocumentRole DOCUMENT;
  private static final FormRole FORM;
  private static final GridcellRole GRIDCELL;
  private static final GridRole GRID;
  private static final GroupRole GROUP;
  private static final HeadingRole HEADING;
  private static final ImgRole IMG;
  private static final LinkRole LINK;
  private static final ListboxRole LISTBOX;
  private static final ListitemRole LISTITEM;
  private static final ListRole LIST;
  private static final LogRole LOG;
  private static final MainRole MAIN;
  private static final MarqueeRole MARQUEE;
  private static final MathRole MATH;
  private static final MenubarRole MENUBAR;
  private static final MenuitemcheckboxRole MENUITEMCHECKBOX;
  private static final MenuitemradioRole MENUITEMRADIO;
  private static final MenuitemRole MENUITEM;
  private static final MenuRole MENU;
  private static final NavigationRole NAVIGATION;
  private static final NoteRole NOTE;
  private static final OptionRole OPTION;
  private static final PresentationRole PRESENTATION;
  private static final ProgressbarRole PROGRESSBAR;
  private static final RadiogroupRole RADIOGROUP;
  private static final RadioRole RADIO;
  private static final RegionRole REGION;
  private static final RowgroupRole ROWGROUP;
  private static final RowheaderRole ROWHEADER;
  private static final RowRole ROW;
  private static final ScrollbarRole SCROLLBAR;
  private static final SearchRole SEARCH;
  private static final SeparatorRole SEPARATOR;
  private static final SliderRole SLIDER;
  private static final SpinbuttonRole SPINBUTTON;
  private static final StatusRole STATUS;
  private static final TablistRole TABLIST;
  private static final TabpanelRole TABPANEL;
  private static final TabRole TAB;
  private static final TextboxRole TEXTBOX;
  private static final TimerRole TIMER;
  private static final ToolbarRole TOOLBAR;
  private static final TooltipRole TOOLTIP;
  private static final TreegridRole TREEGRID;
  private static final TreeitemRole TREEITEM;
  private static final TreeRole TREE;
  private static final Map<String, Role> ROLES_MAP;
  
  static
  {
    ALERTDIALOG = new AlertdialogRoleImpl("alertdialog");
    ALERT = new AlertRoleImpl("alert");
    APPLICATION = new ApplicationRoleImpl("application");
    ARTICLE = new ArticleRoleImpl("article");
    BANNER = new BannerRoleImpl("banner");
    BUTTON = new ButtonRoleImpl("button");
    CHECKBOX = new CheckboxRoleImpl("checkbox");
    COLUMNHEADER = new ColumnheaderRoleImpl("columnheader");
    COMBOBOX = new ComboboxRoleImpl("combobox");
    COMPLEMENTARY = new ComplementaryRoleImpl("complementary");
    CONTENTINFO = new ContentinfoRoleImpl("contentinfo");
    DEFINITION = new DefinitionRoleImpl("definition");
    DIALOG = new DialogRoleImpl("dialog");
    DIRECTORY = new DirectoryRoleImpl("directory");
    DOCUMENT = new DocumentRoleImpl("document");
    FORM = new FormRoleImpl("form");
    GRIDCELL = new GridcellRoleImpl("gridcell");
    GRID = new GridRoleImpl("grid");
    GROUP = new GroupRoleImpl("group");
    HEADING = new HeadingRoleImpl("heading");
    IMG = new ImgRoleImpl("img");
    LINK = new LinkRoleImpl("link");
    LISTBOX = new ListboxRoleImpl("listbox");
    LISTITEM = new ListitemRoleImpl("listitem");
    LIST = new ListRoleImpl("list");
    LOG = new LogRoleImpl("log");
    MAIN = new MainRoleImpl("main");
    MARQUEE = new MarqueeRoleImpl("marquee");
    MATH = new MathRoleImpl("math");
    MENUBAR = new MenubarRoleImpl("menubar");
    MENUITEMCHECKBOX = new MenuitemcheckboxRoleImpl("menuitemcheckbox");
    MENUITEMRADIO = new MenuitemradioRoleImpl("menuitemradio");
    MENUITEM = new MenuitemRoleImpl("menuitem");
    MENU = new MenuRoleImpl("menu");
    NAVIGATION = new NavigationRoleImpl("navigation");
    NOTE = new NoteRoleImpl("note");
    OPTION = new OptionRoleImpl("option");
    PRESENTATION = new PresentationRoleImpl("presentation");
    PROGRESSBAR = new ProgressbarRoleImpl("progressbar");
    RADIOGROUP = new RadiogroupRoleImpl("radiogroup");
    RADIO = new RadioRoleImpl("radio");
    REGION = new RegionRoleImpl("region");
    ROWGROUP = new RowgroupRoleImpl("rowgroup");
    ROWHEADER = new RowheaderRoleImpl("rowheader");
    ROW = new RowRoleImpl("row");
    SCROLLBAR = new ScrollbarRoleImpl("scrollbar");
    SEARCH = new SearchRoleImpl("search");
    SEPARATOR = new SeparatorRoleImpl("separator");
    SLIDER = new SliderRoleImpl("slider");
    SPINBUTTON = new SpinbuttonRoleImpl("spinbutton");
    STATUS = new StatusRoleImpl("status");
    TABLIST = new TablistRoleImpl("tablist");
    TABPANEL = new TabpanelRoleImpl("tabpanel");
    TAB = new TabRoleImpl("tab");
    TEXTBOX = new TextboxRoleImpl("textbox");
    TIMER = new TimerRoleImpl("timer");
    TOOLBAR = new ToolbarRoleImpl("toolbar");
    TOOLTIP = new TooltipRoleImpl("tooltip");
    TREEGRID = new TreegridRoleImpl("treegrid");
    TREEITEM = new TreeitemRoleImpl("treeitem");
    TREE = new TreeRoleImpl("tree");
    
    ROLES_MAP = new HashMap();
    
    ROLES_MAP.put("region", REGION);
    ROLES_MAP.put("alert", ALERT);
    ROLES_MAP.put("dialog", DIALOG);
    ROLES_MAP.put("alertdialog", ALERTDIALOG);
    ROLES_MAP.put("application", APPLICATION);
    ROLES_MAP.put("document", DOCUMENT);
    ROLES_MAP.put("article", ARTICLE);
    ROLES_MAP.put("banner", BANNER);
    ROLES_MAP.put("button", BUTTON);
    ROLES_MAP.put("checkbox", CHECKBOX);
    ROLES_MAP.put("gridcell", GRIDCELL);
    ROLES_MAP.put("columnheader", COLUMNHEADER);
    ROLES_MAP.put("group", GROUP);
    ROLES_MAP.put("combobox", COMBOBOX);
    ROLES_MAP.put("complementary", COMPLEMENTARY);
    ROLES_MAP.put("contentinfo", CONTENTINFO);
    ROLES_MAP.put("definition", DEFINITION);
    ROLES_MAP.put("list", LIST);
    ROLES_MAP.put("directory", DIRECTORY);
    ROLES_MAP.put("form", FORM);
    ROLES_MAP.put("grid", GRID);
    ROLES_MAP.put("heading", HEADING);
    ROLES_MAP.put("img", IMG);
    ROLES_MAP.put("link", LINK);
    ROLES_MAP.put("listbox", LISTBOX);
    ROLES_MAP.put("listitem", LISTITEM);
    ROLES_MAP.put("log", LOG);
    ROLES_MAP.put("main", MAIN);
    ROLES_MAP.put("marquee", MARQUEE);
    ROLES_MAP.put("math", MATH);
    ROLES_MAP.put("menu", MENU);
    ROLES_MAP.put("menubar", MENUBAR);
    ROLES_MAP.put("menuitem", MENUITEM);
    ROLES_MAP.put("menuitemcheckbox", MENUITEMCHECKBOX);
    ROLES_MAP.put("option", OPTION);
    ROLES_MAP.put("radio", RADIO);
    ROLES_MAP.put("menuitemradio", MENUITEMRADIO);
    ROLES_MAP.put("navigation", NAVIGATION);
    ROLES_MAP.put("note", NOTE);
    ROLES_MAP.put("presentation", PRESENTATION);
    ROLES_MAP.put("progressbar", PROGRESSBAR);
    ROLES_MAP.put("radiogroup", RADIOGROUP);
    ROLES_MAP.put("row", ROW);
    ROLES_MAP.put("rowgroup", ROWGROUP);
    ROLES_MAP.put("rowheader", ROWHEADER);
    ROLES_MAP.put("search", SEARCH);
    ROLES_MAP.put("separator", SEPARATOR);
    ROLES_MAP.put("scrollbar", SCROLLBAR);
    ROLES_MAP.put("slider", SLIDER);
    ROLES_MAP.put("spinbutton", SPINBUTTON);
    ROLES_MAP.put("status", STATUS);
    ROLES_MAP.put("tab", TAB);
    ROLES_MAP.put("tablist", TABLIST);
    ROLES_MAP.put("tabpanel", TABPANEL);
    ROLES_MAP.put("textbox", TEXTBOX);
    ROLES_MAP.put("timer", TIMER);
    ROLES_MAP.put("toolbar", TOOLBAR);
    ROLES_MAP.put("tooltip", TOOLTIP);
    ROLES_MAP.put("tree", TREE);
    ROLES_MAP.put("treegrid", TREEGRID);
    ROLES_MAP.put("treeitem", TREEITEM);
  }
  
  public static AlertdialogRole getAlertdialogRole()
  {
    return ALERTDIALOG;
  }
  
  public static AlertRole getAlertRole()
  {
    return ALERT;
  }
  
  public static ApplicationRole getApplicationRole()
  {
    return APPLICATION;
  }
  
  public static ArticleRole getArticleRole()
  {
    return ARTICLE;
  }
  
  public static BannerRole getBannerRole()
  {
    return BANNER;
  }
  
  public static ButtonRole getButtonRole()
  {
    return BUTTON;
  }
  
  public static CheckboxRole getCheckboxRole()
  {
    return CHECKBOX;
  }
  
  public static ColumnheaderRole getColumnheaderRole()
  {
    return COLUMNHEADER;
  }
  
  public static ComboboxRole getComboboxRole()
  {
    return COMBOBOX;
  }
  
  public static ComplementaryRole getComplementaryRole()
  {
    return COMPLEMENTARY;
  }
  
  public static ContentinfoRole getContentinfoRole()
  {
    return CONTENTINFO;
  }
  
  public static DefinitionRole getDefinitionRole()
  {
    return DEFINITION;
  }
  
  public static DialogRole getDialogRole()
  {
    return DIALOG;
  }
  
  public static DirectoryRole getDirectoryRole()
  {
    return DIRECTORY;
  }
  
  public static DocumentRole getDocumentRole()
  {
    return DOCUMENT;
  }
  
  public static FormRole getFormRole()
  {
    return FORM;
  }
  
  public static GridcellRole getGridcellRole()
  {
    return GRIDCELL;
  }
  
  public static GridRole getGridRole()
  {
    return GRID;
  }
  
  public static GroupRole getGroupRole()
  {
    return GROUP;
  }
  
  public static HeadingRole getHeadingRole()
  {
    return HEADING;
  }
  
  public static ImgRole getImgRole()
  {
    return IMG;
  }
  
  public static LinkRole getLinkRole()
  {
    return LINK;
  }
  
  public static ListboxRole getListboxRole()
  {
    return LISTBOX;
  }
  
  public static ListitemRole getListitemRole()
  {
    return LISTITEM;
  }
  
  public static ListRole getListRole()
  {
    return LIST;
  }
  
  public static LogRole getLogRole()
  {
    return LOG;
  }
  
  public static MainRole getMainRole()
  {
    return MAIN;
  }
  
  public static MarqueeRole getMarqueeRole()
  {
    return MARQUEE;
  }
  
  public static MathRole getMathRole()
  {
    return MATH;
  }
  
  public static MenubarRole getMenubarRole()
  {
    return MENUBAR;
  }
  
  public static MenuitemcheckboxRole getMenuitemcheckboxRole()
  {
    return MENUITEMCHECKBOX;
  }
  
  public static MenuitemradioRole getMenuitemradioRole()
  {
    return MENUITEMRADIO;
  }
  
  public static MenuitemRole getMenuitemRole()
  {
    return MENUITEM;
  }
  
  public static MenuRole getMenuRole()
  {
    return MENU;
  }
  
  public static NavigationRole getNavigationRole()
  {
    return NAVIGATION;
  }
  
  public static NoteRole getNoteRole()
  {
    return NOTE;
  }
  
  public static OptionRole getOptionRole()
  {
    return OPTION;
  }
  
  public static PresentationRole getPresentationRole()
  {
    return PRESENTATION;
  }
  
  public static ProgressbarRole getProgressbarRole()
  {
    return PROGRESSBAR;
  }
  
  public static RadiogroupRole getRadiogroupRole()
  {
    return RADIOGROUP;
  }
  
  public static RadioRole getRadioRole()
  {
    return RADIO;
  }
  
  public static RegionRole getRegionRole()
  {
    return REGION;
  }
  
  public static RowgroupRole getRowgroupRole()
  {
    return ROWGROUP;
  }
  
  public static RowheaderRole getRowheaderRole()
  {
    return ROWHEADER;
  }
  
  public static RowRole getRowRole()
  {
    return ROW;
  }
  
  public static ScrollbarRole getScrollbarRole()
  {
    return SCROLLBAR;
  }
  
  public static SearchRole getSearchRole()
  {
    return SEARCH;
  }
  
  public static SeparatorRole getSeparatorRole()
  {
    return SEPARATOR;
  }
  
  public static SliderRole getSliderRole()
  {
    return SLIDER;
  }
  
  public static SpinbuttonRole getSpinbuttonRole()
  {
    return SPINBUTTON;
  }
  
  public static StatusRole getStatusRole()
  {
    return STATUS;
  }
  
  public static TablistRole getTablistRole()
  {
    return TABLIST;
  }
  
  public static TabpanelRole getTabpanelRole()
  {
    return TABPANEL;
  }
  
  public static TabRole getTabRole()
  {
    return TAB;
  }
  
  public static TextboxRole getTextboxRole()
  {
    return TEXTBOX;
  }
  
  public static TimerRole getTimerRole()
  {
    return TIMER;
  }
  
  public static ToolbarRole getToolbarRole()
  {
    return TOOLBAR;
  }
  
  public static TooltipRole getTooltipRole()
  {
    return TOOLTIP;
  }
  
  public static TreegridRole getTreegridRole()
  {
    return TREEGRID;
  }
  
  public static TreeitemRole getTreeitemRole()
  {
    return TREEITEM;
  }
  
  public static TreeRole getTreeRole()
  {
    return TREE;
  }
  
  public static Role roleOf(Element element)
  {
    assert (element != null) : "Element cannot be null.";
    String roleAttributeValue = element.getAttribute("role");
    for (String testRoleName : roleAttributeValue.split("\\s+"))
    {
      Role role = (Role)ROLES_MAP.get(testRoleName);
      if (role != null) {
        return role;
      }
    }
    return null;
  }
}
