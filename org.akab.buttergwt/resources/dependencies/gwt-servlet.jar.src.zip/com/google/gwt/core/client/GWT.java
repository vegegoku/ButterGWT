package com.google.gwt.core.client;

import com.google.gwt.core.client.impl.Impl;

public final class GWT
{
  public static final String HOSTED_MODE_PERMUTATION_STRONG_NAME = "HostedMode";
  
  private static final class DefaultUncaughtExceptionHandler
    implements GWT.UncaughtExceptionHandler
  {
    public void onUncaughtException(Throwable e)
    {
      GWT.log("Uncaught exception escaped", e);
    }
  }
  
  private static UncaughtExceptionHandler uncaughtExceptionHandler = null;
  
  public static <T> T create(Class<?> classLiteral)
  {
    return (T)com.google.gwt.core.shared.GWT.create(classLiteral);
  }
  
  public static void exportUnloadModule() {}
  
  public static String getHostPageBaseURL()
  {
    return Impl.getHostPageBaseURL();
  }
  
  public static String getModuleBaseForStaticFiles()
  {
    return Impl.getModuleBaseURLForStaticFiles();
  }
  
  public static String getModuleBaseURL()
  {
    return Impl.getModuleBaseURL();
  }
  
  public static String getModuleName()
  {
    return Impl.getModuleName();
  }
  
  public static String getPermutationStrongName()
  {
    if (isScript()) {
      return Impl.getPermutationStrongName();
    }
    return "HostedMode";
  }
  
  @Deprecated
  public static String getTypeName(Object o)
  {
    return o == null ? null : o.getClass().getName();
  }
  
  public static UncaughtExceptionHandler getUncaughtExceptionHandler()
  {
    return uncaughtExceptionHandler;
  }
  
  public static void reportUncaughtException(Throwable e)
  {
    Impl.reportUncaughtException(e);
  }
  
  public static String getUniqueThreadId()
  {
    return com.google.gwt.core.shared.GWT.getUniqueThreadId();
  }
  
  public static String getVersion()
  {
    String version = com.google.gwt.core.shared.GWT.getVersion();
    if (version == null) {
      version = getVersion0();
    }
    return version;
  }
  
  public static boolean isClient()
  {
    return com.google.gwt.core.shared.GWT.isClient();
  }
  
  public static boolean isProdMode()
  {
    return com.google.gwt.core.shared.GWT.isProdMode();
  }
  
  public static boolean isScript()
  {
    return com.google.gwt.core.shared.GWT.isScript();
  }
  
  public static void log(String message)
  {
    com.google.gwt.core.shared.GWT.log(message);
  }
  
  public static void log(String message, Throwable e)
  {
    com.google.gwt.core.shared.GWT.log(message, e);
  }
  
  public static void debugger() {}
  
  public static void runAsync(Class<?> name, RunAsyncCallback callback)
  {
    runAsyncImpl(callback);
  }
  
  public static void runAsync(RunAsyncCallback callback)
  {
    runAsyncImpl(callback);
  }
  
  private static void runAsyncImpl(RunAsyncCallback callback)
  {
    Scheduler.get().scheduleDeferred(new Scheduler.ScheduledCommand()
    {
      public void execute()
      {
        this.val$callback.onSuccess();
      }
    });
  }
  
  public static void setUncaughtExceptionHandler(UncaughtExceptionHandler handler)
  {
    uncaughtExceptionHandler = handler;
  }
  
  static void setBridge(GWTBridge bridge)
  {
    com.google.gwt.core.shared.GWT.setBridge(bridge);
    if (bridge != null) {
      setUncaughtExceptionHandler(new DefaultUncaughtExceptionHandler(null));
    }
  }
  
  private static native String getVersion0();
  
  private static void unloadModule() {}
  
  public static abstract interface UncaughtExceptionHandler
  {
    public abstract void onUncaughtException(Throwable paramThrowable);
  }
}
