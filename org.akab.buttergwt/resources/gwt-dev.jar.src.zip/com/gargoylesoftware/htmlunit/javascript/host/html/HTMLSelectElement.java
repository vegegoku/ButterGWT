package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.ElementFactory;
import com.gargoylesoftware.htmlunit.html.HTMLParser;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlOption;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.FormField;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.EvaluatorException;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass(domClasses={HtmlSelect.class})
public class HTMLSelectElement
  extends FormField
{
  private HTMLOptionsCollection optionsArray_;
  
  public void initialize()
  {
    HtmlSelect htmlSelect = getHtmlSelect();
    htmlSelect.setScriptObject(this);
    if (this.optionsArray_ == null)
    {
      this.optionsArray_ = new HTMLOptionsCollection(this);
      this.optionsArray_.initialize(htmlSelect);
    }
  }
  
  @JsxFunction
  public void remove(int index)
  {
    put(index, null, null);
  }
  
  @JsxFunction
  public void add(HTMLOptionElement newOptionObject, Object arg2)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SELECT_ADD_SECOND_PARAM_IS_INDEX)) {
      add_IE(newOptionObject, arg2);
    } else {
      add_FF(newOptionObject, arg2);
    }
    ensureSelectedIndex();
  }
  
  public Object appendChild(Object childObject)
  {
    Object object = super.appendChild(childObject);
    ensureSelectedIndex();
    return object;
  }
  
  public Object insertBeforeImpl(Object[] args)
  {
    Object object = super.insertBeforeImpl(args);
    ensureSelectedIndex();
    return object;
  }
  
  @JsxFunction
  public HTMLOptionElement item(int index)
  {
    if (index < 0)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SELECT_ITEM_THROWS_IF_NEGATIVE)) {
        throw Context.reportRuntimeError("Invalid index for select node: " + index);
      }
      return null;
    }
    int length = getLength();
    if (index > length) {
      return null;
    }
    return (HTMLOptionElement)getHtmlSelect().getOption(index).getScriptObject();
  }
  
  protected void add_IE(HTMLOptionElement newOptionObject, Object index)
  {
    if (index == null) {
      throw new EvaluatorException("Null not supported as index.");
    }
    HtmlOption beforeOption;
    HtmlOption beforeOption;
    if (Context.getUndefinedValue().equals(index))
    {
      beforeOption = null;
    }
    else
    {
      HtmlSelect select = getHtmlSelect();
      int intIndex = ((Integer)Context.jsToJava(index, Integer.class)).intValue();
      HtmlOption beforeOption;
      if (intIndex >= select.getOptionSize()) {
        beforeOption = null;
      } else {
        beforeOption = select.getOption(intIndex);
      }
    }
    addBefore(newOptionObject, beforeOption);
  }
  
  protected void add_FF(HTMLOptionElement newOptionObject, Object beforeOptionObject)
  {
    HtmlOption beforeOption;
    HtmlOption beforeOption;
    if (beforeOptionObject == null)
    {
      beforeOption = null;
    }
    else
    {
      HtmlOption beforeOption;
      if (Context.getUndefinedValue().equals(beforeOptionObject))
      {
        if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SELECT_ADD_SECOND_PARAM_IS_REQUIRED)) {
          throw Context.reportRuntimeError("Not enough arguments [SelectElement.add]");
        }
        beforeOption = null;
      }
      else
      {
        HtmlOption beforeOption;
        if ((beforeOptionObject instanceof Number))
        {
          HtmlSelect select = getHtmlSelect();
          int intIndex = ((Integer)Context.jsToJava(beforeOptionObject, Integer.class)).intValue();
          HtmlOption beforeOption;
          if (intIndex >= select.getOptionSize()) {
            beforeOption = null;
          } else {
            beforeOption = select.getOption(intIndex);
          }
        }
        else
        {
          beforeOption = (HtmlOption)((HTMLOptionElement)beforeOptionObject).getDomNodeOrDie();
        }
      }
    }
    addBefore(newOptionObject, beforeOption);
  }
  
  protected void addBefore(HTMLOptionElement newOptionObject, HtmlOption beforeOption)
  {
    HtmlSelect select = getHtmlSelect();
    
    HtmlOption htmlOption = newOptionObject.getDomNodeOrNull();
    if (htmlOption == null) {
      htmlOption = (HtmlOption)HTMLParser.getFactory("option").createElement(select.getPage(), "option", null);
    }
    if (beforeOption == null) {
      select.appendChild(htmlOption);
    } else {
      beforeOption.insertBefore(htmlOption);
    }
  }
  
  public String getType()
  {
    String type;
    String type;
    if (getHtmlSelect().isMultipleSelectEnabled()) {
      type = "select-multiple";
    } else {
      type = "select-one";
    }
    return type;
  }
  
  @JsxGetter
  public HTMLOptionsCollection getOptions()
  {
    if (this.optionsArray_ == null) {
      initialize();
    }
    return this.optionsArray_;
  }
  
  @JsxGetter
  public int getSelectedIndex()
  {
    HtmlSelect htmlSelect = getHtmlSelect();
    List<HtmlOption> selectedOptions = htmlSelect.getSelectedOptions();
    if (selectedOptions.isEmpty()) {
      return -1;
    }
    List<HtmlOption> allOptions = htmlSelect.getOptions();
    return allOptions.indexOf(selectedOptions.get(0));
  }
  
  @JsxSetter
  public void setSelectedIndex(int index)
  {
    HtmlSelect htmlSelect = getHtmlSelect();
    if ((index != 0) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SELECT_SELECTED_INDEX_THROWS_IF_BAD)) && ((index < -1) || (index >= htmlSelect.getOptionSize()))) {
      throw Context.reportRuntimeError("Invalid index for select node: " + index);
    }
    for (HtmlOption itemToUnSelect : htmlSelect.getSelectedOptions()) {
      htmlSelect.setSelectedAttribute(itemToUnSelect, false);
    }
    if (index < 0) {
      return;
    }
    List<HtmlOption> allOptions = htmlSelect.getOptions();
    if (index < allOptions.size())
    {
      HtmlOption itemToSelect = (HtmlOption)allOptions.get(index);
      htmlSelect.setSelectedAttribute(itemToSelect, true, false);
    }
  }
  
  public String getValue()
  {
    HtmlSelect htmlSelect = getHtmlSelect();
    List<HtmlOption> selectedOptions = htmlSelect.getSelectedOptions();
    if (selectedOptions.isEmpty()) {
      return "";
    }
    return ((HTMLOptionElement)((HtmlOption)selectedOptions.get(0)).getScriptObject()).getValue();
  }
  
  @JsxGetter
  public int getLength()
  {
    if (this.optionsArray_ == null) {
      initialize();
    }
    return this.optionsArray_.getLength();
  }
  
  @JsxSetter
  public void setLength(int newLength)
  {
    if (this.optionsArray_ == null) {
      initialize();
    }
    this.optionsArray_.setLength(newLength);
  }
  
  public Object get(int index, Scriptable start)
  {
    if (this.optionsArray_ == null) {
      initialize();
    }
    return this.optionsArray_.get(index, start);
  }
  
  public void put(int index, Scriptable start, Object newValue)
  {
    if (this.optionsArray_ == null) {
      initialize();
    }
    this.optionsArray_.put(index, start, newValue);
  }
  
  private HtmlSelect getHtmlSelect()
  {
    return (HtmlSelect)getDomNodeOrDie();
  }
  
  public void setValue(String newValue)
  {
    getHtmlSelect().setSelectedAttribute(newValue, true);
  }
  
  @JsxGetter
  public int getSize()
  {
    int size = 0;
    String sizeAttribute = getDomNodeOrDie().getAttribute("size");
    if ((sizeAttribute != DomElement.ATTRIBUTE_NOT_DEFINED) && (sizeAttribute != DomElement.ATTRIBUTE_VALUE_EMPTY)) {
      try
      {
        size = Integer.parseInt(sizeAttribute);
      }
      catch (Exception e) {}
    }
    return size;
  }
  
  @JsxSetter
  public void setSize(String size)
  {
    getDomNodeOrDie().setAttribute("size", size);
  }
  
  @JsxGetter
  public boolean getMultiple()
  {
    return getDomNodeOrDie().hasAttribute("multiple");
  }
  
  @JsxSetter
  public void setMultiple(boolean multiple)
  {
    if (multiple) {
      getDomNodeOrDie().setAttribute("multiple", "multiple");
    } else {
      getDomNodeOrDie().removeAttribute("multiple");
    }
  }
  
  private void ensureSelectedIndex()
  {
    HtmlSelect select = getHtmlSelect();
    if (select.getOptionSize() == 0) {
      setSelectedIndex(-1);
    } else if (getSelectedIndex() == -1) {
      setSelectedIndex(0);
    }
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "inline";
    }
    return "inline-block";
  }
}
