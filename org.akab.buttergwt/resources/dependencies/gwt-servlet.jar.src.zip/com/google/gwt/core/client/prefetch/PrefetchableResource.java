package com.google.gwt.core.client.prefetch;

public abstract interface PrefetchableResource {}
