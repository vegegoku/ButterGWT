package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface ColumnheaderRole
  extends GridcellRole, SectionheadRole, WidgetRole
{
  public abstract String getAriaSortProperty(Element paramElement);
  
  public abstract void removeAriaSortProperty(Element paramElement);
  
  public abstract void setAriaSortProperty(Element paramElement, SortValue paramSortValue);
}
