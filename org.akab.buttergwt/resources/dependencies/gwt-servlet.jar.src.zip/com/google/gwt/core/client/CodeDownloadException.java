package com.google.gwt.core.client;

public final class CodeDownloadException
  extends RuntimeException
{
  private final Reason reason;
  
  public static enum Reason
  {
    TERMINATED;
    
    private Reason() {}
  }
  
  public CodeDownloadException(String message)
  {
    super(message);
    this.reason = Reason.TERMINATED;
  }
  
  public CodeDownloadException(String message, Reason reason)
  {
    super(message);
    this.reason = reason;
  }
  
  public Reason getReason()
  {
    return this.reason;
  }
}
