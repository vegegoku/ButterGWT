package com.google.gwt.aria.client;

class AriaValueAttribute<T extends AriaAttributeType>
  extends Attribute<T>
{
  public AriaValueAttribute(String name, String defaultValue)
  {
    super(name, defaultValue);
  }
  
  public AriaValueAttribute(String name)
  {
    super(name);
  }
  
  protected String getSingleValue(T value)
  {
    return value.getAriaValue();
  }
}
