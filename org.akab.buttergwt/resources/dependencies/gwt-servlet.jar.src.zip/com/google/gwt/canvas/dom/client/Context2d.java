package com.google.gwt.canvas.dom.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.dom.client.CanvasElement;
import com.google.gwt.dom.client.ImageElement;
import com.google.gwt.dom.client.VideoElement;

public class Context2d
  extends JavaScriptObject
  implements Context
{
  public static final String CONTEXT_ID = "2d";
  public final native void arc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
  
  public final native void arc(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, boolean paramBoolean);
  
  public final native void arcTo(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5);
  
  public final native void beginPath();
  
  public final native void bezierCurveTo(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public final native void clearRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void clip();
  
  public final native void closePath();
  
  public final native ImageData createImageData(ImageData paramImageData);
  
  public final native ImageData createImageData(int paramInt1, int paramInt2);
  
  public final native CanvasGradient createLinearGradient(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public static enum Composite
  {
    COPY("copy"),  DESTINATION_ATOP("destination-atop"),  DESTINATION_IN("destination-in"),  DESTINATION_OUT("destination-out"),  DESTINATION_OVER("destination-over"),  LIGHTER("lighter"),  SOURCE_ATOP("source-atop"),  SOURCE_IN("source-in"),  SOURCE_OUT("source-out"),  SOURCE_OVER("source-over"),  XOR("xor");
    
    private final String value;
    
    private Composite(String value)
    {
      this.value = value;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
  
  public static enum LineCap
  {
    BUTT("butt"),  ROUND("round"),  SQUARE("square");
    
    private final String value;
    
    private LineCap(String value)
    {
      this.value = value;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
  
  public static enum LineJoin
  {
    BEVEL("bevel"),  MITER("miter"),  ROUND("round");
    
    private final String value;
    
    private LineJoin(String value)
    {
      this.value = value;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
  
  public static enum Repetition
  {
    NO_REPEAT("no-repeat"),  REPEAT("repeat"),  REPEAT_X("repeat-x"),  REPEAT_Y("repeat-y");
    
    private final String value;
    
    private Repetition(String value)
    {
      this.value = value;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
  
  public static enum TextAlign
  {
    CENTER("center"),  END("end"),  LEFT("left"),  RIGHT("right"),  START("start");
    
    private final String value;
    
    private TextAlign(String value)
    {
      this.value = value;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
  
  public static enum TextBaseline
  {
    ALPHABETIC("alphabetic"),  BOTTOM("bottom"),  HANGING("hanging"),  IDEOGRAPHIC("ideographic"),  MIDDLE("middle"),  TOP("top");
    
    private final String value;
    
    private TextBaseline(String value)
    {
      this.value = value;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
  
  public final CanvasPattern createPattern(CanvasElement image, Repetition repetition)
  {
    return createPattern(image, repetition.getValue());
  }
  
  public final native CanvasPattern createPattern(CanvasElement paramCanvasElement, String paramString);
  
  public final CanvasPattern createPattern(ImageElement image, Repetition repetition)
  {
    return createPattern(image, repetition.getValue());
  }
  
  public final native CanvasPattern createPattern(ImageElement paramImageElement, String paramString);
  
  public final native CanvasGradient createRadialGradient(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public final native void drawImage(CanvasElement paramCanvasElement, double paramDouble1, double paramDouble2);
  
  public final native void drawImage(CanvasElement paramCanvasElement, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void drawImage(CanvasElement paramCanvasElement, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8);
  
  public final native void drawImage(ImageElement paramImageElement, double paramDouble1, double paramDouble2);
  
  public final native void drawImage(ImageElement paramImageElement, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void drawImage(ImageElement paramImageElement, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8);
  
  public final native void drawImage(VideoElement paramVideoElement, double paramDouble1, double paramDouble2);
  
  public final native void drawImage(VideoElement paramVideoElement, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void drawImage(VideoElement paramVideoElement, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7, double paramDouble8);
  
  public final native void fill();
  
  public final native void fillRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void fillText(String paramString, double paramDouble1, double paramDouble2);
  
  public final native void fillText(String paramString, double paramDouble1, double paramDouble2, double paramDouble3);
  
  public final native CanvasElement getCanvas();
  
  public final FillStrokeStyle getFillStyle()
  {
    if (GWT.isScript()) {
      return getFillStyleWeb();
    }
    return getFillStyleDev();
  }
  
  public final native String getFont();
  
  public final native double getGlobalAlpha();
  
  public final native String getGlobalCompositeOperation();
  
  public final native ImageData getImageData(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native String getLineCap();
  
  public final native String getLineJoin();
  
  public final native double getLineWidth();
  
  public final native double getMiterLimit();
  
  public final native double getShadowBlur();
  
  public final native String getShadowColor();
  
  public final native double getShadowOffsetX();
  
  public final native double getShadowOffsetY();
  
  public final FillStrokeStyle getStrokeStyle()
  {
    if (GWT.isScript()) {
      return getStrokeStyleWeb();
    }
    return getStrokeStyleDev();
  }
  
  public final native String getTextAlign();
  
  public final native String getTextBaseline();
  
  public final native boolean isPointInPath(double paramDouble1, double paramDouble2);
  
  public final native void lineTo(double paramDouble1, double paramDouble2);
  
  public final native TextMetrics measureText(String paramString);
  
  public final native void moveTo(double paramDouble1, double paramDouble2);
  
  public final native void putImageData(ImageData paramImageData, double paramDouble1, double paramDouble2);
  
  public final native void quadraticCurveTo(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void rect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void restore();
  
  public final native void rotate(double paramDouble);
  
  public final native void save();
  
  public final native void scale(double paramDouble1, double paramDouble2);
  
  public final void setFillStyle(FillStrokeStyle fillStyle)
  {
    if (GWT.isScript()) {
      setFillStyleWeb(fillStyle);
    } else {
      setFillStyleDev(fillStyle);
    }
  }
  
  public final void setFillStyle(String fillStyleColor)
  {
    setFillStyle(CssColor.make(fillStyleColor));
  }
  
  public final native void setFont(String paramString);
  
  public final native void setGlobalAlpha(double paramDouble);
  
  public final void setGlobalCompositeOperation(Composite composite)
  {
    setGlobalCompositeOperation(composite.getValue());
  }
  
  public final native void setGlobalCompositeOperation(String paramString);
  
  public final void setLineCap(LineCap lineCap)
  {
    setLineCap(lineCap.getValue());
  }
  
  public final native void setLineCap(String paramString);
  
  public final void setLineJoin(LineJoin lineJoin)
  {
    setLineJoin(lineJoin.getValue());
  }
  
  public final native void setLineJoin(String paramString);
  
  public final native void setLineWidth(double paramDouble);
  
  public final native void setMiterLimit(double paramDouble);
  
  public final native void setShadowBlur(double paramDouble);
  
  public final native void setShadowColor(String paramString);
  
  public final native void setShadowOffsetX(double paramDouble);
  
  public final native void setShadowOffsetY(double paramDouble);
  
  public final void setStrokeStyle(FillStrokeStyle strokeStyle)
  {
    if (GWT.isScript()) {
      setStrokeStyleWeb(strokeStyle);
    } else {
      setStrokeStyleDev(strokeStyle);
    }
  }
  
  public final void setStrokeStyle(String strokeStyleColor)
  {
    setStrokeStyle(CssColor.make(strokeStyleColor));
  }
  
  public final native void setTextAlign(String paramString);
  
  public final void setTextAlign(TextAlign align)
  {
    setTextAlign(align.getValue());
  }
  
  public final native void setTextBaseline(String paramString);
  
  public final void setTextBaseline(TextBaseline baseline)
  {
    setTextBaseline(baseline.getValue());
  }
  
  public final native void setTransform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public final native void stroke();
  
  public final native void strokeRect(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4);
  
  public final native void strokeText(String paramString, double paramDouble1, double paramDouble2);
  
  public final native void strokeText(String paramString, double paramDouble1, double paramDouble2, double paramDouble3);
  
  public final native void transform(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  public final native void translate(double paramDouble1, double paramDouble2);
  
  private native FillStrokeStyle getFillStyleDev();
  
  private native FillStrokeStyle getFillStyleWeb();
  
  private native FillStrokeStyle getStrokeStyleDev();
  
  private native FillStrokeStyle getStrokeStyleWeb();
  
  private native void setFillStyleDev(FillStrokeStyle paramFillStrokeStyle);
  
  private native void setFillStyleWeb(FillStrokeStyle paramFillStrokeStyle);
  
  private native void setStrokeStyleDev(FillStrokeStyle paramFillStrokeStyle);
  
  private native void setStrokeStyleWeb(FillStrokeStyle paramFillStrokeStyle);
}
