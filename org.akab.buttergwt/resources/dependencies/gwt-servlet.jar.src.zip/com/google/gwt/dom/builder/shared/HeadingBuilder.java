package com.google.gwt.dom.builder.shared;

public abstract interface HeadingBuilder
  extends ElementBuilderBase<HeadingBuilder>
{}
