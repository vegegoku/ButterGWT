package com.google.gwt.core.client.impl;

public abstract interface Disposable
{
  public abstract void dispose();
}
