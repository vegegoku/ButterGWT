package com.google.gwt.dev.asm.commons;

import com.google.gwt.dev.asm.Handle;
import com.google.gwt.dev.asm.Label;
import com.google.gwt.dev.asm.MethodVisitor;
import com.google.gwt.dev.asm.Type;

public class InstructionAdapter
  extends MethodVisitor
{
  public static final Type OBJECT_TYPE = Type.getType("Ljava/lang/Object;");
  
  public InstructionAdapter(MethodVisitor mv)
  {
    this(262144, mv);
  }
  
  protected InstructionAdapter(int api, MethodVisitor mv)
  {
    super(api, mv);
  }
  
  public void visitInsn(int opcode)
  {
    switch (opcode)
    {
    case 0: 
      nop();
      break;
    case 1: 
      aconst(null);
      break;
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
    case 7: 
    case 8: 
      iconst(opcode - 3);
      break;
    case 9: 
    case 10: 
      lconst(opcode - 9);
      break;
    case 11: 
    case 12: 
    case 13: 
      fconst(opcode - 11);
      break;
    case 14: 
    case 15: 
      dconst(opcode - 14);
      break;
    case 46: 
      aload(Type.INT_TYPE);
      break;
    case 47: 
      aload(Type.LONG_TYPE);
      break;
    case 48: 
      aload(Type.FLOAT_TYPE);
      break;
    case 49: 
      aload(Type.DOUBLE_TYPE);
      break;
    case 50: 
      aload(OBJECT_TYPE);
      break;
    case 51: 
      aload(Type.BYTE_TYPE);
      break;
    case 52: 
      aload(Type.CHAR_TYPE);
      break;
    case 53: 
      aload(Type.SHORT_TYPE);
      break;
    case 79: 
      astore(Type.INT_TYPE);
      break;
    case 80: 
      astore(Type.LONG_TYPE);
      break;
    case 81: 
      astore(Type.FLOAT_TYPE);
      break;
    case 82: 
      astore(Type.DOUBLE_TYPE);
      break;
    case 83: 
      astore(OBJECT_TYPE);
      break;
    case 84: 
      astore(Type.BYTE_TYPE);
      break;
    case 85: 
      astore(Type.CHAR_TYPE);
      break;
    case 86: 
      astore(Type.SHORT_TYPE);
      break;
    case 87: 
      pop();
      break;
    case 88: 
      pop2();
      break;
    case 89: 
      dup();
      break;
    case 90: 
      dupX1();
      break;
    case 91: 
      dupX2();
      break;
    case 92: 
      dup2();
      break;
    case 93: 
      dup2X1();
      break;
    case 94: 
      dup2X2();
      break;
    case 95: 
      swap();
      break;
    case 96: 
      add(Type.INT_TYPE);
      break;
    case 97: 
      add(Type.LONG_TYPE);
      break;
    case 98: 
      add(Type.FLOAT_TYPE);
      break;
    case 99: 
      add(Type.DOUBLE_TYPE);
      break;
    case 100: 
      sub(Type.INT_TYPE);
      break;
    case 101: 
      sub(Type.LONG_TYPE);
      break;
    case 102: 
      sub(Type.FLOAT_TYPE);
      break;
    case 103: 
      sub(Type.DOUBLE_TYPE);
      break;
    case 104: 
      mul(Type.INT_TYPE);
      break;
    case 105: 
      mul(Type.LONG_TYPE);
      break;
    case 106: 
      mul(Type.FLOAT_TYPE);
      break;
    case 107: 
      mul(Type.DOUBLE_TYPE);
      break;
    case 108: 
      div(Type.INT_TYPE);
      break;
    case 109: 
      div(Type.LONG_TYPE);
      break;
    case 110: 
      div(Type.FLOAT_TYPE);
      break;
    case 111: 
      div(Type.DOUBLE_TYPE);
      break;
    case 112: 
      rem(Type.INT_TYPE);
      break;
    case 113: 
      rem(Type.LONG_TYPE);
      break;
    case 114: 
      rem(Type.FLOAT_TYPE);
      break;
    case 115: 
      rem(Type.DOUBLE_TYPE);
      break;
    case 116: 
      neg(Type.INT_TYPE);
      break;
    case 117: 
      neg(Type.LONG_TYPE);
      break;
    case 118: 
      neg(Type.FLOAT_TYPE);
      break;
    case 119: 
      neg(Type.DOUBLE_TYPE);
      break;
    case 120: 
      shl(Type.INT_TYPE);
      break;
    case 121: 
      shl(Type.LONG_TYPE);
      break;
    case 122: 
      shr(Type.INT_TYPE);
      break;
    case 123: 
      shr(Type.LONG_TYPE);
      break;
    case 124: 
      ushr(Type.INT_TYPE);
      break;
    case 125: 
      ushr(Type.LONG_TYPE);
      break;
    case 126: 
      and(Type.INT_TYPE);
      break;
    case 127: 
      and(Type.LONG_TYPE);
      break;
    case 128: 
      or(Type.INT_TYPE);
      break;
    case 129: 
      or(Type.LONG_TYPE);
      break;
    case 130: 
      xor(Type.INT_TYPE);
      break;
    case 131: 
      xor(Type.LONG_TYPE);
      break;
    case 133: 
      cast(Type.INT_TYPE, Type.LONG_TYPE);
      break;
    case 134: 
      cast(Type.INT_TYPE, Type.FLOAT_TYPE);
      break;
    case 135: 
      cast(Type.INT_TYPE, Type.DOUBLE_TYPE);
      break;
    case 136: 
      cast(Type.LONG_TYPE, Type.INT_TYPE);
      break;
    case 137: 
      cast(Type.LONG_TYPE, Type.FLOAT_TYPE);
      break;
    case 138: 
      cast(Type.LONG_TYPE, Type.DOUBLE_TYPE);
      break;
    case 139: 
      cast(Type.FLOAT_TYPE, Type.INT_TYPE);
      break;
    case 140: 
      cast(Type.FLOAT_TYPE, Type.LONG_TYPE);
      break;
    case 141: 
      cast(Type.FLOAT_TYPE, Type.DOUBLE_TYPE);
      break;
    case 142: 
      cast(Type.DOUBLE_TYPE, Type.INT_TYPE);
      break;
    case 143: 
      cast(Type.DOUBLE_TYPE, Type.LONG_TYPE);
      break;
    case 144: 
      cast(Type.DOUBLE_TYPE, Type.FLOAT_TYPE);
      break;
    case 145: 
      cast(Type.INT_TYPE, Type.BYTE_TYPE);
      break;
    case 146: 
      cast(Type.INT_TYPE, Type.CHAR_TYPE);
      break;
    case 147: 
      cast(Type.INT_TYPE, Type.SHORT_TYPE);
      break;
    case 148: 
      lcmp();
      break;
    case 149: 
      cmpl(Type.FLOAT_TYPE);
      break;
    case 150: 
      cmpg(Type.FLOAT_TYPE);
      break;
    case 151: 
      cmpl(Type.DOUBLE_TYPE);
      break;
    case 152: 
      cmpg(Type.DOUBLE_TYPE);
      break;
    case 172: 
      areturn(Type.INT_TYPE);
      break;
    case 173: 
      areturn(Type.LONG_TYPE);
      break;
    case 174: 
      areturn(Type.FLOAT_TYPE);
      break;
    case 175: 
      areturn(Type.DOUBLE_TYPE);
      break;
    case 176: 
      areturn(OBJECT_TYPE);
      break;
    case 177: 
      areturn(Type.VOID_TYPE);
      break;
    case 190: 
      arraylength();
      break;
    case 191: 
      athrow();
      break;
    case 194: 
      monitorenter();
      break;
    case 195: 
      monitorexit();
      break;
    case 16: 
    case 17: 
    case 18: 
    case 19: 
    case 20: 
    case 21: 
    case 22: 
    case 23: 
    case 24: 
    case 25: 
    case 26: 
    case 27: 
    case 28: 
    case 29: 
    case 30: 
    case 31: 
    case 32: 
    case 33: 
    case 34: 
    case 35: 
    case 36: 
    case 37: 
    case 38: 
    case 39: 
    case 40: 
    case 41: 
    case 42: 
    case 43: 
    case 44: 
    case 45: 
    case 54: 
    case 55: 
    case 56: 
    case 57: 
    case 58: 
    case 59: 
    case 60: 
    case 61: 
    case 62: 
    case 63: 
    case 64: 
    case 65: 
    case 66: 
    case 67: 
    case 68: 
    case 69: 
    case 70: 
    case 71: 
    case 72: 
    case 73: 
    case 74: 
    case 75: 
    case 76: 
    case 77: 
    case 78: 
    case 132: 
    case 153: 
    case 154: 
    case 155: 
    case 156: 
    case 157: 
    case 158: 
    case 159: 
    case 160: 
    case 161: 
    case 162: 
    case 163: 
    case 164: 
    case 165: 
    case 166: 
    case 167: 
    case 168: 
    case 169: 
    case 170: 
    case 171: 
    case 178: 
    case 179: 
    case 180: 
    case 181: 
    case 182: 
    case 183: 
    case 184: 
    case 185: 
    case 186: 
    case 187: 
    case 188: 
    case 189: 
    case 192: 
    case 193: 
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitIntInsn(int opcode, int operand)
  {
    switch (opcode)
    {
    case 16: 
      iconst(operand);
      break;
    case 17: 
      iconst(operand);
      break;
    case 188: 
      switch (operand)
      {
      case 4: 
        newarray(Type.BOOLEAN_TYPE);
        break;
      case 5: 
        newarray(Type.CHAR_TYPE);
        break;
      case 8: 
        newarray(Type.BYTE_TYPE);
        break;
      case 9: 
        newarray(Type.SHORT_TYPE);
        break;
      case 10: 
        newarray(Type.INT_TYPE);
        break;
      case 6: 
        newarray(Type.FLOAT_TYPE);
        break;
      case 11: 
        newarray(Type.LONG_TYPE);
        break;
      case 7: 
        newarray(Type.DOUBLE_TYPE);
        break;
      default: 
        throw new IllegalArgumentException();
      }
      break;
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitVarInsn(int opcode, int var)
  {
    switch (opcode)
    {
    case 21: 
      load(var, Type.INT_TYPE);
      break;
    case 22: 
      load(var, Type.LONG_TYPE);
      break;
    case 23: 
      load(var, Type.FLOAT_TYPE);
      break;
    case 24: 
      load(var, Type.DOUBLE_TYPE);
      break;
    case 25: 
      load(var, OBJECT_TYPE);
      break;
    case 54: 
      store(var, Type.INT_TYPE);
      break;
    case 55: 
      store(var, Type.LONG_TYPE);
      break;
    case 56: 
      store(var, Type.FLOAT_TYPE);
      break;
    case 57: 
      store(var, Type.DOUBLE_TYPE);
      break;
    case 58: 
      store(var, OBJECT_TYPE);
      break;
    case 169: 
      ret(var);
      break;
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitTypeInsn(int opcode, String type)
  {
    Type t = Type.getObjectType(type);
    switch (opcode)
    {
    case 187: 
      anew(t);
      break;
    case 189: 
      newarray(t);
      break;
    case 192: 
      checkcast(t);
      break;
    case 193: 
      instanceOf(t);
      break;
    case 188: 
    case 190: 
    case 191: 
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitFieldInsn(int opcode, String owner, String name, String desc)
  {
    switch (opcode)
    {
    case 178: 
      getstatic(owner, name, desc);
      break;
    case 179: 
      putstatic(owner, name, desc);
      break;
    case 180: 
      getfield(owner, name, desc);
      break;
    case 181: 
      putfield(owner, name, desc);
      break;
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitMethodInsn(int opcode, String owner, String name, String desc)
  {
    switch (opcode)
    {
    case 183: 
      invokespecial(owner, name, desc);
      break;
    case 182: 
      invokevirtual(owner, name, desc);
      break;
    case 184: 
      invokestatic(owner, name, desc);
      break;
    case 185: 
      invokeinterface(owner, name, desc);
      break;
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs)
  {
    invokedynamic(name, desc, bsm, bsmArgs);
  }
  
  public void visitJumpInsn(int opcode, Label label)
  {
    switch (opcode)
    {
    case 153: 
      ifeq(label);
      break;
    case 154: 
      ifne(label);
      break;
    case 155: 
      iflt(label);
      break;
    case 156: 
      ifge(label);
      break;
    case 157: 
      ifgt(label);
      break;
    case 158: 
      ifle(label);
      break;
    case 159: 
      ificmpeq(label);
      break;
    case 160: 
      ificmpne(label);
      break;
    case 161: 
      ificmplt(label);
      break;
    case 162: 
      ificmpge(label);
      break;
    case 163: 
      ificmpgt(label);
      break;
    case 164: 
      ificmple(label);
      break;
    case 165: 
      ifacmpeq(label);
      break;
    case 166: 
      ifacmpne(label);
      break;
    case 167: 
      goTo(label);
      break;
    case 168: 
      jsr(label);
      break;
    case 198: 
      ifnull(label);
      break;
    case 199: 
      ifnonnull(label);
      break;
    case 169: 
    case 170: 
    case 171: 
    case 172: 
    case 173: 
    case 174: 
    case 175: 
    case 176: 
    case 177: 
    case 178: 
    case 179: 
    case 180: 
    case 181: 
    case 182: 
    case 183: 
    case 184: 
    case 185: 
    case 186: 
    case 187: 
    case 188: 
    case 189: 
    case 190: 
    case 191: 
    case 192: 
    case 193: 
    case 194: 
    case 195: 
    case 196: 
    case 197: 
    default: 
      throw new IllegalArgumentException();
    }
  }
  
  public void visitLabel(Label label)
  {
    mark(label);
  }
  
  public void visitLdcInsn(Object cst)
  {
    if ((cst instanceof Integer))
    {
      int val = ((Integer)cst).intValue();
      iconst(val);
    }
    else if ((cst instanceof Byte))
    {
      int val = ((Byte)cst).intValue();
      iconst(val);
    }
    else if ((cst instanceof Character))
    {
      int val = ((Character)cst).charValue();
      iconst(val);
    }
    else if ((cst instanceof Short))
    {
      int val = ((Short)cst).intValue();
      iconst(val);
    }
    else if ((cst instanceof Boolean))
    {
      int val = ((Boolean)cst).booleanValue() ? 1 : 0;
      iconst(val);
    }
    else if ((cst instanceof Float))
    {
      float val = ((Float)cst).floatValue();
      fconst(val);
    }
    else if ((cst instanceof Long))
    {
      long val = ((Long)cst).longValue();
      lconst(val);
    }
    else if ((cst instanceof Double))
    {
      double val = ((Double)cst).doubleValue();
      dconst(val);
    }
    else if ((cst instanceof String))
    {
      aconst(cst);
    }
    else if ((cst instanceof Type))
    {
      tconst((Type)cst);
    }
    else if ((cst instanceof Handle))
    {
      hconst((Handle)cst);
    }
    else
    {
      throw new IllegalArgumentException();
    }
  }
  
  public void visitIincInsn(int var, int increment)
  {
    iinc(var, increment);
  }
  
  public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels)
  {
    tableswitch(min, max, dflt, labels);
  }
  
  public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels)
  {
    lookupswitch(dflt, keys, labels);
  }
  
  public void visitMultiANewArrayInsn(String desc, int dims)
  {
    multianewarray(desc, dims);
  }
  
  public void nop()
  {
    this.mv.visitInsn(0);
  }
  
  public void aconst(Object cst)
  {
    if (cst == null) {
      this.mv.visitInsn(1);
    } else {
      this.mv.visitLdcInsn(cst);
    }
  }
  
  public void iconst(int cst)
  {
    if ((cst >= -1) && (cst <= 5)) {
      this.mv.visitInsn(3 + cst);
    } else if ((cst >= -128) && (cst <= 127)) {
      this.mv.visitIntInsn(16, cst);
    } else if ((cst >= 32768) && (cst <= 32767)) {
      this.mv.visitIntInsn(17, cst);
    } else {
      this.mv.visitLdcInsn(new Integer(cst));
    }
  }
  
  public void lconst(long cst)
  {
    if ((cst == 0L) || (cst == 1L)) {
      this.mv.visitInsn(9 + (int)cst);
    } else {
      this.mv.visitLdcInsn(new Long(cst));
    }
  }
  
  public void fconst(float cst)
  {
    int bits = Float.floatToIntBits(cst);
    if ((bits == 0L) || (bits == 1065353216) || (bits == 1073741824)) {
      this.mv.visitInsn(11 + (int)cst);
    } else {
      this.mv.visitLdcInsn(new Float(cst));
    }
  }
  
  public void dconst(double cst)
  {
    long bits = Double.doubleToLongBits(cst);
    if ((bits == 0L) || (bits == 4607182418800017408L)) {
      this.mv.visitInsn(14 + (int)cst);
    } else {
      this.mv.visitLdcInsn(new Double(cst));
    }
  }
  
  public void tconst(Type type)
  {
    this.mv.visitLdcInsn(type);
  }
  
  public void hconst(Handle handle)
  {
    this.mv.visitLdcInsn(handle);
  }
  
  public void load(int var, Type type)
  {
    this.mv.visitVarInsn(type.getOpcode(21), var);
  }
  
  public void aload(Type type)
  {
    this.mv.visitInsn(type.getOpcode(46));
  }
  
  public void store(int var, Type type)
  {
    this.mv.visitVarInsn(type.getOpcode(54), var);
  }
  
  public void astore(Type type)
  {
    this.mv.visitInsn(type.getOpcode(79));
  }
  
  public void pop()
  {
    this.mv.visitInsn(87);
  }
  
  public void pop2()
  {
    this.mv.visitInsn(88);
  }
  
  public void dup()
  {
    this.mv.visitInsn(89);
  }
  
  public void dup2()
  {
    this.mv.visitInsn(92);
  }
  
  public void dupX1()
  {
    this.mv.visitInsn(90);
  }
  
  public void dupX2()
  {
    this.mv.visitInsn(91);
  }
  
  public void dup2X1()
  {
    this.mv.visitInsn(93);
  }
  
  public void dup2X2()
  {
    this.mv.visitInsn(94);
  }
  
  public void swap()
  {
    this.mv.visitInsn(95);
  }
  
  public void add(Type type)
  {
    this.mv.visitInsn(type.getOpcode(96));
  }
  
  public void sub(Type type)
  {
    this.mv.visitInsn(type.getOpcode(100));
  }
  
  public void mul(Type type)
  {
    this.mv.visitInsn(type.getOpcode(104));
  }
  
  public void div(Type type)
  {
    this.mv.visitInsn(type.getOpcode(108));
  }
  
  public void rem(Type type)
  {
    this.mv.visitInsn(type.getOpcode(112));
  }
  
  public void neg(Type type)
  {
    this.mv.visitInsn(type.getOpcode(116));
  }
  
  public void shl(Type type)
  {
    this.mv.visitInsn(type.getOpcode(120));
  }
  
  public void shr(Type type)
  {
    this.mv.visitInsn(type.getOpcode(122));
  }
  
  public void ushr(Type type)
  {
    this.mv.visitInsn(type.getOpcode(124));
  }
  
  public void and(Type type)
  {
    this.mv.visitInsn(type.getOpcode(126));
  }
  
  public void or(Type type)
  {
    this.mv.visitInsn(type.getOpcode(128));
  }
  
  public void xor(Type type)
  {
    this.mv.visitInsn(type.getOpcode(130));
  }
  
  public void iinc(int var, int increment)
  {
    this.mv.visitIincInsn(var, increment);
  }
  
  public void cast(Type from, Type to)
  {
    if (from != to) {
      if (from == Type.DOUBLE_TYPE)
      {
        if (to == Type.FLOAT_TYPE)
        {
          this.mv.visitInsn(144);
        }
        else if (to == Type.LONG_TYPE)
        {
          this.mv.visitInsn(143);
        }
        else
        {
          this.mv.visitInsn(142);
          cast(Type.INT_TYPE, to);
        }
      }
      else if (from == Type.FLOAT_TYPE)
      {
        if (to == Type.DOUBLE_TYPE)
        {
          this.mv.visitInsn(141);
        }
        else if (to == Type.LONG_TYPE)
        {
          this.mv.visitInsn(140);
        }
        else
        {
          this.mv.visitInsn(139);
          cast(Type.INT_TYPE, to);
        }
      }
      else if (from == Type.LONG_TYPE)
      {
        if (to == Type.DOUBLE_TYPE)
        {
          this.mv.visitInsn(138);
        }
        else if (to == Type.FLOAT_TYPE)
        {
          this.mv.visitInsn(137);
        }
        else
        {
          this.mv.visitInsn(136);
          cast(Type.INT_TYPE, to);
        }
      }
      else if (to == Type.BYTE_TYPE) {
        this.mv.visitInsn(145);
      } else if (to == Type.CHAR_TYPE) {
        this.mv.visitInsn(146);
      } else if (to == Type.DOUBLE_TYPE) {
        this.mv.visitInsn(135);
      } else if (to == Type.FLOAT_TYPE) {
        this.mv.visitInsn(134);
      } else if (to == Type.LONG_TYPE) {
        this.mv.visitInsn(133);
      } else if (to == Type.SHORT_TYPE) {
        this.mv.visitInsn(147);
      }
    }
  }
  
  public void lcmp()
  {
    this.mv.visitInsn(148);
  }
  
  public void cmpl(Type type)
  {
    this.mv.visitInsn(type == Type.FLOAT_TYPE ? 149 : 151);
  }
  
  public void cmpg(Type type)
  {
    this.mv.visitInsn(type == Type.FLOAT_TYPE ? 150 : 152);
  }
  
  public void ifeq(Label label)
  {
    this.mv.visitJumpInsn(153, label);
  }
  
  public void ifne(Label label)
  {
    this.mv.visitJumpInsn(154, label);
  }
  
  public void iflt(Label label)
  {
    this.mv.visitJumpInsn(155, label);
  }
  
  public void ifge(Label label)
  {
    this.mv.visitJumpInsn(156, label);
  }
  
  public void ifgt(Label label)
  {
    this.mv.visitJumpInsn(157, label);
  }
  
  public void ifle(Label label)
  {
    this.mv.visitJumpInsn(158, label);
  }
  
  public void ificmpeq(Label label)
  {
    this.mv.visitJumpInsn(159, label);
  }
  
  public void ificmpne(Label label)
  {
    this.mv.visitJumpInsn(160, label);
  }
  
  public void ificmplt(Label label)
  {
    this.mv.visitJumpInsn(161, label);
  }
  
  public void ificmpge(Label label)
  {
    this.mv.visitJumpInsn(162, label);
  }
  
  public void ificmpgt(Label label)
  {
    this.mv.visitJumpInsn(163, label);
  }
  
  public void ificmple(Label label)
  {
    this.mv.visitJumpInsn(164, label);
  }
  
  public void ifacmpeq(Label label)
  {
    this.mv.visitJumpInsn(165, label);
  }
  
  public void ifacmpne(Label label)
  {
    this.mv.visitJumpInsn(166, label);
  }
  
  public void goTo(Label label)
  {
    this.mv.visitJumpInsn(167, label);
  }
  
  public void jsr(Label label)
  {
    this.mv.visitJumpInsn(168, label);
  }
  
  public void ret(int var)
  {
    this.mv.visitVarInsn(169, var);
  }
  
  public void tableswitch(int min, int max, Label dflt, Label... labels)
  {
    this.mv.visitTableSwitchInsn(min, max, dflt, labels);
  }
  
  public void lookupswitch(Label dflt, int[] keys, Label[] labels)
  {
    this.mv.visitLookupSwitchInsn(dflt, keys, labels);
  }
  
  public void areturn(Type t)
  {
    this.mv.visitInsn(t.getOpcode(172));
  }
  
  public void getstatic(String owner, String name, String desc)
  {
    this.mv.visitFieldInsn(178, owner, name, desc);
  }
  
  public void putstatic(String owner, String name, String desc)
  {
    this.mv.visitFieldInsn(179, owner, name, desc);
  }
  
  public void getfield(String owner, String name, String desc)
  {
    this.mv.visitFieldInsn(180, owner, name, desc);
  }
  
  public void putfield(String owner, String name, String desc)
  {
    this.mv.visitFieldInsn(181, owner, name, desc);
  }
  
  public void invokevirtual(String owner, String name, String desc)
  {
    this.mv.visitMethodInsn(182, owner, name, desc);
  }
  
  public void invokespecial(String owner, String name, String desc)
  {
    this.mv.visitMethodInsn(183, owner, name, desc);
  }
  
  public void invokestatic(String owner, String name, String desc)
  {
    this.mv.visitMethodInsn(184, owner, name, desc);
  }
  
  public void invokeinterface(String owner, String name, String desc)
  {
    this.mv.visitMethodInsn(185, owner, name, desc);
  }
  
  public void invokedynamic(String name, String desc, Handle bsm, Object[] bsmArgs)
  {
    this.mv.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs);
  }
  
  public void anew(Type type)
  {
    this.mv.visitTypeInsn(187, type.getInternalName());
  }
  
  public void newarray(Type type)
  {
    int typ;
    switch (type.getSort())
    {
    case 1: 
      typ = 4;
      break;
    case 2: 
      typ = 5;
      break;
    case 3: 
      typ = 8;
      break;
    case 4: 
      typ = 9;
      break;
    case 5: 
      typ = 10;
      break;
    case 6: 
      typ = 6;
      break;
    case 7: 
      typ = 11;
      break;
    case 8: 
      typ = 7;
      break;
    default: 
      this.mv.visitTypeInsn(189, type.getInternalName());
      return;
    }
    this.mv.visitIntInsn(188, typ);
  }
  
  public void arraylength()
  {
    this.mv.visitInsn(190);
  }
  
  public void athrow()
  {
    this.mv.visitInsn(191);
  }
  
  public void checkcast(Type type)
  {
    this.mv.visitTypeInsn(192, type.getInternalName());
  }
  
  public void instanceOf(Type type)
  {
    this.mv.visitTypeInsn(193, type.getInternalName());
  }
  
  public void monitorenter()
  {
    this.mv.visitInsn(194);
  }
  
  public void monitorexit()
  {
    this.mv.visitInsn(195);
  }
  
  public void multianewarray(String desc, int dims)
  {
    this.mv.visitMultiANewArrayInsn(desc, dims);
  }
  
  public void ifnull(Label label)
  {
    this.mv.visitJumpInsn(198, label);
  }
  
  public void ifnonnull(Label label)
  {
    this.mv.visitJumpInsn(199, label);
  }
  
  public void mark(Label label)
  {
    this.mv.visitLabel(label);
  }
}
