package com.google.gwt.dom.builder.shared;

import com.google.gwt.safehtml.shared.SafeUri;

public abstract interface FrameBuilder
  extends ElementBuilderBase<FrameBuilder>
{
  public abstract FrameBuilder frameBorder(int paramInt);
  
  public abstract FrameBuilder longDesc(SafeUri paramSafeUri);
  
  public abstract FrameBuilder longDesc(String paramString);
  
  public abstract FrameBuilder marginHeight(int paramInt);
  
  public abstract FrameBuilder marginWidth(int paramInt);
  
  public abstract FrameBuilder name(String paramString);
  
  public abstract FrameBuilder noResize();
  
  public abstract FrameBuilder scrolling(String paramString);
  
  public abstract FrameBuilder src(SafeUri paramSafeUri);
  
  public abstract FrameBuilder src(String paramString);
}
