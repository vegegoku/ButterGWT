package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class GridRoleImpl
  extends RoleImpl
  implements GridRole
{
  GridRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaActivedescendantProperty(Element element)
  {
    return Property.ACTIVEDESCENDANT.get(element);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaLevelProperty(Element element)
  {
    return Property.LEVEL.get(element);
  }
  
  public String getAriaMultiselectableProperty(Element element)
  {
    return Property.MULTISELECTABLE.get(element);
  }
  
  public String getAriaReadonlyProperty(Element element)
  {
    return Property.READONLY.get(element);
  }
  
  public void removeAriaActivedescendantProperty(Element element)
  {
    Property.ACTIVEDESCENDANT.remove(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaLevelProperty(Element element)
  {
    Property.LEVEL.remove(element);
  }
  
  public void removeAriaMultiselectableProperty(Element element)
  {
    Property.MULTISELECTABLE.remove(element);
  }
  
  public void removeAriaReadonlyProperty(Element element)
  {
    Property.READONLY.remove(element);
  }
  
  public void setAriaActivedescendantProperty(Element element, Id value)
  {
    Property.ACTIVEDESCENDANT.set(element, new Id[] { value });
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaLevelProperty(Element element, int value)
  {
    Property.LEVEL.set(element, new Integer[] { Integer.valueOf(value) });
  }
  
  public void setAriaMultiselectableProperty(Element element, boolean value)
  {
    Property.MULTISELECTABLE.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaReadonlyProperty(Element element, boolean value)
  {
    Property.READONLY.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
}
