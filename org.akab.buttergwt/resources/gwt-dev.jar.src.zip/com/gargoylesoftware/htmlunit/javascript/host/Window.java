package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.AlertHandler;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ConfirmHandler;
import com.gargoylesoftware.htmlunit.DialogWindow;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.PromptHandler;
import com.gargoylesoftware.htmlunit.ScriptException;
import com.gargoylesoftware.htmlunit.ScriptResult;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.StatusHandler;
import com.gargoylesoftware.htmlunit.StorageHolder;
import com.gargoylesoftware.htmlunit.StorageHolder.Type;
import com.gargoylesoftware.htmlunit.TopLevelWindow;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.WebWindowNotFoundException;
import com.gargoylesoftware.htmlunit.html.BaseFrameElement;
import com.gargoylesoftware.htmlunit.html.DomChangeEvent;
import com.gargoylesoftware.htmlunit.html.DomChangeListener;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.FrameWindow;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeEvent;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeListener;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlLink;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlStyle;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.PostponedAction;
import com.gargoylesoftware.htmlunit.javascript.ScriptableWithFallbackGetter;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.background.BackgroundJavaScriptFactory;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptJob;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptJobManager;
import com.gargoylesoftware.htmlunit.javascript.configuration.CanSetReadOnly;
import com.gargoylesoftware.htmlunit.javascript.configuration.CanSetReadOnlyStatus;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleDeclaration;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet;
import com.gargoylesoftware.htmlunit.javascript.host.css.ComputedCSSStyleDeclaration;
import com.gargoylesoftware.htmlunit.javascript.host.css.StyleSheetList;
import com.gargoylesoftware.htmlunit.javascript.host.html.DocumentProxy;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLBodyElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCollection;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLUnknownElement;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLDocument;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.FunctionObject;
import net.sourceforge.htmlunit.corejs.javascript.ScriptRuntime;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@JsxClass
public class Window
  extends SimpleScriptable
  implements ScriptableWithFallbackGetter, Function
{
  private static final Log LOG = LogFactory.getLog(Window.class);
  private static final int MIN_TIMER_DELAY = 1;
  private Document document_;
  private DocumentProxy documentProxy_;
  private Navigator navigator_;
  private WebWindow webWindow_;
  private WindowProxy windowProxy_;
  private Screen screen_;
  private History history_;
  private Location location_;
  private ScriptableObject console_;
  private OfflineResourceList applicationCache_;
  private Selection selection_;
  private Event currentEvent_;
  private String status_ = "";
  private HTMLCollection frames_;
  private Map<Class<? extends SimpleScriptable>, Scriptable> prototypes_ = new HashMap();
  private EventListenersContainer eventListenersContainer_;
  private Object controllers_;
  private Object opener_;
  private Object top_ = NOT_FOUND;
  private transient WeakHashMap<Node, ComputedCSSStyleDeclaration> computedStyles_ = new WeakHashMap();
  private final Map<StorageHolder.Type, Storage> storages_ = new HashMap();
  private StorageList storageList_;
  
  private void readObject(ObjectInputStream stream)
    throws IOException, ClassNotFoundException
  {
    stream.defaultReadObject();
    this.computedStyles_ = new WeakHashMap();
  }
  
  public Scriptable getPrototype(Class<? extends SimpleScriptable> jsClass)
  {
    return (Scriptable)this.prototypes_.get(jsClass);
  }
  
  public void setPrototypes(Map<Class<? extends SimpleScriptable>, Scriptable> map)
  {
    this.prototypes_ = map;
  }
  
  @JsxFunction
  public void alert(Object message)
  {
    String stringMessage = Context.toString(message);
    AlertHandler handler = getWebWindow().getWebClient().getAlertHandler();
    if (handler == null) {
      LOG.warn("window.alert(\"" + stringMessage + "\") no alert handler installed");
    } else {
      handler.handleAlert(((HTMLDocument)this.document_).getHtmlPage(), stringMessage);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String btoa(String stringToEncode)
  {
    return new String(Base64.encodeBase64(stringToEncode.getBytes()));
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String atob(String encodedData)
  {
    return new String(Base64.decodeBase64(encodedData.getBytes()));
  }
  
  @JsxFunction
  public boolean confirm(String message)
  {
    ConfirmHandler handler = getWebWindow().getWebClient().getConfirmHandler();
    if (handler == null)
    {
      LOG.warn("window.confirm(\"" + message + "\") no confirm handler installed, simulating the OK button");
      
      return true;
    }
    return handler.handleConfirm(((HTMLDocument)this.document_).getHtmlPage(), message);
  }
  
  @JsxFunction
  public String prompt(String message)
  {
    PromptHandler handler = getWebWindow().getWebClient().getPromptHandler();
    if (handler == null)
    {
      LOG.warn("window.prompt(\"" + message + "\") no prompt handler installed");
      return null;
    }
    return handler.handlePrompt(((HTMLDocument)this.document_).getHtmlPage(), message);
  }
  
  @JsxGetter(propertyName="document")
  public DocumentProxy getDocument_js()
  {
    return this.documentProxy_;
  }
  
  public Document getDocument()
  {
    return this.document_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public OfflineResourceList getApplicationCache()
  {
    return this.applicationCache_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getEvent()
  {
    return this.currentEvent_;
  }
  
  public Event getCurrentEvent()
  {
    return this.currentEvent_;
  }
  
  void setCurrentEvent(Event event)
  {
    this.currentEvent_ = event;
  }
  
  @JsxFunction
  public WindowProxy open(Object url, Object name, Object features, Object replace)
  {
    String urlString = null;
    if (url != Undefined.instance) {
      urlString = Context.toString(url);
    }
    String windowName = "";
    if (name != Undefined.instance) {
      windowName = Context.toString(name);
    }
    String featuresString = null;
    if (features != Undefined.instance) {
      featuresString = Context.toString(features);
    }
    WebClient webClient = getWebWindow().getWebClient();
    if (webClient.getOptions().isPopupBlockerEnabled())
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("Ignoring window.open() invocation because popups are blocked.");
      }
      return null;
    }
    boolean replaceCurrentEntryInBrowsingHistory = false;
    if (replace != Undefined.instance) {
      replaceCurrentEntryInBrowsingHistory = Context.toBoolean(replace);
    }
    if (((featuresString != null) || (replaceCurrentEntryInBrowsingHistory)) && 
      (LOG.isDebugEnabled())) {
      LOG.debug("window.open: features and replaceCurrentEntryInBrowsingHistory not implemented: url=[" + urlString + "] windowName=[" + windowName + "] features=[" + featuresString + "] replaceCurrentEntry=[" + replaceCurrentEntryInBrowsingHistory + "]");
    }
    if ((StringUtils.isEmpty(urlString)) && (!"".equals(windowName))) {
      try
      {
        WebWindow webWindow = webClient.getWebWindowByName(windowName);
        return getProxy(webWindow);
      }
      catch (WebWindowNotFoundException e) {}
    }
    URL newUrl = makeUrlForOpenWindow(urlString);
    WebWindow newWebWindow = webClient.openWindow(newUrl, windowName, this.webWindow_);
    return getProxy(newWebWindow);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Popup createPopup()
  {
    Popup popup = new Popup();
    popup.setParentScope(this);
    popup.setPrototype(getPrototype(Popup.class));
    popup.init(this);
    return popup;
  }
  
  private URL makeUrlForOpenWindow(String urlString)
  {
    if (urlString.isEmpty()) {
      return WebClient.URL_ABOUT_BLANK;
    }
    try
    {
      Page page = getWebWindow().getEnclosedPage();
      if ((page != null) && (page.isHtmlPage())) {
        return ((HtmlPage)page).getFullyQualifiedUrl(urlString);
      }
      return new URL(urlString);
    }
    catch (MalformedURLException e)
    {
      LOG.error("Unable to create URL for openWindow: relativeUrl=[" + urlString + "]", e);
    }
    return null;
  }
  
  @JsxFunction
  public int setTimeout(Object code, int timeout, Object language)
  {
    if (timeout < 1) {
      timeout = 1;
    }
    if (code == null) {
      throw Context.reportRuntimeError("Function not provided.");
    }
    WebWindow webWindow = getWebWindow();
    Page page = (Page)getDomNodeOrNull();
    int id;
    if ((code instanceof String))
    {
      String s = (String)code;
      String description = "window.setTimeout(" + s + ", " + timeout + ")";
      JavaScriptJob job = BackgroundJavaScriptFactory.theFactory().createJavaScriptJob(timeout, null, description, webWindow, s);
      
      id = webWindow.getJobManager().addJob(job, page);
    }
    else
    {
      int id;
      if ((code instanceof Function))
      {
        Function f = (Function)code;
        String functionName;
        String functionName;
        if ((f instanceof FunctionObject)) {
          functionName = ((FunctionObject)f).getFunctionName();
        } else {
          functionName = String.valueOf(f);
        }
        String description = "window.setTimeout(" + functionName + ", " + timeout + ")";
        JavaScriptJob job = BackgroundJavaScriptFactory.theFactory().createJavaScriptJob(timeout, null, description, webWindow, f);
        
        id = webWindow.getJobManager().addJob(job, page);
      }
      else
      {
        throw Context.reportRuntimeError("Unknown type for function.");
      }
    }
    int id;
    return id;
  }
  
  @JsxFunction
  public void clearTimeout(int timeoutId)
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("clearTimeout(" + timeoutId + ")");
    }
    getWebWindow().getJobManager().removeJob(timeoutId);
  }
  
  @JsxGetter
  public Navigator getNavigator()
  {
    return this.navigator_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Navigator getClientInformation()
  {
    return this.navigator_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public ClipboardData getClipboardData()
  {
    ClipboardData clipboardData = new ClipboardData();
    clipboardData.setParentScope(this);
    clipboardData.setPrototype(getPrototype(clipboardData.getClass()));
    return clipboardData;
  }
  
  @JsxGetter(propertyName="window")
  public WindowProxy getWindow_js()
  {
    return this.windowProxy_;
  }
  
  @JsxGetter
  public WindowProxy getSelf()
  {
    return this.windowProxy_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Storage getLocalStorage()
  {
    return getStorage(StorageHolder.Type.LOCAL_STORAGE);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Storage getSessionStorage()
  {
    return getStorage(StorageHolder.Type.SESSION_STORAGE);
  }
  
  public Storage getStorage(StorageHolder.Type storageType)
  {
    Storage storage = (Storage)this.storages_.get(storageType);
    if (storage == null)
    {
      WebWindow webWindow = getWebWindow();
      Map<String, String> store = webWindow.getWebClient().getStorageHolder().getStore(storageType, webWindow.getEnclosedPage());
      
      storage = new Storage(this, store);
      this.storages_.put(storageType, storage);
    }
    return storage;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, maxVersion=10.0F)})
  public StorageList getGlobalStorage()
  {
    if (this.storageList_ == null)
    {
      this.storageList_ = new StorageList();
      this.storageList_.setParentScope(this);
      this.storageList_.setPrototype(getPrototype(StorageList.class));
    }
    return this.storageList_;
  }
  
  @JsxGetter
  public Location getLocation()
  {
    return this.location_;
  }
  
  @JsxSetter
  public void setLocation(String newLocation)
    throws IOException
  {
    this.location_.setHref(newLocation);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=4.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=9.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public ScriptableObject getConsole()
  {
    return this.console_;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=4.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=9.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void setConsole(ScriptableObject console)
  {
    this.console_ = console;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void dump(String message)
  {
    if ((this.console_ instanceof Console)) {
      Console.log(null, this.console_, new Object[] { message }, null);
    }
  }
  
  @JsxGetter
  public Screen getScreen()
  {
    return this.screen_;
  }
  
  @JsxGetter
  public History getHistory()
  {
    return this.history_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public External getExternal()
  {
    External external = new External();
    external.setParentScope(this);
    external.setPrototype(getPrototype(external.getClass()));
    return external;
  }
  
  public void initialize(WebWindow webWindow)
  {
    this.webWindow_ = webWindow;
    this.webWindow_.setScriptObject(this);
    
    this.windowProxy_ = new WindowProxy(this.webWindow_);
    
    Page enclosedPage = webWindow.getEnclosedPage();
    if ((enclosedPage instanceof XmlPage)) {
      this.document_ = new XMLDocument();
    } else {
      this.document_ = new HTMLDocument();
    }
    this.document_.setParentScope(this);
    this.document_.setPrototype(getPrototype(this.document_.getClass()));
    this.document_.setWindow(this);
    if ((enclosedPage instanceof SgmlPage))
    {
      SgmlPage page = (SgmlPage)enclosedPage;
      this.document_.setDomNode(page);
      
      DomHtmlAttributeChangeListenerImpl listener = new DomHtmlAttributeChangeListenerImpl(null);
      page.addDomChangeListener(listener);
      if (page.isHtmlPage()) {
        ((HtmlPage)page).addHtmlAttributeChangeListener(listener);
      }
    }
    this.documentProxy_ = new DocumentProxy(this.webWindow_);
    
    this.navigator_ = new Navigator();
    this.navigator_.setParentScope(this);
    this.navigator_.setPrototype(getPrototype(this.navigator_.getClass()));
    
    this.screen_ = new Screen();
    this.screen_.setParentScope(this);
    this.screen_.setPrototype(getPrototype(this.screen_.getClass()));
    
    this.history_ = new History();
    this.history_.setParentScope(this);
    this.history_.setPrototype(getPrototype(this.history_.getClass()));
    
    this.location_ = new Location();
    this.location_.setParentScope(this);
    this.location_.setPrototype(getPrototype(this.location_.getClass()));
    this.location_.initialize(this);
    
    this.console_ = new Console();
    ((Console)this.console_).setWebWindow(this.webWindow_);
    this.console_.setParentScope(this);
    ((Console)this.console_).setPrototype(getPrototype(((SimpleScriptable)this.console_).getClass()));
    
    this.applicationCache_ = new OfflineResourceList();
    this.applicationCache_.setParentScope(this);
    this.applicationCache_.setPrototype(getPrototype(this.applicationCache_.getClass()));
    
    Context ctx = Context.getCurrentContext();
    this.controllers_ = ctx.newObject(this);
    if ((this.webWindow_ instanceof TopLevelWindow))
    {
      WebWindow opener = ((TopLevelWindow)this.webWindow_).getOpener();
      if (opener != null) {
        this.opener_ = opener.getScriptObject();
      }
    }
  }
  
  public void initialize(Page enclosedPage)
  {
    if ((enclosedPage != null) && (enclosedPage.isHtmlPage()))
    {
      HtmlPage htmlPage = (HtmlPage)enclosedPage;
      
      setDomNode(htmlPage);
      this.eventListenersContainer_ = null;
      
      WebAssert.notNull("document_", this.document_);
      this.document_.setDomNode(htmlPage);
    }
  }
  
  public void initialize() {}
  
  @JsxGetter
  public Object getTop()
  {
    if (this.top_ != NOT_FOUND) {
      return this.top_;
    }
    WebWindow top = getWebWindow().getTopWindow();
    return getProxy(top);
  }
  
  @JsxSetter
  public void setTop(Object o)
  {
    this.top_ = o;
  }
  
  @JsxGetter
  public WindowProxy getParent()
  {
    WebWindow parent = getWebWindow().getParentWindow();
    return getProxy(parent);
  }
  
  @JsxGetter
  public Object getOpener()
  {
    Object opener = this.opener_;
    if ((opener instanceof Window)) {
      opener = ((Window)opener).windowProxy_;
    }
    return opener;
  }
  
  @JsxSetter
  public void setOpener(Object newValue)
  {
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_WINDOW_CHANGE_OPENER_NOT_ALLOWED)) && (newValue != this.opener_)) {
      if ((this.opener_ == null) || (newValue == null) || (newValue == Context.getUndefinedValue())) {
        newValue = null;
      } else {
        throw Context.reportRuntimeError("Can't set opener!");
      }
    }
    this.opener_ = newValue;
  }
  
  @JsxGetter
  public Object getFrameElement()
  {
    WebWindow window = getWebWindow();
    if ((window instanceof FrameWindow)) {
      return ((FrameWindow)window).getFrameElement().getScriptObject();
    }
    return null;
  }
  
  @JsxGetter(propertyName="frames")
  public WindowProxy getFrames_js()
  {
    return this.windowProxy_;
  }
  
  @JsxGetter
  public int getLength()
  {
    return getFrames().getLength();
  }
  
  private HTMLCollection getFrames()
  {
    if (this.frames_ == null)
    {
      HtmlPage page = (HtmlPage)getWebWindow().getEnclosedPage();
      this.frames_ = new HTMLCollectionFrames(page);
    }
    return this.frames_;
  }
  
  public WebWindow getWebWindow()
  {
    return this.webWindow_;
  }
  
  @JsxFunction
  public void focus()
  {
    WebWindow window = getWebWindow();
    window.getWebClient().setCurrentWindow(window);
  }
  
  @JsxFunction
  public void blur()
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("window.blur() not implemented");
    }
  }
  
  @JsxFunction
  public void close()
  {
    WebWindow webWindow = getWebWindow();
    if ((webWindow instanceof TopLevelWindow)) {
      ((TopLevelWindow)webWindow).close();
    } else {
      webWindow.getWebClient().deregisterWebWindow(webWindow);
    }
  }
  
  @JsxGetter
  @CanSetReadOnly(CanSetReadOnlyStatus.IGNORE)
  public boolean getClosed()
  {
    WebWindow webWindow = getWebWindow();
    return !webWindow.getWebClient().containsWebWindow(webWindow);
  }
  
  @JsxFunction
  public void moveTo(int x, int y)
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("window.moveTo() not implemented");
    }
  }
  
  @JsxFunction
  public void moveBy(int x, int y)
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("window.moveBy() not implemented");
    }
  }
  
  @JsxFunction
  public void resizeBy(int width, int height)
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("window.resizeBy() not implemented");
    }
  }
  
  @JsxFunction
  public void resizeTo(int width, int height)
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("window.resizeTo() not implemented");
    }
  }
  
  @JsxFunction
  public void scroll(int x, int y)
  {
    scrollTo(x, y);
  }
  
  @JsxFunction
  public void scrollBy(int x, int y)
  {
    HTMLElement body = ((HTMLDocument)this.document_).getBody();
    if (body != null)
    {
      body.setScrollLeft(body.getScrollLeft() + x);
      body.setScrollTop(body.getScrollTop() + y);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void scrollByLines(int lines)
  {
    HTMLElement body = ((HTMLDocument)this.document_).getBody();
    if (body != null) {
      body.setScrollTop(body.getScrollTop() + 19 * lines);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void scrollByPages(int pages)
  {
    HTMLElement body = ((HTMLDocument)this.document_).getBody();
    if (body != null) {
      body.setScrollTop(body.getScrollTop() + getInnerHeight() * pages);
    }
  }
  
  @JsxFunction
  public void scrollTo(int x, int y)
  {
    HTMLElement body = ((HTMLDocument)this.document_).getBody();
    if (body != null)
    {
      body.setScrollLeft(x);
      body.setScrollTop(y);
    }
  }
  
  @JsxSetter
  public void setOnload(Object newOnload)
  {
    getEventListenersContainer().setEventHandlerProp("load", newOnload);
  }
  
  @JsxSetter
  public void setOnclick(Object newOnload)
  {
    getEventListenersContainer().setEventHandlerProp("click", newOnload);
  }
  
  @JsxGetter
  public Object getOnclick()
  {
    return getEventListenersContainer().getEventHandlerProp("click");
  }
  
  @JsxSetter
  public void setOndblclick(Object newHandler)
  {
    getEventListenersContainer().setEventHandlerProp("dblclick", newHandler);
  }
  
  @JsxGetter
  public Object getOndblclick()
  {
    return getEventListenersContainer().getEventHandlerProp("dblclick");
  }
  
  @JsxGetter
  public Object getOnload()
  {
    Object onload = getEventListenersContainer().getEventHandlerProp("load");
    if (onload == null)
    {
      HtmlPage page = (HtmlPage)getWebWindow().getEnclosedPage();
      HtmlElement body = page.getBody();
      if (body != null)
      {
        HTMLBodyElement b = (HTMLBodyElement)body.getScriptObject();
        return b.getEventHandler("onload");
      }
      return null;
    }
    return onload;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getOnhashchange()
  {
    return getEventListenersContainer().getEventHandlerProp("hashchange");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOnhashchange(Object newHandler)
  {
    getEventListenersContainer().setEventHandlerProp("hashchange", newHandler);
  }
  
  public EventListenersContainer getEventListenersContainer()
  {
    if (this.eventListenersContainer_ == null) {
      this.eventListenersContainer_ = new EventListenersContainer(this);
    }
    return this.eventListenersContainer_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean attachEvent(String type, Function listener)
  {
    return getEventListenersContainer().addEventListener(StringUtils.substring(type, 2), listener, false);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void addEventListener(String type, Function listener, boolean useCapture)
  {
    getEventListenersContainer().addEventListener(type, listener, useCapture);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void detachEvent(String type, Function listener)
  {
    getEventListenersContainer().removeEventListener(StringUtils.substring(type, 2), listener, false);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void removeEventListener(String type, Function listener, boolean useCapture)
  {
    getEventListenersContainer().removeEventListener(type, listener, useCapture);
  }
  
  @JsxGetter
  public String getName()
  {
    return getWebWindow().getName();
  }
  
  @JsxSetter
  public void setName(String name)
  {
    getWebWindow().setName(name);
  }
  
  @JsxGetter
  public Object getOnbeforeunload()
  {
    return getHandlerForJavaScript("beforeunload");
  }
  
  @JsxSetter
  public void setOnbeforeunload(Object onbeforeunload)
  {
    setHandlerForJavaScript("beforeunload", onbeforeunload);
  }
  
  @JsxGetter
  public Object getOnerror()
  {
    return getHandlerForJavaScript("error");
  }
  
  @JsxSetter
  public void setOnerror(Object onerror)
  {
    setHandlerForJavaScript("error", onerror);
  }
  
  public void triggerOnError(ScriptException e)
  {
    Object o = getOnerror();
    if ((o instanceof Function))
    {
      Function f = (Function)o;
      String msg = e.getMessage();
      String url = e.getPage().getUrl().toExternalForm();
      int line = e.getFailingLineNumber();
      Object[] args = { msg, url, Integer.valueOf(line) };
      f.call(Context.getCurrentContext(), this, this, args);
    }
  }
  
  private Object getHandlerForJavaScript(String eventName)
  {
    Object handler = getEventListenersContainer().getEventHandlerProp(eventName);
    if ((handler == null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_HANDLER_UNDEFINED))) {
      handler = Scriptable.NOT_FOUND;
    }
    return handler;
  }
  
  private void setHandlerForJavaScript(String eventName, Object handler)
  {
    if ((handler == null) || ((handler instanceof Function))) {
      getEventListenersContainer().setEventHandlerProp(eventName, handler);
    }
  }
  
  public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
  {
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_WINDOW_IS_NOT_A_FUNCTION)) {
      throw Context.reportRuntimeError("Window is not a function.");
    }
    if (args.length > 0)
    {
      Object arg = args[0];
      if ((arg instanceof String)) {
        return ScriptableObject.getProperty(this, (String)arg);
      }
      if ((arg instanceof Number)) {
        return ScriptableObject.getProperty(this, ((Number)arg).intValue());
      }
    }
    return Context.getUndefinedValue();
  }
  
  public Scriptable construct(Context cx, Scriptable scope, Object[] args)
  {
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_WINDOW_IS_NOT_A_FUNCTION)) {
      throw Context.reportRuntimeError("Window is not a function.");
    }
    return null;
  }
  
  public Object getWithFallback(String name)
  {
    Object result = NOT_FOUND;
    
    DomNode domNode = getDomNodeOrNull();
    if (domNode != null)
    {
      HtmlPage page = (HtmlPage)domNode.getPage();
      result = getFrameWindowByName(page, name);
      if (result == NOT_FOUND)
      {
        List<DomElement> elements = page.getElementsByName(name);
        if (elements.size() == 1) {
          result = getScriptableFor(elements.get(0));
        } else if (elements.size() > 1) {
          result = ((HTMLDocument)this.document_).getElementsByName(name);
        } else {
          try
          {
            HtmlElement htmlElement = page.getHtmlElementById(name);
            result = getScriptableFor(htmlElement);
          }
          catch (ElementNotFoundException e)
          {
            result = NOT_FOUND;
          }
        }
      }
      if ((result instanceof Window))
      {
        WebWindow webWindow = ((Window)result).getWebWindow();
        result = getProxy(webWindow);
      }
      else if (((result instanceof HTMLUnknownElement)) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_XML_SUPPORT_VIA_ACTIVEXOBJECT)))
      {
        HtmlElement unknownElement = ((HTMLUnknownElement)result).getDomNodeOrDie();
        if ("xml".equals(unknownElement.getNodeName()))
        {
          XMLDocument document = ActiveXObject.buildXMLDocument(getWebWindow());
          document.setParentScope(this);
          Iterator<HtmlElement> children = unknownElement.getHtmlElementDescendants().iterator();
          if (children.hasNext())
          {
            HtmlElement root = (HtmlElement)children.next();
            document.loadXML(root.asXml().trim());
          }
          result = document;
        }
      }
    }
    return result;
  }
  
  public Object get(int index, Scriptable start)
  {
    HTMLCollection frames = getFrames();
    if (index >= frames.getLength()) {
      return Context.getUndefinedValue();
    }
    return frames.item(Integer.valueOf(index));
  }
  
  public Object get(String name, Scriptable start)
  {
    if ("Option".equals(name)) {
      name = "HTMLOptionElement";
    } else if ("Image".equals(name)) {
      name = "HTMLImageElement";
    }
    return super.get(name, start);
  }
  
  private static Object getFrameWindowByName(HtmlPage page, String name)
  {
    try
    {
      return page.getFrameByName(name).getScriptObject();
    }
    catch (ElementNotFoundException e) {}
    return NOT_FOUND;
  }
  
  public static WindowProxy getProxy(WebWindow w)
  {
    return ((Window)w.getScriptObject()).windowProxy_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void execScript(String script, Object language)
  {
    String languageStr = Context.toString(language);
    if ((language == Undefined.instance) || ("javascript".equalsIgnoreCase(languageStr)) || ("jscript".equalsIgnoreCase(languageStr))) {
      ScriptRuntime.evalSpecial(Context.getCurrentContext(), this, this, new Object[] { script }, null, 0);
    } else if ("vbscript".equalsIgnoreCase(languageStr)) {
      LOG.warn("VBScript not supported in Window.execScript().");
    } else {
      throw Context.reportRuntimeError("Invalid class string");
    }
  }
  
  @JsxGetter
  public String getStatus()
  {
    return this.status_;
  }
  
  @JsxSetter
  public void setStatus(String message)
  {
    this.status_ = message;
    
    StatusHandler statusHandler = this.webWindow_.getWebClient().getStatusHandler();
    if (statusHandler != null) {
      statusHandler.statusMessageChanged(this.webWindow_.getEnclosedPage(), message);
    }
  }
  
  @JsxFunction
  public int setInterval(Object code, int timeout, Object language)
  {
    if ((timeout == 0) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_133))) {
      return setTimeout(code, timeout, language);
    }
    if (timeout < 1) {
      timeout = 1;
    }
    WebWindow w = getWebWindow();
    Page page = (Page)getDomNodeOrNull();
    String description = "window.setInterval(" + timeout + ")";
    if (code == null) {
      throw Context.reportRuntimeError("Function not provided.");
    }
    int id;
    if ((code instanceof String))
    {
      String s = (String)code;
      JavaScriptJob job = BackgroundJavaScriptFactory.theFactory().createJavaScriptJob(timeout, Integer.valueOf(timeout), description, w, s);
      
      id = getWebWindow().getJobManager().addJob(job, page);
    }
    else
    {
      int id;
      if ((code instanceof Function))
      {
        Function f = (Function)code;
        JavaScriptJob job = BackgroundJavaScriptFactory.theFactory().createJavaScriptJob(timeout, Integer.valueOf(timeout), description, w, f);
        
        id = getWebWindow().getJobManager().addJob(job, page);
      }
      else
      {
        throw Context.reportRuntimeError("Unknown type for function.");
      }
    }
    int id;
    return id;
  }
  
  @JsxFunction
  public void clearInterval(int intervalID)
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("clearInterval(" + intervalID + ")");
    }
    getWebWindow().getJobManager().removeJob(intervalID);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getInnerWidth()
  {
    return getWebWindow().getInnerWidth();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getOuterWidth()
  {
    return getWebWindow().getOuterWidth();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getInnerHeight()
  {
    return getWebWindow().getInnerHeight();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getOuterHeight()
  {
    return getWebWindow().getOuterHeight();
  }
  
  @JsxFunction
  public void print()
  {
    if (LOG.isDebugEnabled()) {
      LOG.debug("window.print() not implemented");
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void captureEvents(String type) {}
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void CollectGarbage() {}
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public ComputedCSSStyleDeclaration getComputedStyle(Element element, String pseudo)
  {
    synchronized (this.computedStyles_)
    {
      style = (ComputedCSSStyleDeclaration)this.computedStyles_.get(element);
    }
    if (style != null) {
      return style;
    }
    CSSStyleDeclaration original = element.getStyle();
    ComputedCSSStyleDeclaration style = new ComputedCSSStyleDeclaration(original);
    
    StyleSheetList sheets = ((HTMLDocument)this.document_).getStyleSheets();
    boolean trace = LOG.isTraceEnabled();
    for (int i = 0; i < sheets.getLength(); i++)
    {
      CSSStyleSheet sheet = (CSSStyleSheet)sheets.item(i);
      if (sheet.isActive())
      {
        if (trace) {
          LOG.trace("modifyIfNecessary: " + sheet + ", " + style + ", " + element);
        }
        sheet.modifyIfNecessary(style, element);
      }
    }
    synchronized (this.computedStyles_)
    {
      this.computedStyles_.put(element, style);
    }
    return style;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Selection getSelection()
  {
    WebWindow webWindow = getWebWindow();
    if ((webWindow instanceof FrameWindow))
    {
      FrameWindow frameWindow = (FrameWindow)webWindow;
      if (!frameWindow.getFrameElement().isDisplayed()) {
        return null;
      }
    }
    return getSelectionImpl();
  }
  
  public Selection getSelectionImpl()
  {
    if (this.selection_ == null)
    {
      this.selection_ = new Selection();
      this.selection_.setParentScope(this);
      this.selection_.setPrototype(getPrototype(this.selection_.getClass()));
    }
    return this.selection_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object showModalDialog(String url, Object arguments, String features)
  {
    WebWindow webWindow = getWebWindow();
    WebClient client = webWindow.getWebClient();
    try
    {
      URL completeUrl = ((HtmlPage)getDomNodeOrDie()).getFullyQualifiedUrl(url);
      DialogWindow dialog = client.openDialogWindow(completeUrl, webWindow, arguments);
      
      ScriptableObject jsDialog = (ScriptableObject)dialog.getScriptObject();
      return jsDialog.get("returnValue", jsDialog);
    }
    catch (IOException e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object showModelessDialog(String url, Object arguments, String features)
  {
    WebWindow webWindow = getWebWindow();
    WebClient client = webWindow.getWebClient();
    try
    {
      URL completeUrl = ((HtmlPage)getDomNodeOrDie()).getFullyQualifiedUrl(url);
      DialogWindow dialog = client.openDialogWindow(completeUrl, webWindow, arguments);
      return (Window)dialog.getScriptObject();
    }
    catch (IOException e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getControllers()
  {
    return this.controllers_;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setControllers(Object value)
  {
    this.controllers_ = value;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getMozInnerScreenX()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getMozInnerScreenY()
  {
    return 82;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getMozPaintCount()
  {
    return 23;
  }
  
  private static final Set<String> ATTRIBUTES_AFFECTING_PARENT = new HashSet(Arrays.asList(new String[] { "style", "class", "height", "width" }));
  
  private class DomHtmlAttributeChangeListenerImpl
    implements DomChangeListener, HtmlAttributeChangeListener
  {
    private DomHtmlAttributeChangeListenerImpl() {}
    
    public void nodeAdded(DomChangeEvent event)
    {
      nodeChanged(event.getChangedNode(), null);
    }
    
    public void nodeDeleted(DomChangeEvent event)
    {
      nodeChanged(event.getChangedNode(), null);
    }
    
    public void attributeAdded(HtmlAttributeChangeEvent event)
    {
      nodeChanged(event.getHtmlElement(), event.getName());
    }
    
    public void attributeRemoved(HtmlAttributeChangeEvent event)
    {
      nodeChanged(event.getHtmlElement(), event.getName());
    }
    
    public void attributeReplaced(HtmlAttributeChangeEvent event)
    {
      nodeChanged(event.getHtmlElement(), event.getName());
    }
    
    private void nodeChanged(DomNode changed, String attribName)
    {
      if ((changed instanceof HtmlStyle))
      {
        synchronized (Window.this.computedStyles_)
        {
          Window.this.computedStyles_.clear();
        }
        return;
      }
      if ((changed instanceof HtmlLink))
      {
        String rel = ((HtmlLink)changed).getRelAttribute().toLowerCase(Locale.ENGLISH);
        if ("stylesheet".equals(rel))
        {
          synchronized (Window.this.computedStyles_)
          {
            Window.this.computedStyles_.clear();
          }
          return;
        }
      }
      synchronized (Window.this.computedStyles_)
      {
        boolean clearParents = Window.ATTRIBUTES_AFFECTING_PARENT.contains(attribName);
        Object i = Window.this.computedStyles_.entrySet().iterator();
        while (((Iterator)i).hasNext())
        {
          Map.Entry<Node, ComputedCSSStyleDeclaration> entry = (Map.Entry)((Iterator)i).next();
          DomNode node = ((Node)entry.getKey()).getDomNodeOrDie();
          if ((changed == node) || (changed.getParentNode() == node.getParentNode()) || (changed.isAncestorOf(node)) || ((clearParents) && (node.isAncestorOf(changed)))) {
            ((Iterator)i).remove();
          }
        }
      }
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String ScriptEngine()
  {
    return "JScript";
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int ScriptEngineBuildVersion()
  {
    return 12345;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int ScriptEngineMajorVersion()
  {
    return 5;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int ScriptEngineMinorVersion()
  {
    return (int)getBrowserVersion().getBrowserVersionNumeric();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void stop() {}
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getPageXOffset()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getPageYOffset()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getScrollX()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getScrollY()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Netscape getNetscape()
  {
    return new Netscape(this);
  }
  
  public ScriptResult executeEvent(Event event)
  {
    return executeEvent(event, this.eventListenersContainer_);
  }
  
  protected ScriptResult executeEvent(Event event, EventListenersContainer eventListenersContainer)
  {
    if (eventListenersContainer != null)
    {
      boolean eventParam = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_EVENT_HANDLER_AS_PROPERTY_DONT_RECEIVE_EVENT);
      
      Object[] args = { event };
      Object[] propHandlerArgs;
      Object[] propHandlerArgs;
      if (eventParam) {
        propHandlerArgs = ArrayUtils.EMPTY_OBJECT_ARRAY;
      } else {
        propHandlerArgs = args;
      }
      setCurrentEvent(event);
      try
      {
        return eventListenersContainer.executeListeners(event, args, propHandlerArgs);
      }
      finally
      {
        setCurrentEvent(null);
      }
    }
    return null;
  }
  
  public boolean isConst(String name)
  {
    if (("undefined".equals(name)) || ("Infinity".equals(name)) || ("NaN".equals(name))) {
      return false;
    }
    return super.isConst(name);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public boolean dispatchEvent(Event event)
  {
    event.setTarget(this);
    ScriptResult result = Node.fireEvent(this, event);
    return !event.isAborted(result);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Object getOnchange()
  {
    return getHandlerForJavaScript("change");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void setOnchange(Object onchange)
  {
    setHandlerForJavaScript("change", onchange);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F)})
  public void postMessage(String message, String targetOrigin)
  {
    final MessageEvent event = new MessageEvent(message);
    event.setParentScope(this);
    event.setPrototype(getPrototype(event.getClass()));
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_WINDOW_POST_MESSAGE_SYNCHRONOUSE))
    {
      dispatchEvent(event);
      return;
    }
    PostponedAction action = new PostponedAction(getDomNodeOrDie().getPage())
    {
      public void execute()
        throws Exception
      {
        Window.this.dispatchEvent(event);
      }
    };
    getWebWindow().getWebClient().getJavaScriptEngine().addPostponedAction(action);
  }
}
