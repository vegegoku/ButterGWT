package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.StorageHolder.Type;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import java.net.URL;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

public class StorageList
  extends SimpleScriptable
{
  public Object get(String name, Scriptable start)
  {
    if (name.equals(((HtmlPage)getWindow().getWebWindow().getEnclosedPage()).getUrl().getHost())) {
      return getWindow().getStorage(StorageHolder.Type.GLOBAL_STORAGE);
    }
    Context.reportError("Security error: can not access the specified host");
    return null;
  }
}
