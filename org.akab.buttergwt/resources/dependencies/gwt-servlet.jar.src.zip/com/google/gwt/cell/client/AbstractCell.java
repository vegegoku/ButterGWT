package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public abstract class AbstractCell<C>
  implements Cell<C>
{
  private Set<String> consumedEvents;
  
  public AbstractCell(String... consumedEvents)
  {
    Set<String> events = null;
    if ((consumedEvents != null) && (consumedEvents.length > 0))
    {
      events = new HashSet();
      for (String event : consumedEvents) {
        events.add(event);
      }
    }
    init(events);
  }
  
  public AbstractCell(Set<String> consumedEvents)
  {
    init(consumedEvents);
  }
  
  public boolean dependsOnSelection()
  {
    return false;
  }
  
  public Set<String> getConsumedEvents()
  {
    return this.consumedEvents;
  }
  
  public boolean handlesSelection()
  {
    return false;
  }
  
  public boolean isEditing(Cell.Context context, Element parent, C value)
  {
    return false;
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    String eventType = event.getType();
    if (("keydown".equals(eventType)) && (event.getKeyCode() == 13)) {
      onEnterKeyDown(context, parent, value, event, valueUpdater);
    }
  }
  
  public abstract void render(Cell.Context paramContext, C paramC, SafeHtmlBuilder paramSafeHtmlBuilder);
  
  public boolean resetFocus(Cell.Context context, Element parent, C value)
  {
    return false;
  }
  
  public void setValue(Cell.Context context, Element parent, C value)
  {
    SafeHtmlBuilder sb = new SafeHtmlBuilder();
    render(context, value, sb);
    parent.setInnerSafeHtml(sb.toSafeHtml());
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater) {}
  
  private void init(Set<String> consumedEvents)
  {
    if (consumedEvents != null) {
      this.consumedEvents = Collections.unmodifiableSet(consumedEvents);
    }
  }
}
