package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
public class XSLTemplate
  extends SimpleScriptable
{
  private Node stylesheet_;
  
  @JsxSetter
  public void setStylesheet(Node node)
  {
    this.stylesheet_ = node;
  }
  
  @JsxGetter
  public Node getStylesheet()
  {
    return this.stylesheet_;
  }
  
  @JsxFunction
  public XSLTProcessor createProcessor()
  {
    XSLTProcessor processor = new XSLTProcessor();
    processor.setPrototype(getPrototype(processor.getClass()));
    processor.setParentScope(getParentScope());
    processor.importStylesheet(this.stylesheet_);
    return processor;
  }
}
