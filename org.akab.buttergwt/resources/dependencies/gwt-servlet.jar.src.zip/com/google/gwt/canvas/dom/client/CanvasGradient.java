package com.google.gwt.canvas.dom.client;

public class CanvasGradient
  extends FillStrokeStyle
{
  public final native void addColorStop(double paramDouble, String paramString);
}
