package com.google.gwt.animation.client;

import com.google.gwt.dom.client.Element;

public abstract class AnimationScheduler
{
  public static AnimationScheduler get()
  {
    return AnimationSchedulerImpl.INSTANCE;
  }
  
  public AnimationHandle requestAnimationFrame(AnimationCallback callback)
  {
    return requestAnimationFrame(callback, null);
  }
  
  public abstract AnimationHandle requestAnimationFrame(AnimationCallback paramAnimationCallback, Element paramElement);
  
  public static abstract class AnimationHandle
  {
    public abstract void cancel();
  }
  
  public static abstract interface AnimationCallback
  {
    public abstract void execute(double paramDouble);
  }
}
