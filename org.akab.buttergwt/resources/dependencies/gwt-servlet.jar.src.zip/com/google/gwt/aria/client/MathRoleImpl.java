package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class MathRoleImpl
  extends RoleImpl
  implements MathRole
{
  MathRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
}
