package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import java.io.IOException;
import java.util.Map;

public class HtmlLabel
  extends HtmlElement
{
  public static final String TAG_NAME = "label";
  
  HtmlLabel(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public final String getForAttribute()
  {
    return getAttribute("for");
  }
  
  public final String getAccessKeyAttribute()
  {
    return getAttribute("accesskey");
  }
  
  public final String getOnFocusAttribute()
  {
    return getAttribute("onfocus");
  }
  
  public final String getOnBlurAttribute()
  {
    return getAttribute("onblur");
  }
  
  public void blur()
  {
    HtmlElement element = getReferencedElement();
    if (element != null) {
      element.blur();
    }
  }
  
  public void focus()
  {
    HtmlElement element = getReferencedElement();
    if (element != null) {
      element.focus();
    }
  }
  
  public HtmlElement getReferencedElement()
  {
    String elementId = getForAttribute();
    if (!ATTRIBUTE_NOT_DEFINED.equals(elementId)) {
      try
      {
        return ((HtmlPage)getPage()).getHtmlElementById(elementId);
      }
      catch (ElementNotFoundException e)
      {
        return null;
      }
    }
    for (DomNode element : getChildren()) {
      if ((element instanceof HtmlInput)) {
        return (HtmlInput)element;
      }
    }
    return null;
  }
  
  public Page click()
    throws IOException
  {
    Page page = super.click();
    
    HtmlElement element = getReferencedElement();
    Page response;
    Page response;
    if (element != null) {
      response = element.click();
    } else {
      response = page;
    }
    return response;
  }
}
