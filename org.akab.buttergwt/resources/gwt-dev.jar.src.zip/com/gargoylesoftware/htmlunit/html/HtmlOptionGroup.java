package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlOptionGroup
  extends HtmlElement
  implements DisabledElement
{
  public static final String TAG_NAME = "optgroup";
  
  HtmlOptionGroup(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public final boolean isDisabled()
  {
    if (hasFeature(BrowserVersionFeatures.HTMLOPTIONGROUP_NO_DISABLED)) {
      return false;
    }
    return hasAttribute("disabled");
  }
  
  public final String getDisabledAttribute()
  {
    return getAttribute("disabled");
  }
  
  public final String getLabelAttribute()
  {
    return getAttribute("label");
  }
  
  public HtmlSelect getEnclosingSelect()
  {
    return (HtmlSelect)getEnclosingElement("select");
  }
}
