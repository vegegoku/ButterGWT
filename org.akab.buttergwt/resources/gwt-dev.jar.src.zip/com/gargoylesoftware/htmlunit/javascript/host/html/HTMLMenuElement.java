package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlMenu;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={HtmlMenu.class})
public class HTMLMenuElement
  extends HTMLListElement
{}
