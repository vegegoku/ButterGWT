package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ScriptResult;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomDocumentFragment;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.html.HtmlInlineFrame;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstant;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.dom.DOMException;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLHtmlElement;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLSerializer;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.Interpreter;
import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;
import net.sourceforge.htmlunit.corejs.javascript.RhinoException;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;

@JsxClass
public class Node
  extends SimpleScriptable
{
  private NodeList childNodes_;
  private EventListenersContainer eventListenersContainer_;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short ELEMENT_NODE = 1;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short ATTRIBUTE_NODE = 2;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short TEXT_NODE = 3;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short CDATA_SECTION_NODE = 4;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short ENTITY_REFERENCE_NODE = 5;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short ENTITY_NODE = 6;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short PROCESSING_INSTRUCTION_NODE = 7;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short COMMENT_NODE = 8;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_NODE = 9;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_TYPE_NODE = 10;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_FRAGMENT_NODE = 11;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short NOTATION_NODE = 12;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_POSITION_DISCONNECTED = 1;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_POSITION_PRECEDING = 2;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_POSITION_FOLLOWING = 4;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_POSITION_CONTAINS = 8;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_POSITION_CONTAINED_BY = 16;
  @JsxConstant({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public static final short DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC = 32;
  
  @JsxGetter
  public short getNodeType()
  {
    return getDomNodeOrDie().getNodeType();
  }
  
  @JsxGetter
  public String getNodeName()
  {
    return getDomNodeOrDie().getNodeName();
  }
  
  @JsxGetter
  public String getNodeValue()
  {
    return getDomNodeOrDie().getNodeValue();
  }
  
  @JsxSetter
  public void setNodeValue(String newValue)
  {
    getDomNodeOrDie().setNodeValue(newValue);
  }
  
  @JsxFunction
  public Object appendChild(Object childObject)
  {
    Object appendedChild = null;
    if ((childObject instanceof Node))
    {
      Node childNode = (Node)childObject;
      if (!isNodeInsertable(childNode))
      {
        if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_APPEND_CHILD_THROWS_NO_EXCEPTION_FOR_WRONG_NOTE)) {
          return childObject;
        }
        throw asJavaScriptException(new DOMException("Node cannot be inserted at the specified point in the hierarchy", (short)3));
      }
      DomNode childDomNode = childNode.getDomNodeOrDie();
      
      DomNode parentNode = getDomNodeOrDie();
      
      parentNode.appendChild(childDomNode);
      appendedChild = childObject;
      if ((!(parentNode instanceof SgmlPage)) && (!(this instanceof DocumentFragment)) && (parentNode.getParentNode() == null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_APPEND_CHILD_CREATE_DOCUMENT_FRAGMENT_PARENT)))
      {
        DomDocumentFragment fragment = parentNode.getPage().createDomDocumentFragment();
        fragment.appendChild(parentNode);
      }
      initInlineFrameIfNeeded(childDomNode);
      for (DomNode domNode : childDomNode.getChildren()) {
        initInlineFrameIfNeeded(domNode);
      }
    }
    return appendedChild;
  }
  
  private void initInlineFrameIfNeeded(DomNode childDomNode)
  {
    if ((childDomNode instanceof HtmlInlineFrame))
    {
      HtmlInlineFrame frame = (HtmlInlineFrame)childDomNode;
      if (DomElement.ATTRIBUTE_NOT_DEFINED == frame.getSrcAttribute()) {
        frame.loadInnerPage();
      }
    }
  }
  
  private RhinoException asJavaScriptException(DOMException exception)
  {
    exception.setPrototype(getWindow().getPrototype(exception.getClass()));
    exception.setParentScope(getWindow());
    int lineNumber;
    if (Context.getCurrentContext().getOptimizationLevel() == -1)
    {
      int[] linep = new int[1];
      String sourceName = new Interpreter().getSourcePositionFromStack(Context.getCurrentContext(), linep);
      String fileName = sourceName.replaceFirst("script in (.*) from .*", "$1");
      lineNumber = linep[0];
    }
    else
    {
      throw new Error("HtmlUnit not ready to run in compiled mode");
    }
    int lineNumber;
    String fileName;
    exception.setLocation(fileName, lineNumber);
    
    return new JavaScriptException(exception, fileName, lineNumber);
  }
  
  private boolean isNodeInsertable(Node childObject)
  {
    return !(childObject instanceof HTMLHtmlElement);
  }
  
  @JsxFunction
  public Object cloneNode(boolean deep)
  {
    DomNode domNode = getDomNodeOrDie();
    DomNode clonedNode = domNode.cloneNode(deep);
    
    Node jsClonedNode = getJavaScriptNode(clonedNode);
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_CLONE_NODE_COPIES_EVENT_LISTENERS)) {
      copyEventListenersWhenNeeded(domNode, clonedNode);
    }
    return jsClonedNode;
  }
  
  private void copyEventListenersWhenNeeded(DomNode domNode, DomNode clonedNode)
  {
    Node jsNode = (Node)domNode.getScriptObject();
    if (jsNode != null)
    {
      Node jsClonedNode = getJavaScriptNode(clonedNode);
      jsClonedNode.getEventListenersContainer().copyFrom(jsNode.getEventListenersContainer());
    }
    DomNode child = domNode.getFirstChild();
    DomNode clonedChild = clonedNode.getFirstChild();
    while ((child != null) && (clonedChild != null))
    {
      copyEventListenersWhenNeeded(child, clonedChild);
      child = child.getNextSibling();
      clonedChild = clonedChild.getNextSibling();
    }
  }
  
  @JsxFunction
  public static Object insertBefore(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    return ((Node)thisObj).insertBeforeImpl(args);
  }
  
  protected Object insertBeforeImpl(Object[] args)
  {
    Object newChildObject = args[0];
    Object refChildObject;
    Object refChildObject;
    if (args.length > 1) {
      refChildObject = args[1];
    } else {
      refChildObject = Undefined.instance;
    }
    Object appendedChild = null;
    if ((newChildObject instanceof Node))
    {
      Node newChild = (Node)newChildObject;
      DomNode newChildNode = newChild.getDomNodeOrDie();
      if (!isNodeInsertable(newChild))
      {
        if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_APPEND_CHILD_THROWS_NO_EXCEPTION_FOR_WRONG_NOTE)) {
          return newChildNode;
        }
        throw Context.reportRuntimeError("Node cannot be inserted at the specified point in the hierarchy");
      }
      if ((newChildNode instanceof DomDocumentFragment))
      {
        DomDocumentFragment fragment = (DomDocumentFragment)newChildNode;
        for (DomNode child : fragment.getChildren()) {
          insertBeforeImpl(new Object[] { child.getScriptObject(), refChildObject });
        }
        return newChildObject;
      }
      DomNode refChildNode;
      if (refChildObject == Undefined.instance)
      {
        DomNode refChildNode;
        if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_121))
        {
          if (args.length > 1) {
            throw Context.reportRuntimeError("Invalid argument.");
          }
          refChildNode = null;
        }
        else
        {
          DomNode refChildNode;
          if (args.length == 2) {
            refChildNode = null;
          } else {
            throw Context.reportRuntimeError("insertBefore: not enough arguments");
          }
        }
      }
      else
      {
        DomNode refChildNode;
        if (refChildObject != null) {
          refChildNode = ((Node)refChildObject).getDomNodeOrDie();
        } else {
          refChildNode = null;
        }
      }
      DomNode domNode = getDomNodeOrDie();
      if (refChildNode != null)
      {
        refChildNode.insertBefore(newChildNode);
        appendedChild = newChildObject;
      }
      else
      {
        domNode.appendChild(newChildNode);
        appendedChild = newChildObject;
      }
      if ((domNode.getParentNode() == null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_APPEND_CHILD_CREATE_DOCUMENT_FRAGMENT_PARENT)))
      {
        DomDocumentFragment fragment = domNode.getPage().createDomDocumentFragment();
        fragment.appendChild(domNode);
      }
    }
    return appendedChild;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, maxVersion=3.6F)})
  public boolean isSameNode(Object other)
  {
    return other == this;
  }
  
  @JsxFunction
  public Object removeChild(Object childObject)
  {
    Object removedChild = null;
    if ((childObject instanceof Node))
    {
      DomNode childNode = ((Node)childObject).getDomNodeOrDie();
      
      childNode.remove();
      removedChild = childObject;
    }
    return removedChild;
  }
  
  @JsxFunction
  public boolean hasChildNodes()
  {
    return getDomNodeOrDie().getChildren().iterator().hasNext();
  }
  
  @JsxGetter
  public NodeList getChildNodes()
  {
    if (this.childNodes_ == null)
    {
      final DomNode node = getDomNodeOrDie();
      boolean isXmlPage = node.getOwnerDocument() instanceof XmlPage;
      boolean isIE = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_45);
      Boolean xmlSpaceDefault = isXMLSpaceDefault(node);
      final boolean skipEmptyTextNode = (isIE) && (isXmlPage) && (!Boolean.FALSE.equals(xmlSpaceDefault));
      
      this.childNodes_ = new NodeList(node, false, "Node.childNodes")
      {
        protected List<Object> computeElements()
        {
          List<Object> response = new ArrayList();
          for (DomNode child : node.getChildren()) {
            if ((!skipEmptyTextNode) || (!(child instanceof DomText)) || (!StringUtils.isBlank(((DomText)child).getNodeValue()))) {
              response.add(child);
            }
          }
          return response;
        }
      };
    }
    return this.childNodes_;
  }
  
  private static Boolean isXMLSpaceDefault(DomNode node)
  {
    for (; (node instanceof DomElement); node = node.getParentNode())
    {
      String value = ((DomElement)node).getAttribute("xml:space");
      if (!value.isEmpty())
      {
        if ("default".equals(value)) {
          return Boolean.TRUE;
        }
        return Boolean.FALSE;
      }
    }
    return null;
  }
  
  @JsxFunction
  public Object replaceChild(Object newChildObject, Object oldChildObject)
  {
    Object removedChild = null;
    if ((newChildObject instanceof DocumentFragment))
    {
      DocumentFragment fragment = (DocumentFragment)newChildObject;
      Node firstNode = null;
      Node refChildObject = ((Node)oldChildObject).getNextSibling();
      for (DomNode node : fragment.getDomNodeOrDie().getChildren()) {
        if (firstNode == null)
        {
          replaceChild(node.getScriptObject(), oldChildObject);
          firstNode = (Node)node.getScriptObject();
        }
        else
        {
          insertBeforeImpl(new Object[] { node.getScriptObject(), refChildObject });
        }
      }
      if (firstNode == null) {
        removeChild(oldChildObject);
      }
      removedChild = oldChildObject;
    }
    else if (((newChildObject instanceof Node)) && ((oldChildObject instanceof Node)))
    {
      Node newChild = (Node)newChildObject;
      if (!isNodeInsertable(newChild)) {
        throw Context.reportRuntimeError("Node cannot be inserted at the specified point in the hierarchy");
      }
      DomNode newChildNode = newChild.getDomNodeOrDie();
      DomNode oldChildNode = ((Node)oldChildObject).getDomNodeOrDie();
      
      oldChildNode.replace(newChildNode);
      removedChild = oldChildObject;
    }
    return removedChild;
  }
  
  public Node getParent()
  {
    return getJavaScriptNode(getDomNodeOrDie().getParentNode());
  }
  
  @JsxGetter
  public Object getParentNode()
  {
    return getJavaScriptNode(getDomNodeOrDie().getParentNode());
  }
  
  @JsxGetter
  public Node getNextSibling()
  {
    return getJavaScriptNode(getDomNodeOrDie().getNextSibling());
  }
  
  @JsxGetter
  public Node getPreviousSibling()
  {
    return getJavaScriptNode(getDomNodeOrDie().getPreviousSibling());
  }
  
  @JsxGetter
  public Node getFirstChild()
  {
    return getJavaScriptNode(getDomNodeOrDie().getFirstChild());
  }
  
  @JsxGetter
  public Node getLastChild()
  {
    return getJavaScriptNode(getDomNodeOrDie().getLastChild());
  }
  
  protected Node getJavaScriptNode(DomNode domNode)
  {
    if (domNode == null) {
      return null;
    }
    return (Node)getScriptableFor(domNode);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean attachEvent(String type, Function listener)
  {
    return getEventListenersContainer().addEventListener(StringUtils.substring(type, 2), listener, false);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void addEventListener(String type, Function listener, boolean useCapture)
  {
    getEventListenersContainer().addEventListener(type, listener, useCapture);
  }
  
  private EventListenersContainer getEventListenersContainer()
  {
    if (this.eventListenersContainer_ == null) {
      this.eventListenersContainer_ = new EventListenersContainer(this);
    }
    return this.eventListenersContainer_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void detachEvent(String type, Function listener)
  {
    removeEventListener(StringUtils.substring(type, 2), listener, false);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void removeEventListener(String type, Function listener, boolean useCapture)
  {
    getEventListenersContainer().removeEventListener(type, listener, useCapture);
  }
  
  public ScriptResult executeEvent(Event event)
  {
    if (this.eventListenersContainer_ != null)
    {
      HtmlPage page = (HtmlPage)getDomNodeOrDie().getPage();
      Window window = (Window)page.getEnclosingWindow().getScriptObject();
      return window.executeEvent(event, this.eventListenersContainer_);
    }
    return null;
  }
  
  public ScriptResult fireEvent(Event event)
  {
    return fireEvent(this, event);
  }
  
  public static ScriptResult fireEvent(SimpleScriptable scriptable, Event event)
  {
    HtmlPage page = (HtmlPage)scriptable.getDomNodeOrDie().getPage();
    Window window = (Window)page.getEnclosingWindow().getScriptObject();
    Object[] args = { event };
    
    event.startFire();
    ScriptResult result = null;
    Event previousEvent = window.getCurrentEvent();
    window.setCurrentEvent(event);
    try
    {
      EventListenersContainer windowsListeners = scriptable.getWindow().getEventListenersContainer();
      
      event.setEventPhase((short)1);
      result = windowsListeners.executeCapturingListeners(event, args);
      if (event.isPropagationStopped()) {
        return result;
      }
      Object parents = new ArrayList();
      DomNode node = scriptable.getDomNodeOrDie();
      while (node != null)
      {
        ((List)parents).add(node);
        node = node.getParentNode();
      }
      boolean ie = scriptable.getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_124);
      ScriptResult r;
      for (int i = ((List)parents).size() - 1; i >= 0; i--)
      {
        DomNode curNode = (DomNode)((List)parents).get(i);
        Node jsNode = (Node)curNode.getScriptObject();
        EventListenersContainer elc = jsNode.eventListenersContainer_;
        if (elc != null)
        {
          r = elc.executeCapturingListeners(event, args);
          result = ScriptResult.combine(r, result, ie);
          if (event.isPropagationStopped()) {
            return result;
          }
        }
      }
      Object[] propHandlerArgs;
      Object[] propHandlerArgs;
      if (ie) {
        propHandlerArgs = ArrayUtils.EMPTY_OBJECT_ARRAY;
      } else {
        propHandlerArgs = args;
      }
      event.setEventPhase((short)2);
      node = scriptable.getDomNodeOrDie();
      while (node != null)
      {
        Node jsNode = (Node)node.getScriptObject();
        EventListenersContainer elc = jsNode.eventListenersContainer_;
        if (elc != null)
        {
          ScriptResult r = elc.executeBubblingListeners(event, args, propHandlerArgs);
          result = ScriptResult.combine(r, result, ie);
          if (event.isPropagationStopped()) {
            return result;
          }
        }
        node = node.getParentNode();
        event.setEventPhase((short)3);
      }
      ScriptResult r = windowsListeners.executeBubblingListeners(event, args, propHandlerArgs);
      result = ScriptResult.combine(r, result, ie);
    }
    finally
    {
      event.endFire();
      window.setCurrentEvent(previousEvent);
    }
    return result;
  }
  
  public Function getEventHandler(String eventName)
  {
    if (this.eventListenersContainer_ == null) {
      return null;
    }
    return this.eventListenersContainer_.getEventHandler(StringUtils.substring(eventName, 2));
  }
  
  public boolean hasEventHandlers(String eventName)
  {
    if (this.eventListenersContainer_ == null) {
      return false;
    }
    return this.eventListenersContainer_.hasEventHandlers(StringUtils.substring(eventName, 2));
  }
  
  public void setEventHandler(String eventName, Function eventHandler)
  {
    setEventHandlerProp(eventName, eventHandler);
  }
  
  protected void setEventHandlerProp(String eventName, Object value)
  {
    getEventListenersContainer().setEventHandlerProp(StringUtils.substring(eventName.toLowerCase(), 2), value);
  }
  
  protected Object getEventHandlerProp(String eventName)
  {
    if (this.eventListenersContainer_ == null) {
      return null;
    }
    String name = StringUtils.substring(eventName.toLowerCase(Locale.ENGLISH), 2);
    return this.eventListenersContainer_.getEventHandlerProp(name);
  }
  
  @JsxGetter
  public Object getOwnerDocument()
  {
    Object document = getDomNodeOrDie().getOwnerDocument();
    if (document == null) {
      return null;
    }
    return ((SgmlPage)document).getScriptObject();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPrefix()
  {
    DomNode domNode = getDomNodeOrDie();
    String prefix = domNode.getPrefix();
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_PREFIX_RETURNS_EMPTY_WHEN_UNDEFINED)) && ((prefix == null) || (domNode.getHtmlPageOrNull() != null))) {
      return "";
    }
    return prefix;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getLocalName()
  {
    return getDomNodeOrDie().getLocalName();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getNamespaceURI()
  {
    String namespaceURI = getDomNodeOrDie().getNamespaceURI();
    if ((namespaceURI == null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_XML_SUPPORT_VIA_ACTIVEXOBJECT))) {
      return "";
    }
    return namespaceURI;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getBaseName()
  {
    DomElement domElem = (DomElement)getDomNodeOrDie();
    boolean isXmlPage = domElem.getOwnerDocument() instanceof XmlPage;
    if (isXmlPage) {
      return domElem.getLocalName();
    }
    return Undefined.instance;
  }
  
  public void setDomNode(DomNode domNode)
  {
    super.setDomNode(domNode);
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_XML_SUPPORT_VIA_ACTIVEXOBJECT)) && (null == getDomNodeOrDie().getHtmlPageOrNull()))
    {
      ActiveXObject.addProperty(this, "namespaceURI", true, false);
      ActiveXObject.addProperty(this, "prefix", true, false);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public short compareDocumentPosition(Object node)
  {
    if (!(node instanceof Node)) {
      throw Context.reportRuntimeError("Could not convert JavaScript argument arg 0");
    }
    return getDomNodeOrDie().compareDocumentPosition(((Node)node).getDomNodeOrDie());
  }
  
  @JsxFunction
  public void normalize()
  {
    getDomNodeOrDie().normalize();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getXml()
  {
    DomNode node = getDomNodeOrDie();
    if ((node.getPage() instanceof XmlPage))
    {
      if ((this instanceof Element))
      {
        XMLSerializer serializer = new XMLSerializer();
        serializer.setParentScope(getParentScope());
        String xml = serializer.serializeToString(this);
        if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_XML_SERIALIZER_APPENDS_CRLF)) && (xml.endsWith("\r\n"))) {
          xml = xml.substring(0, xml.length() - 2);
        }
        return xml;
      }
      return node.asXml();
    }
    return Undefined.instance;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getTextContent()
  {
    return getDomNodeOrDie().getTextContent();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setTextContent(Object value)
  {
    getDomNodeOrDie().setTextContent(value == null ? null : Context.toString(value));
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Element getParentElement()
  {
    Node parent = getParent();
    if (!(parent instanceof Element)) {
      return null;
    }
    return (Element)parent;
  }
  
  @JsxGetter
  public Object getAttributes()
  {
    return null;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public boolean contains(Object element)
  {
    if (!(element instanceof Node)) {
      throw Context.reportRuntimeError("Could not convert JavaScript argument arg 0");
    }
    for (Node parent = (Node)element; parent != null; parent = parent.getParentElement()) {
      if (this == parent) {
        return true;
      }
    }
    return false;
  }
}
