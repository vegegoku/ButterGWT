package com.google.gwt.aria.client;

public abstract interface SelectRole
  extends CompositeRole, GroupRole, InputRole
{}
