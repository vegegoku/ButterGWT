package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import org.w3c.dom.CharacterData;

public abstract class DomCharacterData
  extends DomNode
  implements CharacterData
{
  private String data_;
  
  public DomCharacterData(SgmlPage page, String data)
  {
    super(page);
    this.data_ = data;
  }
  
  public String getData()
  {
    return this.data_;
  }
  
  public void setData(String data)
  {
    this.data_ = data;
  }
  
  public void setNodeValue(String newValue)
  {
    this.data_ = newValue;
  }
  
  public void setTextContent(String textContent)
  {
    this.data_ = textContent;
  }
  
  public int getLength()
  {
    return this.data_.length();
  }
  
  public void appendData(String newData)
  {
    this.data_ += newData;
  }
  
  public void deleteData(int offset, int count)
  {
    if ((offset < 0) || (count < 0)) {
      throw new IllegalArgumentException("offset: " + offset + " count: " + count);
    }
    int tailLength = Math.max(this.data_.length() - count - offset, 0);
    if (tailLength > 0) {
      this.data_ = (this.data_.substring(0, offset) + this.data_.substring(offset + count, offset + count + tailLength));
    } else {
      this.data_ = "";
    }
  }
  
  public void insertData(int offset, String arg)
  {
    this.data_ = new StringBuilder(this.data_).insert(offset, arg).toString();
  }
  
  public void replaceData(int offset, int count, String arg)
  {
    deleteData(offset, count);
    insertData(offset, arg);
  }
  
  public String substringData(int offset, int count)
  {
    int length = this.data_.length();
    if ((count < 0) || (offset < 0) || (offset > length - 1)) {
      throw new IllegalArgumentException("offset: " + offset + " count: " + count);
    }
    int tailIndex = Math.min(offset + count, length);
    return this.data_.substring(offset, tailIndex);
  }
  
  public String getNodeValue()
  {
    return this.data_;
  }
  
  public String getCanonicalXPath()
  {
    return getParentNode().getCanonicalXPath() + '/' + getXPathToken();
  }
  
  private String getXPathToken()
  {
    DomNode parent = getParentNode();
    
    int siblingsOfSameType = 0;
    int nodeIndex = 0;
    for (DomNode child : parent.getChildren()) {
      if (child == this)
      {
        siblingsOfSameType++;nodeIndex = siblingsOfSameType;
        if (nodeIndex > 1) {
          break;
        }
      }
      else if (child.getNodeType() == getNodeType())
      {
        siblingsOfSameType++;
        if (nodeIndex > 0) {
          break;
        }
      }
    }
    String nodeName = getNodeName().substring(1) + "()";
    if (siblingsOfSameType == 1) {
      return nodeName;
    }
    return nodeName + '[' + nodeIndex + ']';
  }
}
