package com.google.gwt.cell.client;

import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.ui.ImageResourceRenderer;

public class ImageResourceCell
  extends AbstractCell<ImageResource>
{
  private static ImageResourceRenderer renderer;
  
  public ImageResourceCell()
  {
    super(new String[0]);
    if (renderer == null) {
      renderer = new ImageResourceRenderer();
    }
  }
  
  public void render(Cell.Context context, ImageResource value, SafeHtmlBuilder sb)
  {
    if (value != null) {
      sb.append(renderer.render(value));
    }
  }
}
