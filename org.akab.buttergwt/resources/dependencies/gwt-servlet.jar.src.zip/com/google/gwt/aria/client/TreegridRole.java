package com.google.gwt.aria.client;

public abstract interface TreegridRole
  extends GridRole, TreeRole
{}
