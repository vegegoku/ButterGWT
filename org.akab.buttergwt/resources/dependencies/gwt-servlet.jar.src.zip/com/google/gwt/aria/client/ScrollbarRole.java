package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface ScrollbarRole
  extends InputRole, RangeRole
{
  public abstract String getAriaOrientationProperty(Element paramElement);
  
  public abstract void removeAriaOrientationProperty(Element paramElement);
  
  public abstract void setAriaOrientationProperty(Element paramElement, OrientationValue paramOrientationValue);
}
