package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.util.ArrayList;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;

@JsxClass
public class StaticNodeList
  extends SimpleScriptable
{
  private final List<Node> elements_;
  
  public StaticNodeList()
  {
    this.elements_ = new ArrayList();
  }
  
  public StaticNodeList(List<Node> elements, ScriptableObject parentScope)
  {
    this.elements_ = elements;
    setParentScope(parentScope);
    setPrototype(getPrototype(getClass()));
  }
  
  public Object get(int index, Scriptable start)
  {
    StaticNodeList staticNodeList = (StaticNodeList)start;
    Object result = staticNodeList.item(index);
    if (null == result) {
      return NOT_FOUND;
    }
    return result;
  }
  
  @JsxFunction
  public Node item(int index)
  {
    if ((index < 0) || (index >= getLength())) {
      return null;
    }
    return (Node)this.elements_.get(index);
  }
  
  @JsxGetter
  public int getLength()
  {
    return this.elements_.size();
  }
}
