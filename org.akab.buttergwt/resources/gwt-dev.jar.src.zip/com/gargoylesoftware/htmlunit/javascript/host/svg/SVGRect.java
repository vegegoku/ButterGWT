package com.gargoylesoftware.htmlunit.javascript.host.svg;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass
public class SVGRect
  extends SimpleScriptable
{
  private double xValue_;
  private double yValue_;
  private double width_;
  private double height_;
  
  @JsxGetter
  public double getX()
  {
    return this.xValue_;
  }
  
  @JsxSetter
  public void setX(double x)
  {
    this.xValue_ = x;
  }
  
  @JsxGetter
  public double getY()
  {
    return this.yValue_;
  }
  
  @JsxSetter
  public void setY(double y)
  {
    this.yValue_ = y;
  }
  
  @JsxGetter
  public double getWidth()
  {
    return this.width_;
  }
  
  @JsxSetter
  public void setWidth(double width)
  {
    this.width_ = width;
  }
  
  @JsxGetter
  public double getHeight()
  {
    return this.height_;
  }
  
  @JsxSetter
  public void setHeigth(double height)
  {
    this.height_ = height;
  }
}
