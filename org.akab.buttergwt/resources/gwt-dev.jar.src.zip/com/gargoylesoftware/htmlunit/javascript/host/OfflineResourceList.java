package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
public class OfflineResourceList
  extends SimpleScriptable
{
  public static final short STATUS_UNCACHED = 0;
  public static final short STATUS_IDLE = 1;
  public static final short STATUS_CHECKING = 2;
  public static final short STATUS_DOWNLOADING = 3;
  public static final short STATUS_UPDATEREADY = 4;
  public static final short STATUS_OBSOLETE = 5;
  private short status_ = 0;
  private Object onchecking_;
  private Object onerror_;
  private Object onnoupdate_;
  private Object ondownloading_;
  private Object onprogress_;
  private Object onupdateready_;
  private Object oncached_;
  
  @JsxGetter
  public Object getOnchecking()
  {
    return this.onchecking_;
  }
  
  @JsxSetter
  public void setOnchecking(Object o)
  {
    this.onchecking_ = o;
  }
  
  @JsxGetter
  public Object getOnerror()
  {
    return this.onerror_;
  }
  
  @JsxSetter
  public void setOnerror(Object o)
  {
    this.onerror_ = o;
  }
  
  @JsxGetter
  public Object getOnnoupdate()
  {
    return this.onnoupdate_;
  }
  
  @JsxSetter
  public void setOnnoupdate(Object o)
  {
    this.onnoupdate_ = o;
  }
  
  @JsxGetter
  public Object getOndownloading()
  {
    return this.ondownloading_;
  }
  
  @JsxSetter
  public void setOndownloading(Object o)
  {
    this.ondownloading_ = o;
  }
  
  @JsxGetter
  public Object getOnprogress()
  {
    return this.onprogress_;
  }
  
  @JsxSetter
  public void setOnprogress(Object o)
  {
    this.onprogress_ = o;
  }
  
  @JsxGetter
  public Object getOnupdateready()
  {
    return this.onupdateready_;
  }
  
  @JsxSetter
  public void setOnupdateready(Object o)
  {
    this.onupdateready_ = o;
  }
  
  @JsxGetter
  public Object getOncached()
  {
    return this.oncached_;
  }
  
  @JsxSetter
  public void setOncached(Object o)
  {
    this.oncached_ = o;
  }
  
  @JsxGetter
  public short getStatus()
  {
    return this.status_;
  }
  
  @JsxGetter
  public int getLength()
  {
    return 0;
  }
  
  @JsxFunction
  public void add(String uri) {}
  
  @JsxFunction
  public boolean hasItem(String uri)
  {
    return false;
  }
  
  @JsxFunction
  public String item(int index)
  {
    return null;
  }
  
  @JsxFunction
  public void remove(String uri) {}
  
  @JsxFunction
  public void swapCache() {}
  
  @JsxFunction
  public void update() {}
}
