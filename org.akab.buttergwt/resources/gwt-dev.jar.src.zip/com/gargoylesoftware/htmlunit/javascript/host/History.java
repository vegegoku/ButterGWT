package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.io.IOException;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass
public class History
  extends SimpleScriptable
{
  public Object[] getIds()
  {
    Object[] ids = super.getIds();
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_156))
    {
      int len = getWindow().getWebWindow().getHistory().getLength();
      if (len > 0)
      {
        Object[] allIds = new Object[ids.length + len];
        System.arraycopy(ids, 0, allIds, 0, ids.length);
        for (int i = 0; i < len; i++) {
          allIds[(ids.length + i)] = Integer.valueOf(i);
        }
        ids = allIds;
      }
    }
    return ids;
  }
  
  public boolean has(int index, Scriptable start)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_157))
    {
      History h = (History)start;
      if ((index >= 0) && (index < h.getLength())) {
        return true;
      }
    }
    return super.has(index, start);
  }
  
  public Object get(int index, Scriptable start)
  {
    History h = (History)start;
    if ((index < 0) || (index >= h.getLength())) {
      return NOT_FOUND;
    }
    return item(index);
  }
  
  @JsxGetter
  public int getLength()
  {
    WebWindow w = getWindow().getWebWindow();
    return w.getHistory().getLength();
  }
  
  @JsxFunction
  public void back()
  {
    WebWindow w = getWindow().getWebWindow();
    try
    {
      w.getHistory().back();
    }
    catch (IOException e)
    {
      Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxFunction
  public void forward()
  {
    WebWindow w = getWindow().getWebWindow();
    try
    {
      w.getHistory().forward();
    }
    catch (IOException e)
    {
      Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxFunction
  public void go(int relativeIndex)
  {
    WebWindow w = getWindow().getWebWindow();
    try
    {
      w.getHistory().go(relativeIndex);
    }
    catch (IOException e)
    {
      Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCurrent()
  {
    throw Context.reportRuntimeError("Permission denied to get property History.current");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPrevious()
  {
    throw Context.reportRuntimeError("Permission denied to get property History.previous");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getNext()
  {
    throw Context.reportRuntimeError("Permission denied to get property History.next");
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String item(int index)
  {
    throw Context.reportRuntimeError("Permission denied to call method History.item");
  }
}
