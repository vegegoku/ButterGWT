package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlMeter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass(domClasses={HtmlMeter.class}, browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=16.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class HTMLMeterElement
  extends HTMLElement
{
  @JsxGetter
  public double getValue()
  {
    return getAttributeAsDouble("value", 0.0D);
  }
  
  @JsxGetter
  public double getMin()
  {
    return getAttributeAsDouble("min", 0.0D);
  }
  
  @JsxGetter
  public double getMax()
  {
    return getAttributeAsDouble("max", 1.0D);
  }
  
  @JsxGetter
  public double getLow()
  {
    double val = getAttributeAsDouble("low", Double.MAX_VALUE);
    if (val == Double.MAX_VALUE) {
      return getMin();
    }
    return val;
  }
  
  @JsxGetter
  public double getHigh()
  {
    double val = getAttributeAsDouble("high", Double.MIN_VALUE);
    if (val == Double.MIN_VALUE) {
      return getMax();
    }
    return val;
  }
  
  @JsxGetter
  public double getOptimum()
  {
    double val = getAttributeAsDouble("optimum", Double.MAX_VALUE);
    if (val == Double.MAX_VALUE) {
      return getValue();
    }
    return val;
  }
  
  private double getAttributeAsDouble(String attributeName, double defaultValue)
  {
    try
    {
      return Double.parseDouble(getDomNodeOrDie().getAttribute(attributeName));
    }
    catch (NumberFormatException e) {}
    return defaultValue;
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "inline-block";
    }
    return "inline";
  }
}
