package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface GridcellRole
  extends SectionRole, WidgetRole
{
  public abstract String getAriaReadonlyProperty(Element paramElement);
  
  public abstract String getAriaRequiredProperty(Element paramElement);
  
  public abstract String getAriaSelectedState(Element paramElement);
  
  public abstract void removeAriaReadonlyProperty(Element paramElement);
  
  public abstract void removeAriaRequiredProperty(Element paramElement);
  
  public abstract void removeAriaSelectedState(Element paramElement);
  
  public abstract void setAriaReadonlyProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaRequiredProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaSelectedState(Element paramElement, SelectedValue paramSelectedValue);
}
