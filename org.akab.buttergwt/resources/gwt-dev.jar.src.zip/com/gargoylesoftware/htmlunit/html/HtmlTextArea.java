package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.impl.SelectableTextInput;
import com.gargoylesoftware.htmlunit.html.impl.SelectionDelegate;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import org.apache.commons.lang3.StringEscapeUtils;

public class HtmlTextArea
  extends HtmlElement
  implements DisabledElement, SubmittableElement, SelectableTextInput, FormFieldWithNameHistory
{
  public static final String TAG_NAME = "textarea";
  private String defaultValue_;
  private String valueAtFocus_;
  private String originalName_;
  private Collection<String> previousNames_ = Collections.emptySet();
  private final SelectionDelegate selectionDelegate_ = new SelectionDelegate(this);
  private final DoTypeProcessor doTypeProcessor_ = new DoTypeProcessor()
  {
    void typeDone(String newValue, int newCursorPosition)
    {
      HtmlTextArea.this.setTextInternal(newValue);
      HtmlTextArea.this.setSelectionStart(newCursorPosition);
      HtmlTextArea.this.setSelectionEnd(newCursorPosition);
    }
    
    protected boolean acceptChar(char c)
    {
      return (super.acceptChar(c)) || (c == '\n') || (c == '\r');
    }
  };
  
  HtmlTextArea(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    this.originalName_ = getNameAttribute();
  }
  
  private void initDefaultValue()
  {
    if (this.defaultValue_ == null) {
      this.defaultValue_ = readValue();
    }
  }
  
  public final String getText()
  {
    return readValue();
  }
  
  private String readValue()
  {
    StringBuilder buffer = new StringBuilder();
    for (DomNode node : getChildren()) {
      if ((node instanceof DomText)) {
        buffer.append(((DomText)node).getData());
      }
    }
    if ((buffer.length() > 0) && (buffer.charAt(0) == '\n')) {
      buffer.deleteCharAt(0);
    }
    return buffer.toString();
  }
  
  public final void setText(String newValue)
  {
    setTextInternal(newValue);
    
    HtmlInput.executeOnChangeHandlerIfAppropriate(this);
  }
  
  private void setTextInternal(String newValue)
  {
    initDefaultValue();
    DomText child = (DomText)getFirstChild();
    if (child == null)
    {
      DomText newChild = new DomText(getPage(), newValue);
      appendChild(newChild);
    }
    else
    {
      child.setData(newValue);
    }
    setSelectionStart(newValue.length());
    setSelectionEnd(newValue.length());
  }
  
  public NameValuePair[] getSubmitKeyValuePairs()
  {
    String text = getText();
    text = text.replace("\r\n", "\n").replace("\n", "\r\n");
    
    return new NameValuePair[] { new NameValuePair(getNameAttribute(), text) };
  }
  
  public void reset()
  {
    initDefaultValue();
    setText(this.defaultValue_);
  }
  
  public void setDefaultValue(String defaultValue)
  {
    initDefaultValue();
    if (defaultValue == null) {
      defaultValue = "";
    }
    if ((hasFeature(BrowserVersionFeatures.HTMLTEXTAREA_SET_DEFAULT_VALUE_UPDATES_VALUE)) && (getText().equals(getDefaultValue()))) {
      setTextInternal(defaultValue);
    }
    this.defaultValue_ = defaultValue;
  }
  
  public String getDefaultValue()
  {
    initDefaultValue();
    return this.defaultValue_;
  }
  
  public void setDefaultChecked(boolean defaultChecked) {}
  
  public boolean isDefaultChecked()
  {
    return false;
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final String getRowsAttribute()
  {
    return getAttribute("rows");
  }
  
  public final String getColumnsAttribute()
  {
    return getAttribute("cols");
  }
  
  public final boolean isDisabled()
  {
    return hasAttribute("disabled");
  }
  
  public final String getDisabledAttribute()
  {
    return getAttribute("disabled");
  }
  
  public final String getReadOnlyAttribute()
  {
    return getAttribute("readonly");
  }
  
  public final String getTabIndexAttribute()
  {
    return getAttribute("tabindex");
  }
  
  public final String getAccessKeyAttribute()
  {
    return getAttribute("accesskey");
  }
  
  public final String getOnFocusAttribute()
  {
    return getAttribute("onfocus");
  }
  
  public final String getOnBlurAttribute()
  {
    return getAttribute("onblur");
  }
  
  public final String getOnSelectAttribute()
  {
    return getAttribute("onselect");
  }
  
  public final String getOnChangeAttribute()
  {
    return getAttribute("onchange");
  }
  
  public void select()
  {
    this.selectionDelegate_.select();
  }
  
  public String getSelectedText()
  {
    return this.selectionDelegate_.getSelectedText();
  }
  
  public int getSelectionStart()
  {
    return this.selectionDelegate_.getSelectionStart();
  }
  
  public void setSelectionStart(int selectionStart)
  {
    this.selectionDelegate_.setSelectionStart(selectionStart);
  }
  
  public int getSelectionEnd()
  {
    return this.selectionDelegate_.getSelectionEnd();
  }
  
  public void setSelectionEnd(int selectionEnd)
  {
    this.selectionDelegate_.setSelectionEnd(selectionEnd);
  }
  
  protected void printXml(String indent, PrintWriter printWriter)
  {
    printWriter.print(indent + "<");
    printOpeningTagContentAsXml(printWriter);
    
    printWriter.print(">");
    printWriter.print(StringEscapeUtils.escapeXml(getText()));
    printWriter.print("</textarea>");
  }
  
  protected void doType(char c, boolean shiftKey, boolean ctrlKey, boolean altKey)
  {
    this.doTypeProcessor_.doType(getText(), getSelectionStart(), getSelectionEnd(), c, shiftKey, ctrlKey, altKey);
  }
  
  public void focus()
  {
    super.focus();
    this.valueAtFocus_ = getText();
  }
  
  void removeFocus()
  {
    super.removeFocus();
    if (!this.valueAtFocus_.equals(getText())) {
      HtmlInput.executeOnChangeHandlerIfAppropriate(this);
    }
    this.valueAtFocus_ = null;
  }
  
  public void setReadOnly(boolean isReadOnly)
  {
    if (isReadOnly) {
      setAttribute("readOnly", "readOnly");
    } else {
      removeAttribute("readOnly");
    }
  }
  
  public boolean isReadOnly()
  {
    return hasAttribute("readOnly");
  }
  
  protected Object clone()
    throws CloneNotSupportedException
  {
    return new HtmlTextArea(getNamespaceURI(), getQualifiedName(), getPage(), getAttributesMap());
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ("name".equals(qualifiedName))
    {
      if (this.previousNames_.isEmpty()) {
        this.previousNames_ = new HashSet();
      }
      this.previousNames_.add(attributeValue);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
  
  public String getOriginalName()
  {
    return this.originalName_;
  }
  
  public Collection<String> getPreviousNames()
  {
    return this.previousNames_;
  }
  
  protected boolean isEmptyXmlTagExpanded()
  {
    return true;
  }
}
