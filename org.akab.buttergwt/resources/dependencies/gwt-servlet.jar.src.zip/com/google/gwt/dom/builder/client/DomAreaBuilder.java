package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.AreaBuilder;
import com.google.gwt.dom.client.AreaElement;

public class DomAreaBuilder
  extends DomElementBuilderBase<AreaBuilder, AreaElement>
  implements AreaBuilder
{
  DomAreaBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public AreaBuilder accessKey(String accessKey)
  {
    ((AreaElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
  
  public AreaBuilder alt(String alt)
  {
    ((AreaElement)assertCanAddAttribute()).setAlt(alt);
    return this;
  }
  
  public AreaBuilder coords(String coords)
  {
    ((AreaElement)assertCanAddAttribute()).setCoords(coords);
    return this;
  }
  
  public AreaBuilder href(String href)
  {
    ((AreaElement)assertCanAddAttribute()).setHref(href);
    return this;
  }
  
  public AreaBuilder shape(String shape)
  {
    ((AreaElement)assertCanAddAttribute()).setShape(shape);
    return this;
  }
  
  public AreaBuilder target(String target)
  {
    ((AreaElement)assertCanAddAttribute()).setTarget(target);
    return this;
  }
}
