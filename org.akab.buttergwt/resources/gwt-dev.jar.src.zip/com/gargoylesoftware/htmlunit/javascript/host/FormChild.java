package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLFormElement;

@JsxClass(isJSObject=false)
public class FormChild
  extends HTMLElement
{
  @JsxGetter
  public HTMLFormElement getForm()
  {
    HtmlForm form = getDomNodeOrDie().getEnclosingForm();
    if (form == null) {
      return null;
    }
    return (HTMLFormElement)getScriptableFor(form);
  }
}
