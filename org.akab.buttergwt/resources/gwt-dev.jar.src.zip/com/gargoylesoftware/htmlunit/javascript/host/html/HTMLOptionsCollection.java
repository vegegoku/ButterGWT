package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.html.ElementFactory;
import com.gargoylesoftware.htmlunit.html.HTMLParser;
import com.gargoylesoftware.htmlunit.html.HtmlOption;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.javascript.ScriptableWithFallbackGetter;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;

@JsxClass
public class HTMLOptionsCollection
  extends SimpleScriptable
  implements ScriptableWithFallbackGetter
{
  private HtmlSelect htmlSelect_;
  
  public HTMLOptionsCollection() {}
  
  public HTMLOptionsCollection(SimpleScriptable parentScope)
  {
    setParentScope(parentScope);
    setPrototype(getPrototype(getClass()));
  }
  
  public void initialize(HtmlSelect select)
  {
    WebAssert.notNull("select", select);
    this.htmlSelect_ = select;
  }
  
  public Object get(int index, Scriptable start)
  {
    if (index < 0) {
      throw Context.reportRuntimeError("Index or size is negative");
    }
    Object response;
    Object response;
    if (index >= this.htmlSelect_.getOptionSize()) {
      response = Context.getUndefinedValue();
    } else {
      response = getScriptableFor(this.htmlSelect_.getOption(index));
    }
    return response;
  }
  
  public void put(String name, Scriptable start, Object value)
  {
    if (this.htmlSelect_ == null)
    {
      super.put(name, start, value);
      return;
    }
    HTMLSelectElement parent = (HTMLSelectElement)this.htmlSelect_.getScriptObject();
    if ((!has(name, start)) && (ScriptableObject.hasProperty(parent, name))) {
      ScriptableObject.putProperty(parent, name, value);
    } else {
      super.put(name, start, value);
    }
  }
  
  public Object getWithFallback(String name)
  {
    if ((!getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SELECT_OPTIONS_HAS_CHILDNODES_PROPERTY)) && ("childNodes".equals(name))) {
      return NOT_FOUND;
    }
    HTMLSelectElement select = (HTMLSelectElement)this.htmlSelect_.getScriptObject();
    return ScriptableObject.getProperty(select, name);
  }
  
  @JsxFunction
  public Object item(int index)
  {
    return get(index, null);
  }
  
  public void put(int index, Scriptable start, Object newValue)
  {
    if (newValue == null)
    {
      this.htmlSelect_.removeOption(index);
    }
    else
    {
      HTMLOptionElement option = (HTMLOptionElement)newValue;
      HtmlOption htmlOption = option.getDomNodeOrNull();
      if (index >= getLength()) {
        this.htmlSelect_.appendOption(htmlOption);
      } else {
        this.htmlSelect_.replaceOption(index, htmlOption);
      }
    }
    if ((getLength() == 1) && (!this.htmlSelect_.isMultipleSelectEnabled())) {
      ((HTMLSelectElement)this.htmlSelect_.getScriptObject()).setSelectedIndex(0);
    }
  }
  
  @JsxGetter
  public int getLength()
  {
    return this.htmlSelect_.getOptionSize();
  }
  
  @JsxSetter
  public void setLength(int newLength)
  {
    int currentLength = this.htmlSelect_.getOptionSize();
    if (currentLength > newLength) {
      this.htmlSelect_.setOptionSize(newLength);
    } else {
      for (int i = currentLength; i < newLength; i++)
      {
        HtmlOption option = (HtmlOption)HTMLParser.getFactory("option").createElement(this.htmlSelect_.getPage(), "option", null);
        
        this.htmlSelect_.appendOption(option);
        if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_88)) {
          option.appendChild(new DomText(option.getPage(), ""));
        }
      }
    }
  }
  
  @JsxFunction
  public void add(Object newOptionObject, Object newIndex)
  {
    int index = getLength();
    if ((newIndex instanceof Number)) {
      index = ((Number)newIndex).intValue();
    }
    put(index, null, newOptionObject);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F)})
  public void remove(int index)
  {
    if (index < 0) {
      Context.reportRuntimeError("Invalid index: " + index);
    }
    if (index < getLength()) {
      this.htmlSelect_.removeOption(index);
    }
  }
}
