package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.MetaBuilder;
import com.google.gwt.dom.client.MetaElement;

public class DomMetaBuilder
  extends DomElementBuilderBase<MetaBuilder, MetaElement>
  implements MetaBuilder
{
  DomMetaBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public MetaBuilder content(String content)
  {
    ((MetaElement)assertCanAddAttribute()).setContent(content);
    return this;
  }
  
  public MetaBuilder httpEquiv(String httpEquiv)
  {
    ((MetaElement)assertCanAddAttribute()).setHttpEquiv(httpEquiv);
    return this;
  }
  
  public MetaBuilder name(String name)
  {
    ((MetaElement)assertCanAddAttribute()).setName(name);
    return this;
  }
}
