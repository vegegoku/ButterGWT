package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import org.apache.commons.lang3.time.DateFormatUtils;

public final class DateCustom
{
  private static final TimeZone UTC_TIME_ZONE = TimeZone.getTimeZone("UTC");
  private static Field DATE_FIELD_;
  
  public static String toLocaleDateString(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    SimpleDateFormat format = new SimpleDateFormat("EEEE, MMMM dd, yyyy", getLocale(thisObj));
    return format.format(new Date(getDateValue(thisObj)));
  }
  
  public static String toLocaleTimeString(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    String formatString;
    String formatString;
    if (((Window)thisObj.getParentScope()).getWebWindow().getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DATE_LOCATE_TIME_24)) {
      formatString = "HH:mm:ss";
    } else {
      formatString = "hh:mm:ss a";
    }
    DateFormat format = new SimpleDateFormat(formatString, getLocale(thisObj));
    return format.format(new Date(getDateValue(thisObj)));
  }
  
  public static String toUTCString(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    Date date = new Date(getDateValue(thisObj));
    return DateFormatUtils.format(date, "EEE, d MMM yyyy HH:mm:ss z", UTC_TIME_ZONE, Locale.ENGLISH);
  }
  
  private static long getDateValue(Scriptable thisObj)
  {
    try
    {
      if (DATE_FIELD_ == null)
      {
        DATE_FIELD_ = thisObj.getClass().getDeclaredField("date");
        DATE_FIELD_.setAccessible(true);
      }
      return ((Double)DATE_FIELD_.get(thisObj)).longValue();
    }
    catch (Exception e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  private static Locale getLocale(Scriptable thisObj)
  {
    BrowserVersion broserVersion = ((Window)thisObj.getParentScope()).getWebWindow().getWebClient().getBrowserVersion();
    
    return new Locale(broserVersion.getSystemLanguage());
  }
}
