package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
public class Namespace
  extends SimpleScriptable
{
  private String name_;
  private String urn_;
  
  @Deprecated
  public Namespace() {}
  
  public Namespace(ScriptableObject parentScope, String name, String urn)
  {
    setParentScope(parentScope);
    setPrototype(getPrototype(getClass()));
    this.name_ = name;
    this.urn_ = urn;
  }
  
  @JsxGetter
  public String getName()
  {
    return this.name_;
  }
  
  @JsxGetter
  public String getUrn()
  {
    return this.urn_;
  }
  
  @JsxSetter
  public void setUrn(String urn)
  {
    this.urn_ = urn;
  }
}
