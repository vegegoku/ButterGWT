package com.google.gwt.codegen.server;

import java.io.PrintWriter;

public class AbortablePrintWriter
  extends PrintWriter
{
  private boolean isClosed = false;
  
  public AbortablePrintWriter(PrintWriter pw)
  {
    super(pw);
  }
  
  public void abort()
  {
    if (!this.isClosed)
    {
      flush();
      super.close();
      this.isClosed = true;
      onClose(true);
    }
  }
  
  public void close()
  {
    if (!this.isClosed)
    {
      flush();
      super.close();
      this.isClosed = true;
      onClose(false);
    }
  }
  
  protected void onClose(boolean aborted) {}
}
