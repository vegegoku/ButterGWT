package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Function;

@JsxClass(isJSObject=false)
public class FormField
  extends FormChild
{
  public void setDomNode(DomNode domNode)
  {
    super.setDomNode(domNode);
    
    HtmlForm form = ((HtmlElement)domNode).getEnclosingForm();
    if (form != null) {
      setParentScope(getScriptableFor(form));
    }
  }
  
  @JsxGetter
  public String getValue()
  {
    return getDomNodeOrDie().getAttribute("value");
  }
  
  @JsxSetter
  public void setValue(String newValue)
  {
    getDomNodeOrDie().setAttribute("value", newValue);
  }
  
  @JsxGetter
  public String getName()
  {
    return getDomNodeOrDie().getAttribute("name");
  }
  
  @JsxSetter
  public void setName(String newName)
  {
    getDomNodeOrDie().setAttribute("name", newName);
  }
  
  @JsxGetter
  public String getType()
  {
    return getDomNodeOrDie().getAttribute("type");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOnchange(Object onchange)
  {
    setEventHandlerProp("onchange", onchange);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Function getOnchange()
  {
    return getEventHandler("onchange");
  }
  
  @JsxGetter
  public boolean getDisabled()
  {
    return super.getDisabled();
  }
  
  @JsxSetter
  public void setDisabled(boolean disabled)
  {
    super.setDisabled(disabled);
  }
}
