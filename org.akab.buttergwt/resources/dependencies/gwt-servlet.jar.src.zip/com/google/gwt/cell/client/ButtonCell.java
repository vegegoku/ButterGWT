package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.text.shared.SimpleSafeHtmlRenderer;

public class ButtonCell
  extends AbstractSafeHtmlCell<String>
{
  public ButtonCell()
  {
    this(SimpleSafeHtmlRenderer.getInstance());
  }
  
  public ButtonCell(SafeHtmlRenderer<String> renderer)
  {
    super(renderer, new String[] { "click", "keydown" });
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    if ("click".equals(event.getType()))
    {
      EventTarget eventTarget = event.getEventTarget();
      if (!Element.is(eventTarget)) {
        return;
      }
      if (parent.getFirstChildElement().isOrHasChild(Element.as(eventTarget))) {
        onEnterKeyDown(context, parent, value, event, valueUpdater);
      }
    }
  }
  
  public void render(Cell.Context context, SafeHtml data, SafeHtmlBuilder sb)
  {
    sb.appendHtmlConstant("<button type=\"button\" tabindex=\"-1\">");
    if (data != null) {
      sb.append(data);
    }
    sb.appendHtmlConstant("</button>");
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    if (valueUpdater != null) {
      valueUpdater.update(value);
    }
  }
}
