package com.google.gwt.dev.asm.tree;

import com.google.gwt.dev.asm.AnnotationVisitor;
import com.google.gwt.dev.asm.Attribute;
import com.google.gwt.dev.asm.ClassVisitor;
import com.google.gwt.dev.asm.FieldVisitor;
import java.util.ArrayList;
import java.util.List;

public class FieldNode
  extends FieldVisitor
{
  public int access;
  public String name;
  public String desc;
  public String signature;
  public Object value;
  public List<AnnotationNode> visibleAnnotations;
  public List<AnnotationNode> invisibleAnnotations;
  public List<Attribute> attrs;
  
  public FieldNode(int access, String name, String desc, String signature, Object value)
  {
    this(262144, access, name, desc, signature, value);
  }
  
  public FieldNode(int api, int access, String name, String desc, String signature, Object value)
  {
    super(api);
    this.access = access;
    this.name = name;
    this.desc = desc;
    this.signature = signature;
    this.value = value;
  }
  
  public AnnotationVisitor visitAnnotation(String desc, boolean visible)
  {
    AnnotationNode an = new AnnotationNode(desc);
    if (visible)
    {
      if (this.visibleAnnotations == null) {
        this.visibleAnnotations = new ArrayList(1);
      }
      this.visibleAnnotations.add(an);
    }
    else
    {
      if (this.invisibleAnnotations == null) {
        this.invisibleAnnotations = new ArrayList(1);
      }
      this.invisibleAnnotations.add(an);
    }
    return an;
  }
  
  public void visitAttribute(Attribute attr)
  {
    if (this.attrs == null) {
      this.attrs = new ArrayList(1);
    }
    this.attrs.add(attr);
  }
  
  public void visitEnd() {}
  
  public void check(int api) {}
  
  public void accept(ClassVisitor cv)
  {
    FieldVisitor fv = cv.visitField(this.access, this.name, this.desc, this.signature, this.value);
    if (fv == null) {
      return;
    }
    int n = this.visibleAnnotations == null ? 0 : this.visibleAnnotations.size();
    for (int i = 0; i < n; i++)
    {
      AnnotationNode an = (AnnotationNode)this.visibleAnnotations.get(i);
      an.accept(fv.visitAnnotation(an.desc, true));
    }
    n = this.invisibleAnnotations == null ? 0 : this.invisibleAnnotations.size();
    for (i = 0; i < n; i++)
    {
      AnnotationNode an = (AnnotationNode)this.invisibleAnnotations.get(i);
      an.accept(fv.visitAnnotation(an.desc, false));
    }
    n = this.attrs == null ? 0 : this.attrs.size();
    for (i = 0; i < n; i++) {
      fv.visitAttribute((Attribute)this.attrs.get(i));
    }
    fv.visitEnd();
  }
}
