package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.html.xpath.XPathUtils;
import java.io.Serializable;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.collections.Transformer;
import org.apache.commons.collections.functors.NOPTransformer;
import org.w3c.dom.Node;

class XPathDomNodeList<E extends DomNode>
  extends AbstractList<E>
  implements DomNodeList<E>, Serializable
{
  private String xpath_;
  private DomNode node_;
  private Transformer transformer_;
  private List<Object> cachedElements_;
  
  public XPathDomNodeList(DomNode node, String xpath)
  {
    this(node, xpath, NOPTransformer.INSTANCE);
  }
  
  public XPathDomNodeList(DomNode node, String xpath, Transformer transformer)
  {
    if (node != null)
    {
      this.node_ = node;
      this.xpath_ = xpath;
      this.transformer_ = transformer;
      XPathDomNodeList<E>.DomHtmlAttributeChangeListenerImpl listener = new DomHtmlAttributeChangeListenerImpl(null);
      this.node_.addDomChangeListener(listener);
      if ((this.node_ instanceof HtmlElement))
      {
        ((HtmlElement)this.node_).addHtmlAttributeChangeListener(listener);
        this.cachedElements_ = null;
      }
    }
  }
  
  private List<Object> getNodes()
  {
    if (this.cachedElements_ == null) {
      if (this.node_ != null) {
        this.cachedElements_ = XPathUtils.getByXPath(this.node_, this.xpath_, null);
      } else {
        this.cachedElements_ = new ArrayList();
      }
    }
    return this.cachedElements_;
  }
  
  public int size()
  {
    return getLength();
  }
  
  public int getLength()
  {
    return getNodes().size();
  }
  
  public Node item(int index)
  {
    return (DomNode)this.transformer_.transform(getNodes().get(index));
  }
  
  public E get(int index)
  {
    return (DomNode)getNodes().get(index);
  }
  
  public String toString()
  {
    return "XPathDomNodeList[" + this.xpath_ + "]";
  }
  
  private class DomHtmlAttributeChangeListenerImpl
    implements DomChangeListener, HtmlAttributeChangeListener
  {
    private DomHtmlAttributeChangeListenerImpl() {}
    
    public void nodeAdded(DomChangeEvent event)
    {
      XPathDomNodeList.this.cachedElements_ = null;
    }
    
    public void nodeDeleted(DomChangeEvent event)
    {
      XPathDomNodeList.this.cachedElements_ = null;
    }
    
    public void attributeAdded(HtmlAttributeChangeEvent event)
    {
      XPathDomNodeList.this.cachedElements_ = null;
    }
    
    public void attributeRemoved(HtmlAttributeChangeEvent event)
    {
      XPathDomNodeList.this.cachedElements_ = null;
    }
    
    public void attributeReplaced(HtmlAttributeChangeEvent event)
    {
      XPathDomNodeList.this.cachedElements_ = null;
    }
  }
}
