package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ElementBuilder;
import com.google.gwt.dom.client.Element;

public class DomElementBuilder
  extends DomElementBuilderBase<ElementBuilder, Element>
  implements ElementBuilder
{
  DomElementBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
