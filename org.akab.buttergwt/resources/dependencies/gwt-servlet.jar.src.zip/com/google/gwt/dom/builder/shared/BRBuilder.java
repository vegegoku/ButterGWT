package com.google.gwt.dom.builder.shared;

public abstract interface BRBuilder
  extends ElementBuilderBase<BRBuilder>
{}
