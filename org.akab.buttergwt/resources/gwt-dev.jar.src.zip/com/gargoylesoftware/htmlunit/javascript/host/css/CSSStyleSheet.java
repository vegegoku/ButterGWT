package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Cache;
import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DisabledElement;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomNodeList;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.html.HtmlCheckBoxInput;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlLink;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlRadioButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlStyle;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import com.steadystate.css.dom.CSSImportRuleImpl;
import com.steadystate.css.dom.CSSMediaRuleImpl;
import com.steadystate.css.dom.CSSStyleRuleImpl;
import com.steadystate.css.dom.CSSStyleSheetImpl;
import com.steadystate.css.parser.CSSOMParser;
import com.steadystate.css.parser.SACParserCSS3;
import com.steadystate.css.parser.SelectorListImpl;
import com.steadystate.css.parser.selectors.GeneralAdjacentSelectorImpl;
import com.steadystate.css.parser.selectors.PrefixAttributeConditionImpl;
import com.steadystate.css.parser.selectors.PseudoClassConditionImpl;
import com.steadystate.css.parser.selectors.SubstringAttributeConditionImpl;
import com.steadystate.css.parser.selectors.SuffixAttributeConditionImpl;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.css.sac.AttributeCondition;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.CSSParseException;
import org.w3c.css.sac.CombinatorCondition;
import org.w3c.css.sac.Condition;
import org.w3c.css.sac.ConditionalSelector;
import org.w3c.css.sac.ContentCondition;
import org.w3c.css.sac.DescendantSelector;
import org.w3c.css.sac.ElementSelector;
import org.w3c.css.sac.ErrorHandler;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.LangCondition;
import org.w3c.css.sac.NegativeCondition;
import org.w3c.css.sac.NegativeSelector;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SelectorList;
import org.w3c.css.sac.SiblingSelector;
import org.w3c.css.sac.SimpleSelector;
import org.w3c.dom.DOMException;
import org.w3c.dom.css.CSSImportRule;
import org.w3c.dom.css.CSSRule;
import org.w3c.dom.css.CSSStyleDeclaration;
import org.w3c.dom.stylesheets.MediaList;

@JsxClass
public class CSSStyleSheet
  extends SimpleScriptable
{
  private static final Log LOG = LogFactory.getLog(CSSStyleSheet.class);
  private static final Pattern NTH_NUMERIC = Pattern.compile("\\d+");
  private static final Pattern NTH_COMPLEX = Pattern.compile("[+-]?\\d*n\\w*([+-]\\w\\d*)?");
  private static final Pattern UNESCAPE_SELECTOR = Pattern.compile("\\\\([\\[\\]\\.:])");
  private final org.w3c.dom.css.CSSStyleSheet wrapped_;
  private final HTMLElement ownerNode_;
  private CSSRuleList cssRules_;
  private final Map<CSSImportRule, CSSStyleSheet> imports_ = new HashMap();
  private String uri_;
  private static final Set<String> CSS2_PSEUDO_CLASSES = new HashSet(Arrays.asList(new String[] { "link", "visited", "hover", "active", "focus", "lang", "first-child" }));
  private static final Set<String> CSS3_PSEUDO_CLASSES = new HashSet(Arrays.asList(new String[] { "checked", "disabled", "enabled", "indeterminated", "root", "target", "not()", "nth-child()", "nth-last-child()", "nth-of-type()", "nth-last-of-type()", "last-child", "first-of-type", "last-of-type", "only-child", "only-of-type", "empty" }));
  
  static
  {
    CSS3_PSEUDO_CLASSES.addAll(CSS2_PSEUDO_CLASSES);
  }
  
  public CSSStyleSheet()
  {
    this.wrapped_ = new CSSStyleSheetImpl();
    this.ownerNode_ = null;
  }
  
  public CSSStyleSheet(HTMLElement element, InputSource source, String uri)
  {
    setParentScope(element.getWindow());
    setPrototype(getPrototype(CSSStyleSheet.class));
    if (source != null) {
      source.setURI(uri);
    }
    this.wrapped_ = parseCSS(source);
    this.uri_ = uri;
    this.ownerNode_ = element;
  }
  
  public CSSStyleSheet(HTMLElement element, org.w3c.dom.css.CSSStyleSheet wrapped, String uri)
  {
    setParentScope(element.getWindow());
    setPrototype(getPrototype(CSSStyleSheet.class));
    this.wrapped_ = wrapped;
    this.uri_ = uri;
    this.ownerNode_ = element;
  }
  
  public org.w3c.dom.css.CSSStyleSheet getWrappedSheet()
  {
    return this.wrapped_;
  }
  
  public void modifyIfNecessary(ComputedCSSStyleDeclaration style, Element element)
  {
    org.w3c.dom.css.CSSRuleList rules = getWrappedSheet().getCssRules();
    modifyIfNecessary(style, element, rules, new HashSet());
  }
  
  private void modifyIfNecessary(ComputedCSSStyleDeclaration style, Element element, org.w3c.dom.css.CSSRuleList rules, Set<String> alreadyProcessing)
  {
    if (rules == null) {
      return;
    }
    BrowserVersion browser = getBrowserVersion();
    DomElement e = element.getDomNodeOrDie();
    int rulesLength = rules.getLength();
    for (int i = 0; i < rulesLength; i++)
    {
      CSSRule rule = rules.item(i);
      
      short ruleType = rule.getType();
      if (1 == ruleType)
      {
        CSSStyleRuleImpl styleRule = (CSSStyleRuleImpl)rule;
        SelectorList selectors = styleRule.getSelectors();
        for (int j = 0; j < selectors.getLength(); j++)
        {
          Selector selector = selectors.item(j);
          boolean selected = selects(browser, selector, e);
          if (selected)
          {
            CSSStyleDeclaration dec = styleRule.getStyle();
            style.applyStyleFromSelector(dec, selector);
          }
        }
      }
      else if (3 == ruleType)
      {
        CSSImportRuleImpl importRule = (CSSImportRuleImpl)rule;
        String media = importRule.getMedia().getMediaText();
        if (isActive(media))
        {
          CSSStyleSheet sheet = (CSSStyleSheet)this.imports_.get(importRule);
          if (sheet == null)
          {
            String uri = this.uri_ != null ? this.uri_ : e.getPage().getUrl().toExternalForm();
            String href = importRule.getHref();
            String url = UrlUtils.resolveUrl(uri, href);
            sheet = loadStylesheet(getWindow(), this.ownerNode_, null, url);
            this.imports_.put(importRule, sheet);
          }
          if (!alreadyProcessing.contains(sheet.getUri()))
          {
            org.w3c.dom.css.CSSRuleList sheetRules = sheet.getWrappedSheet().getCssRules();
            alreadyProcessing.add(getUri());
            sheet.modifyIfNecessary(style, element, sheetRules, alreadyProcessing);
          }
        }
      }
      else if (4 == ruleType)
      {
        CSSMediaRuleImpl mediaRule = (CSSMediaRuleImpl)rule;
        String media = mediaRule.getMedia().getMediaText();
        if (isActive(media))
        {
          org.w3c.dom.css.CSSRuleList internalRules = mediaRule.getCssRules();
          modifyIfNecessary(style, element, internalRules, alreadyProcessing);
        }
      }
    }
  }
  
  public static CSSStyleSheet loadStylesheet(Window window, HTMLElement element, HtmlLink link, String url)
  {
    HtmlPage page = (HtmlPage)element.getDomNodeOrDie().getPage();
    String uri = page.getUrl().toExternalForm();
    CSSStyleSheet sheet;
    try
    {
      String accept = page.getWebClient().getBrowserVersion().getCssAcceptHeader();
      WebClient client = page.getWebClient();
      WebRequest request;
      if (link != null)
      {
        WebRequest request = link.getWebRequest();
        request.setAdditionalHeader("Accept", accept);
      }
      else
      {
        request = new WebRequest(new URL(url), accept);
        String referer = page.getUrl().toExternalForm();
        request.setAdditionalHeader("Referer", referer);
      }
      uri = request.getUrl().toExternalForm();
      Cache cache = client.getCache();
      Object fromCache = cache.getCachedObject(request);
      CSSStyleSheet sheet;
      if ((fromCache != null) && ((fromCache instanceof org.w3c.dom.css.CSSStyleSheet)))
      {
        sheet = new CSSStyleSheet(element, (org.w3c.dom.css.CSSStyleSheet)fromCache, uri);
      }
      else
      {
        WebResponse response = client.loadWebResponse(request);
        uri = response.getWebRequest().getUrl().toExternalForm();
        client.printContentIfNecessary(response);
        client.throwFailingHttpStatusCodeExceptionIfNecessary(response);
        
        InputSource source = new InputSource();
        source.setByteStream(response.getContentAsStream());
        source.setEncoding(response.getContentCharset());
        sheet = new CSSStyleSheet(element, source, uri);
        cache.cacheIfPossible(request, response, sheet.getWrappedSheet());
      }
    }
    catch (FailingHttpStatusCodeException e)
    {
      LOG.error("Exception loading " + uri, e);
      InputSource source = new InputSource(new StringReader(""));
      sheet = new CSSStyleSheet(element, source, uri);
    }
    catch (IOException e)
    {
      LOG.error("IOException loading " + uri, e);
      InputSource source = new InputSource(new StringReader(""));
      sheet = new CSSStyleSheet(element, source, uri);
    }
    catch (RuntimeException e)
    {
      LOG.error("RuntimeException loading " + uri, e);
      throw Context.reportRuntimeError("Exception: " + e);
    }
    catch (Exception e)
    {
      LOG.error("Exception loading " + uri, e);
      throw Context.reportRuntimeError("Exception: " + e);
    }
    return sheet;
  }
  
  boolean selects(Selector selector, DomElement element)
  {
    return selects(getBrowserVersion(), selector, element);
  }
  
  public static boolean selects(BrowserVersion browserVersion, Selector selector, DomElement element)
  {
    if ((selector instanceof GeneralAdjacentSelectorImpl))
    {
      SiblingSelector ss = (SiblingSelector)selector;
      Selector ssSelector = ss.getSelector();
      SimpleSelector ssSiblingSelector = ss.getSiblingSelector();
      for (DomNode prev = element.getPreviousSibling(); prev != null; prev = prev.getPreviousSibling()) {
        if (((prev instanceof HtmlElement)) && (selects(browserVersion, ssSelector, (HtmlElement)prev)) && (selects(browserVersion, ssSiblingSelector, element))) {
          return true;
        }
      }
      return false;
    }
    switch (selector.getSelectorType())
    {
    case 1: 
      return true;
    case 11: 
      DomNode parentNode = element.getParentNode();
      if (parentNode == element.getPage()) {
        return false;
      }
      if (!(parentNode instanceof HtmlElement)) {
        return false;
      }
      DescendantSelector cs = (DescendantSelector)selector;
      HtmlElement parent = (HtmlElement)parentNode;
      return (selects(browserVersion, cs.getSimpleSelector(), element)) && (selects(browserVersion, cs.getAncestorSelector(), parent));
    case 10: 
      DescendantSelector ds = (DescendantSelector)selector;
      if (selects(browserVersion, ds.getSimpleSelector(), element))
      {
        DomNode ancestor = element.getParentNode();
        Selector dsAncestorSelector = ds.getAncestorSelector();
        while ((ancestor instanceof HtmlElement))
        {
          if (selects(browserVersion, dsAncestorSelector, (HtmlElement)ancestor)) {
            return true;
          }
          ancestor = ancestor.getParentNode();
        }
      }
      return false;
    case 0: 
      ConditionalSelector conditional = (ConditionalSelector)selector;
      Condition condition = conditional.getCondition();
      return (selects(browserVersion, conditional.getSimpleSelector(), element)) && (selects(browserVersion, condition, element));
    case 4: 
      ElementSelector es = (ElementSelector)selector;
      String name = es.getLocalName();
      return (name == null) || (name.equalsIgnoreCase(element.getTagName()));
    case 2: 
      return "html".equalsIgnoreCase(element.getTagName());
    case 12: 
      SiblingSelector ss = (SiblingSelector)selector;
      DomNode prev = element.getPreviousSibling();
      while ((prev != null) && (!(prev instanceof HtmlElement))) {
        prev = prev.getPreviousSibling();
      }
      return (prev != null) && (selects(browserVersion, ss.getSelector(), (HtmlElement)prev)) && (selects(browserVersion, ss.getSiblingSelector(), element));
    case 3: 
      NegativeSelector ns = (NegativeSelector)selector;
      return !selects(browserVersion, ns.getSimpleSelector(), element);
    case 5: 
    case 6: 
    case 7: 
    case 8: 
    case 9: 
      return false;
    }
    LOG.error("Unknown CSS selector type '" + selector.getSelectorType() + "'.");
    return false;
  }
  
  static boolean selects(BrowserVersion browserVersion, Condition condition, DomElement element)
  {
    if ((condition instanceof PrefixAttributeConditionImpl))
    {
      AttributeCondition ac = (AttributeCondition)condition;
      String value = ac.getValue();
      return (!"".equals(value)) && (element.getAttribute(ac.getLocalName()).startsWith(value));
    }
    if ((condition instanceof SuffixAttributeConditionImpl))
    {
      AttributeCondition ac = (AttributeCondition)condition;
      String value = ac.getValue();
      return (!"".equals(value)) && (element.getAttribute(ac.getLocalName()).endsWith(value));
    }
    if ((condition instanceof SubstringAttributeConditionImpl))
    {
      AttributeCondition ac = (AttributeCondition)condition;
      String value = ac.getValue();
      return (!"".equals(value)) && (element.getAttribute(ac.getLocalName()).contains(value));
    }
    switch (condition.getConditionType())
    {
    case 5: 
      AttributeCondition ac4 = (AttributeCondition)condition;
      return ac4.getValue().equals(element.getId());
    case 9: 
      AttributeCondition ac3 = (AttributeCondition)condition;
      String v3 = ac3.getValue();
      if (v3.indexOf('\\') > -1) {
        v3 = UNESCAPE_SELECTOR.matcher(v3).replaceAll("$1");
      }
      String a3 = element.getAttribute("class");
      return selects(v3, a3, ' ');
    case 0: 
      CombinatorCondition cc1 = (CombinatorCondition)condition;
      return (selects(browserVersion, cc1.getFirstCondition(), element)) && (selects(browserVersion, cc1.getSecondCondition(), element));
    case 4: 
      AttributeCondition ac1 = (AttributeCondition)condition;
      if (ac1.getSpecified())
      {
        String value = ac1.getValue();
        if (value.indexOf('\\') > -1)
        {
          if (!browserVersion.hasFeature(BrowserVersionFeatures.SELECTOR_ATTRIBUTE_ESCAPING)) {
            throw new CSSException("Invalid selectors: '" + value + "'");
          }
          value = UNESCAPE_SELECTOR.matcher(value).replaceAll("$1");
        }
        return element.getAttribute(ac1.getLocalName()).equals(value);
      }
      return element.hasAttribute(ac1.getLocalName());
    case 8: 
      AttributeCondition ac2 = (AttributeCondition)condition;
      String v = ac2.getValue();
      String a = element.getAttribute(ac2.getLocalName());
      return selects(v, a, '-');
    case 7: 
      AttributeCondition ac5 = (AttributeCondition)condition;
      String v2 = ac5.getValue();
      String a2 = element.getAttribute(ac5.getLocalName());
      return selects(v2, a2, ' ');
    case 1: 
      CombinatorCondition cc2 = (CombinatorCondition)condition;
      return (selects(browserVersion, cc2.getFirstCondition(), element)) || (selects(browserVersion, cc2.getSecondCondition(), element));
    case 2: 
      NegativeCondition nc = (NegativeCondition)condition;
      return !selects(browserVersion, nc.getCondition(), element);
    case 11: 
      return element.getParentNode().getChildNodes().getLength() == 1;
    case 13: 
      ContentCondition cc = (ContentCondition)condition;
      return element.asText().contains(cc.getData());
    case 6: 
      if (!browserVersion.hasFeature(BrowserVersionFeatures.CSS_SELECTOR_LANG)) {
        return false;
      }
      String lcLang = ((LangCondition)condition).getLang();
      int lcLangLength = lcLang.length();
      for (DomNode node = element; (node instanceof HtmlElement); node = node.getParentNode())
      {
        String nodeLang = ((HtmlElement)node).getAttribute("lang");
        if ((nodeLang.startsWith(lcLang)) && ((nodeLang.length() == lcLangLength) || ('-' == nodeLang.charAt(lcLangLength)))) {
          return true;
        }
      }
      return false;
    case 12: 
      String tagName = element.getTagName();
      return ((HtmlPage)element.getPage()).getElementsByTagName(tagName).getLength() == 1;
    case 10: 
      return selectsPseudoClass(browserVersion, (AttributeCondition)condition, element);
    case 3: 
      return false;
    }
    LOG.error("Unknown CSS condition type '" + condition.getConditionType() + "'.");
    return false;
  }
  
  private static boolean selects(String condition, String attribute, char separator)
  {
    int conditionLength = condition.length();
    if (conditionLength < 1) {
      return false;
    }
    int attribLength = attribute.length();
    if (attribLength < conditionLength) {
      return false;
    }
    if (attribLength > conditionLength)
    {
      if ((separator == attribute.charAt(conditionLength)) && (attribute.startsWith(condition))) {
        return true;
      }
      if ((separator == attribute.charAt(attribLength - conditionLength - 1)) && (attribute.endsWith(condition))) {
        return true;
      }
      if (attribLength + 1 > conditionLength)
      {
        StringBuilder tmp = new StringBuilder(conditionLength + 2);
        tmp.append(separator).append(condition).append(separator);
        return attribute.contains(tmp);
      }
      return false;
    }
    return attribute.equals(condition);
  }
  
  private static boolean selectsPseudoClass(BrowserVersion browserVersion, AttributeCondition condition, DomElement element)
  {
    if (browserVersion.hasFeature(BrowserVersionFeatures.QUERYSELECTORALL_NOT_IN_QUIRKS))
    {
      ScriptableObject sobj = element.getPage().getScriptObject();
      if (((sobj instanceof HTMLDocument)) && (((HTMLDocument)sobj).getDocumentMode() < 8)) {
        return false;
      }
    }
    String value = condition.getValue();
    if ("root".equals(value)) {
      return element == element.getPage().getDocumentElement();
    }
    if ("enabled".equals(value)) {
      return ((element instanceof DisabledElement)) && (!((DisabledElement)element).isDisabled());
    }
    if ("disabled".equals(value)) {
      return ((element instanceof DisabledElement)) && (((DisabledElement)element).isDisabled());
    }
    if ("focus".equals(value))
    {
      HtmlPage htmlPage = element.getHtmlPageOrNull();
      if (htmlPage != null)
      {
        HtmlElement focus = htmlPage.getFocusedElement();
        return element == focus;
      }
    }
    else
    {
      if ("checked".equals(value)) {
        return (((element instanceof HtmlCheckBoxInput)) && (((HtmlCheckBoxInput)element).isChecked())) || (((element instanceof HtmlRadioButtonInput)) && (((HtmlRadioButtonInput)element).isChecked()));
      }
      if ("first-child".equals(value))
      {
        for (DomNode n = element.getPreviousSibling(); n != null; n = n.getPreviousSibling()) {
          if ((n instanceof DomElement)) {
            return false;
          }
        }
        return true;
      }
      if ("last-child".equals(value))
      {
        for (DomNode n = element.getNextSibling(); n != null; n = n.getNextSibling()) {
          if ((n instanceof DomElement)) {
            return false;
          }
        }
        return true;
      }
      if ("first-of-type".equals(value))
      {
        String type = element.getNodeName();
        for (DomNode n = element.getPreviousSibling(); n != null; n = n.getPreviousSibling()) {
          if (((n instanceof DomElement)) && (n.getNodeName().equals(type))) {
            return false;
          }
        }
        return true;
      }
      if ("last-of-type".equals(value))
      {
        String type = element.getNodeName();
        for (DomNode n = element.getNextSibling(); n != null; n = n.getNextSibling()) {
          if (((n instanceof DomElement)) && (n.getNodeName().equals(type))) {
            return false;
          }
        }
        return true;
      }
      if (value.startsWith("nth-child("))
      {
        String nth = value.substring(value.indexOf('(') + 1, value.length() - 1);
        int index = 0;
        for (DomNode n = element; n != null; n = n.getPreviousSibling()) {
          if ((n instanceof DomElement)) {
            index++;
          }
        }
        return getNth(nth, index);
      }
      if (value.startsWith("nth-last-child("))
      {
        String nth = value.substring(value.indexOf('(') + 1, value.length() - 1);
        int index = 0;
        for (DomNode n = element; n != null; n = n.getNextSibling()) {
          if ((n instanceof DomElement)) {
            index++;
          }
        }
        return getNth(nth, index);
      }
      if (value.startsWith("nth-of-type("))
      {
        String type = element.getNodeName();
        String nth = value.substring(value.indexOf('(') + 1, value.length() - 1);
        int index = 0;
        for (DomNode n = element; n != null; n = n.getPreviousSibling()) {
          if (((n instanceof DomElement)) && (n.getNodeName().equals(type))) {
            index++;
          }
        }
        return getNth(nth, index);
      }
      if (value.startsWith("nth-last-of-type("))
      {
        String type = element.getNodeName();
        String nth = value.substring(value.indexOf('(') + 1, value.length() - 1);
        int index = 0;
        for (DomNode n = element; n != null; n = n.getNextSibling()) {
          if (((n instanceof DomElement)) && (n.getNodeName().equals(type))) {
            index++;
          }
        }
        return getNth(nth, index);
      }
      if ("only-child".equals(value))
      {
        for (DomNode n = element.getPreviousSibling(); n != null; n = n.getPreviousSibling()) {
          if ((n instanceof DomElement)) {
            return false;
          }
        }
        for (DomNode n = element.getNextSibling(); n != null; n = n.getNextSibling()) {
          if ((n instanceof DomElement)) {
            return false;
          }
        }
        return true;
      }
      if ("only-of-type".equals(value))
      {
        String type = element.getNodeName();
        for (DomNode n = element.getPreviousSibling(); n != null; n = n.getPreviousSibling()) {
          if (((n instanceof DomElement)) && (n.getNodeName().equals(type))) {
            return false;
          }
        }
        for (DomNode n = element.getNextSibling(); n != null; n = n.getNextSibling()) {
          if (((n instanceof DomElement)) && (n.getNodeName().equals(type))) {
            return false;
          }
        }
        return true;
      }
      if ("empty".equals(value)) {
        return isEmpty(element);
      }
      if ("target".equals(value))
      {
        String ref = element.getPage().getUrl().getRef();
        return (StringUtils.isNotBlank(ref)) && (ref.equals(element.getId()));
      }
      if (value.startsWith("not("))
      {
        String selectors = value.substring(value.indexOf('(') + 1, value.length() - 1);
        AtomicBoolean errorOccured = new AtomicBoolean(false);
        ErrorHandler errorHandler = new ErrorHandler()
        {
          public void warning(CSSParseException exception)
            throws CSSException
          {}
          
          public void fatalError(CSSParseException exception)
            throws CSSException
          {
            this.val$errorOccured.set(true);
          }
          
          public void error(CSSParseException exception)
            throws CSSException
          {
            this.val$errorOccured.set(true);
          }
        };
        CSSOMParser parser = new CSSOMParser(new SACParserCSS3());
        parser.setErrorHandler(errorHandler);
        try
        {
          SelectorList selectorList = parser.parseSelectors(new InputSource(new StringReader(selectors)));
          if ((errorOccured.get()) || (selectorList == null) || (selectorList.getLength() != 1)) {
            throw new CSSException("Invalid selectors: " + selectors);
          }
          validateSelectors(selectorList, 9);
          
          return !selects(browserVersion, selectorList.item(0), element);
        }
        catch (IOException e)
        {
          throw new CSSException("Error parsing CSS selectors from '" + selectors + "': " + e.getMessage());
        }
      }
    }
    return false;
  }
  
  private static boolean isEmpty(DomElement element)
  {
    for (DomNode n = element.getFirstChild(); n != null; n = n.getNextSibling()) {
      if (((n instanceof DomElement)) || ((n instanceof DomText))) {
        return false;
      }
    }
    return true;
  }
  
  private static boolean getNth(String nth, int index)
  {
    if ("odd".equalsIgnoreCase(nth)) {
      return index % 2 != 0;
    }
    if ("even".equalsIgnoreCase(nth)) {
      return index % 2 == 0;
    }
    int nIndex = nth.indexOf('n');
    int a = 0;
    if (nIndex != -1)
    {
      String value = nth.substring(0, nIndex).trim();
      if ("-".equals(value))
      {
        a = -1;
      }
      else
      {
        if (value.startsWith("+")) {
          value = value.substring(1);
        }
        a = NumberUtils.toInt(value, 1);
      }
    }
    String value = nth.substring(nIndex + 1).trim();
    if (value.startsWith("+")) {
      value = value.substring(1);
    }
    int b = NumberUtils.toInt(value, 0);
    if (a == 0) {
      return (index == b) && (b > 0);
    }
    double n = (index - b) / a;
    return (n >= 0.0D) && (n % 1.0D == 0.0D);
  }
  
  private org.w3c.dom.css.CSSStyleSheet parseCSS(InputSource source)
  {
    org.w3c.dom.css.CSSStyleSheet ss;
    try
    {
      ErrorHandler errorHandler = getWindow().getWebWindow().getWebClient().getCssErrorHandler();
      CSSOMParser parser = new CSSOMParser(new SACParserCSS3());
      parser.setErrorHandler(errorHandler);
      ss = parser.parseStyleSheet(source, null, null);
    }
    catch (Exception e)
    {
      LOG.error("Error parsing CSS from '" + toString(source) + "': " + e.getMessage(), e);
      ss = new CSSStyleSheetImpl();
    }
    catch (Error e)
    {
      LOG.error("Error parsing CSS from '" + toString(source) + "': " + e.getMessage(), e);
      ss = new CSSStyleSheetImpl();
    }
    return ss;
  }
  
  public SelectorList parseSelectors(InputSource source)
  {
    SelectorList selectors;
    try
    {
      ErrorHandler errorHandler = getWindow().getWebWindow().getWebClient().getCssErrorHandler();
      CSSOMParser parser = new CSSOMParser(new SACParserCSS3());
      parser.setErrorHandler(errorHandler);
      selectors = parser.parseSelectors(source);
      if (null == selectors) {
        selectors = new SelectorListImpl();
      }
    }
    catch (Exception e)
    {
      LOG.error("Error parsing CSS selectors from '" + toString(source) + "': " + e.getMessage(), e);
      selectors = new SelectorListImpl();
    }
    catch (Error e)
    {
      LOG.error("Error parsing CSS selectors from '" + toString(source) + "': " + e.getMessage(), e);
      selectors = new SelectorListImpl();
    }
    return selectors;
  }
  
  private static String toString(InputSource source)
  {
    try
    {
      Reader reader = source.getCharacterStream();
      if (null != reader)
      {
        if ((reader instanceof StringReader))
        {
          StringReader sr = (StringReader)reader;
          sr.reset();
        }
        return IOUtils.toString(reader);
      }
      InputStream is = source.getByteStream();
      if (null != is)
      {
        if ((is instanceof ByteArrayInputStream))
        {
          ByteArrayInputStream bis = (ByteArrayInputStream)is;
          bis.reset();
        }
        return IOUtils.toString(is);
      }
      return "";
    }
    catch (IOException e) {}
    return "";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public HTMLElement getOwnerNode()
  {
    return this.ownerNode_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public HTMLElement getOwningElement()
  {
    return this.ownerNode_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public CSSRuleList getRules()
  {
    return getCssRules();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public CSSRuleList getCssRules()
  {
    if (this.cssRules_ == null) {
      this.cssRules_ = new CSSRuleList(this);
    }
    return this.cssRules_;
  }
  
  @JsxGetter
  public String getHref()
  {
    BrowserVersion version = getBrowserVersion();
    if (this.ownerNode_ != null)
    {
      DomNode node = this.ownerNode_.getDomNodeOrDie();
      if ((node instanceof HtmlLink))
      {
        HtmlLink link = (HtmlLink)node;
        HtmlPage page = (HtmlPage)link.getPage();
        String href = link.getHrefAttribute();
        if (!version.hasFeature(BrowserVersionFeatures.STYLESHEET_HREF_EXPANDURL)) {
          return href;
        }
        try
        {
          URL url = page.getFullyQualifiedUrl(href);
          return url.toExternalForm();
        }
        catch (MalformedURLException e)
        {
          LOG.warn(e.getMessage(), e);
        }
      }
    }
    if (version.hasFeature(BrowserVersionFeatures.STYLESHEET_HREF_STYLE_EMPTY)) {
      return "";
    }
    if (version.hasFeature(BrowserVersionFeatures.STYLESHEET_HREF_STYLE_NULL)) {
      return null;
    }
    DomNode node = this.ownerNode_.getDomNodeOrDie();
    HtmlPage page = (HtmlPage)node.getPage();
    URL url = page.getUrl();
    return url.toExternalForm();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int insertRule(String rule, int position)
  {
    try
    {
      return this.wrapped_.insertRule(rule, position);
    }
    catch (DOMException e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void deleteRule(int position)
  {
    try
    {
      this.wrapped_.deleteRule(position);
    }
    catch (DOMException e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int addRule(String selector, String rule)
  {
    String completeRule = selector + " {" + rule + "}";
    try
    {
      this.wrapped_.insertRule(completeRule, this.wrapped_.getCssRules().getLength());
    }
    catch (DOMException e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
    return -1;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void removeRule(int position)
  {
    try
    {
      this.wrapped_.deleteRule(position);
    }
    catch (DOMException e)
    {
      throw Context.throwAsScriptRuntimeEx(e);
    }
  }
  
  public String getUri()
  {
    return this.uri_;
  }
  
  public boolean isActive()
  {
    HtmlElement e = this.ownerNode_.getDomNodeOrNull();
    String media;
    String media;
    if ((e instanceof HtmlStyle))
    {
      HtmlStyle style = (HtmlStyle)e;
      media = style.getMediaAttribute();
    }
    else
    {
      String media;
      if ((e instanceof HtmlLink))
      {
        HtmlLink link = (HtmlLink)e;
        media = link.getMediaAttribute();
      }
      else
      {
        media = "";
      }
    }
    return isActive(media);
  }
  
  private static boolean isActive(String media)
  {
    if (StringUtils.isBlank(media)) {
      return true;
    }
    for (String s : StringUtils.split(media, ','))
    {
      String mediaType = s.trim();
      if (("screen".equals(mediaType)) || ("all".equals(mediaType))) {
        return true;
      }
    }
    return false;
  }
  
  public static void validateSelectors(SelectorList selectorList, int documentMode)
    throws CSSException
  {
    for (int i = 0; i < selectorList.getLength(); i++)
    {
      Selector item = selectorList.item(i);
      if (!isValidSelector(item, documentMode)) {
        throw new CSSException("Invalid selector: " + item);
      }
    }
  }
  
  private static boolean isValidSelector(Selector selector, int documentMode)
  {
    switch (selector.getSelectorType())
    {
    case 4: 
      return true;
    case 0: 
      ConditionalSelector conditional = (ConditionalSelector)selector;
      return (isValidSelector(conditional.getSimpleSelector(), documentMode)) && (isValidSelector(conditional.getCondition(), documentMode));
    case 10: 
    case 11: 
      DescendantSelector ds = (DescendantSelector)selector;
      return (isValidSelector(ds.getAncestorSelector(), documentMode)) && (isValidSelector(ds.getSimpleSelector(), documentMode));
    case 12: 
      SiblingSelector ss = (SiblingSelector)selector;
      return (isValidSelector(ss.getSelector(), documentMode)) && (isValidSelector(ss.getSiblingSelector(), documentMode));
    case 1: 
      if ((selector instanceof SiblingSelector))
      {
        SiblingSelector sibling = (SiblingSelector)selector;
        return (isValidSelector(sibling.getSelector(), documentMode)) && (isValidSelector(sibling.getSiblingSelector(), documentMode));
      }
      break;
    }
    LOG.warn("Unhandled CSS selector type '" + selector.getSelectorType() + "'. Accepting it silently.");
    return true;
  }
  
  private static boolean isValidSelector(Condition condition, int documentMode)
  {
    switch (condition.getConditionType())
    {
    case 0: 
      CombinatorCondition cc1 = (CombinatorCondition)condition;
      return (isValidSelector(cc1.getFirstCondition(), documentMode)) && (isValidSelector(cc1.getSecondCondition(), documentMode));
    case 4: 
    case 5: 
    case 9: 
      return true;
    case 10: 
      PseudoClassConditionImpl pcc = (PseudoClassConditionImpl)condition;
      String value = pcc.getValue();
      if (value.endsWith(")"))
      {
        if (value.endsWith("()")) {
          return false;
        }
        value = value.substring(0, value.indexOf('(') + 1) + ')';
      }
      if (documentMode < 9) {
        return CSS2_PSEUDO_CLASSES.contains(value);
      }
      if ("nth-child()".equals(value))
      {
        String arg = StringUtils.substringBetween(pcc.getValue(), "(", ")").trim();
        return ("even".equalsIgnoreCase(arg)) || ("odd".equalsIgnoreCase(arg)) || (NTH_NUMERIC.matcher(arg).matches()) || (NTH_COMPLEX.matcher(arg).matches());
      }
      return CSS3_PSEUDO_CLASSES.contains(value);
    }
    LOG.warn("Unhandled CSS condition type '" + condition.getConditionType() + "'. Accepting it silently.");
    return true;
  }
}
