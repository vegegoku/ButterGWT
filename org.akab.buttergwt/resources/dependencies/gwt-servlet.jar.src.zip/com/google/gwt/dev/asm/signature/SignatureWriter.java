package com.google.gwt.dev.asm.signature;

public class SignatureWriter
  extends SignatureVisitor
{
  private final StringBuffer buf = new StringBuffer();
  private boolean hasFormals;
  private boolean hasParameters;
  private int argumentStack;
  
  public SignatureWriter()
  {
    super(262144);
  }
  
  public void visitFormalTypeParameter(String name)
  {
    if (!this.hasFormals)
    {
      this.hasFormals = true;
      this.buf.append('<');
    }
    this.buf.append(name);
    this.buf.append(':');
  }
  
  public SignatureVisitor visitClassBound()
  {
    return this;
  }
  
  public SignatureVisitor visitInterfaceBound()
  {
    this.buf.append(':');
    return this;
  }
  
  public SignatureVisitor visitSuperclass()
  {
    endFormals();
    return this;
  }
  
  public SignatureVisitor visitInterface()
  {
    return this;
  }
  
  public SignatureVisitor visitParameterType()
  {
    endFormals();
    if (!this.hasParameters)
    {
      this.hasParameters = true;
      this.buf.append('(');
    }
    return this;
  }
  
  public SignatureVisitor visitReturnType()
  {
    endFormals();
    if (!this.hasParameters) {
      this.buf.append('(');
    }
    this.buf.append(')');
    return this;
  }
  
  public SignatureVisitor visitExceptionType()
  {
    this.buf.append('^');
    return this;
  }
  
  public void visitBaseType(char descriptor)
  {
    this.buf.append(descriptor);
  }
  
  public void visitTypeVariable(String name)
  {
    this.buf.append('T');
    this.buf.append(name);
    this.buf.append(';');
  }
  
  public SignatureVisitor visitArrayType()
  {
    this.buf.append('[');
    return this;
  }
  
  public void visitClassType(String name)
  {
    this.buf.append('L');
    this.buf.append(name);
    this.argumentStack *= 2;
  }
  
  public void visitInnerClassType(String name)
  {
    endArguments();
    this.buf.append('.');
    this.buf.append(name);
    this.argumentStack *= 2;
  }
  
  public void visitTypeArgument()
  {
    if (this.argumentStack % 2 == 0)
    {
      this.argumentStack += 1;
      this.buf.append('<');
    }
    this.buf.append('*');
  }
  
  public SignatureVisitor visitTypeArgument(char wildcard)
  {
    if (this.argumentStack % 2 == 0)
    {
      this.argumentStack += 1;
      this.buf.append('<');
    }
    if (wildcard != '=') {
      this.buf.append(wildcard);
    }
    return this;
  }
  
  public void visitEnd()
  {
    endArguments();
    this.buf.append(';');
  }
  
  public String toString()
  {
    return this.buf.toString();
  }
  
  private void endFormals()
  {
    if (this.hasFormals)
    {
      this.hasFormals = false;
      this.buf.append('>');
    }
  }
  
  private void endArguments()
  {
    if (this.argumentStack % 2 != 0) {
      this.buf.append('>');
    }
    this.argumentStack /= 2;
  }
}
