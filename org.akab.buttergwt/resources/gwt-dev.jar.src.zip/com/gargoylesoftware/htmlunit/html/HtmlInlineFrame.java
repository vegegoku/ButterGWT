package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlInlineFrame
  extends BaseFrameElement
{
  public static final String TAG_NAME = "iframe";
  
  HtmlInlineFrame(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  protected boolean isEmptyXmlTagExpanded()
  {
    return true;
  }
}
