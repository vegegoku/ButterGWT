package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.BRBuilder;
import com.google.gwt.dom.client.BRElement;

public class DomBRBuilder
  extends DomElementBuilderBase<BRBuilder, BRElement>
  implements BRBuilder
{
  DomBRBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
}
