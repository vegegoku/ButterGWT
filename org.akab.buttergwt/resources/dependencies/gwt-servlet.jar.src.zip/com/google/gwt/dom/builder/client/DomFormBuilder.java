package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.FormBuilder;
import com.google.gwt.dom.client.FormElement;
import com.google.gwt.safehtml.shared.SafeUri;

public class DomFormBuilder
  extends DomElementBuilderBase<FormBuilder, FormElement>
  implements FormBuilder
{
  DomFormBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public FormBuilder acceptCharset(String acceptCharset)
  {
    ((FormElement)assertCanAddAttribute()).setAcceptCharset(acceptCharset);
    return this;
  }
  
  public FormBuilder action(SafeUri action)
  {
    ((FormElement)assertCanAddAttribute()).setAction(action);
    return this;
  }
  
  public FormBuilder action(String action)
  {
    ((FormElement)assertCanAddAttribute()).setAction(action);
    return this;
  }
  
  public FormBuilder enctype(String enctype)
  {
    ((FormElement)assertCanAddAttribute()).setEnctype(enctype);
    return this;
  }
  
  public FormBuilder method(String method)
  {
    ((FormElement)assertCanAddAttribute()).setMethod(method);
    return this;
  }
  
  public FormBuilder name(String name)
  {
    ((FormElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public FormBuilder target(String target)
  {
    ((FormElement)assertCanAddAttribute()).setTarget(target);
    return this;
  }
}
