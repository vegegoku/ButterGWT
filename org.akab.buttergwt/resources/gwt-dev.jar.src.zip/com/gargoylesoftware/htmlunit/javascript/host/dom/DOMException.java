package com.gargoylesoftware.htmlunit.javascript.host.dom;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstant;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
public class DOMException
  extends SimpleScriptable
{
  @JsxConstant
  public static final short DOMSTRING_SIZE_ERR = 2;
  @JsxConstant
  public static final short HIERARCHY_REQUEST_ERR = 3;
  @JsxConstant
  public static final short INDEX_SIZE_ERR = 1;
  @JsxConstant
  public static final short INUSE_ATTRIBUTE_ERR = 10;
  @JsxConstant
  public static final short INVALID_ACCESS_ERR = 15;
  @JsxConstant
  public static final short INVALID_CHARACTER_ERR = 5;
  @JsxConstant
  public static final short INVALID_MODIFICATION_ERR = 13;
  @JsxConstant
  public static final short INVALID_STATE_ERR = 11;
  @JsxConstant
  public static final short NAMESPACE_ERR = 14;
  @JsxConstant
  public static final short NO_DATA_ALLOWED_ERR = 6;
  @JsxConstant
  public static final short NO_MODIFICATION_ALLOWED_ERR = 7;
  @JsxConstant
  public static final short NOT_FOUND_ERR = 8;
  @JsxConstant
  public static final short NOT_SUPPORTED_ERR = 9;
  @JsxConstant
  public static final short SYNTAX_ERR = 12;
  @JsxConstant
  public static final short WRONG_DOCUMENT_ERR = 4;
  private final short code_;
  private final String message_;
  private int lineNumber_;
  private String fileName_;
  
  public DOMException()
  {
    this.code_ = -1;
    this.message_ = null;
  }
  
  public DOMException(String message, short errorCode)
  {
    this.code_ = errorCode;
    this.message_ = message;
  }
  
  @JsxGetter
  public Object getCode()
  {
    if (this.code_ == -1) {
      return Context.getUndefinedValue();
    }
    return Short.valueOf(this.code_);
  }
  
  @JsxGetter
  public Object getMessage()
  {
    if (this.message_ == null) {
      return Context.getUndefinedValue();
    }
    return this.message_;
  }
  
  @JsxGetter
  public Object getLineNumber()
  {
    if (this.lineNumber_ == -1) {
      return Context.getUndefinedValue();
    }
    return Integer.valueOf(this.lineNumber_);
  }
  
  @JsxGetter
  public Object getFilename()
  {
    if (this.fileName_ == null) {
      return Context.getUndefinedValue();
    }
    return this.fileName_;
  }
  
  public void setLocation(String fileName, int lineNumber)
  {
    this.fileName_ = fileName;
    this.lineNumber_ = lineNumber;
  }
}
