package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomComment;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.configuration.ClassConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.JavaScriptConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.host.NodeList;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;

@JsxClass
public class HTMLCollection
  extends NodeList
{
  private int currentIndex_ = 0;
  
  @Deprecated
  public HTMLCollection() {}
  
  private HTMLCollection(ScriptableObject parentScope)
  {
    setParentScope(parentScope);
    setPrototype(getPrototype(getClass()));
  }
  
  public HTMLCollection(DomNode parentScope, boolean attributeChangeSensitive, String description)
  {
    super(parentScope, attributeChangeSensitive, description);
  }
  
  HTMLCollection(DomNode parentScope, List<?> initialElements)
  {
    super(parentScope, initialElements);
  }
  
  public static HTMLCollection emptyCollection(Window window)
  {
    final List<Object> list = Collections.emptyList();
    new HTMLCollection(window, list)
    {
      public List<Object> getElements()
      {
        return list;
      }
    };
  }
  
  private Object getIt(Object o)
  {
    if ((o instanceof Number))
    {
      Number n = (Number)o;
      int i = n.intValue();
      return get(i, this);
    }
    String key = String.valueOf(o);
    return get(key, this);
  }
  
  protected List<Object> computeElements()
  {
    List<Object> response = new ArrayList();
    DomNode domNode = getDomNodeOrNull();
    if (domNode == null) {
      return response;
    }
    boolean commentIsElement = getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_COMMENT_IS_ELEMENT);
    for (DomNode node : getCandidates()) {
      if ((((node instanceof DomElement)) || ((commentIsElement) && ((node instanceof DomComment)))) && (isMatching(node))) {
        response.add(node);
      }
    }
    return response;
  }
  
  protected Iterable<DomNode> getCandidates()
  {
    DomNode domNode = getDomNodeOrNull();
    return domNode.getDescendants();
  }
  
  protected boolean isMatching(DomNode node)
  {
    return false;
  }
  
  protected Object getWithPreemption(String name)
  {
    if ("length".equals(name)) {
      return NOT_FOUND;
    }
    List<Object> elements = getElements();
    
    List<Object> matchingElements = new ArrayList();
    for (Object next : elements) {
      if ((next instanceof DomElement))
      {
        String id = ((DomElement)next).getAttribute("id");
        if (name.equals(id))
        {
          if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_IDENTICAL_IDS)) {
            return getScriptableForElement(next);
          }
          matchingElements.add(next);
        }
      }
    }
    if (matchingElements.size() == 1) {
      return getScriptableForElement(matchingElements.get(0));
    }
    if (!matchingElements.isEmpty())
    {
      HTMLCollection collection = new HTMLCollection(getDomNodeOrDie(), matchingElements);
      collection.setAvoidObjectDetection(!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_OBJECT_DETECTION));
      
      return collection;
    }
    for (Object next : elements) {
      if ((next instanceof DomElement))
      {
        String nodeName = ((DomElement)next).getAttribute("name");
        if (name.equals(nodeName))
        {
          if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_IDENTICAL_IDS)) {
            return getScriptableForElement(next);
          }
          matchingElements.add(next);
        }
      }
    }
    if (matchingElements.isEmpty()) {
      return NOT_FOUND;
    }
    if (matchingElements.size() == 1) {
      return getScriptableForElement(matchingElements.get(0));
    }
    DomNode domNode = getDomNodeOrNull();
    HTMLCollection collection = new HTMLCollection(domNode, matchingElements);
    collection.setAvoidObjectDetection(!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_OBJECT_DETECTION));
    return collection;
  }
  
  private Object nullIfNotFound(Object object)
  {
    if (object == NOT_FOUND)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_48)) {
        return null;
      }
      return Context.getUndefinedValue();
    }
    return object;
  }
  
  @JsxFunction
  public final Object namedItem(String name)
  {
    return nullIfNotFound(getIt(name));
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object nextNode()
  {
    List<Object> elements = getElements();
    Object nextNode;
    Object nextNode;
    if ((this.currentIndex_ >= 0) && (this.currentIndex_ < elements.size())) {
      nextNode = elements.get(this.currentIndex_);
    } else {
      nextNode = null;
    }
    this.currentIndex_ += 1;
    return nextNode;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void reset()
  {
    this.currentIndex_ = 0;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object tags(final String tagName)
  {
    HTMLCollection collection = new HTMLSubCollection(this, ".tags('" + tagName + "')")
    {
      protected boolean isMatching(DomNode node)
      {
        return tagName.equalsIgnoreCase(node.getLocalName());
      }
    };
    return collection;
  }
  
  protected Object equivalentValues(Object other)
  {
    if (other == this) {
      return Boolean.TRUE;
    }
    if ((other instanceof HTMLCollection))
    {
      HTMLCollection otherArray = (HTMLCollection)other;
      DomNode domNode = getDomNodeOrNull();
      DomNode domNodeOther = otherArray.getDomNodeOrNull();
      if ((getClass() == other.getClass()) && (domNode == domNodeOther) && (getElements().equals(otherArray.getElements()))) {
        return Boolean.TRUE;
      }
      return NOT_FOUND;
    }
    return super.equivalentValues(other);
  }
  
  public Object[] getIds()
  {
    if (isPrototype()) {
      return super.getIds();
    }
    List<String> idList = new ArrayList();
    
    List<Object> elements = getElements();
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_50))
    {
      int length = elements.size();
      for (int i = 0; i < length; i++) {
        idList.add(Integer.toString(i));
      }
      idList.add("length");
      JavaScriptConfiguration jsConfig = getWindow().getWebWindow().getWebClient().getJavaScriptEngine().getJavaScriptConfiguration();
      for (String name : jsConfig.getClassConfiguration(getClassName()).functionKeys()) {
        idList.add(name);
      }
    }
    else
    {
      idList.add("length");
      
      addElementIds(idList, elements);
    }
    return idList.toArray();
  }
  
  private boolean isPrototype()
  {
    return !(getPrototype() instanceof HTMLCollection);
  }
  
  protected void addElementIds(List<String> idList, List<Object> elements)
  {
    int index = 0;
    for (Object next : elements)
    {
      HtmlElement element = (HtmlElement)next;
      String name = element.getAttribute("name");
      if (name != DomElement.ATTRIBUTE_NOT_DEFINED)
      {
        idList.add(name);
      }
      else
      {
        String id = element.getId();
        if (id != DomElement.ATTRIBUTE_NOT_DEFINED) {
          idList.add(id);
        } else {
          idList.add(Integer.toString(index));
        }
      }
      index++;
    }
  }
  
  protected Scriptable getScriptableForElement(Object object)
  {
    if ((object instanceof Scriptable)) {
      return (Scriptable)object;
    }
    return getScriptableFor(object);
  }
  
  public String getClassName()
  {
    return "HTMLCollection";
  }
}
