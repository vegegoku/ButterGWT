package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlMedia;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;

@JsxClass(isJSObject=false)
public class HTMLMediaElement
  extends HTMLElement
{
  @JsxFunction
  public String canPlayType(String type)
  {
    return ((HtmlMedia)getDomNodeOrDie()).canPlayType(type);
  }
}
