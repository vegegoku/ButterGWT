package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.FrameBuilder;
import com.google.gwt.dom.client.FrameElement;
import com.google.gwt.safehtml.shared.SafeUri;

public class DomFrameBuilder
  extends DomElementBuilderBase<FrameBuilder, FrameElement>
  implements FrameBuilder
{
  DomFrameBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public FrameBuilder frameBorder(int frameBorder)
  {
    ((FrameElement)assertCanAddAttribute()).setFrameBorder(frameBorder);
    return this;
  }
  
  public FrameBuilder longDesc(SafeUri longDesc)
  {
    ((FrameElement)assertCanAddAttribute()).setLongDesc(longDesc);
    return this;
  }
  
  public FrameBuilder longDesc(String longDesc)
  {
    ((FrameElement)assertCanAddAttribute()).setLongDesc(longDesc);
    return this;
  }
  
  public FrameBuilder marginHeight(int marginHeight)
  {
    ((FrameElement)assertCanAddAttribute()).setMarginHeight(marginHeight);
    return this;
  }
  
  public FrameBuilder marginWidth(int marginWidth)
  {
    ((FrameElement)assertCanAddAttribute()).setMarginWidth(marginWidth);
    return this;
  }
  
  public FrameBuilder name(String name)
  {
    ((FrameElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public FrameBuilder noResize()
  {
    ((FrameElement)assertCanAddAttribute()).setNoResize(true);
    return this;
  }
  
  public FrameBuilder scrolling(String scrolling)
  {
    ((FrameElement)assertCanAddAttribute()).setScrolling(scrolling);
    return this;
  }
  
  public FrameBuilder src(SafeUri src)
  {
    ((FrameElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
  
  public FrameBuilder src(String src)
  {
    ((FrameElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
}
