package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeEvent;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlLink;
import com.gargoylesoftware.htmlunit.html.HtmlStyle;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.NodeList.EffectOnCache;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCollection;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLLinkElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLStyleElement;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass
public class StyleSheetList
  extends SimpleScriptable
{
  private HTMLCollection nodes_;
  
  public static boolean isStyleSheetLink(DomNode domNode)
  {
    return ((domNode instanceof HtmlLink)) && ("stylesheet".equalsIgnoreCase(((HtmlLink)domNode).getRelAttribute()));
  }
  
  public StyleSheetList() {}
  
  public StyleSheetList(HTMLDocument document)
  {
    setParentScope(document);
    setPrototype(getPrototype(getClass()));
    
    boolean cssEnabled = getWindow().getWebWindow().getWebClient().getOptions().isCssEnabled();
    if (cssEnabled) {
      this.nodes_ = new HTMLCollection(document.getDomNodeOrDie(), true, "stylesheets")
      {
        protected boolean isMatching(DomNode node)
        {
          return ((node instanceof HtmlStyle)) || (StyleSheetList.isStyleSheetLink(node));
        }
        
        protected NodeList.EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
        {
          HtmlElement node = event.getHtmlElement();
          if (((node instanceof HtmlLink)) && ("rel".equalsIgnoreCase(event.getName()))) {
            return NodeList.EffectOnCache.RESET;
          }
          return NodeList.EffectOnCache.NONE;
        }
      };
    } else {
      this.nodes_ = HTMLCollection.emptyCollection(getWindow());
    }
  }
  
  @JsxGetter
  public int getLength()
  {
    return this.nodes_.getLength();
  }
  
  @JsxFunction
  public Object item(int index)
  {
    if (index < 0) {
      throw Context.reportRuntimeError("Invalid negative index: " + index);
    }
    if (index >= this.nodes_.getLength())
    {
      if (getWindow().getWebWindow().getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_STYLESHEET_LIST_EXEPTION_FOR_ALL_INVALID_INDEXES)) {
        throw Context.reportRuntimeError("Invalid index: " + index);
      }
      return Context.getUndefinedValue();
    }
    HTMLElement element = (HTMLElement)this.nodes_.item(Integer.valueOf(index));
    CSSStyleSheet sheet;
    CSSStyleSheet sheet;
    if ((element instanceof HTMLStyleElement)) {
      sheet = ((HTMLStyleElement)element).getSheet();
    } else {
      sheet = ((HTMLLinkElement)element).getSheet();
    }
    return sheet;
  }
  
  public Object get(int index, Scriptable start)
  {
    if (this == start) {
      return item(index);
    }
    return super.get(index, start);
  }
}
