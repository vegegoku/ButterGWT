package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.AnchorBuilder;
import com.google.gwt.dom.client.AnchorElement;
import com.google.gwt.safehtml.shared.SafeUri;

public class DomAnchorBuilder
  extends DomElementBuilderBase<AnchorBuilder, AnchorElement>
  implements AnchorBuilder
{
  DomAnchorBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public AnchorBuilder accessKey(String accessKey)
  {
    ((AnchorElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
  
  public AnchorBuilder href(SafeUri href)
  {
    ((AnchorElement)assertCanAddAttribute()).setHref(href);
    return this;
  }
  
  public AnchorBuilder href(String href)
  {
    ((AnchorElement)assertCanAddAttribute()).setHref(href);
    return this;
  }
  
  public AnchorBuilder hreflang(String hreflang)
  {
    ((AnchorElement)assertCanAddAttribute()).setHreflang(hreflang);
    return this;
  }
  
  public AnchorBuilder name(String name)
  {
    ((AnchorElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public AnchorBuilder rel(String rel)
  {
    ((AnchorElement)assertCanAddAttribute()).setRel(rel);
    return this;
  }
  
  public AnchorBuilder target(String target)
  {
    ((AnchorElement)assertCanAddAttribute()).setTarget(target);
    return this;
  }
  
  public AnchorBuilder type(String type)
  {
    ((AnchorElement)assertCanAddAttribute()).setType(type);
    return this;
  }
}
