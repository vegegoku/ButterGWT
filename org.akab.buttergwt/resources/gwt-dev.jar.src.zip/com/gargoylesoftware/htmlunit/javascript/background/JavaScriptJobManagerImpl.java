package com.gargoylesoftware.htmlunit.javascript.background;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebWindow;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.concurrent.atomic.AtomicInteger;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class JavaScriptJobManagerImpl
  implements JavaScriptJobManager
{
  private static final long serialVersionUID = -4681836475956316533L;
  private final transient WeakReference<WebWindow> window_;
  private transient PriorityQueue<JavaScriptJob> scheduledJobsQ_ = new PriorityQueue();
  private transient ArrayList<Integer> cancelledJobs_ = new ArrayList();
  private transient JavaScriptJob currentlyRunningJob_ = null;
  private static final AtomicInteger NEXT_JOB_ID_ = new AtomicInteger(1);
  private static final Log LOG = LogFactory.getLog(JavaScriptJobManagerImpl.class);
  
  public JavaScriptJobManagerImpl(WebWindow window)
  {
    this.window_ = new WeakReference(window);
  }
  
  public synchronized int getJobCount()
  {
    return this.scheduledJobsQ_.size() + (this.currentlyRunningJob_ != null ? 1 : 0);
  }
  
  public int addJob(JavaScriptJob job, Page page)
  {
    WebWindow w = getWindow();
    if (w == null) {
      return 0;
    }
    if (w.getEnclosedPage() != page) {
      return 0;
    }
    int id = NEXT_JOB_ID_.getAndIncrement();
    job.setId(Integer.valueOf(id));
    synchronized (this)
    {
      this.scheduledJobsQ_.add(job);
      if (LOG.isDebugEnabled())
      {
        LOG.debug("job added to queue");
        LOG.debug("    window is: " + w);
        LOG.debug("    added job: " + job.toString());
        LOG.debug("after adding job to the queue, the queue is: ");
        printQueue();
      }
      notify();
    }
    return id;
  }
  
  public synchronized void removeJob(int id)
  {
    for (JavaScriptJob job : this.scheduledJobsQ_)
    {
      int jobId = job.getId().intValue();
      if (jobId == id)
      {
        this.scheduledJobsQ_.remove(job);
        break;
      }
    }
    this.cancelledJobs_.add(Integer.valueOf(id));
    notify();
  }
  
  public synchronized void stopJob(int id)
  {
    for (JavaScriptJob job : this.scheduledJobsQ_)
    {
      int jobId = job.getId().intValue();
      if (jobId == id)
      {
        this.scheduledJobsQ_.remove(job);
        
        break;
      }
    }
    this.cancelledJobs_.add(Integer.valueOf(id));
    notify();
  }
  
  public synchronized void removeAllJobs()
  {
    if (this.currentlyRunningJob_ != null) {
      this.cancelledJobs_.add(this.currentlyRunningJob_.getId());
    }
    for (JavaScriptJob job : this.scheduledJobsQ_) {
      this.cancelledJobs_.add(job.getId());
    }
    this.scheduledJobsQ_.clear();
    notify();
  }
  
  public int waitForJobs(long timeoutMillis)
  {
    boolean debug = LOG.isDebugEnabled();
    if (debug) {
      LOG.debug("Waiting for all jobs to finish (will wait max " + timeoutMillis + " millis).");
    }
    if (timeoutMillis > 0L)
    {
      long now = System.currentTimeMillis();
      long end = now + timeoutMillis;
      while ((getJobCount() > 0) && (now < end)) {
        try
        {
          synchronized (this)
          {
            wait(end - now);
          }
          now = System.currentTimeMillis();
        }
        catch (InterruptedException e)
        {
          LOG.error("InterruptedException while in waitForJobs", e);
        }
      }
    }
    int jobs = getJobCount();
    if (debug) {
      LOG.debug("Finished waiting for all jobs to finish (final job count is " + jobs + ").");
    }
    return jobs;
  }
  
  public int waitForJobsStartingBefore(long delayMillis)
  {
    boolean debug = LOG.isDebugEnabled();
    
    long latestExecutionTime = System.currentTimeMillis() + delayMillis;
    if (debug) {
      LOG.debug("Waiting for all jobs that have execution time before " + delayMillis + " (" + latestExecutionTime + ") to finish");
    }
    JavaScriptJob earliestJob;
    boolean waitingJob;
    boolean currentJob;
    synchronized (this)
    {
      earliestJob = getEarliestJob();
      waitingJob = (earliestJob != null) && (earliestJob.getTargetExecutionTime() < latestExecutionTime);
      currentJob = (this.currentlyRunningJob_ != null) && (this.currentlyRunningJob_.getTargetExecutionTime() < latestExecutionTime);
    }
    long interval = Math.max(40L, delayMillis);
    while ((currentJob) || (waitingJob))
    {
      try
      {
        synchronized (this)
        {
          wait(interval);
        }
      }
      catch (InterruptedException e)
      {
        LOG.error("InterruptedException while in waitForJobsStartingBefore", e);
      }
      synchronized (this)
      {
        earliestJob = getEarliestJob();
        waitingJob = (earliestJob != null) && (earliestJob.getTargetExecutionTime() < latestExecutionTime);
        currentJob = (this.currentlyRunningJob_ != null) && (this.currentlyRunningJob_.getTargetExecutionTime() < latestExecutionTime);
      }
    }
    int jobs = getJobCount();
    if (debug) {
      LOG.debug("Finished waiting for all jobs that have target execution time earlier than " + latestExecutionTime + ", final job count is " + jobs);
    }
    return jobs;
  }
  
  public synchronized void shutdown()
  {
    this.scheduledJobsQ_.clear();
    notify();
  }
  
  private WebWindow getWindow()
  {
    return (WebWindow)this.window_.get();
  }
  
  private void printQueue()
  {
    if (LOG.isDebugEnabled())
    {
      LOG.debug("------ printing JavaScript job queue -----");
      LOG.debug("  number of jobs on the queue: " + this.scheduledJobsQ_.size());
      int count = 1;
      for (JavaScriptJob job : this.scheduledJobsQ_)
      {
        LOG.debug("  " + count + ")  Job target execution time: " + job.getTargetExecutionTime());
        LOG.debug("      job to string: " + job.toString());
        LOG.debug("      job id: " + job.getId());
        if (job.isPeriodic()) {
          LOG.debug("      period: " + job.getPeriod().longValue());
        }
        count++;
      }
      LOG.debug("------------------------------------------");
    }
  }
  
  public JavaScriptJob getEarliestJob()
  {
    return (JavaScriptJob)this.scheduledJobsQ_.peek();
  }
  
  public boolean runSingleJob(JavaScriptJob givenJob)
  {
    assert (givenJob != null);
    JavaScriptJob job = getEarliestJob();
    if (job != givenJob) {
      return false;
    }
    long currentTime = System.currentTimeMillis();
    if (job.getTargetExecutionTime() > currentTime) {
      return false;
    }
    synchronized (this)
    {
      if (this.scheduledJobsQ_.remove(job)) {
        this.currentlyRunningJob_ = job;
      }
    }
    boolean debug = LOG.isDebugEnabled();
    boolean isPeriodicJob = job.isPeriodic();
    if (isPeriodicJob)
    {
      long jobPeriod = job.getPeriod().longValue();
      
      long timeDifference = currentTime - job.getTargetExecutionTime();
      timeDifference = timeDifference / jobPeriod * jobPeriod + jobPeriod;
      job.setTargetExecutionTime(job.getTargetExecutionTime() + timeDifference);
      synchronized (this)
      {
        if (!this.cancelledJobs_.contains(job.getId()))
        {
          if (debug) {
            LOG.debug("Reschedulling job " + job);
          }
          this.scheduledJobsQ_.add(job);
          notify();
        }
      }
    }
    if (debug)
    {
      String periodicJob = isPeriodicJob ? "interval " : "";
      LOG.debug("Starting " + periodicJob + "job " + job);
    }
    try
    {
      job.run();
    }
    catch (RuntimeException e)
    {
      LOG.error("Job run failed with unexpected RuntimeException: " + e.getMessage(), e);
    }
    finally
    {
      synchronized (this)
      {
        if (job == this.currentlyRunningJob_) {
          this.currentlyRunningJob_ = null;
        }
        notify();
      }
    }
    if (debug)
    {
      String periodicJob = isPeriodicJob ? "interval " : "";
      LOG.debug("Finished " + periodicJob + "job " + job);
    }
    return true;
  }
  
  private void writeObject(ObjectOutputStream out)
    throws IOException
  {
    out.defaultWriteObject();
  }
  
  private void readObject(ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    
    this.scheduledJobsQ_ = new PriorityQueue();
    this.cancelledJobs_ = new ArrayList();
    this.currentlyRunningJob_ = null;
  }
}
