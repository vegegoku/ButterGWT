package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class RoleImpl
  implements Role
{
  private static final String ATTR_NAME_ROLE = "role";
  private final String roleName;
  
  RoleImpl(String roleName)
  {
    assert (roleName != null) : "Role name cannot be null";
    this.roleName = roleName;
  }
  
  public String getAriaAtomicProperty(Element element)
  {
    return Property.ATOMIC.get(element);
  }
  
  public String getAriaBusyState(Element element)
  {
    return State.BUSY.get(element);
  }
  
  public String getAriaControlsProperty(Element element)
  {
    return Property.CONTROLS.get(element);
  }
  
  public String getAriaDescribedbyProperty(Element element)
  {
    return Property.DESCRIBEDBY.get(element);
  }
  
  public String getAriaDisabledState(Element element)
  {
    return State.DISABLED.get(element);
  }
  
  public String getAriaDropeffectProperty(Element element)
  {
    return Property.DROPEFFECT.get(element);
  }
  
  public String getAriaFlowtoProperty(Element element)
  {
    return Property.FLOWTO.get(element);
  }
  
  public String getAriaGrabbedState(Element element)
  {
    return State.GRABBED.get(element);
  }
  
  public String getAriaHaspopupProperty(Element element)
  {
    return Property.HASPOPUP.get(element);
  }
  
  public String getAriaHiddenState(Element element)
  {
    return State.HIDDEN.get(element);
  }
  
  public String getAriaInvalidState(Element element)
  {
    return State.INVALID.get(element);
  }
  
  public String getAriaLabelledbyProperty(Element element)
  {
    return Property.LABELLEDBY.get(element);
  }
  
  public String getAriaLabelProperty(Element element)
  {
    return Property.LABEL.get(element);
  }
  
  public String getAriaLiveProperty(Element element)
  {
    return Property.LIVE.get(element);
  }
  
  public String getAriaOwnsProperty(Element element)
  {
    return Property.OWNS.get(element);
  }
  
  public String getAriaRelevantProperty(Element element)
  {
    return Property.RELEVANT.get(element);
  }
  
  public String getName()
  {
    return this.roleName;
  }
  
  public String getTabindexExtraAttribute(Element element)
  {
    return ExtraAttribute.TABINDEX.get(element);
  }
  
  public void remove(Element element)
  {
    assert (element != null) : "Element cannot be null.";
    element.removeAttribute("role");
  }
  
  public void removeAriaAtomicProperty(Element element)
  {
    Property.ATOMIC.remove(element);
  }
  
  public void removeAriaBusyState(Element element)
  {
    State.BUSY.remove(element);
  }
  
  public void removeAriaControlsProperty(Element element)
  {
    Property.CONTROLS.remove(element);
  }
  
  public void removeAriaDescribedbyProperty(Element element)
  {
    Property.DESCRIBEDBY.remove(element);
  }
  
  public void removeAriaDisabledState(Element element)
  {
    State.DISABLED.remove(element);
  }
  
  public void removeAriaDropeffectProperty(Element element)
  {
    Property.DROPEFFECT.remove(element);
  }
  
  public void removeAriaFlowtoProperty(Element element)
  {
    Property.FLOWTO.remove(element);
  }
  
  public void removeAriaGrabbedState(Element element)
  {
    State.GRABBED.remove(element);
  }
  
  public void removeAriaHaspopupProperty(Element element)
  {
    Property.HASPOPUP.remove(element);
  }
  
  public void removeAriaHiddenState(Element element)
  {
    State.HIDDEN.remove(element);
  }
  
  public void removeAriaInvalidState(Element element)
  {
    State.INVALID.remove(element);
  }
  
  public void removeAriaLabelledbyProperty(Element element)
  {
    Property.LABELLEDBY.remove(element);
  }
  
  public void removeAriaLabelProperty(Element element)
  {
    Property.LABEL.remove(element);
  }
  
  public void removeAriaLiveProperty(Element element)
  {
    Property.LIVE.remove(element);
  }
  
  public void removeAriaOwnsProperty(Element element)
  {
    Property.OWNS.remove(element);
  }
  
  public void removeAriaRelevantProperty(Element element)
  {
    Property.RELEVANT.remove(element);
  }
  
  public void removeTabindexExtraAttribute(Element element)
  {
    ExtraAttribute.TABINDEX.remove(element);
  }
  
  public void set(Element element)
  {
    assert (element != null) : "Element cannot be null.";
    element.setAttribute("role", this.roleName);
  }
  
  public void setAriaAtomicProperty(Element element, boolean value)
  {
    Property.ATOMIC.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaBusyState(Element element, boolean value)
  {
    State.BUSY.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaControlsProperty(Element element, Id... value)
  {
    Property.CONTROLS.set(element, value);
  }
  
  public void setAriaDescribedbyProperty(Element element, Id... value)
  {
    Property.DESCRIBEDBY.set(element, value);
  }
  
  public void setAriaDisabledState(Element element, boolean value)
  {
    State.DISABLED.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaDropeffectProperty(Element element, DropeffectValue... value)
  {
    Property.DROPEFFECT.set(element, value);
  }
  
  public void setAriaFlowtoProperty(Element element, Id... value)
  {
    Property.FLOWTO.set(element, value);
  }
  
  public void setAriaGrabbedState(Element element, GrabbedValue value)
  {
    State.GRABBED.set(element, new GrabbedValue[] { value });
  }
  
  public void setAriaHaspopupProperty(Element element, boolean value)
  {
    Property.HASPOPUP.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaHiddenState(Element element, boolean value)
  {
    State.HIDDEN.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaInvalidState(Element element, InvalidValue value)
  {
    State.INVALID.set(element, new InvalidValue[] { value });
  }
  
  public void setAriaLabelledbyProperty(Element element, Id... value)
  {
    Property.LABELLEDBY.set(element, value);
  }
  
  public void setAriaLabelProperty(Element element, String value)
  {
    Property.LABEL.set(element, new String[] { value });
  }
  
  public void setAriaLiveProperty(Element element, LiveValue value)
  {
    Property.LIVE.set(element, new LiveValue[] { value });
  }
  
  public void setAriaOwnsProperty(Element element, Id... value)
  {
    Property.OWNS.set(element, value);
  }
  
  public void setAriaRelevantProperty(Element element, RelevantValue... value)
  {
    Property.RELEVANT.set(element, value);
  }
  
  public void setTabindexExtraAttribute(Element element, int value)
  {
    ExtraAttribute.TABINDEX.set(element, new Integer[] { Integer.valueOf(value) });
  }
}
