package com.google.gwt.aria.client;

public final class State
{
  public static final Attribute<Boolean> BUSY = new PrimitiveValueAttribute("aria-busy", "false");
  public static final Attribute<CheckedValue> CHECKED = new AriaValueAttribute("aria-checked", "undefined");
  public static final Attribute<Boolean> DISABLED = new PrimitiveValueAttribute("aria-disabled", "false");
  public static final Attribute<ExpandedValue> EXPANDED = new AriaValueAttribute("aria-expanded", "undefined");
  public static final Attribute<GrabbedValue> GRABBED = new AriaValueAttribute("aria-grabbed", "undefined");
  public static final Attribute<Boolean> HIDDEN = new PrimitiveValueAttribute("aria-hidden", "false");
  public static final Attribute<InvalidValue> INVALID = new AriaValueAttribute("aria-invalid", "false");
  public static final Attribute<PressedValue> PRESSED = new AriaValueAttribute("aria-pressed", "undefined");
  public static final Attribute<SelectedValue> SELECTED = new AriaValueAttribute("aria-selected", "undefined");
}
