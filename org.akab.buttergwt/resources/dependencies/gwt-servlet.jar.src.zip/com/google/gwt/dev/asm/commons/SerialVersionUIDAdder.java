package com.google.gwt.dev.asm.commons;

import com.google.gwt.dev.asm.ClassVisitor;
import com.google.gwt.dev.asm.FieldVisitor;
import com.google.gwt.dev.asm.MethodVisitor;
import java.io.ByteArrayOutputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

public class SerialVersionUIDAdder
  extends ClassVisitor
{
  private boolean computeSVUID;
  private boolean hasSVUID;
  private int access;
  private String name;
  private String[] interfaces;
  private Collection<Item> svuidFields;
  private boolean hasStaticInitializer;
  private Collection<Item> svuidConstructors;
  private Collection<Item> svuidMethods;
  
  public SerialVersionUIDAdder(ClassVisitor cv)
  {
    this(262144, cv);
  }
  
  protected SerialVersionUIDAdder(int api, ClassVisitor cv)
  {
    super(api, cv);
    this.svuidFields = new ArrayList();
    this.svuidConstructors = new ArrayList();
    this.svuidMethods = new ArrayList();
  }
  
  public void visit(int version, int access, String name, String signature, String superName, String[] interfaces)
  {
    this.computeSVUID = ((access & 0x200) == 0);
    if (this.computeSVUID)
    {
      this.name = name;
      this.access = access;
      this.interfaces = interfaces;
    }
    super.visit(version, access, name, signature, superName, interfaces);
  }
  
  public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions)
  {
    if (this.computeSVUID)
    {
      if ("<clinit>".equals(name)) {
        this.hasStaticInitializer = true;
      }
      int mods = access & 0xD3F;
      if ((access & 0x2) == 0) {
        if ("<init>".equals(name)) {
          this.svuidConstructors.add(new Item(name, mods, desc));
        } else if (!"<clinit>".equals(name)) {
          this.svuidMethods.add(new Item(name, mods, desc));
        }
      }
    }
    return super.visitMethod(access, name, desc, signature, exceptions);
  }
  
  public FieldVisitor visitField(int access, String name, String desc, String signature, Object value)
  {
    if (this.computeSVUID)
    {
      if ("serialVersionUID".equals(name))
      {
        this.computeSVUID = false;
        this.hasSVUID = true;
      }
      if (((access & 0x2) == 0) || ((access & 0x88) == 0))
      {
        int mods = access & 0xDF;
        
        this.svuidFields.add(new Item(name, mods, desc));
      }
    }
    return super.visitField(access, name, desc, signature, value);
  }
  
  public void visitInnerClass(String aname, String outerName, String innerName, int attr_access)
  {
    if ((this.name != null) && (this.name.equals(aname))) {
      this.access = attr_access;
    }
    super.visitInnerClass(aname, outerName, innerName, attr_access);
  }
  
  public void visitEnd()
  {
    if ((this.computeSVUID) && (!this.hasSVUID)) {
      try
      {
        addSVUID(computeSVUID());
      }
      catch (Throwable e)
      {
        throw new RuntimeException("Error while computing SVUID for " + this.name, e);
      }
    }
    super.visitEnd();
  }
  
  public boolean hasSVUID()
  {
    return this.hasSVUID;
  }
  
  protected void addSVUID(long svuid)
  {
    FieldVisitor fv = super.visitField(24, "serialVersionUID", "J", null, new Long(svuid));
    if (fv != null) {
      fv.visitEnd();
    }
  }
  
  protected long computeSVUID()
    throws IOException
  {
    DataOutputStream dos = null;
    long svuid = 0L;
    try
    {
      ByteArrayOutputStream bos = new ByteArrayOutputStream();
      dos = new DataOutputStream(bos);
      
      dos.writeUTF(this.name.replace('/', '.'));
      
      dos.writeInt(this.access & 0x611);
      
      Arrays.sort(this.interfaces);
      for (int i = 0; i < this.interfaces.length; i++) {
        dos.writeUTF(this.interfaces[i].replace('/', '.'));
      }
      writeItems(this.svuidFields, dos, false);
      if (this.hasStaticInitializer)
      {
        dos.writeUTF("<clinit>");
        dos.writeInt(8);
        dos.writeUTF("()V");
      }
      writeItems(this.svuidConstructors, dos, true);
      
      writeItems(this.svuidMethods, dos, true);
      
      dos.flush();
      
      byte[] hashBytes = computeSHAdigest(bos.toByteArray());
      for (int i = Math.min(hashBytes.length, 8) - 1; i >= 0; i--) {
        svuid = svuid << 8 | hashBytes[i] & 0xFF;
      }
    }
    finally
    {
      if (dos != null) {
        dos.close();
      }
    }
    return svuid;
  }
  
  protected byte[] computeSHAdigest(byte[] value)
  {
    try
    {
      return MessageDigest.getInstance("SHA").digest(value);
    }
    catch (Exception e)
    {
      throw new UnsupportedOperationException(e.toString());
    }
  }
  
  private static void writeItems(Collection<Item> itemCollection, DataOutput dos, boolean dotted)
    throws IOException
  {
    int size = itemCollection.size();
    Item[] items = (Item[])itemCollection.toArray(new Item[size]);
    Arrays.sort(items);
    for (int i = 0; i < size; i++)
    {
      dos.writeUTF(items[i].name);
      dos.writeInt(items[i].access);
      dos.writeUTF(dotted ? items[i].desc.replace('/', '.') : items[i].desc);
    }
  }
  
  private static class Item
    implements Comparable<Item>
  {
    final String name;
    final int access;
    final String desc;
    
    Item(String name, int access, String desc)
    {
      this.name = name;
      this.access = access;
      this.desc = desc;
    }
    
    public int compareTo(Item other)
    {
      int retVal = this.name.compareTo(other.name);
      if (retVal == 0) {
        retVal = this.desc.compareTo(other.desc);
      }
      return retVal;
    }
    
    public boolean equals(Object o)
    {
      if ((o instanceof Item)) {
        return compareTo((Item)o) == 0;
      }
      return false;
    }
    
    public int hashCode()
    {
      return (this.name + this.desc).hashCode();
    }
  }
}
