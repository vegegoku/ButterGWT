package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.RunAsyncCallback;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.core.client.Scheduler.ScheduledCommand;

class OnSuccessExecutor
{
  void execute(final AsyncFragmentLoader fragmentLoader, final RunAsyncCallback callback)
  {
    Scheduler.get().scheduleDeferred(new Scheduler.ScheduledCommand()
    {
      public void execute()
      {
        fragmentLoader.executeOnSuccess0(callback);
      }
    });
  }
}
