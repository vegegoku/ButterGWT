package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.VideoBuilder;
import com.google.gwt.dom.client.VideoElement;

public class DomVideoBuilder
  extends DomMediaBuilderBase<VideoBuilder, VideoElement>
  implements VideoBuilder
{
  DomVideoBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public VideoBuilder height(int height)
  {
    ((VideoElement)assertCanAddAttribute()).setHeight(height);
    return this;
  }
  
  public VideoBuilder poster(String url)
  {
    ((VideoElement)assertCanAddAttribute()).setPoster(url);
    return this;
  }
  
  public VideoBuilder width(int width)
  {
    ((VideoElement)assertCanAddAttribute()).setWidth(width);
    return this;
  }
}
