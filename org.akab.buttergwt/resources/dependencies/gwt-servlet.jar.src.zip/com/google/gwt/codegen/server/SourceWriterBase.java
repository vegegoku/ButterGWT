package com.google.gwt.codegen.server;

public abstract class SourceWriterBase
  implements SourceWriter
{
  private boolean atStart;
  private boolean inComment;
  private int indent;
  
  public abstract void abort();
  
  public void beginJavaDocComment()
  {
    println("\n/**");
    this.inComment = true;
  }
  
  public void close()
  {
    outdent();
    println("}");
  }
  
  public void endJavaDocComment()
  {
    this.inComment = false;
    println("\n */");
  }
  
  public void indent()
  {
    this.indent += 1;
  }
  
  public void indentln(String string)
  {
    indent();
    println(string);
    outdent();
  }
  
  public void indentln(String format, Object... args)
  {
    indentln(String.format(format, args));
  }
  
  public void outdent()
  {
    if (this.indent > 0) {
      this.indent -= 1;
    }
  }
  
  public void print(String s)
  {
    if (this.atStart)
    {
      for (int j = 0; j < this.indent; j++) {
        writeString("  ");
      }
      if (this.inComment) {
        writeString(" * ");
      }
      this.atStart = false;
    }
    String rest = null;
    int i = s.indexOf("\n");
    if ((i > -1) && (i < s.length() - 1))
    {
      rest = s.substring(i + 1);
      s = s.substring(0, i + 1);
    }
    writeString(s);
    if (rest != null)
    {
      this.atStart = true;
      print(rest);
    }
  }
  
  public void print(String format, Object... args)
  {
    print(String.format(format, args));
  }
  
  public void println()
  {
    print("\n");
    this.atStart = true;
  }
  
  public void println(String string)
  {
    print(string);
    println();
  }
  
  public void println(String format, Object... args)
  {
    println(String.format(format, args));
  }
  
  protected abstract void writeString(String paramString);
}
