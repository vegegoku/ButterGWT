package com.google.gwt.core.client.impl;

import java.io.Serializable;

@Deprecated
public class SerializableThrowable
  implements Serializable
{
  private SerializableThrowable cause = null;
  private String message = null;
  private StackTraceElement[] stackTrace = null;
  private String typeName = null;
  
  @Deprecated
  public static class ThrowableWithClassName
    extends Throwable
  {
    private String typeName;
    
    public ThrowableWithClassName(String message, Throwable cause, String typeName)
    {
      super(cause);
      this.typeName = typeName;
    }
    
    public ThrowableWithClassName(String message, String typeName)
    {
      super();
      this.typeName = typeName;
    }
    
    public String getExceptionClass()
    {
      return this.typeName;
    }
  }
  
  public SerializableThrowable(Throwable t)
  {
    this.message = t.getMessage();
    if ((t.getCause() != null) && (t.getCause() != t)) {
      this.cause = new SerializableThrowable(t.getCause());
    }
    this.stackTrace = t.getStackTrace();
    this.typeName = t.getClass().getName();
  }
  
  protected SerializableThrowable() {}
  
  public SerializableThrowable getCause()
  {
    return this.cause;
  }
  
  public String getMessage()
  {
    return this.message;
  }
  
  public StackTraceElement[] getStackTrace()
  {
    return this.stackTrace;
  }
  
  public Throwable getThrowable()
  {
    Throwable t;
    Throwable t;
    if (this.cause != null) {
      t = new ThrowableWithClassName(this.message, this.cause.getThrowable(), this.typeName);
    } else {
      t = new ThrowableWithClassName(this.message, this.typeName);
    }
    t.setStackTrace(this.stackTrace);
    return t;
  }
  
  public void setCause(SerializableThrowable c)
  {
    this.cause = c;
  }
  
  public void setMessage(String msg)
  {
    this.message = msg;
  }
  
  public void setStackTrace(StackTraceElement[] st)
  {
    this.stackTrace = st;
  }
}
