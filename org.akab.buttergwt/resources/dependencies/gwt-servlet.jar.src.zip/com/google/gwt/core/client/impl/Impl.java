package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.Duration;
import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.GWT.UncaughtExceptionHandler;
import com.google.gwt.core.client.JavaScriptException;
import com.google.gwt.core.client.JavaScriptObject;

public final class Impl
{
  public static boolean moduleUnloaded;
  private static final int WATCHDOG_ENTRY_DEPTH_CHECK_INTERVAL_MS = 2000;
  private static int entryDepth;
  private static int sNextHashId;
  private static double watchdogEntryDepthLastScheduled;
  private static int watchdogEntryDepthTimerId;
  private static UnloadSupport unloadSupport;
  private static GWT.UncaughtExceptionHandler uncaughtExceptionHandlerForTest;
  
  static
  {
    moduleUnloaded = false;
    
    entryDepth = 0;
    sNextHashId = 0;
    
    watchdogEntryDepthTimerId = -1;
    
    unloadSupport = GWT.isScript() ? (UnloadSupport)GWT.create(UnloadSupport.class) : new UnloadSupport();
    
    exportUnloadModule();
  }
  
  public static void clearInterval(int timerId)
  {
    unloadSupport.clearInterval(timerId);
  }
  
  public static void clearTimeout(int timerId)
  {
    unloadSupport.clearTimeout(timerId);
  }
  
  public static void dispose(Disposable d)
  {
    unloadSupport.dispose(d);
  }
  
  public static void exportUnloadModule()
  {
    unloadSupport.exportUnloadModule();
  }
  
  public static String getNameOf(String jsniIdent)
  {
    assert (!GWT.isScript()) : "ReplaceRebinds failed to replace this method";
    throw new UnsupportedOperationException("Impl.getNameOf() is unimplemented in Development Mode");
  }
  
  public static void setUncaughtExceptionHandlerForTest(GWT.UncaughtExceptionHandler handler)
  {
    uncaughtExceptionHandlerForTest = handler;
  }
  
  public static void reportUncaughtException(Throwable e)
  {
    if (uncaughtExceptionHandlerForTest != null) {
      uncaughtExceptionHandlerForTest.onUncaughtException(e);
    }
    GWT.UncaughtExceptionHandler handler = GWT.getUncaughtExceptionHandler();
    if (handler != null)
    {
      if (handler == uncaughtExceptionHandlerForTest) {
        return;
      }
      handler.onUncaughtException(e);
      return;
    }
    reportToBrowser(e);
  }
  
  private static void reportToBrowser(Throwable e)
  {
    reportToBrowser((e instanceof JavaScriptException) ? ((JavaScriptException)e).getThrown() : e);
  }
  
  public static boolean isEntryOnStack()
  {
    return entryDepth > 0;
  }
  
  public static boolean isModuleUnloaded()
  {
    return moduleUnloaded;
  }
  
  public static boolean isNestedEntry()
  {
    return entryDepth > 1;
  }
  
  public static void scheduleDispose(Disposable d)
  {
    unloadSupport.scheduleDispose(d);
  }
  
  public static int setInterval(JavaScriptObject func, int time)
  {
    return unloadSupport.setInterval(func, time);
  }
  
  public static int setTimeout(JavaScriptObject func, int time)
  {
    return unloadSupport.setTimeout(func, time);
  }
  
  public static void unloadModule()
  {
    if (unloadSupport.isUnloadSupported())
    {
      moduleUnloaded = true;
      unloadSupport.disposeAll();
    }
  }
  
  private static boolean enter()
  {
    assert (entryDepth >= 0) : ("Negative entryDepth value at entry " + entryDepth);
    if ((GWT.isScript()) && (entryDepth != 0))
    {
      double now = Duration.currentTimeMillis();
      if (now - watchdogEntryDepthLastScheduled > 2000.0D)
      {
        watchdogEntryDepthLastScheduled = now;
        watchdogEntryDepthTimerId = watchdogEntryDepthSchedule();
      }
    }
    if (entryDepth++ == 0)
    {
      SchedulerImpl.INSTANCE.flushEntryCommands();
      return true;
    }
    return false;
  }
  
  private static Object entry0(Object jsFunction, Object thisObj, Object args)
    throws Throwable
  {
    if ((unloadSupport.isUnloadSupported()) && (isModuleUnloaded())) {
      return null;
    }
    boolean initialEntry = enter();
    try
    {
      if (GWT.getUncaughtExceptionHandler() != null) {
        try
        {
          return apply(jsFunction, thisObj, args);
        }
        catch (Throwable t)
        {
          reportUncaughtException((Throwable)t);
          return undefined();
        }
      }
      return apply(jsFunction, thisObj, args);
    }
    finally
    {
      exit(initialEntry);
    }
  }
  
  private static void exit(boolean initialEntry)
  {
    if (initialEntry) {
      SchedulerImpl.INSTANCE.flushFinallyCommands();
    }
    entryDepth -= 1;
    assert (entryDepth >= 0) : ("Negative entryDepth value at exit " + entryDepth);
    if (initialEntry)
    {
      assert (entryDepth == 0) : ("Depth not 0" + entryDepth);
      if ((GWT.isScript()) && (watchdogEntryDepthTimerId != -1))
      {
        watchdogEntryDepthCancel(watchdogEntryDepthTimerId);
        watchdogEntryDepthTimerId = -1;
      }
    }
  }
  
  private static int getNextHashId()
  {
    return ++sNextHashId;
  }
  
  private static void watchdogEntryDepthRun()
  {
    if ((GWT.isScript()) && (entryDepth != 0)) {
      entryDepth = 0;
    }
    watchdogEntryDepthTimerId = -1;
  }
  
  public static native JavaScriptObject entry(JavaScriptObject paramJavaScriptObject);
  
  public static native int getHashCode(Object paramObject);
  
  public static native String getHostPageBaseURL();
  
  public static native String getModuleBaseURL();
  
  public static native String getModuleBaseURLForStaticFiles();
  
  public static native String getModuleName();
  
  public static native String getPermutationStrongName();
  
  private static native void reportToBrowser(Object paramObject);
  
  public static native JavaScriptObject registerEntry();
  
  private static native Object apply(Object paramObject1, Object paramObject2, Object paramObject3);
  
  private static native Object undefined();
  
  private static native void watchdogEntryDepthCancel(int paramInt);
  
  private static native int watchdogEntryDepthSchedule();
}
