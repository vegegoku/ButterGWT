package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TableColBuilder;
import com.google.gwt.dom.client.TableColElement;

public class DomTableColBuilder
  extends DomElementBuilderBase<TableColBuilder, TableColElement>
  implements TableColBuilder
{
  DomTableColBuilder(DomBuilderImpl delegate, boolean group)
  {
    super(delegate, !group);
  }
  
  public TableColBuilder align(String align)
  {
    ((TableColElement)assertCanAddAttribute()).setAlign(align);
    return this;
  }
  
  public TableColBuilder ch(String ch)
  {
    ((TableColElement)assertCanAddAttribute()).setCh(ch);
    return this;
  }
  
  public TableColBuilder chOff(String chOff)
  {
    ((TableColElement)assertCanAddAttribute()).setChOff(chOff);
    return this;
  }
  
  public TableColBuilder span(int span)
  {
    ((TableColElement)assertCanAddAttribute()).setSpan(span);
    return this;
  }
  
  public TableColBuilder vAlign(String vAlign)
  {
    ((TableColElement)assertCanAddAttribute()).setVAlign(vAlign);
    return this;
  }
  
  public TableColBuilder width(String width)
  {
    ((TableColElement)assertCanAddAttribute()).setWidth(width);
    return this;
  }
}
