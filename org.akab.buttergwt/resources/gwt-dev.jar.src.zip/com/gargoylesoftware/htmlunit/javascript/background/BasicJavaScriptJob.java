package com.gargoylesoftware.htmlunit.javascript.background;

abstract class BasicJavaScriptJob
  implements JavaScriptJob
{
  private Integer id_;
  private final int initialDelay_;
  private final Integer period_;
  private final boolean executeAsap_;
  private long targetExecutionTime_;
  
  public BasicJavaScriptJob()
  {
    this(0, null);
  }
  
  public BasicJavaScriptJob(int initialDelay, Integer period)
  {
    this.initialDelay_ = initialDelay;
    this.period_ = period;
    setTargetExecutionTime(initialDelay + System.currentTimeMillis());
    this.executeAsap_ = (initialDelay == 0);
  }
  
  public void setId(Integer id)
  {
    this.id_ = id;
  }
  
  public Integer getId()
  {
    return this.id_;
  }
  
  public int getInitialDelay()
  {
    return this.initialDelay_;
  }
  
  public Integer getPeriod()
  {
    return this.period_;
  }
  
  public boolean isPeriodic()
  {
    return this.period_ != null;
  }
  
  public boolean isExecuteAsap()
  {
    return this.executeAsap_;
  }
  
  public String toString()
  {
    return "JavaScript Job " + this.id_;
  }
  
  public int compareTo(JavaScriptJob other)
  {
    boolean xhr1 = this.executeAsap_;
    boolean xhr2 = other.isExecuteAsap();
    if ((xhr1) && (xhr2)) {
      return getId().intValue() - other.getId().intValue();
    }
    if (xhr1) {
      return -1;
    }
    if (xhr2) {
      return 1;
    }
    return (int)(this.targetExecutionTime_ - other.getTargetExecutionTime());
  }
  
  public long getTargetExecutionTime()
  {
    return this.targetExecutionTime_;
  }
  
  public void setTargetExecutionTime(long targetExecutionTime)
  {
    this.targetExecutionTime_ = targetExecutionTime;
  }
}
