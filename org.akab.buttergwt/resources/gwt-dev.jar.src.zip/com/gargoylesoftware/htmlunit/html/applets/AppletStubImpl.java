package com.gargoylesoftware.htmlunit.html.applets;

import com.gargoylesoftware.htmlunit.html.HtmlApplet;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import java.applet.AppletContext;
import java.applet.AppletStub;
import java.net.URL;
import java.util.HashMap;

public class AppletStubImpl
  implements AppletStub
{
  private final AppletContextImpl appletContextImpl_;
  private final HashMap<String, String> parameters_;
  private final URL codebase_;
  private final URL documentbase_;
  
  public AppletStubImpl(HtmlApplet htmlApplet, HashMap<String, String> parameters, URL codebase, URL documentbase)
  {
    this.appletContextImpl_ = new AppletContextImpl((HtmlPage)htmlApplet.getPage());
    this.parameters_ = parameters;
    this.codebase_ = codebase;
    this.documentbase_ = documentbase;
  }
  
  public void appletResize(int width, int height) {}
  
  public AppletContext getAppletContext()
  {
    return this.appletContextImpl_;
  }
  
  public URL getCodeBase()
  {
    return this.codebase_;
  }
  
  public URL getDocumentBase()
  {
    return this.documentbase_;
  }
  
  public String getParameter(String name)
  {
    return (String)this.parameters_.get(name);
  }
  
  public boolean isActive()
  {
    throw new RuntimeException("Not yet implemented! (com.gargoylesoftware.htmlunit.html.applets.AppletStubImpl.isActive())");
  }
}
