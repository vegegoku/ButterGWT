package com.google.gwt.core.shared;

import com.google.gwt.core.shared.impl.JsLogger;

public final class GWT
{
  private static GWTBridge sGWTBridge = null;
  private static final JsLogger logger;
  
  static
  {
    if (isScript()) {
      logger = (JsLogger)create(JsLogger.class);
    } else {
      logger = null;
    }
  }
  
  public static <T> T create(Class<?> classLiteral)
  {
    if (sGWTBridge == null) {
      throw new UnsupportedOperationException("ERROR: GWT.create() is only usable in client code!  It cannot be called, for example, from server code.  If you are running a unit test, check that your test case extends GWTTestCase and that GWT.create() is not called from within an initializer or constructor.");
    }
    return (T)sGWTBridge.create(classLiteral);
  }
  
  public static String getUniqueThreadId()
  {
    if (sGWTBridge != null) {
      return sGWTBridge.getThreadUniqueID();
    }
    return "";
  }
  
  public static String getVersion()
  {
    return sGWTBridge == null ? null : sGWTBridge.getVersion();
  }
  
  public static boolean isClient()
  {
    return (sGWTBridge != null) && (sGWTBridge.isClient());
  }
  
  public static boolean isProdMode()
  {
    return false;
  }
  
  public static boolean isScript()
  {
    return false;
  }
  
  public static void log(String message)
  {
    log(message, null);
  }
  
  public static void log(String message, Throwable e)
  {
    if (sGWTBridge != null) {
      sGWTBridge.log(message, e);
    } else if (logger != null) {
      logger.log(message, e);
    }
  }
  
  public static void setBridge(GWTBridge bridge)
  {
    sGWTBridge = bridge;
  }
  
  public static void debugger() {}
}
