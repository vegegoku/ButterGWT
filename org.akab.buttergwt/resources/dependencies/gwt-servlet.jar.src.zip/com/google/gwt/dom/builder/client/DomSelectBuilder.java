package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.SelectBuilder;
import com.google.gwt.dom.client.SelectElement;

public class DomSelectBuilder
  extends DomElementBuilderBase<SelectBuilder, SelectElement>
  implements SelectBuilder
{
  DomSelectBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public SelectBuilder disabled()
  {
    ((SelectElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public SelectBuilder multiple()
  {
    ((SelectElement)assertCanAddAttribute()).setMultiple(true);
    return this;
  }
  
  public SelectBuilder name(String name)
  {
    ((SelectElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public SelectBuilder selectedIndex(int index)
  {
    ((SelectElement)assertCanAddAttribute()).setSelectedIndex(index);
    return this;
  }
  
  public SelectBuilder size(int size)
  {
    ((SelectElement)assertCanAddAttribute()).setSize(size);
    return this;
  }
  
  public SelectBuilder type(String type)
  {
    ((SelectElement)assertCanAddAttribute()).setType(type);
    return this;
  }
  
  public SelectBuilder value(String value)
  {
    ((SelectElement)assertCanAddAttribute()).setValue(value);
    return this;
  }
}
