package com.google.gwt.canvas.dom.client;

public abstract interface Context {}
