package com.google.gwt.codegen.server;

public class CodeGenUtils
{
  public static String asStringLiteral(String literal)
  {
    return '"' + escape(literal) + '"';
  }
  
  public static String escape(String unescaped)
  {
    int extra = 0;
    int in = 0;
    for (int n = unescaped.length(); in < n; in++) {
      switch (unescaped.charAt(in))
      {
      case '\000': 
      case '\n': 
      case '\r': 
      case '"': 
      case '\\': 
        extra++;
      }
    }
    if (extra == 0) {
      return unescaped;
    }
    char[] oldChars = unescaped.toCharArray();
    char[] newChars = new char[oldChars.length + extra];
    int in = 0;int out = 0;
    for (int n = oldChars.length; in < n; out++)
    {
      char c = oldChars[in];
      switch (c)
      {
      case '\000': 
        newChars[(out++)] = '\\';
        c = '0';
        break;
      case '\n': 
        newChars[(out++)] = '\\';
        c = 'n';
        break;
      case '\r': 
        newChars[(out++)] = '\\';
        c = 'r';
        break;
      case '"': 
        newChars[(out++)] = '\\';
        c = '"';
        break;
      case '\\': 
        newChars[(out++)] = '\\';
        c = '\\';
      }
      newChars[out] = c;in++;
    }
    return String.valueOf(newChars);
  }
}
