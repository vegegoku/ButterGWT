package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface RangeRole
  extends WidgetRole
{
  public abstract String getAriaValuemaxProperty(Element paramElement);
  
  public abstract String getAriaValueminProperty(Element paramElement);
  
  public abstract String getAriaValuenowProperty(Element paramElement);
  
  public abstract String getAriaValuetextProperty(Element paramElement);
  
  public abstract void removeAriaValuemaxProperty(Element paramElement);
  
  public abstract void removeAriaValueminProperty(Element paramElement);
  
  public abstract void removeAriaValuenowProperty(Element paramElement);
  
  public abstract void removeAriaValuetextProperty(Element paramElement);
  
  public abstract void setAriaValuemaxProperty(Element paramElement, Number paramNumber);
  
  public abstract void setAriaValueminProperty(Element paramElement, Number paramNumber);
  
  public abstract void setAriaValuenowProperty(Element paramElement, Number paramNumber);
  
  public abstract void setAriaValuetextProperty(Element paramElement, String paramString);
}
