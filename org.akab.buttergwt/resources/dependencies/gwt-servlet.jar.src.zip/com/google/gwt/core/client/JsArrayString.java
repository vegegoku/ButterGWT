package com.google.gwt.core.client;

public class JsArrayString
  extends JavaScriptObject
{
  public final native String get(int paramInt);
  
  public final String join()
  {
    return join(",");
  }
  
  public final native String join(String paramString);
  
  public final native int length();
  
  public final native void push(String paramString);
  
  public final native void set(int paramInt, String paramString);
  
  public final native void setLength(int paramInt);
  
  public final native String shift();
  
  public final native void unshift(String paramString);
}
