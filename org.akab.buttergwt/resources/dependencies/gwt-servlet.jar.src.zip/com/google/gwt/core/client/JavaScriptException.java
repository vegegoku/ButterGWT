package com.google.gwt.core.client;

import com.google.gwt.core.client.impl.StackTraceCreator;

public final class JavaScriptException
  extends RuntimeException
{
  private static final Object NOT_SET = new Object();
  
  private static String getExceptionDescription(Object e)
  {
    if ((e instanceof JavaScriptObject)) {
      return getExceptionDescription0((JavaScriptObject)e);
    }
    return e + "";
  }
  
  private static native String getExceptionDescription0(JavaScriptObject paramJavaScriptObject);
  
  private static String getExceptionName(Object e)
  {
    if (e == null) {
      return "null";
    }
    if ((e instanceof JavaScriptObject)) {
      return getExceptionName0((JavaScriptObject)e);
    }
    if ((e instanceof String)) {
      return "String";
    }
    return e.getClass().getName();
  }
  
  private static native String getExceptionName0(JavaScriptObject paramJavaScriptObject);
  
  private static String getExceptionProperties(Object e)
  {
    return (GWT.isScript()) && ((e instanceof JavaScriptObject)) ? StackTraceCreator.getProperties((JavaScriptObject)e) : "";
  }
  
  private String description = "";
  private final Object e;
  private String message;
  private String name;
  
  public JavaScriptException(Object e)
  {
    this(e, "");
  }
  
  public JavaScriptException(Object e, String description)
  {
    this.e = e;
    this.description = description;
    if (GWT.isScript()) {
      StackTraceCreator.createStackTrace(this);
    }
  }
  
  public JavaScriptException(String name, String description)
  {
    this.message = ("JavaScript " + name + " exception: " + description);
    this.name = name;
    this.description = description;
    this.e = NOT_SET;
  }
  
  protected JavaScriptException(String message)
  {
    super(message);
    this.message = (this.description = message);
    this.e = NOT_SET;
  }
  
  public boolean isThrownSet()
  {
    return this.e != NOT_SET;
  }
  
  public Object getThrown()
  {
    return this.e == NOT_SET ? null : this.e;
  }
  
  public String getDescription()
  {
    ensureInit();
    return this.description;
  }
  
  @Deprecated
  public JavaScriptObject getException()
  {
    return (this.e instanceof JavaScriptObject) ? (JavaScriptObject)this.e : null;
  }
  
  public String getMessage()
  {
    ensureInit();
    return this.message;
  }
  
  public String getName()
  {
    ensureInit();
    return this.name;
  }
  
  private void ensureInit()
  {
    if (this.message == null)
    {
      Object exception = getThrown();
      this.name = getExceptionName(exception);
      this.description = (this.description + ": " + getExceptionDescription(exception));
      this.message = ("(" + this.name + ") " + getExceptionProperties(exception) + this.description);
    }
  }
}
