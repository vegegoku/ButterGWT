package com.google.gwt.animation.client;

import com.google.gwt.core.client.Duration;
import com.google.gwt.dom.client.Element;

public abstract class Animation
{
  private final AnimationScheduler.AnimationCallback callback = new AnimationScheduler.AnimationCallback()
  {
    public void execute(double timestamp)
    {
      if (Animation.this.update(timestamp)) {
        Animation.this.requestHandle = Animation.this.scheduler.requestAnimationFrame(Animation.this.callback, Animation.this.element);
      } else {
        Animation.this.requestHandle = null;
      }
    }
  };
  private int duration = -1;
  private Element element;
  private boolean isRunning = false;
  private boolean isStarted = false;
  private AnimationScheduler.AnimationHandle requestHandle;
  private int runId = -1;
  private final AnimationScheduler scheduler;
  private double startTime = -1.0D;
  private boolean wasStarted = false;
  
  public Animation()
  {
    this(AnimationScheduler.get());
  }
  
  protected Animation(AnimationScheduler scheduler)
  {
    this.scheduler = scheduler;
  }
  
  public void cancel()
  {
    if (!this.isRunning) {
      return;
    }
    this.wasStarted = this.isStarted;
    this.element = null;
    this.isRunning = false;
    this.isStarted = false;
    if (this.requestHandle != null)
    {
      this.requestHandle.cancel();
      this.requestHandle = null;
    }
    onCancel();
  }
  
  public void run(int duration)
  {
    run(duration, null);
  }
  
  public void run(int duration, Element element)
  {
    run(duration, Duration.currentTimeMillis(), element);
  }
  
  public void run(int duration, double startTime)
  {
    run(duration, startTime, null);
  }
  
  public void run(int duration, double startTime, Element element)
  {
    cancel();
    
    this.isRunning = true;
    this.isStarted = false;
    this.duration = duration;
    this.startTime = startTime;
    this.element = element;
    this.runId += 1;
    
    this.callback.execute(Duration.currentTimeMillis());
  }
  
  public boolean isRunning()
  {
    return this.isRunning;
  }
  
  protected double interpolate(double progress)
  {
    return (1.0D + Math.cos(3.141592653589793D + progress * 3.141592653589793D)) / 2.0D;
  }
  
  protected void onCancel()
  {
    if (this.wasStarted) {
      onComplete();
    }
  }
  
  protected void onComplete()
  {
    onUpdate(interpolate(1.0D));
  }
  
  protected void onStart()
  {
    onUpdate(interpolate(0.0D));
  }
  
  protected abstract void onUpdate(double paramDouble);
  
  private boolean isRunning(int curRunId)
  {
    return (this.isRunning) && (this.runId == curRunId);
  }
  
  private boolean update(double curTime)
  {
    int curRunId = this.runId;
    
    boolean finished = curTime >= this.startTime + this.duration;
    if ((this.isStarted) && (!finished))
    {
      double progress = (curTime - this.startTime) / this.duration;
      onUpdate(interpolate(progress));
      return isRunning(curRunId);
    }
    if ((!this.isStarted) && (curTime >= this.startTime))
    {
      this.isStarted = true;
      onStart();
      if (!isRunning(curRunId)) {
        return false;
      }
    }
    if (finished)
    {
      this.isRunning = false;
      this.isStarted = false;
      onComplete();
      return false;
    }
    return true;
  }
}
