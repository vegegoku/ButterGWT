package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.dom.client.Node;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesBuilder;
import com.google.gwt.safecss.shared.SafeStylesUtils;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.HasVerticalAlignment;
import com.google.gwt.user.client.ui.HasVerticalAlignment.VerticalAlignmentConstant;
import java.util.Set;

public class IconCellDecorator<C>
  implements Cell<C>
{
  private static final int DEFAULT_SPACING = 6;
  private static Template template;
  private final Cell<C> cell;
  private final String direction = LocaleInfo.getCurrentLocale().isRTL() ? "right" : "left";
  private final SafeHtml iconHtml;
  private final int imageWidth;
  private final SafeStyles outerDivPadding;
  private final SafeHtml placeHolderHtml;
  
  public IconCellDecorator(ImageResource icon, Cell<C> cell)
  {
    this(icon, cell, HasVerticalAlignment.ALIGN_MIDDLE, 6);
  }
  
  public IconCellDecorator(ImageResource icon, Cell<C> cell, HasVerticalAlignment.VerticalAlignmentConstant valign, int spacing)
  {
    if (template == null) {
      template = (Template)GWT.create(Template.class);
    }
    this.cell = cell;
    this.iconHtml = getImageHtml(icon, valign, false);
    this.imageWidth = (icon.getWidth() + spacing);
    this.placeHolderHtml = getImageHtml(icon, valign, true);
    this.outerDivPadding = SafeStylesUtils.fromTrustedString("padding-" + this.direction + ": " + this.imageWidth + "px;");
  }
  
  public boolean dependsOnSelection()
  {
    return this.cell.dependsOnSelection();
  }
  
  public Set<String> getConsumedEvents()
  {
    return this.cell.getConsumedEvents();
  }
  
  public boolean handlesSelection()
  {
    return this.cell.handlesSelection();
  }
  
  public boolean isEditing(Cell.Context context, Element parent, C value)
  {
    return this.cell.isEditing(context, getCellParent(parent), value);
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    this.cell.onBrowserEvent(context, getCellParent(parent), value, event, valueUpdater);
  }
  
  public void render(Cell.Context context, C value, SafeHtmlBuilder sb)
  {
    SafeHtmlBuilder cellBuilder = new SafeHtmlBuilder();
    this.cell.render(context, value, cellBuilder);
    sb.append(template.outerDiv(this.outerDivPadding, isIconUsed(value) ? getIconHtml(value) : this.placeHolderHtml, cellBuilder.toSafeHtml()));
  }
  
  public boolean resetFocus(Cell.Context context, Element parent, C value)
  {
    return this.cell.resetFocus(context, getCellParent(parent), value);
  }
  
  public void setValue(Cell.Context context, Element parent, C value)
  {
    this.cell.setValue(context, getCellParent(parent), value);
  }
  
  protected SafeHtml getIconHtml(C value)
  {
    return this.iconHtml;
  }
  
  protected boolean isIconUsed(C value)
  {
    return true;
  }
  
  SafeHtml getImageHtml(ImageResource res, HasVerticalAlignment.VerticalAlignmentConstant valign, boolean isPlaceholder)
  {
    SafeHtml image;
    SafeHtml image;
    if (isPlaceholder)
    {
      image = SafeHtmlUtils.fromTrustedString("<div></div>");
    }
    else
    {
      AbstractImagePrototype proto = AbstractImagePrototype.create(res);
      image = SafeHtmlUtils.fromTrustedString(proto.getHTML());
    }
    SafeStylesBuilder cssStyles = new SafeStylesBuilder().appendTrustedString(this.direction + ":0px;");
    if (HasVerticalAlignment.ALIGN_TOP == valign) {
      return template.imageWrapperTop(cssStyles.toSafeStyles(), image);
    }
    if (HasVerticalAlignment.ALIGN_BOTTOM == valign) {
      return template.imageWrapperBottom(cssStyles.toSafeStyles(), image);
    }
    int halfHeight = (int)Math.round(res.getHeight() / 2.0D);
    cssStyles.appendTrustedString("margin-top:-" + halfHeight + "px;");
    return template.imageWrapperMiddle(cssStyles.toSafeStyles(), image);
  }
  
  private Element getCellParent(Element parent)
  {
    return (Element)parent.getFirstChildElement().getChild(1).cast();
  }
  
  static abstract interface Template
    extends SafeHtmlTemplates
  {
    @SafeHtmlTemplates.Template("<div style=\"{0}position:relative;zoom:1;\">{1}<div>{2}</div></div>")
    public abstract SafeHtml outerDiv(SafeStyles paramSafeStyles, SafeHtml paramSafeHtml1, SafeHtml paramSafeHtml2);
    
    @SafeHtmlTemplates.Template("<div style=\"{0}position:absolute;bottom:0px;line-height:0px;\">{1}</div>")
    public abstract SafeHtml imageWrapperBottom(SafeStyles paramSafeStyles, SafeHtml paramSafeHtml);
    
    @SafeHtmlTemplates.Template("<div style=\"{0}position:absolute;top:50%;line-height:0px;\">{1}</div>")
    public abstract SafeHtml imageWrapperMiddle(SafeStyles paramSafeStyles, SafeHtml paramSafeHtml);
    
    @SafeHtmlTemplates.Template("<div style=\"{0}position:absolute;top:0px;line-height:0px;\">{1}</div>")
    public abstract SafeHtml imageWrapperTop(SafeStyles paramSafeStyles, SafeHtml paramSafeHtml);
  }
}
