package com.google.gwt.dom.builder.shared;

import com.google.gwt.safehtml.shared.SafeUri;

public abstract interface FormBuilder
  extends ElementBuilderBase<FormBuilder>
{
  public abstract FormBuilder acceptCharset(String paramString);
  
  public abstract FormBuilder action(SafeUri paramSafeUri);
  
  public abstract FormBuilder action(String paramString);
  
  public abstract FormBuilder enctype(String paramString);
  
  public abstract FormBuilder method(String paramString);
  
  public abstract FormBuilder name(String paramString);
  
  public abstract FormBuilder target(String paramString);
}
