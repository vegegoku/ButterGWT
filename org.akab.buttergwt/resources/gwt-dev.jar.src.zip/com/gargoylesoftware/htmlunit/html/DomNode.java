package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.IncorrectnessListener;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.xpath.XPathUtils;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleDeclaration;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import com.steadystate.css.parser.CSSOMParser;
import com.steadystate.css.parser.SACParserCSS3;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.atomic.AtomicBoolean;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.xml.utils.PrefixResolver;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.CSSParseException;
import org.w3c.css.sac.ErrorHandler;
import org.w3c.css.sac.InputSource;
import org.w3c.css.sac.Selector;
import org.w3c.css.sac.SelectorList;
import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.UserDataHandler;

public abstract class DomNode
  implements Cloneable, Serializable, Node
{
  protected static final String AS_TEXT_BLOCK_SEPARATOR = "§bs§";
  protected static final String AS_TEXT_NEW_LINE = "§nl§";
  protected static final String AS_TEXT_BLANK = "§blank§";
  protected static final String AS_TEXT_TAB = "§tab§";
  public static final String READY_STATE_UNINITIALIZED = "uninitialized";
  public static final String READY_STATE_LOADING = "loading";
  public static final String READY_STATE_LOADED = "loaded";
  public static final String READY_STATE_INTERACTIVE = "interactive";
  public static final String READY_STATE_COMPLETE = "complete";
  public static final String PROPERTY_ELEMENT = "element";
  private SgmlPage page_;
  private DomNode parent_;
  private DomNode previousSibling_;
  private DomNode nextSibling_;
  private DomNode firstChild_;
  private ScriptableObject scriptObject_;
  private String readyState_;
  private int startLineNumber_ = -1;
  private int startColumnNumber_ = -1;
  private int endLineNumber_ = -1;
  private int endColumnNumber_ = -1;
  private boolean directlyAttachedToPage_;
  private Collection<DomChangeListener> domListeners_;
  private final Object domListeners_lock_ = new Serializable() {};
  
  @Deprecated
  protected DomNode()
  {
    this(null);
  }
  
  protected DomNode(SgmlPage page)
  {
    this.readyState_ = "loading";
    this.page_ = page;
  }
  
  void setStartLocation(int startLineNumber, int startColumnNumber)
  {
    this.startLineNumber_ = startLineNumber;
    this.startColumnNumber_ = startColumnNumber;
  }
  
  void setEndLocation(int endLineNumber, int endColumnNumber)
  {
    this.endLineNumber_ = endLineNumber;
    this.endColumnNumber_ = endColumnNumber;
  }
  
  public int getStartLineNumber()
  {
    return this.startLineNumber_;
  }
  
  public int getStartColumnNumber()
  {
    return this.startColumnNumber_;
  }
  
  public int getEndLineNumber()
  {
    return this.endLineNumber_;
  }
  
  public int getEndColumnNumber()
  {
    return this.endColumnNumber_;
  }
  
  public SgmlPage getPage()
  {
    return this.page_;
  }
  
  public HtmlPage getHtmlPageOrNull()
  {
    if ((this.page_ == null) || (!this.page_.isHtmlPage())) {
      return null;
    }
    return (HtmlPage)this.page_;
  }
  
  public org.w3c.dom.Document getOwnerDocument()
  {
    return getPage();
  }
  
  public void setScriptObject(ScriptableObject scriptObject)
  {
    this.scriptObject_ = scriptObject;
  }
  
  public DomNode getLastChild()
  {
    if (this.firstChild_ != null) {
      return this.firstChild_.previousSibling_;
    }
    return null;
  }
  
  public DomNode getParentNode()
  {
    return this.parent_;
  }
  
  protected void setParentNode(DomNode parent)
  {
    this.parent_ = parent;
  }
  
  public int getIndex()
  {
    int index = 0;
    for (DomNode n = this.previousSibling_; (n != null) && (n.nextSibling_ != null); n = n.previousSibling_) {
      index++;
    }
    return index;
  }
  
  public DomNode getPreviousSibling()
  {
    if ((this.parent_ == null) || (this == this.parent_.firstChild_)) {
      return null;
    }
    return this.previousSibling_;
  }
  
  public DomNode getNextSibling()
  {
    return this.nextSibling_;
  }
  
  public DomNode getFirstChild()
  {
    return this.firstChild_;
  }
  
  public boolean isAncestorOf(DomNode node)
  {
    while (node != null)
    {
      if (node == this) {
        return true;
      }
      node = node.getParentNode();
    }
    return false;
  }
  
  public boolean isAncestorOfAny(DomNode... nodes)
  {
    for (DomNode node : nodes) {
      if (isAncestorOf(node)) {
        return true;
      }
    }
    return false;
  }
  
  protected void setPreviousSibling(DomNode previous)
  {
    this.previousSibling_ = previous;
  }
  
  protected void setNextSibling(DomNode next)
  {
    this.nextSibling_ = next;
  }
  
  public abstract short getNodeType();
  
  public abstract String getNodeName();
  
  public String getNamespaceURI()
  {
    return null;
  }
  
  public String getLocalName()
  {
    return null;
  }
  
  public String getPrefix()
  {
    return null;
  }
  
  public void setPrefix(String prefix) {}
  
  public boolean hasChildNodes()
  {
    return this.firstChild_ != null;
  }
  
  public DomNodeList<DomNode> getChildNodes()
  {
    return new SiblingDomNodeList(this);
  }
  
  public boolean isSupported(String namespace, String featureName)
  {
    throw new UnsupportedOperationException("DomNode.isSupported is not yet implemented.");
  }
  
  public void normalize()
  {
    for (DomNode child = getFirstChild(); child != null; child = child.getNextSibling()) {
      if ((child instanceof DomText))
      {
        boolean removeChildTextNodes = hasFeature(BrowserVersionFeatures.DOM_NORMALIZE_REMOVE_CHILDREN);
        StringBuilder dataBuilder = new StringBuilder();
        DomNode toRemove = child;
        DomText firstText = null;
        while (((toRemove instanceof DomText)) && (!(toRemove instanceof DomCDataSection)))
        {
          DomNode nextChild = toRemove.getNextSibling();
          dataBuilder.append(toRemove.getTextContent());
          if ((removeChildTextNodes) || (firstText != null)) {
            toRemove.remove();
          }
          if (firstText == null) {
            firstText = (DomText)toRemove;
          }
          toRemove = nextChild;
        }
        if (firstText != null) {
          if (removeChildTextNodes)
          {
            DomText newText = new DomText(getPage(), dataBuilder.toString());
            insertBefore(newText, toRemove);
          }
          else
          {
            firstText.setData(dataBuilder.toString());
          }
        }
      }
    }
  }
  
  public String getBaseURI()
  {
    throw new UnsupportedOperationException("DomNode.getBaseURI is not yet implemented.");
  }
  
  public short compareDocumentPosition(Node other)
  {
    if (other == this) {
      return 0;
    }
    List<Node> myAncestors = getAncestors(true);
    List<Node> otherAncestors = ((DomNode)other).getAncestors(true);
    
    int max = Math.min(myAncestors.size(), otherAncestors.size());
    
    int i = 1;
    while ((i < max) && (myAncestors.get(i) == otherAncestors.get(i))) {
      i++;
    }
    if ((i != 1) && (i == max))
    {
      if (myAncestors.size() == max) {
        return 20;
      }
      return 10;
    }
    if (max == 1)
    {
      if (myAncestors.contains(other)) {
        return 8;
      }
      if (otherAncestors.contains(this)) {
        return 20;
      }
      return 33;
    }
    Node myAncestor = (Node)myAncestors.get(i);
    Node otherAncestor = (Node)otherAncestors.get(i);
    Node node = myAncestor;
    while ((node != otherAncestor) && (node != null)) {
      node = node.getPreviousSibling();
    }
    if (node == null) {
      return 4;
    }
    return 2;
  }
  
  protected List<Node> getAncestors(boolean includeSelf)
  {
    List<Node> list = new ArrayList();
    if (includeSelf) {
      list.add(this);
    }
    Node node = getParentNode();
    while (node != null)
    {
      list.add(0, node);
      node = node.getParentNode();
    }
    return list;
  }
  
  public String getTextContent()
  {
    switch (getNodeType())
    {
    case 1: 
    case 2: 
    case 5: 
    case 6: 
    case 11: 
      StringBuilder builder = new StringBuilder();
      for (DomNode child : getChildren())
      {
        short childType = child.getNodeType();
        if ((childType != 8) && (childType != 7)) {
          builder.append(child.getTextContent());
        }
      }
      return builder.toString();
    case 3: 
    case 4: 
    case 7: 
    case 8: 
      return getNodeValue();
    }
    return null;
  }
  
  public void setTextContent(String textContent)
  {
    removeAllChildren();
    if (textContent != null) {
      appendChild(new DomText(getPage(), textContent));
    }
  }
  
  public boolean isSameNode(Node other)
  {
    return other == this;
  }
  
  public String lookupPrefix(String namespaceURI)
  {
    throw new UnsupportedOperationException("DomNode.lookupPrefix is not yet implemented.");
  }
  
  public boolean isDefaultNamespace(String namespaceURI)
  {
    throw new UnsupportedOperationException("DomNode.isDefaultNamespace is not yet implemented.");
  }
  
  public String lookupNamespaceURI(String prefix)
  {
    throw new UnsupportedOperationException("DomNode.lookupNamespaceURI is not yet implemented.");
  }
  
  public boolean isEqualNode(Node arg)
  {
    throw new UnsupportedOperationException("DomNode.isEqualNode is not yet implemented.");
  }
  
  public Object getFeature(String feature, String version)
  {
    throw new UnsupportedOperationException("DomNode.getFeature is not yet implemented.");
  }
  
  public Object getUserData(String key)
  {
    throw new UnsupportedOperationException("DomNode.getUserData is not yet implemented.");
  }
  
  public Object setUserData(String key, Object data, UserDataHandler handler)
  {
    throw new UnsupportedOperationException("DomNode.setUserData is not yet implemented.");
  }
  
  public boolean hasAttributes()
  {
    return false;
  }
  
  protected boolean isTrimmedText()
  {
    return true;
  }
  
  public boolean isDisplayed()
  {
    if (!mayBeDisplayed()) {
      return false;
    }
    HtmlPage htmlPage = getHtmlPageOrNull();
    boolean collapseInvisible;
    if ((htmlPage != null) && (htmlPage.getEnclosingWindow().getWebClient().getOptions().isCssEnabled()))
    {
      LinkedList<CSSStyleDeclaration> styles = new LinkedList();
      for (Node node : getAncestors(true))
      {
        ScriptableObject scriptableObject = ((DomNode)node).getScriptObject();
        if ((scriptableObject instanceof HTMLElement))
        {
          CSSStyleDeclaration style = ((HTMLElement)scriptableObject).getCurrentStyle();
          String display = style.getDisplay();
          if ("none".equals(display)) {
            return false;
          }
          styles.addFirst(style);
        }
      }
      collapseInvisible = hasFeature(BrowserVersionFeatures.DISPLAYED_COLLAPSE);
      for (CSSStyleDeclaration style : styles)
      {
        String visibility = style.getVisibility();
        if (visibility.length() > 5)
        {
          if ("visible".equals(visibility)) {
            return true;
          }
          if (("hidden".equals(visibility)) || ((collapseInvisible) && ("collapse".equals(visibility)))) {
            return false;
          }
        }
      }
    }
    return true;
  }
  
  public boolean mayBeDisplayed()
  {
    return true;
  }
  
  public String asText()
  {
    HtmlSerializer ser = new HtmlSerializer();
    return ser.asText(this);
  }
  
  protected boolean isBlock()
  {
    return false;
  }
  
  public String asXml()
  {
    String charsetName = null;
    HtmlPage htmlPage = getHtmlPageOrNull();
    if (htmlPage != null) {
      charsetName = htmlPage.getPageEncoding();
    }
    StringWriter stringWriter = new StringWriter();
    PrintWriter printWriter = new PrintWriter(stringWriter);
    if ((charsetName != null) && ((this instanceof HtmlHtml))) {
      printWriter.println("<?xml version=\"1.0\" encoding=\"" + charsetName + "\"?>");
    }
    printXml("", printWriter);
    printWriter.close();
    return stringWriter.toString();
  }
  
  protected void printXml(String indent, PrintWriter printWriter)
  {
    printWriter.println(indent + this);
    printChildrenAsXml(indent, printWriter);
  }
  
  protected void printChildrenAsXml(String indent, PrintWriter printWriter)
  {
    DomNode child = getFirstChild();
    while (child != null)
    {
      child.printXml(indent + "  ", printWriter);
      child = child.getNextSibling();
    }
  }
  
  public String getNodeValue()
  {
    return null;
  }
  
  public void setNodeValue(String value) {}
  
  public DomNode cloneNode(boolean deep)
  {
    DomNode newnode;
    try
    {
      newnode = (DomNode)clone();
    }
    catch (CloneNotSupportedException e)
    {
      throw new IllegalStateException("Clone not supported for node [" + this + "]");
    }
    newnode.parent_ = null;
    newnode.nextSibling_ = null;
    newnode.previousSibling_ = null;
    newnode.firstChild_ = null;
    newnode.scriptObject_ = null;
    newnode.directlyAttachedToPage_ = false;
    if (deep) {
      for (DomNode child = this.firstChild_; child != null; child = child.nextSibling_) {
        newnode.appendChild(child.cloneNode(true));
      }
    }
    return newnode;
  }
  
  public ScriptableObject getScriptObject()
  {
    if (this.scriptObject_ == null)
    {
      SgmlPage page = getPage();
      if (this == getPage())
      {
        StringBuilder msg = new StringBuilder("No script object associated with the Page.");
        
        msg.append(" class: '");
        msg.append(page.getClass().getName());
        msg.append("'");
        try
        {
          msg.append(" url: '" + page.getUrl() + "'");
          msg.append(" content: ");
          msg.append(page.getWebResponse().getContentAsString());
        }
        catch (Exception e)
        {
          msg.append(" no details: '" + e.toString() + "'");
        }
        throw new IllegalStateException(msg.toString());
      }
      this.scriptObject_ = ((SimpleScriptable)this.page_.getScriptObject()).makeScriptableFor(this);
    }
    return this.scriptObject_;
  }
  
  public DomNode appendChild(Node node)
  {
    if (node == this)
    {
      if (!hasFeature(BrowserVersionFeatures.NODE_APPEND_CHILD_SELF_IGNORE)) {
        Context.throwAsScriptRuntimeEx(new Exception("Can not add not to itself " + this));
      }
      return this;
    }
    DomNode domNode = (DomNode)node;
    if (domNode.isDescendant(this)) {
      Context.throwAsScriptRuntimeEx(new Exception("Can not add (grand)parent to itself " + this));
    }
    if ((domNode instanceof DomDocumentFragment))
    {
      DomDocumentFragment fragment = (DomDocumentFragment)domNode;
      for (DomNode child : fragment.getChildren()) {
        appendChild(child);
      }
    }
    else
    {
      if ((domNode != this) && (domNode.getParentNode() != null)) {
        domNode.detach();
      }
      basicAppend(domNode);
      
      fireAddition(domNode);
    }
    return domNode;
  }
  
  private void fireAddition(DomNode domNode)
  {
    boolean wasAlreadyAttached = domNode.isDirectlyAttachedToPage();
    domNode.directlyAttachedToPage_ = isDirectlyAttachedToPage();
    if (isDirectlyAttachedToPage())
    {
      Page page = getPage();
      if ((page instanceof HtmlPage)) {
        ((HtmlPage)page).notifyNodeAdded(domNode);
      }
      if ((!domNode.isBodyParsed()) && (!wasAlreadyAttached))
      {
        for (DomNode child : domNode.getDescendants())
        {
          child.directlyAttachedToPage_ = true;
          child.onAllChildrenAddedToPage(true);
        }
        domNode.onAllChildrenAddedToPage(true);
      }
    }
    if ((this instanceof DomDocumentFragment)) {
      onAddedToDocumentFragment();
    }
    fireNodeAdded(this, domNode);
  }
  
  private boolean isBodyParsed()
  {
    return (getStartLineNumber() != -1) && (getEndLineNumber() == -1);
  }
  
  void quietlyRemoveAndMoveChildrenTo(DomNode destination)
  {
    if (destination.getPage() != getPage()) {
      throw new RuntimeException("Cannot perform quiet move on nodes from different pages.");
    }
    for (DomNode child : getChildren())
    {
      child.basicRemove();
      destination.basicAppend(child);
    }
    basicRemove();
  }
  
  private void basicAppend(DomNode node)
  {
    node.setPage(getPage());
    if (this.firstChild_ == null)
    {
      this.firstChild_ = node;
      this.firstChild_.previousSibling_ = node;
    }
    else
    {
      DomNode last = getLastChild();
      last.nextSibling_ = node;
      node.previousSibling_ = last;
      node.nextSibling_ = null;
      this.firstChild_.previousSibling_ = node;
    }
    node.parent_ = this;
  }
  
  protected void checkChildHierarchy(Node newChild)
    throws DOMException
  {
    Node parentNode = this;
    while (parentNode != null)
    {
      if (parentNode == newChild) {
        throw new DOMException((short)3, "Child node is already a parent.");
      }
      parentNode = parentNode.getParentNode();
    }
    org.w3c.dom.Document thisDocument = getOwnerDocument();
    org.w3c.dom.Document childDocument = newChild.getOwnerDocument();
    if ((childDocument != thisDocument) && (childDocument != null)) {
      throw new DOMException((short)4, "Child node " + newChild.getNodeName() + " is not in the same Document as this " + getNodeName() + ".");
    }
  }
  
  public Node insertBefore(Node newChild, Node refChild)
  {
    if (refChild == null)
    {
      appendChild(newChild);
    }
    else
    {
      if (refChild.getParentNode() != this) {
        throw new DOMException((short)8, "Reference node is not a child of this node.");
      }
      ((DomNode)refChild).insertBefore((DomNode)newChild);
    }
    return null;
  }
  
  public void insertBefore(DomNode newNode)
    throws IllegalStateException
  {
    if (this.previousSibling_ == null) {
      throw new IllegalStateException("Previous sibling for " + this + " is null.");
    }
    if (newNode == this) {
      return;
    }
    DomNode exParent = newNode.getParentNode();
    newNode.basicRemove();
    if (this.parent_.firstChild_ == this) {
      this.parent_.firstChild_ = newNode;
    } else {
      this.previousSibling_.nextSibling_ = newNode;
    }
    newNode.previousSibling_ = this.previousSibling_;
    newNode.nextSibling_ = this;
    this.previousSibling_ = newNode;
    newNode.parent_ = this.parent_;
    newNode.setPage(this.page_);
    
    fireAddition(newNode);
    if (exParent != null)
    {
      fireNodeDeleted(exParent, newNode);
      exParent.fireNodeDeleted(exParent, this);
    }
  }
  
  private void setPage(SgmlPage newPage)
  {
    if (this.page_ == newPage) {
      return;
    }
    this.page_ = newPage;
    for (DomNode node : getChildren()) {
      node.setPage(newPage);
    }
  }
  
  public NamedNodeMap getAttributes()
  {
    return NamedAttrNodeMapImpl.EMPTY_MAP;
  }
  
  public Node removeChild(Node child)
  {
    if (child.getParentNode() != this) {
      throw new DOMException((short)8, "Node is not a child of this node.");
    }
    ((DomNode)child).remove();
    return child;
  }
  
  protected void detach()
  {
    DomNode exParent = this.parent_;
    basicRemove();
    
    HtmlPage htmlPage = getHtmlPageOrNull();
    if (htmlPage != null) {
      htmlPage.notifyNodeRemoved(this);
    }
    if (exParent != null)
    {
      fireNodeDeleted(exParent, this);
      
      exParent.fireNodeDeleted(exParent, this);
    }
  }
  
  public void remove()
  {
    detach();
  }
  
  private void basicRemove()
  {
    if ((this.parent_ != null) && (this.parent_.firstChild_ == this)) {
      this.parent_.firstChild_ = this.nextSibling_;
    } else if ((this.previousSibling_ != null) && (this.previousSibling_.nextSibling_ == this)) {
      this.previousSibling_.nextSibling_ = this.nextSibling_;
    }
    if ((this.nextSibling_ != null) && (this.nextSibling_.previousSibling_ == this)) {
      this.nextSibling_.previousSibling_ = this.previousSibling_;
    }
    if ((this.parent_ != null) && (this == this.parent_.getLastChild())) {
      this.parent_.firstChild_.previousSibling_ = this.previousSibling_;
    }
    this.nextSibling_ = null;
    this.previousSibling_ = null;
    this.parent_ = null;
  }
  
  public Node replaceChild(Node newChild, Node oldChild)
  {
    if (oldChild.getParentNode() != this) {
      throw new DOMException((short)8, "Node is not a child of this node.");
    }
    ((DomNode)oldChild).replace((DomNode)newChild);
    return oldChild;
  }
  
  public void replace(DomNode newNode)
    throws IllegalStateException
  {
    if (newNode != this)
    {
      newNode.remove();
      insertBefore(newNode);
      remove();
    }
  }
  
  protected void onAddedToPage()
  {
    if (this.firstChild_ != null) {
      for (DomNode child : getChildren()) {
        child.onAddedToPage();
      }
    }
  }
  
  protected void onAllChildrenAddedToPage(boolean postponed) {}
  
  protected void onAddedToDocumentFragment()
  {
    if (this.firstChild_ != null) {
      for (DomNode child : getChildren()) {
        child.onAddedToDocumentFragment();
      }
    }
  }
  
  public final Iterable<DomNode> getChildren()
  {
    new Iterable()
    {
      public Iterator<DomNode> iterator()
      {
        return new DomNode.ChildIterator(DomNode.this);
      }
    };
  }
  
  protected class ChildIterator
    implements Iterator<DomNode>
  {
    private DomNode nextNode_ = DomNode.this.firstChild_;
    private DomNode currentNode_ = null;
    
    protected ChildIterator() {}
    
    public boolean hasNext()
    {
      return this.nextNode_ != null;
    }
    
    public DomNode next()
    {
      if (this.nextNode_ != null)
      {
        this.currentNode_ = this.nextNode_;
        this.nextNode_ = this.nextNode_.nextSibling_;
        return this.currentNode_;
      }
      throw new NoSuchElementException();
    }
    
    public void remove()
    {
      if (this.currentNode_ == null) {
        throw new IllegalStateException();
      }
      this.currentNode_.remove();
    }
  }
  
  public final Iterable<DomNode> getDescendants()
  {
    new Iterable()
    {
      public Iterator<DomNode> iterator()
      {
        return new DomNode.DescendantElementsIterator(DomNode.this, DomNode.class);
      }
    };
  }
  
  public final Iterable<HtmlElement> getHtmlElementDescendants()
  {
    new Iterable()
    {
      public Iterator<HtmlElement> iterator()
      {
        return new DomNode.DescendantElementsIterator(DomNode.this, HtmlElement.class);
      }
    };
  }
  
  protected class DescendantElementsIterator<T extends DomNode>
    implements Iterator<T>
  {
    private DomNode currentNode_;
    private DomNode nextNode_;
    private final Class<T> type_;
    
    public DescendantElementsIterator()
    {
      this.type_ = type;
      this.nextNode_ = getFirstChildElement(DomNode.this);
    }
    
    public boolean hasNext()
    {
      return this.nextNode_ != null;
    }
    
    public T next()
    {
      return nextNode();
    }
    
    public void remove()
    {
      if (this.currentNode_ == null) {
        throw new IllegalStateException("Unable to remove current node, because there is no current node.");
      }
      DomNode current = this.currentNode_;
      while ((this.nextNode_ != null) && (current.isAncestorOf(this.nextNode_))) {
        next();
      }
      current.remove();
    }
    
    public T nextNode()
    {
      this.currentNode_ = this.nextNode_;
      setNextElement();
      return this.currentNode_;
    }
    
    private void setNextElement()
    {
      DomNode next = getFirstChildElement(this.nextNode_);
      if (next == null) {
        next = getNextDomSibling(this.nextNode_);
      }
      if (next == null) {
        next = getNextElementUpwards(this.nextNode_);
      }
      this.nextNode_ = next;
    }
    
    private DomNode getNextElementUpwards(DomNode startingNode)
    {
      if (startingNode == DomNode.this) {
        return null;
      }
      DomNode parent = startingNode.getParentNode();
      if ((parent == null) || (parent == DomNode.this)) {
        return null;
      }
      DomNode next = parent.getNextSibling();
      while ((next != null) && (!isAccepted(next))) {
        next = next.getNextSibling();
      }
      if (next == null) {
        return getNextElementUpwards(parent);
      }
      return next;
    }
    
    private DomNode getFirstChildElement(DomNode parent)
    {
      DomNode node = parent.getFirstChild();
      while ((node != null) && (!isAccepted(node))) {
        node = node.getNextSibling();
      }
      return node;
    }
    
    protected boolean isAccepted(DomNode node)
    {
      return this.type_.isAssignableFrom(node.getClass());
    }
    
    private DomNode getNextDomSibling(DomNode element)
    {
      DomNode node = element.getNextSibling();
      while ((node != null) && (!isAccepted(node))) {
        node = node.getNextSibling();
      }
      return node;
    }
  }
  
  public String getReadyState()
  {
    return this.readyState_;
  }
  
  public void setReadyState(String state)
  {
    this.readyState_ = state;
  }
  
  public void removeAllChildren()
  {
    while (getFirstChild() != null) {
      getFirstChild().remove();
    }
  }
  
  private static Map<String, String> parseSelectionNamespaces(String selectionNS)
  {
    Map<String, String> result = new HashMap();
    String[] toks = selectionNS.split("\\s");
    for (String tok : toks) {
      if (tok.startsWith("xmlns="))
      {
        result.put("", tok.substring(7, tok.length() - 7));
      }
      else if (tok.startsWith("xmlns:"))
      {
        String[] prefix = tok.substring(6).split("=");
        result.put(prefix[0], prefix[1].substring(1, prefix[1].length() - 1));
      }
    }
    return result.size() > 0 ? result : null;
  }
  
  public List<?> getByXPath(String xpathExpr)
  {
    PrefixResolver prefixResolver = null;
    if (hasFeature(BrowserVersionFeatures.XPATH_SELECTION_NAMESPACES))
    {
      org.w3c.dom.Document doc = getOwnerDocument();
      if ((doc instanceof XmlPage))
      {
        ScriptableObject scriptable = ((XmlPage)doc).getScriptObject();
        if (ScriptableObject.hasProperty(scriptable, "getProperty"))
        {
          Object selectionNS = ScriptableObject.callMethod(scriptable, "getProperty", new Object[] { "SelectionNamespaces" });
          if ((selectionNS != null) && (selectionNS.toString().length() > 0))
          {
            final Map<String, String> namespaces = parseSelectionNamespaces(selectionNS.toString());
            if (namespaces != null) {
              prefixResolver = new PrefixResolver()
              {
                public String getBaseIdentifier()
                {
                  return (String)namespaces.get("");
                }
                
                public String getNamespaceForPrefix(String prefix)
                {
                  return (String)namespaces.get(prefix);
                }
                
                public String getNamespaceForPrefix(String prefix, Node node)
                {
                  throw new UnsupportedOperationException();
                }
                
                public boolean handlesNullPrefixes()
                {
                  return false;
                }
              };
            }
          }
        }
      }
    }
    return XPathUtils.getByXPath(this, xpathExpr, prefixResolver);
  }
  
  public List<?> getByXPath(String xpathExpr, PrefixResolver resolver)
  {
    return XPathUtils.getByXPath(this, xpathExpr, resolver);
  }
  
  public <X> X getFirstByXPath(String xpathExpr)
  {
    return (X)getFirstByXPath(xpathExpr, null);
  }
  
  public <X> X getFirstByXPath(String xpathExpr, PrefixResolver resolver)
  {
    List<?> results = getByXPath(xpathExpr, resolver);
    if (results.isEmpty()) {
      return null;
    }
    return (X)results.get(0);
  }
  
  public String getCanonicalXPath()
  {
    throw new RuntimeException("Method getCanonicalXPath() not implemented for nodes of type " + getNodeType());
  }
  
  protected void notifyIncorrectness(String message)
  {
    WebClient client = getPage().getEnclosingWindow().getWebClient();
    IncorrectnessListener incorrectnessListener = client.getIncorrectnessListener();
    incorrectnessListener.notify(message, this);
  }
  
  public void addDomChangeListener(DomChangeListener listener)
  {
    WebAssert.notNull("listener", listener);
    synchronized (this.domListeners_lock_)
    {
      if (this.domListeners_ == null) {
        this.domListeners_ = new LinkedHashSet();
      }
      this.domListeners_.add(listener);
    }
  }
  
  public void removeDomChangeListener(DomChangeListener listener)
  {
    WebAssert.notNull("listener", listener);
    synchronized (this.domListeners_lock_)
    {
      if (this.domListeners_ != null) {
        this.domListeners_.remove(listener);
      }
    }
  }
  
  protected void fireNodeAdded(DomNode parentNode, DomNode addedNode)
  {
    List<DomChangeListener> listeners = safeGetDomListeners();
    DomChangeEvent event;
    if (listeners != null)
    {
      event = new DomChangeEvent(parentNode, addedNode);
      for (DomChangeListener listener : listeners) {
        listener.nodeAdded(event);
      }
    }
    if (this.parent_ != null) {
      this.parent_.fireNodeAdded(parentNode, addedNode);
    }
  }
  
  protected void fireNodeDeleted(DomNode parentNode, DomNode deletedNode)
  {
    List<DomChangeListener> listeners = safeGetDomListeners();
    DomChangeEvent event;
    if (listeners != null)
    {
      event = new DomChangeEvent(parentNode, deletedNode);
      for (DomChangeListener listener : listeners) {
        listener.nodeDeleted(event);
      }
    }
    if (this.parent_ != null) {
      this.parent_.fireNodeDeleted(parentNode, deletedNode);
    }
  }
  
  private List<DomChangeListener> safeGetDomListeners()
  {
    synchronized (this.domListeners_lock_)
    {
      if (this.domListeners_ != null) {
        return new ArrayList(this.domListeners_);
      }
      return null;
    }
  }
  
  public DomNodeList<DomNode> querySelectorAll(String selectors)
  {
    List<DomNode> elements = new ArrayList();
    try
    {
      WebClient webClient = getPage().getWebClient();
      final AtomicBoolean errorOccured = new AtomicBoolean(false);
      ErrorHandler errorHandler = new ErrorHandler()
      {
        public void warning(CSSParseException exception)
          throws CSSException
        {}
        
        public void fatalError(CSSParseException exception)
          throws CSSException
        {
          errorOccured.set(true);
        }
        
        public void error(CSSParseException exception)
          throws CSSException
        {
          errorOccured.set(true);
        }
      };
      CSSOMParser parser = new CSSOMParser(new SACParserCSS3());
      parser.setErrorHandler(errorHandler);
      selectorList = parser.parseSelectors(new InputSource(new StringReader(selectors)));
      if (errorOccured.get()) {
        throw new CSSException("Invalid selectors: " + selectors);
      }
      if (null != selectorList)
      {
        browserVersion = webClient.getBrowserVersion();
        int documentMode = 9;
        if (browserVersion.hasFeature(BrowserVersionFeatures.QUERYSELECTORALL_NOT_IN_QUIRKS))
        {
          ScriptableObject sobj = getPage().getScriptObject();
          if ((sobj instanceof HTMLDocument)) {
            documentMode = ((HTMLDocument)sobj).getDocumentMode();
          }
        }
        CSSStyleSheet.validateSelectors(selectorList, documentMode);
        for (HtmlElement child : getHtmlElementDescendants()) {
          for (int i = 0; i < selectorList.getLength(); i++)
          {
            Selector selector = selectorList.item(i);
            if (CSSStyleSheet.selects(browserVersion, selector, child))
            {
              elements.add(child);
              break;
            }
          }
        }
      }
    }
    catch (IOException e)
    {
      SelectorList selectorList;
      BrowserVersion browserVersion;
      throw new CSSException("Error parsing CSS selectors from '" + selectors + "': " + e.getMessage());
    }
    return new StaticDomNodeList(elements);
  }
  
  public DomNode querySelector(String selectors)
  {
    DomNodeList<DomNode> list = querySelectorAll(selectors);
    if (!list.isEmpty()) {
      return (DomNode)list.get(0);
    }
    return null;
  }
  
  protected boolean isDirectlyAttachedToPage()
  {
    return this.directlyAttachedToPage_;
  }
  
  public void processImportNode(com.gargoylesoftware.htmlunit.javascript.host.Document doc) {}
  
  protected boolean hasFeature(BrowserVersionFeatures feature)
  {
    return getPage().getWebClient().getBrowserVersion().hasFeature(feature);
  }
  
  protected boolean isDescendant(DomNode node)
  {
    for (DomNode parent = node; parent != null; parent = parent.getParentNode()) {
      if (parent == this) {
        return true;
      }
    }
    return false;
  }
}
