package com.google.gwt.core.client;

import com.google.gwt.core.client.impl.SchedulerImpl;

public abstract class Scheduler
{
  public static Scheduler get()
  {
    return SchedulerImpl.INSTANCE;
  }
  
  public abstract void scheduleDeferred(ScheduledCommand paramScheduledCommand);
  
  public abstract void scheduleEntry(RepeatingCommand paramRepeatingCommand);
  
  public abstract void scheduleEntry(ScheduledCommand paramScheduledCommand);
  
  public abstract void scheduleFinally(RepeatingCommand paramRepeatingCommand);
  
  public abstract void scheduleFinally(ScheduledCommand paramScheduledCommand);
  
  public abstract void scheduleFixedDelay(RepeatingCommand paramRepeatingCommand, int paramInt);
  
  public abstract void scheduleFixedPeriod(RepeatingCommand paramRepeatingCommand, int paramInt);
  
  public abstract void scheduleIncremental(RepeatingCommand paramRepeatingCommand);
  
  public static abstract interface ScheduledCommand
  {
    public abstract void execute();
  }
  
  public static abstract interface RepeatingCommand
  {
    public abstract boolean execute();
  }
}
