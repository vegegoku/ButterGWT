package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
import java.util.Map;

public class HtmlIsIndex
  extends HtmlElement
  implements SubmittableElement
{
  public static final String TAG_NAME = "isindex";
  private String value_ = "";
  
  HtmlIsIndex(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public void setValue(String newValue)
  {
    WebAssert.notNull("newValue", newValue);
    this.value_ = newValue;
  }
  
  public String getValue()
  {
    return this.value_;
  }
  
  public NameValuePair[] getSubmitKeyValuePairs()
  {
    return new NameValuePair[] { new NameValuePair(getPromptAttribute(), getValue()) };
  }
  
  public void reset()
  {
    this.value_ = "";
  }
  
  public void setDefaultValue(String defaultValue) {}
  
  public String getDefaultValue()
  {
    return "";
  }
  
  public void setDefaultChecked(boolean defaultChecked) {}
  
  public boolean isDefaultChecked()
  {
    return false;
  }
  
  public final String getPromptAttribute()
  {
    return getAttribute("prompt");
  }
}
