package com.google.gwt.core.client;

public class JsDate
  extends JavaScriptObject
{
  public static native JsDate create();
  
  public static native JsDate create(double paramDouble);
  
  public static native JsDate create(int paramInt1, int paramInt2);
  
  public static native JsDate create(int paramInt1, int paramInt2, int paramInt3);
  
  public static native JsDate create(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public static native JsDate create(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  public static native JsDate create(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  public static native JsDate create(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public static native JsDate create(String paramString);
  
  public static native double parse(String paramString);
  
  public static native double UTC(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7);
  
  public final native int getDate();
  
  public final native int getDay();
  
  public final native int getFullYear();
  
  public final native int getHours();
  
  public final native int getMilliseconds();
  
  public final native int getMinutes();
  
  public final native int getMonth();
  
  public final native int getSeconds();
  
  public final native double getTime();
  
  public final native int getTimezoneOffset();
  
  public final native int getUTCDate();
  
  public final native int getUTCDay();
  
  public final native int getUTCFullYear();
  
  public final native int getUTCHours();
  
  public final native int getUTCMilliseconds();
  
  public final native int getUTCMinutes();
  
  public final native int getUTCMonth();
  
  public final native int getUTCSeconds();
  
  @Deprecated
  public final native int getYear();
  
  public final native double setDate(int paramInt);
  
  public final native double setFullYear(int paramInt);
  
  public final native double setFullYear(int paramInt1, int paramInt2);
  
  public final native double setFullYear(int paramInt1, int paramInt2, int paramInt3);
  
  public final native double setHours(int paramInt);
  
  public final native double setHours(int paramInt1, int paramInt2);
  
  public final native double setHours(int paramInt1, int paramInt2, int paramInt3);
  
  public final native double setHours(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public final native double setMinutes(int paramInt);
  
  public final native double setMinutes(int paramInt1, int paramInt2);
  
  public final native double setMinutes(int paramInt1, int paramInt2, int paramInt3);
  
  public final native double setMonth(int paramInt);
  
  public final native double setMonth(int paramInt1, int paramInt2);
  
  public final native double setSeconds(int paramInt);
  
  public final native double setSeconds(int paramInt1, int paramInt2);
  
  public final native double setTime(double paramDouble);
  
  public final native double setUTCDate(int paramInt);
  
  public final native double setUTCFullYear(int paramInt);
  
  public final native double setUTCFullYear(int paramInt1, int paramInt2);
  
  public final native double setUTCFullYear(int paramInt1, int paramInt2, int paramInt3);
  
  public final native double setUTCHours(int paramInt);
  
  public final native double setUTCHours(int paramInt1, int paramInt2);
  
  public final native double setUTCHours(int paramInt1, int paramInt2, int paramInt3);
  
  public final native double setUTCHours(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public final native double setUTCMinutes(int paramInt);
  
  public final native double setUTCMinutes(int paramInt1, int paramInt2);
  
  public final native double setUTCMinutes(int paramInt1, int paramInt2, int paramInt3);
  
  public final native double setUTCMonth(int paramInt);
  
  public final native double setUTCMonth(int paramInt1, int paramInt2);
  
  public final native double setUTCSeconds(int paramInt);
  
  public final native double setUTCSeconds(int paramInt1, int paramInt2);
  
  @Deprecated
  public final native double setYear(int paramInt);
  
  public final native String toDateString();
  
  @Deprecated
  public final native String toGMTString();
  
  public final native String toLocaleDateString();
  
  public final native String toLocaleString();
  
  public final native String toLocaleTimeString();
  
  public final native String toTimeString();
  
  public final native String toUTCString();
  
  public final native double valueOf();
}
