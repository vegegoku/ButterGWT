package com.google.gwt.aria.client;

public abstract interface StatusRole
  extends RegionRole
{}
