package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.impl.SelectableTextInput;
import com.gargoylesoftware.htmlunit.html.impl.SelectionDelegate;
import java.util.Map;

public class HtmlTextInput
  extends HtmlInput
  implements SelectableTextInput
{
  private final SelectionDelegate selectionDelegate_ = new SelectionDelegate(this);
  private final DoTypeProcessor doTypeProcessor_ = new DoTypeProcessor()
  {
    void typeDone(String newValue, int newCursorPosition)
    {
      if (newValue.length() > HtmlTextInput.this.getMaxLength()) {
        return;
      }
      HtmlTextInput.this.setAttribute("value", newValue);
      HtmlTextInput.this.setSelectionStart(newCursorPosition);
      HtmlTextInput.this.setSelectionEnd(newCursorPosition);
    }
  };
  
  HtmlTextInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  protected void doType(char c, boolean shiftKey, boolean ctrlKey, boolean altKey)
  {
    this.doTypeProcessor_.doType(getValueAttribute(), getSelectionStart(), getSelectionEnd(), c, shiftKey, ctrlKey, altKey);
  }
  
  protected boolean isSubmittableByEnter()
  {
    return true;
  }
  
  public void select()
  {
    this.selectionDelegate_.select();
  }
  
  public String getSelectedText()
  {
    return this.selectionDelegate_.getSelectedText();
  }
  
  public String getText()
  {
    return getValueAttribute();
  }
  
  public void setText(String text)
  {
    setValueAttribute(text);
  }
  
  public int getSelectionStart()
  {
    return this.selectionDelegate_.getSelectionStart();
  }
  
  public void setSelectionStart(int selectionStart)
  {
    this.selectionDelegate_.setSelectionStart(selectionStart);
  }
  
  public int getSelectionEnd()
  {
    return this.selectionDelegate_.getSelectionEnd();
  }
  
  public void setSelectionEnd(int selectionEnd)
  {
    this.selectionDelegate_.setSelectionEnd(selectionEnd);
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
    if ("value".equals(qualifiedName))
    {
      SgmlPage page = getPage();
      if ((page != null) && (page.isHtmlPage()))
      {
        setSelectionStart(attributeValue.length());
        setSelectionEnd(attributeValue.length());
      }
    }
  }
  
  protected Object clone()
    throws CloneNotSupportedException
  {
    return new HtmlTextInput(getNamespaceURI(), getQualifiedName(), getPage(), getAttributesMap());
  }
  
  public void setDefaultValue(String defaultValue)
  {
    boolean modifyValue = hasFeature(BrowserVersionFeatures.HTMLINPUT_SET_DEFAULT_VALUE_UPDATES_VALUE);
    modifyValue = (modifyValue) && (getValueAttribute().equals(getDefaultValue()));
    setDefaultValue(defaultValue, modifyValue);
  }
}
