package com.gargoylesoftware.htmlunit.javascript.host.dom;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLDocument;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
public class DOMParser
  extends SimpleScriptable
{
  @JsxConstructor
  public void jsConstructor() {}
  
  @JsxFunction
  public XMLDocument parseFromString(String str, String contentType)
  {
    XMLDocument document = new XMLDocument();
    document.setParentScope(getParentScope());
    document.setPrototype(getPrototype(XMLDocument.class));
    document.loadXML(str);
    return document;
  }
}
