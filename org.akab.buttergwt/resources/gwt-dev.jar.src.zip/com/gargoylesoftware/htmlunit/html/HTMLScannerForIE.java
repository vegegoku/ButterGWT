package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import java.io.IOException;
import org.apache.commons.lang3.StringUtils;
import org.apache.xerces.util.XMLStringBuffer;
import org.apache.xerces.xni.XMLDocumentHandler;
import org.cyberneko.html.HTMLScanner;
import org.cyberneko.html.HTMLScanner.ContentScanner;

class HTMLScannerForIE
  extends HTMLScanner
{
  HTMLScannerForIE(BrowserVersion browserVersion)
  {
    this.fContentScanner = new ContentScannerForIE(browserVersion);
  }
  
  class ContentScannerForIE
    extends HTMLScanner.ContentScanner
  {
    private final BrowserVersion browserVersion_;
    
    ContentScannerForIE(BrowserVersion browserVersion)
    {
      super();
      this.browserVersion_ = browserVersion;
    }
    
    protected void scanComment()
      throws IOException
    {
      String s = nextContent(30);
      if ((s.startsWith("[if ")) && (s.contains("]>")))
      {
        String condition = StringUtils.substringBefore(s.substring(4), "]>");
        try
        {
          if (IEConditionalCommentExpressionEvaluator.evaluate(condition, this.browserVersion_))
          {
            for (int i = 0; i < condition.length() + 6; i++) {
              HTMLScannerForIE.this.read();
            }
            if (s.contains("]><!-->")) {
              HTMLScannerForIE.this.skip("<!-->", false);
            } else if (s.contains("]>-->")) {
              HTMLScannerForIE.this.skip("-->", false);
            }
          }
          else
          {
            StringBuilder builder = new StringBuilder();
            while (!builder.toString().endsWith("-->")) {
              builder.append((char)HTMLScannerForIE.this.read());
            }
          }
          return;
        }
        catch (Exception e)
        {
          XMLStringBuffer buffer = new XMLStringBuffer("<!--");
          scanMarkupContent(buffer, '-');
          buffer.append("-->");
          HTMLScannerForIE.this.fDocumentHandler.characters(buffer, HTMLScannerForIE.this.locationAugs());
          return;
        }
      }
      super.scanComment();
    }
    
    public String nextContent(int len)
      throws IOException
    {
      return super.nextContent(len);
    }
    
    public boolean scanMarkupContent(XMLStringBuffer buffer, char cend)
      throws IOException
    {
      return super.scanMarkupContent(buffer, cend);
    }
  }
  
  protected boolean skipMarkup(boolean balance)
    throws IOException
  {
    ContentScannerForIE contentScanner = (ContentScannerForIE)this.fContentScanner;
    String s = contentScanner.nextContent(30);
    if ((s.startsWith("[if ")) && (s.contains("]>")))
    {
      String condition = StringUtils.substringBefore(s.substring(4), "]>");
      try
      {
        if (IEConditionalCommentExpressionEvaluator.evaluate(condition, contentScanner.browserVersion_))
        {
          for (int i = 0; i < condition.length() + 6; i++) {
            read();
          }
          return true;
        }
        XMLStringBuffer buffer = new XMLStringBuffer();
        int ch;
        while ((ch = read()) != -1)
        {
          buffer.append((char)ch);
          if (buffer.toString().endsWith("<![endif]>"))
          {
            XMLStringBuffer trimmedBuffer = new XMLStringBuffer(buffer.ch, 0, buffer.length - 3);
            
            this.fDocumentHandler.comment(trimmedBuffer, locationAugs());
            return true;
          }
        }
      }
      catch (Exception e)
      {
        XMLStringBuffer buffer = new XMLStringBuffer("<!--");
        contentScanner.scanMarkupContent(buffer, '-');
        buffer.append("-->");
        this.fDocumentHandler.characters(buffer, locationAugs());
        return true;
      }
    }
    return super.skipMarkup(balance);
  }
}
