package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;

public class CrossSiteLoadingStrategy
  implements AsyncFragmentLoader.LoadingStrategy
{
  private static native void clearCallbacks(JavaScriptObject paramJavaScriptObject);
  
  private static native void clearOnSuccess(int paramInt);
  
  private static native JavaScriptObject createScriptTag(String paramString);
  
  private static native void installScriptTag(JavaScriptObject paramJavaScriptObject);
  
  private static native JavaScriptObject removeTagAndCallErrorHandler(int paramInt, JavaScriptObject paramJavaScriptObject, AsyncFragmentLoader.LoadTerminatedHandler paramLoadTerminatedHandler);
  
  private static native JavaScriptObject removeTagAndEvalCode(int paramInt, JavaScriptObject paramJavaScriptObject);
  
  private static native void setOnFailure(JavaScriptObject paramJavaScriptObject1, JavaScriptObject paramJavaScriptObject2);
  
  private static native void setOnSuccess(int paramInt, JavaScriptObject paramJavaScriptObject);
  
  private static final class IntToIntMap
    extends JavaScriptObject
  {
    public static IntToIntMap create()
    {
      return (IntToIntMap)JavaScriptObject.createArray();
    }
    
    public native int get(int paramInt);
    
    public native void put(int paramInt1, int paramInt2);
  }
  
  private static RuntimeException LoadTerminated = new RuntimeException("Code download terminated");
  private final IntToIntMap serialNumbers = IntToIntMap.create();
  
  public void startLoadingFragment(int fragment, AsyncFragmentLoader.LoadTerminatedHandler loadFinishedHandler)
  {
    JavaScriptObject tag = createScriptTag(getUrl(fragment));
    setOnSuccess(fragment, removeTagAndEvalCode(fragment, tag));
    setOnFailure(tag, removeTagAndCallErrorHandler(fragment, tag, loadFinishedHandler));
    
    installScriptTag(tag);
  }
  
  protected String getDeferredJavaScriptDirectory()
  {
    return "deferredjs/";
  }
  
  private int getSerial(int fragment)
  {
    int ser = this.serialNumbers.get(fragment);
    this.serialNumbers.put(fragment, ser + 1);
    return ser;
  }
  
  private String getUrl(int fragment)
  {
    return GWT.getModuleBaseURL() + getDeferredJavaScriptDirectory() + GWT.getPermutationStrongName() + "/" + fragment + ".cache.js?serial=" + getSerial(fragment);
  }
}
