package org.aopalliance.aop;

public abstract interface Advice {}
