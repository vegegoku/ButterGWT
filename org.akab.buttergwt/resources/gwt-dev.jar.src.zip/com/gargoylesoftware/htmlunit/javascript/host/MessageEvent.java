package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass
public class MessageEvent
  extends Event
{
  private Object data_;
  
  public MessageEvent() {}
  
  public MessageEvent(Object data)
  {
    this.data_ = data;
    setType("message");
  }
  
  @JsxGetter
  public Object getData()
  {
    return this.data_;
  }
}
