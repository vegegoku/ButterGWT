package com.google.gwt.aria.client;

public enum GrabbedValue
  implements AriaAttributeType
{
  TRUE,  FALSE,  UNDEFINED;
  
  private GrabbedValue() {}
  
  public static GrabbedValue of(boolean value)
  {
    return value ? TRUE : FALSE;
  }
  
  public String getAriaValue()
  {
    switch (this)
    {
    case TRUE: 
      return "true";
    case FALSE: 
      return "false";
    case UNDEFINED: 
      return "undefined";
    }
    return null;
  }
}
