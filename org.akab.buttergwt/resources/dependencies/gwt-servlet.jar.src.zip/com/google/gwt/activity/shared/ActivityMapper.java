package com.google.gwt.activity.shared;

import com.google.gwt.place.shared.Place;

public abstract interface ActivityMapper
{
  public abstract Activity getActivity(Place paramPlace);
}
