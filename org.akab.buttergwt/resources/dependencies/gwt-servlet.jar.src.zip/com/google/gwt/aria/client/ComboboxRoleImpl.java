package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class ComboboxRoleImpl
  extends RoleImpl
  implements ComboboxRole
{
  ComboboxRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaActivedescendantProperty(Element element)
  {
    return Property.ACTIVEDESCENDANT.get(element);
  }
  
  public String getAriaAutocompleteProperty(Element element)
  {
    return Property.AUTOCOMPLETE.get(element);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaRequiredProperty(Element element)
  {
    return Property.REQUIRED.get(element);
  }
  
  public void removeAriaActivedescendantProperty(Element element)
  {
    Property.ACTIVEDESCENDANT.remove(element);
  }
  
  public void removeAriaAutocompleteProperty(Element element)
  {
    Property.AUTOCOMPLETE.remove(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaRequiredProperty(Element element)
  {
    Property.REQUIRED.remove(element);
  }
  
  public void setAriaActivedescendantProperty(Element element, Id value)
  {
    Property.ACTIVEDESCENDANT.set(element, new Id[] { value });
  }
  
  public void setAriaAutocompleteProperty(Element element, AutocompleteValue value)
  {
    Property.AUTOCOMPLETE.set(element, new AutocompleteValue[] { value });
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaRequiredProperty(Element element, boolean value)
  {
    Property.REQUIRED.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
}
