package com.google.gwt.debug.client;

import com.google.gwt.core.client.GWT;

public class DebugInfo
{
  public static final String DEFAULT_DEBUG_ID_PREFIX = "gwt-debug-";
  
  private static class DebugInfoImpl
  {
    private String debugIdPrefix = "gwt-debug-";
    private String debugIdAttribute = "id";
    private boolean debugIdAsProperty = true;
    
    public String getDebugIdAttribute()
    {
      return this.debugIdAttribute;
    }
    
    public String getDebugIdPrefix()
    {
      return this.debugIdPrefix;
    }
    
    public boolean isDebugIdAsProperty()
    {
      return this.debugIdAsProperty;
    }
    
    public boolean isDebugIdEnabled()
    {
      return false;
    }
    
    public void setDebugIdAttribute(String attribute, boolean asProperty)
    {
      this.debugIdAttribute = attribute;
      this.debugIdAsProperty = asProperty;
    }
    
    public void setDebugIdPrefix(String prefix)
    {
      this.debugIdPrefix = prefix;
    }
  }
  
  private static class DebugInfoImplEnabled
    extends DebugInfo.DebugInfoImpl
  {
    private DebugInfoImplEnabled()
    {
      super();
    }
    
    public boolean isDebugIdEnabled()
    {
      return true;
    }
  }
  
  private static DebugInfoImpl impl = (DebugInfoImpl)GWT.create(DebugInfoImpl.class);
  
  public static String getDebugIdAttribute()
  {
    return impl.getDebugIdAttribute();
  }
  
  public static String getDebugIdPrefix()
  {
    return impl.getDebugIdPrefix();
  }
  
  public static boolean isDebugIdAsProperty()
  {
    return impl.isDebugIdAsProperty();
  }
  
  public static boolean isDebugIdEnabled()
  {
    return impl.isDebugIdEnabled();
  }
  
  public static void setDebugIdAttribute(String attribute, boolean asProperty)
  {
    impl.setDebugIdAttribute(attribute, asProperty);
  }
  
  public static void setDebugIdPrefix(String prefix)
  {
    impl.setDebugIdPrefix(prefix);
  }
}
