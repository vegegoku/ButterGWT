package com.gargoylesoftware.htmlunit.html;

import java.io.Serializable;

abstract class DoTypeProcessor
  implements Serializable
{
  void doType(String currentValue, int selectionStart, int selectionEnd, char c, boolean shiftKey, boolean ctrlKey, boolean altKey)
  {
    StringBuilder newValue = new StringBuilder(currentValue);
    int cursorPosition = selectionStart;
    if (c == '\b')
    {
      if (selectionStart > 0)
      {
        newValue.deleteCharAt(selectionStart - 1);
        cursorPosition = selectionStart - 1;
      }
    }
    else if ((c < 57344) || (c > 63743)) {
      if (acceptChar(c))
      {
        if (selectionStart != currentValue.length()) {
          newValue.replace(selectionStart, selectionEnd, Character.toString(c));
        } else {
          newValue.append(c);
        }
        cursorPosition++;
      }
    }
    typeDone(newValue.toString(), cursorPosition);
  }
  
  protected boolean acceptChar(char c)
  {
    return (c == ' ') || (!Character.isWhitespace(c));
  }
  
  abstract void typeDone(String paramString, int paramInt);
}
