package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.util.ArrayList;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass
public class CSSRuleList
  extends SimpleScriptable
{
  private final CSSStyleSheet stylesheet_;
  private final org.w3c.dom.css.CSSRuleList rules_;
  
  @Deprecated
  public CSSRuleList()
  {
    this.stylesheet_ = null;
    this.rules_ = null;
  }
  
  public CSSRuleList(CSSStyleSheet stylesheet)
  {
    this.stylesheet_ = stylesheet;
    this.rules_ = stylesheet.getWrappedSheet().getCssRules();
    setParentScope(stylesheet.getParentScope());
    setPrototype(getPrototype(getClass()));
  }
  
  @JsxGetter
  public int getLength()
  {
    if (this.rules_ != null) {
      return this.rules_.getLength();
    }
    return 0;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object item(int index)
  {
    return null;
  }
  
  public Object[] getIds()
  {
    List<String> idList = new ArrayList();
    
    int length = getLength();
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_21))
    {
      for (int i = 0; i < length; i++) {
        idList.add(Integer.toString(i));
      }
      idList.add("length");
      idList.add("item");
    }
    else
    {
      idList.add("length");
      for (int i = 0; i < length; i++) {
        idList.add(Integer.toString(i));
      }
    }
    return idList.toArray();
  }
  
  public boolean has(int index, Scriptable start)
  {
    return (index >= 0) && (index < getLength());
  }
  
  public boolean has(String name, Scriptable start)
  {
    if (("length".equals(name)) || ("item".equals(name))) {
      return true;
    }
    try
    {
      return has(Integer.parseInt(name), start);
    }
    catch (Exception e) {}
    return false;
  }
  
  public Object get(int index, Scriptable start)
  {
    if ((index < 0) || (getLength() <= index)) {
      return NOT_FOUND;
    }
    return CSSRule.create(this.stylesheet_, this.rules_.item(index));
  }
}
