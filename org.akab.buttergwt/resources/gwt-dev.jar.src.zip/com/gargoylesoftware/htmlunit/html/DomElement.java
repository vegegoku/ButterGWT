package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.util.StringUtils;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.NoSuchElementException;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.ElementTraversal;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.TypeInfo;

public class DomElement
  extends DomNamespaceNode
  implements Element, ElementTraversal
{
  public static final String ATTRIBUTE_NOT_DEFINED = new String("");
  public static final String ATTRIBUTE_VALUE_EMPTY = new String();
  private NamedAttrNodeMapImpl attributes_ = new NamedAttrNodeMapImpl(this, isAttributeCaseSensitive());
  private Map<String, String> namespaces_ = new HashMap();
  
  public DomElement(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page);
    if ((attributes != null) && (!attributes.isEmpty()))
    {
      this.attributes_ = new NamedAttrNodeMapImpl(this, isAttributeCaseSensitive(), attributes);
      for (DomAttr entry : this.attributes_.values())
      {
        entry.setParentNode(this);
        String attrNamespaceURI = entry.getNamespaceURI();
        if (attrNamespaceURI != null) {
          this.namespaces_.put(attrNamespaceURI, entry.getPrefix());
        }
      }
    }
  }
  
  public String getNodeName()
  {
    return getQualifiedName();
  }
  
  public final short getNodeType()
  {
    return 1;
  }
  
  protected Map<String, String> namespaces()
  {
    return this.namespaces_;
  }
  
  public final String getTagName()
  {
    return getNodeName();
  }
  
  public final boolean hasAttributes()
  {
    return !this.attributes_.isEmpty();
  }
  
  public boolean hasAttribute(String attributeName)
  {
    return this.attributes_.containsKey(attributeName);
  }
  
  protected void printOpeningTagContentAsXml(PrintWriter printWriter)
  {
    printWriter.print(getTagName());
    for (Map.Entry<String, DomAttr> entry : this.attributes_.entrySet())
    {
      printWriter.print(" ");
      printWriter.print((String)entry.getKey());
      printWriter.print("=\"");
      printWriter.print(StringUtils.escapeXmlAttributeValue(((DomAttr)entry.getValue()).getNodeValue()));
      printWriter.print("\"");
    }
  }
  
  protected void printXml(String indent, PrintWriter printWriter)
  {
    boolean hasChildren = getFirstChild() != null;
    printWriter.print(indent + "<");
    printOpeningTagContentAsXml(printWriter);
    if ((!hasChildren) && (!isEmptyXmlTagExpanded()))
    {
      printWriter.println("/>");
    }
    else
    {
      printWriter.println(">");
      printChildrenAsXml(indent, printWriter);
      printWriter.println(indent + "</" + getTagName() + ">");
    }
  }
  
  protected boolean isEmptyXmlTagExpanded()
  {
    return false;
  }
  
  String getQualifiedName(String namespaceURI, String localName)
  {
    String qualifiedName;
    String qualifiedName;
    if (namespaceURI != null)
    {
      String prefix = (String)namespaces().get(namespaceURI);
      String qualifiedName;
      if (prefix != null) {
        qualifiedName = prefix + ':' + localName;
      } else {
        qualifiedName = null;
      }
    }
    else
    {
      qualifiedName = localName;
    }
    return qualifiedName;
  }
  
  public String getAttribute(String attributeName)
  {
    DomAttr attr = this.attributes_.get(attributeName);
    if (attr != null) {
      return attr.getNodeValue();
    }
    return ATTRIBUTE_NOT_DEFINED;
  }
  
  public void removeAttribute(String attributeName)
  {
    this.attributes_.remove(attributeName);
  }
  
  public final void removeAttributeNS(String namespaceURI, String localName)
  {
    String qualifiedName = getQualifiedName(namespaceURI, localName);
    if (qualifiedName != null) {
      removeAttribute(qualifiedName);
    }
  }
  
  public final Attr removeAttributeNode(Attr attribute)
  {
    throw new UnsupportedOperationException("DomElement.removeAttributeNode is not yet implemented.");
  }
  
  public final boolean hasAttributeNS(String namespaceURI, String localName)
  {
    String qualifiedName = getQualifiedName(namespaceURI, localName);
    if (qualifiedName != null) {
      return this.attributes_.get(qualifiedName) != null;
    }
    return false;
  }
  
  public final Map<String, DomAttr> getAttributesMap()
  {
    return this.attributes_;
  }
  
  public NamedNodeMap getAttributes()
  {
    return this.attributes_;
  }
  
  public final void setAttribute(String attributeName, String attributeValue)
  {
    setAttributeNS(null, attributeName, attributeValue);
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    String value = attributeValue;
    DomAttr newAttr = new DomAttr(getPage(), namespaceURI, qualifiedName, value, true);
    newAttr.setParentNode(this);
    this.attributes_.put(qualifiedName, newAttr);
    if (namespaceURI != null) {
      namespaces().put(namespaceURI, newAttr.getPrefix());
    }
  }
  
  protected boolean isAttributeCaseSensitive()
  {
    return true;
  }
  
  public final String getAttributeNS(String namespaceURI, String localName)
  {
    String qualifiedName = getQualifiedName(namespaceURI, localName);
    if (qualifiedName != null) {
      return getAttribute(qualifiedName);
    }
    return ATTRIBUTE_NOT_DEFINED;
  }
  
  public DomAttr getAttributeNode(String name)
  {
    return this.attributes_.get(name);
  }
  
  public DomAttr getAttributeNodeNS(String namespaceURI, String localName)
  {
    String qualifiedName = getQualifiedName(namespaceURI, localName);
    if (qualifiedName != null) {
      return this.attributes_.get(qualifiedName);
    }
    return null;
  }
  
  public DomNodeList<HtmlElement> getElementsByTagName(String tagName)
  {
    return new XPathDomNodeList(this, ".//*[local-name()='" + tagName + "']");
  }
  
  public DomNodeList<HtmlElement> getElementsByTagNameNS(String namespace, String localName)
  {
    throw new UnsupportedOperationException("DomElement.getElementsByTagNameNS is not yet implemented.");
  }
  
  public TypeInfo getSchemaTypeInfo()
  {
    throw new UnsupportedOperationException("DomElement.getSchemaTypeInfo is not yet implemented.");
  }
  
  public void setIdAttribute(String name, boolean isId)
  {
    throw new UnsupportedOperationException("DomElement.setIdAttribute is not yet implemented.");
  }
  
  public void setIdAttributeNS(String namespaceURI, String localName, boolean isId)
  {
    throw new UnsupportedOperationException("DomElement.setIdAttributeNS is not yet implemented.");
  }
  
  public Attr setAttributeNode(Attr attribute)
  {
    this.attributes_.setNamedItem(attribute);
    return null;
  }
  
  public Attr setAttributeNodeNS(Attr attribute)
  {
    throw new UnsupportedOperationException("DomElement.setAttributeNodeNS is not yet implemented.");
  }
  
  public final void setIdAttributeNode(Attr idAttr, boolean isId)
  {
    throw new UnsupportedOperationException("DomElement.setIdAttributeNode is not yet implemented.");
  }
  
  public DomNode cloneNode(boolean deep)
  {
    DomElement clone = (DomElement)super.cloneNode(deep);
    clone.attributes_ = new NamedAttrNodeMapImpl(clone, isAttributeCaseSensitive());
    clone.attributes_.putAll(this.attributes_);
    return clone;
  }
  
  public final String getId()
  {
    return getAttribute("id");
  }
  
  public DomElement getFirstElementChild()
  {
    Iterator<DomElement> i = getChildElements().iterator();
    if (i.hasNext()) {
      return (DomElement)i.next();
    }
    return null;
  }
  
  public DomElement getLastElementChild()
  {
    DomElement lastChild = null;
    Iterator<DomElement> i = getChildElements().iterator();
    while (i.hasNext()) {
      lastChild = (DomElement)i.next();
    }
    return lastChild;
  }
  
  public DomElement getPreviousElementSibling()
  {
    DomNode node = getPreviousSibling();
    while ((node != null) && (!(node instanceof DomElement))) {
      node = node.getPreviousSibling();
    }
    return (DomElement)node;
  }
  
  public DomElement getNextElementSibling()
  {
    DomNode node = getNextSibling();
    while ((node != null) && (!(node instanceof DomElement))) {
      node = node.getNextSibling();
    }
    return (DomElement)node;
  }
  
  public int getChildElementCount()
  {
    int counter = 0;
    Iterator<DomElement> i = getChildElements().iterator();
    while (i.hasNext())
    {
      i.next();
      counter++;
    }
    return counter;
  }
  
  public final Iterable<DomElement> getChildElements()
  {
    new Iterable()
    {
      public Iterator<DomElement> iterator()
      {
        return new DomElement.ChildElementsIterator(DomElement.this);
      }
    };
  }
  
  protected class ChildElementsIterator
    implements Iterator<DomElement>
  {
    private DomElement nextElement_;
    
    protected ChildElementsIterator()
    {
      DomNode child = DomElement.this.getFirstChild();
      if (child != null) {
        if ((child instanceof DomElement)) {
          this.nextElement_ = ((DomElement)child);
        } else {
          setNextElement(child);
        }
      }
    }
    
    public boolean hasNext()
    {
      return this.nextElement_ != null;
    }
    
    public DomElement next()
    {
      return nextElement();
    }
    
    public void remove()
    {
      if (this.nextElement_ == null) {
        throw new IllegalStateException();
      }
      DomNode sibling = this.nextElement_.getPreviousSibling();
      if (sibling != null) {
        sibling.remove();
      }
    }
    
    public DomElement nextElement()
    {
      if (this.nextElement_ != null)
      {
        DomElement result = this.nextElement_;
        setNextElement(this.nextElement_);
        return result;
      }
      throw new NoSuchElementException();
    }
    
    private void setNextElement(DomNode node)
    {
      DomNode next = node.getNextSibling();
      while ((next != null) && (!(next instanceof HtmlElement))) {
        next = next.getNextSibling();
      }
      this.nextElement_ = ((DomElement)next);
    }
  }
}
