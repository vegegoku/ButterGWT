package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.javascript.PostponedAction;
import com.gargoylesoftware.htmlunit.javascript.host.Event;
import com.gargoylesoftware.htmlunit.javascript.host.Node;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import javax.imageio.ImageIO;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class HtmlImage
  extends HtmlElement
{
  private static final Log LOG = LogFactory.getLog(HtmlImage.class);
  public static final String TAG_NAME = "img";
  private int lastClickX_;
  private int lastClickY_;
  private WebResponse imageWebResponse_;
  private ImageReader imageReader_;
  private boolean downloaded_;
  private boolean onloadInvoked_;
  
  HtmlImage(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  protected void onAddedToPage()
  {
    doOnLoad();
    super.onAddedToPage();
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String value)
  {
    HtmlPage htmlPage = getHtmlPageOrNull();
    if (("src".equals(qualifiedName)) && (value != ATTRIBUTE_NOT_DEFINED) && (htmlPage != null))
    {
      String oldValue = getAttributeNS(namespaceURI, qualifiedName);
      if (!oldValue.equals(value))
      {
        super.setAttributeNS(namespaceURI, qualifiedName, value);
        
        this.onloadInvoked_ = false;
        this.downloaded_ = false;
        
        String readyState = htmlPage.getReadyState();
        if ("loading".equals(readyState))
        {
          PostponedAction action = new PostponedAction(getPage())
          {
            public void execute()
              throws Exception
            {
              HtmlImage.this.doOnLoad();
            }
          };
          htmlPage.addAfterLoadAction(action);
          return;
        }
        doOnLoad();
        return;
      }
    }
    super.setAttributeNS(namespaceURI, qualifiedName, value);
  }
  
  public void doOnLoad()
  {
    if (this.onloadInvoked_) {
      return;
    }
    HtmlPage htmlPage = getHtmlPageOrNull();
    if (htmlPage == null) {
      return;
    }
    WebClient client = htmlPage.getWebClient();
    if (!client.getOptions().isJavaScriptEnabled())
    {
      this.onloadInvoked_ = true;
      return;
    }
    if ((hasEventHandlers("onload")) && (getSrcAttribute().length() > 0))
    {
      this.onloadInvoked_ = true;
      boolean ok;
      try
      {
        downloadImageIfNeeded();
        int i = this.imageWebResponse_.getStatusCode();
        ok = ((i >= 200) && (i < 300)) || (i == 305);
      }
      catch (IOException e)
      {
        ok = false;
      }
      if (ok)
      {
        final Event event = new Event(this, "load");
        final Node scriptObject = (Node)getScriptObject();
        
        String readyState = htmlPage.getReadyState();
        if ("loading".equals(readyState))
        {
          PostponedAction action = new PostponedAction(getPage())
          {
            public void execute()
              throws Exception
            {
              scriptObject.executeEvent(event);
            }
          };
          htmlPage.addAfterLoadAction(action);
        }
        else
        {
          scriptObject.executeEvent(event);
        }
      }
      else if (LOG.isDebugEnabled())
      {
        LOG.debug("Unable to download image for tag " + this + "; not firing onload event.");
      }
    }
  }
  
  public final String getSrcAttribute()
  {
    return getAttribute("src");
  }
  
  public final String getAltAttribute()
  {
    return getAttribute("alt");
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final String getLongDescAttribute()
  {
    return getAttribute("longdesc");
  }
  
  public final String getHeightAttribute()
  {
    return getAttribute("height");
  }
  
  public final String getWidthAttribute()
  {
    return getAttribute("width");
  }
  
  public final String getUseMapAttribute()
  {
    return getAttribute("usemap");
  }
  
  public final String getIsmapAttribute()
  {
    return getAttribute("ismap");
  }
  
  public final String getAlignAttribute()
  {
    return getAttribute("align");
  }
  
  public final String getBorderAttribute()
  {
    return getAttribute("border");
  }
  
  public final String getHspaceAttribute()
  {
    return getAttribute("hspace");
  }
  
  public final String getVspaceAttribute()
  {
    return getAttribute("vspace");
  }
  
  public int getHeight()
    throws IOException
  {
    readImageIfNeeded();
    return this.imageReader_.getHeight(0);
  }
  
  public int getWidth()
    throws IOException
  {
    readImageIfNeeded();
    return this.imageReader_.getWidth(0);
  }
  
  public ImageReader getImageReader()
    throws IOException
  {
    readImageIfNeeded();
    return this.imageReader_;
  }
  
  public WebResponse getWebResponse(boolean downloadIfNeeded)
    throws IOException
  {
    if (downloadIfNeeded) {
      downloadImageIfNeeded();
    }
    return this.imageWebResponse_;
  }
  
  private void downloadImageIfNeeded()
    throws IOException
  {
    if (!this.downloaded_)
    {
      HtmlPage page = (HtmlPage)getPage();
      WebClient webclient = page.getWebClient();
      
      URL url = page.getFullyQualifiedUrl(getSrcAttribute());
      String accept = getPage().getWebClient().getBrowserVersion().getImgAcceptHeader();
      WebRequest request = new WebRequest(url, accept);
      request.setAdditionalHeader("Referer", page.getUrl().toExternalForm());
      this.imageWebResponse_ = webclient.loadWebResponse(request);
      this.imageReader_ = null;
      this.downloaded_ = true;
    }
  }
  
  private void readImageIfNeeded()
    throws IOException
  {
    downloadImageIfNeeded();
    if (this.imageReader_ == null)
    {
      ImageInputStream iis = ImageIO.createImageInputStream(this.imageWebResponse_.getContentAsStream());
      Iterator<ImageReader> iter = ImageIO.getImageReaders(iis);
      if (!iter.hasNext())
      {
        iis.close();
        throw new IOException("No image detected in response");
      }
      this.imageReader_ = ((ImageReader)iter.next());
      this.imageReader_.setInput(iis);
    }
  }
  
  public Page click(int x, int y)
    throws IOException
  {
    this.lastClickX_ = x;
    this.lastClickY_ = y;
    return super.click();
  }
  
  public Page click()
    throws IOException
  {
    return click(0, 0);
  }
  
  protected boolean doClickStateUpdate()
    throws IOException
  {
    if (getUseMapAttribute() != ATTRIBUTE_NOT_DEFINED)
    {
      String mapName = getUseMapAttribute().substring(1);
      HtmlElement doc = ((HtmlPage)getPage()).getDocumentElement();
      HtmlMap map = (HtmlMap)doc.getOneHtmlElementByAttribute("map", "name", mapName);
      for (DomElement element : map.getChildElements()) {
        if ((element instanceof HtmlArea))
        {
          HtmlArea area = (HtmlArea)element;
          if (area.containsPoint(this.lastClickX_, this.lastClickY_))
          {
            area.doClickStateUpdate();
            return false;
          }
        }
      }
    }
    HtmlAnchor anchor = (HtmlAnchor)getEnclosingElement("a");
    if (anchor == null) {
      return false;
    }
    if (getIsmapAttribute() != ATTRIBUTE_NOT_DEFINED)
    {
      String suffix = "?" + this.lastClickX_ + "," + this.lastClickY_;
      anchor.doClickStateUpdate(suffix);
      return false;
    }
    anchor.doClickStateUpdate();
    return false;
  }
  
  public void saveAs(File file)
    throws IOException
  {
    ImageReader reader = getImageReader();
    ImageIO.write(reader.read(0), reader.getFormatName(), file);
  }
  
  protected void finalize()
  {
    if (this.imageReader_ != null) {
      try
      {
        ImageInputStream stream = (ImageInputStream)this.imageReader_.getInput();
        if (stream != null) {
          stream.close();
        }
        this.imageReader_.setInput(null);
        this.imageReader_.dispose();
      }
      catch (IOException e)
      {
        LOG.error(e.getMessage(), e);
      }
    }
  }
}
