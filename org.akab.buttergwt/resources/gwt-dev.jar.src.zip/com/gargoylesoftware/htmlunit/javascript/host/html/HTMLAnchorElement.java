package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import java.net.MalformedURLException;
import java.net.URL;
import org.apache.commons.lang3.StringUtils;

@JsxClass(domClasses={HtmlAnchor.class})
public class HTMLAnchorElement
  extends HTMLElement
{
  @JsxSetter
  public void setHref(String href)
  {
    getDomNodeOrDie().setAttribute("href", href);
  }
  
  @JsxGetter
  public String getHref()
  {
    HtmlAnchor anchor = (HtmlAnchor)getDomNodeOrDie();
    String hrefAttr = anchor.getHrefAttribute();
    if (hrefAttr == DomElement.ATTRIBUTE_NOT_DEFINED) {
      return "";
    }
    try
    {
      return getUrl().toString();
    }
    catch (MalformedURLException e) {}
    return hrefAttr;
  }
  
  @JsxSetter
  public void setName(String name)
  {
    getDomNodeOrDie().setAttribute("name", name);
  }
  
  @JsxGetter
  public String getName()
  {
    return getDomNodeOrDie().getAttribute("name");
  }
  
  @JsxSetter
  public void setTarget(String target)
  {
    getDomNodeOrDie().setAttribute("target", target);
  }
  
  @JsxGetter
  public String getTarget()
  {
    return getDomNodeOrDie().getAttribute("target");
  }
  
  private URL getUrl()
    throws MalformedURLException
  {
    HtmlAnchor anchor = (HtmlAnchor)getDomNodeOrDie();
    return ((HtmlPage)anchor.getPage()).getFullyQualifiedUrl(anchor.getHrefAttribute());
  }
  
  private void setUrl(URL url)
  {
    getDomNodeOrDie().setAttribute("href", url.toString());
  }
  
  @JsxSetter
  public void setRel(String rel)
  {
    getDomNodeOrDie().setAttribute("rel", rel);
  }
  
  @JsxGetter
  public String getRel()
  {
    return ((HtmlAnchor)getDomNodeOrDie()).getRelAttribute();
  }
  
  @JsxSetter
  public void setRev(String rel)
  {
    getDomNodeOrDie().setAttribute("rev", rel);
  }
  
  @JsxGetter
  public String getRev()
  {
    return ((HtmlAnchor)getDomNodeOrDie()).getRevAttribute();
  }
  
  @JsxGetter
  public String getSearch()
    throws Exception
  {
    String query = getUrl().getQuery();
    if (query == null) {
      return "";
    }
    return "?" + query;
  }
  
  @JsxSetter
  public void setSearch(String search)
    throws Exception
  {
    String query;
    String query;
    if ((search == null) || ("?".equals(search)) || ("".equals(search)))
    {
      query = null;
    }
    else
    {
      String query;
      if (search.charAt(0) == '?') {
        query = search.substring(1);
      } else {
        query = search;
      }
    }
    setUrl(UrlUtils.getUrlWithNewQuery(getUrl(), query));
  }
  
  @JsxGetter
  public String getHash()
    throws Exception
  {
    String hash = getUrl().getRef();
    if (hash == null) {
      return "";
    }
    return "#" + hash;
  }
  
  @JsxSetter
  public void setHash(String hash)
    throws Exception
  {
    setUrl(UrlUtils.getUrlWithNewRef(getUrl(), hash));
  }
  
  @JsxGetter
  public String getHost()
    throws Exception
  {
    URL url = getUrl();
    int port = url.getPort();
    String host = url.getHost();
    if (port == -1) {
      return host;
    }
    return host + ":" + port;
  }
  
  @JsxSetter
  public void setHost(String host)
    throws Exception
  {
    int index = host.indexOf(':');
    int port;
    String hostname;
    int port;
    if (index != -1)
    {
      String hostname = host.substring(0, index);
      port = Integer.parseInt(host.substring(index + 1));
    }
    else
    {
      hostname = host;
      port = -1;
    }
    URL url = UrlUtils.getUrlWithNewHostAndPort(getUrl(), hostname, port);
    setUrl(url);
  }
  
  @JsxGetter
  public String getHostname()
    throws Exception
  {
    return getUrl().getHost();
  }
  
  @JsxSetter
  public void setHostname(String hostname)
    throws Exception
  {
    setUrl(UrlUtils.getUrlWithNewHost(getUrl(), hostname));
  }
  
  @JsxGetter
  public String getPathname()
    throws Exception
  {
    return getUrl().getPath();
  }
  
  @JsxSetter
  public void setPathname(String pathname)
    throws Exception
  {
    setUrl(UrlUtils.getUrlWithNewPath(getUrl(), pathname));
  }
  
  @JsxGetter
  public String getPort()
    throws Exception
  {
    int port = getUrl().getPort();
    if (port == -1) {
      return "";
    }
    return Integer.toString(port);
  }
  
  @JsxSetter
  public void setPort(String port)
    throws Exception
  {
    setUrl(UrlUtils.getUrlWithNewPort(getUrl(), Integer.parseInt(port)));
  }
  
  @JsxGetter
  public String getProtocol()
    throws Exception
  {
    return getUrl().getProtocol() + ":";
  }
  
  @JsxSetter
  public void setProtocol(String protocol)
    throws Exception
  {
    String bareProtocol = StringUtils.substringBefore(protocol, ":");
    setUrl(UrlUtils.getUrlWithNewProtocol(getUrl(), bareProtocol));
  }
  
  public Object getDefaultValue(Class<?> hint)
  {
    HtmlElement element = getDomNodeOrNull();
    if (element == null) {
      return super.getDefaultValue(null);
    }
    return getDefaultValue(element);
  }
  
  static String getDefaultValue(HtmlElement element)
  {
    String href = element.getAttribute("href");
    if (DomElement.ATTRIBUTE_NOT_DEFINED == href) {
      return "";
    }
    href = href.trim();
    
    SgmlPage page = element.getPage();
    if ((page == null) || (!page.isHtmlPage())) {
      return href;
    }
    int indexAnchor = href.indexOf('#');
    String anchorPart;
    String beforeAnchor;
    String anchorPart;
    if (indexAnchor == -1)
    {
      String beforeAnchor = href;
      anchorPart = "";
    }
    else
    {
      beforeAnchor = href.substring(0, indexAnchor);
      anchorPart = href.substring(indexAnchor);
    }
    HtmlPage htmlPage = (HtmlPage)page;
    try
    {
      return htmlPage.getFullyQualifiedUrl(beforeAnchor).toExternalForm() + anchorPart;
    }
    catch (MalformedURLException e) {}
    return href;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getAccessKey()
  {
    return super.getAccessKey();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setAccessKey(String accessKey)
  {
    super.setAccessKey(accessKey);
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
