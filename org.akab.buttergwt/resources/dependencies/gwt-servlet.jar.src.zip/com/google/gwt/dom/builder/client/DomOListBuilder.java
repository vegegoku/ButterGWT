package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.OListBuilder;
import com.google.gwt.dom.client.OListElement;

public class DomOListBuilder
  extends DomElementBuilderBase<OListBuilder, OListElement>
  implements OListBuilder
{
  DomOListBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
