package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import java.util.Set;

public abstract interface Cell<C>
{
  public abstract boolean dependsOnSelection();
  
  public abstract Set<String> getConsumedEvents();
  
  public abstract boolean handlesSelection();
  
  public abstract boolean isEditing(Context paramContext, Element paramElement, C paramC);
  
  public abstract void onBrowserEvent(Context paramContext, Element paramElement, C paramC, NativeEvent paramNativeEvent, ValueUpdater<C> paramValueUpdater);
  
  public abstract void render(Context paramContext, C paramC, SafeHtmlBuilder paramSafeHtmlBuilder);
  
  public abstract boolean resetFocus(Context paramContext, Element paramElement, C paramC);
  
  public abstract void setValue(Context paramContext, Element paramElement, C paramC);
  
  public static class Context
  {
    private final int column;
    private final int index;
    private final Object key;
    private final int subindex;
    
    public Context(int index, int column, Object key)
    {
      this(index, column, key, 0);
    }
    
    public Context(int index, int column, Object key, int subindex)
    {
      this.index = index;
      this.column = column;
      this.key = key;
      this.subindex = subindex;
    }
    
    public int getColumn()
    {
      return this.column;
    }
    
    public int getIndex()
    {
      return this.index;
    }
    
    public Object getKey()
    {
      return this.key;
    }
    
    public int getSubIndex()
    {
      return this.subindex;
    }
  }
}
