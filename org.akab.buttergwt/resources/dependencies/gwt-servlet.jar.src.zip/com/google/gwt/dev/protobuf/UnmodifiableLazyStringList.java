package com.google.gwt.dev.protobuf;

import java.util.AbstractList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public class UnmodifiableLazyStringList
  extends AbstractList<String>
  implements LazyStringList, RandomAccess
{
  private final LazyStringList list;
  
  public UnmodifiableLazyStringList(LazyStringList list)
  {
    this.list = list;
  }
  
  public String get(int index)
  {
    return (String)this.list.get(index);
  }
  
  public int size()
  {
    return this.list.size();
  }
  
  public ByteString getByteString(int index)
  {
    return this.list.getByteString(index);
  }
  
  public void add(ByteString element)
  {
    throw new UnsupportedOperationException();
  }
  
  public ListIterator<String> listIterator(final int index)
  {
    new ListIterator()
    {
      ListIterator<String> iter = UnmodifiableLazyStringList.this.list.listIterator(index);
      
      public boolean hasNext()
      {
        return this.iter.hasNext();
      }
      
      public String next()
      {
        return (String)this.iter.next();
      }
      
      public boolean hasPrevious()
      {
        return this.iter.hasPrevious();
      }
      
      public String previous()
      {
        return (String)this.iter.previous();
      }
      
      public int nextIndex()
      {
        return this.iter.nextIndex();
      }
      
      public int previousIndex()
      {
        return this.iter.previousIndex();
      }
      
      public void remove()
      {
        throw new UnsupportedOperationException();
      }
      
      public void set(String o)
      {
        throw new UnsupportedOperationException();
      }
      
      public void add(String o)
      {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  public Iterator<String> iterator()
  {
    new Iterator()
    {
      Iterator<String> iter = UnmodifiableLazyStringList.this.list.iterator();
      
      public boolean hasNext()
      {
        return this.iter.hasNext();
      }
      
      public String next()
      {
        return (String)this.iter.next();
      }
      
      public void remove()
      {
        throw new UnsupportedOperationException();
      }
    };
  }
  
  public List<?> getUnderlyingElements()
  {
    return this.list.getUnderlyingElements();
  }
}
