package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.text.shared.SimpleSafeHtmlRenderer;

public class TextButtonCell
  extends ButtonCellBase<String>
{
  public static class DefaultAppearance
    extends ButtonCellBase.DefaultAppearance<String>
    implements TextButtonCell.Appearance
  {
    public DefaultAppearance()
    {
      super();
    }
    
    public DefaultAppearance(ButtonCellBase.DefaultAppearance.Resources resources)
    {
      super(resources);
    }
  }
  
  public TextButtonCell()
  {
    this((Appearance)GWT.create(Appearance.class));
  }
  
  public TextButtonCell(Appearance appearance)
  {
    super(appearance);
  }
  
  public static abstract interface Appearance
    extends ButtonCellBase.Appearance<String>
  {}
}
