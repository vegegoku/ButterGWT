package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass
public class CSSMediaRule
  extends CSSRule
{
  private com.gargoylesoftware.htmlunit.javascript.host.MediaList media_;
  
  @Deprecated
  public CSSMediaRule() {}
  
  protected CSSMediaRule(CSSStyleSheet stylesheet, org.w3c.dom.css.CSSMediaRule rule)
  {
    super(stylesheet, rule);
  }
  
  @JsxGetter
  public com.gargoylesoftware.htmlunit.javascript.host.MediaList getMedia()
  {
    if (this.media_ == null)
    {
      CSSStyleSheet parent = getParentStyleSheet();
      org.w3c.dom.stylesheets.MediaList ml = getMediaRule().getMedia();
      this.media_ = new com.gargoylesoftware.htmlunit.javascript.host.MediaList(parent, ml);
    }
    return this.media_;
  }
  
  private org.w3c.dom.css.CSSMediaRule getMediaRule()
  {
    return (org.w3c.dom.css.CSSMediaRule)getRule();
  }
}
