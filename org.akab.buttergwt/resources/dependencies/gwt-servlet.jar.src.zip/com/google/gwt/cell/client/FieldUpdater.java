package com.google.gwt.cell.client;

public abstract interface FieldUpdater<T, C>
{
  public abstract void update(int paramInt, T paramT, C paramC);
}
