package com.google.gwt.core.client;

public class Duration
{
  private double start = currentTimeMillis();
  
  public static native double currentTimeMillis();
  
  private static native int uncheckedConversion(double paramDouble);
  
  public int elapsedMillis()
  {
    return uncheckedConversion(currentTimeMillis() - this.start);
  }
  
  public double getStartMillis()
  {
    return this.start;
  }
}
