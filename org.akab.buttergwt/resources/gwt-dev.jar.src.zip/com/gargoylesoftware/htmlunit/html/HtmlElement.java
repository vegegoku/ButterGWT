package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.ScriptResult;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.host.Event;
import com.gargoylesoftware.htmlunit.javascript.host.EventHandler;
import com.gargoylesoftware.htmlunit.javascript.host.KeyboardEvent;
import com.gargoylesoftware.htmlunit.javascript.host.MouseEvent;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.sourceforge.htmlunit.corejs.javascript.BaseFunction;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.ContextAction;
import net.sourceforge.htmlunit.corejs.javascript.ContextFactory;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMException;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public abstract class HtmlElement
  extends DomElement
{
  private static final Log LOG = LogFactory.getLog(HtmlElement.class);
  public static final Short TAB_INDEX_OUT_OF_BOUNDS = new Short((short)Short.MIN_VALUE);
  private final List<HtmlAttributeChangeListener> attributeListeners_;
  private HtmlForm owningForm_;
  
  protected HtmlElement(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    this.attributeListeners_ = new ArrayList();
    if ((page != null) && (hasFeature(BrowserVersionFeatures.HTMLELEMENT_TRIM_CLASS_ATTRIBUTE)))
    {
      String value = getAttribute("class");
      if (value != ATTRIBUTE_NOT_DEFINED) {
        getAttributeNode("class").setValue(value.trim());
      }
    }
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if (null == getHtmlPageOrNull())
    {
      super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
      return;
    }
    String oldAttributeValue = getAttribute(qualifiedName);
    HtmlPage htmlPage = (HtmlPage)getPage();
    boolean mappedElement = (isDirectlyAttachedToPage()) && (HtmlPage.isMappedElement(htmlPage, qualifiedName));
    if (mappedElement) {
      htmlPage.removeMappedElement(this);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
    if (mappedElement) {
      htmlPage.addMappedElement(this);
    }
    if (oldAttributeValue == ATTRIBUTE_NOT_DEFINED)
    {
      HtmlAttributeChangeEvent htmlEvent = new HtmlAttributeChangeEvent(this, qualifiedName, attributeValue);
      fireHtmlAttributeAdded(htmlEvent);
      htmlPage.fireHtmlAttributeAdded(htmlEvent);
    }
    else
    {
      HtmlAttributeChangeEvent htmlEvent = new HtmlAttributeChangeEvent(this, qualifiedName, oldAttributeValue);
      fireHtmlAttributeReplaced(htmlEvent);
      htmlPage.fireHtmlAttributeReplaced(htmlEvent);
    }
    if (hasFeature(BrowserVersionFeatures.EVENT_PROPERTY_CHANGE)) {
      fireEvent(Event.createPropertyChangeEvent(this, qualifiedName));
    }
  }
  
  public final List<HtmlElement> getHtmlElementsByTagNames(List<String> tagNames)
  {
    List<HtmlElement> list = new ArrayList();
    for (String tagName : tagNames) {
      list.addAll(getHtmlElementsByTagName(tagName));
    }
    return list;
  }
  
  public final <E extends HtmlElement> List<E> getHtmlElementsByTagName(String tagName)
  {
    List<E> list = new ArrayList();
    String lowerCaseTagName = tagName.toLowerCase(Locale.ENGLISH);
    Iterable<HtmlElement> iterable = getHtmlElementDescendants();
    for (HtmlElement element : iterable) {
      if (lowerCaseTagName.equals(element.getTagName())) {
        list.add(element);
      }
    }
    return list;
  }
  
  public final void removeAttribute(String attributeName)
  {
    String value = getAttribute(attributeName);
    
    HtmlPage htmlPage = getHtmlPageOrNull();
    if (htmlPage != null) {
      htmlPage.removeMappedElement(this);
    }
    super.removeAttribute(attributeName.toLowerCase(Locale.ENGLISH));
    if (htmlPage != null)
    {
      htmlPage.addMappedElement(this);
      
      HtmlAttributeChangeEvent event = new HtmlAttributeChangeEvent(this, attributeName, value);
      fireHtmlAttributeRemoved(event);
      htmlPage.fireHtmlAttributeRemoved(event);
    }
  }
  
  protected void fireHtmlAttributeAdded(HtmlAttributeChangeEvent event)
  {
    synchronized (this.attributeListeners_)
    {
      for (HtmlAttributeChangeListener listener : this.attributeListeners_) {
        listener.attributeAdded(event);
      }
    }
    DomNode parentNode = getParentNode();
    if ((parentNode instanceof HtmlElement)) {
      ((HtmlElement)parentNode).fireHtmlAttributeAdded(event);
    }
  }
  
  protected void fireHtmlAttributeReplaced(HtmlAttributeChangeEvent event)
  {
    synchronized (this.attributeListeners_)
    {
      for (HtmlAttributeChangeListener listener : this.attributeListeners_) {
        listener.attributeReplaced(event);
      }
    }
    DomNode parentNode = getParentNode();
    if ((parentNode instanceof HtmlElement)) {
      ((HtmlElement)parentNode).fireHtmlAttributeReplaced(event);
    }
  }
  
  protected void fireHtmlAttributeRemoved(HtmlAttributeChangeEvent event)
  {
    synchronized (this.attributeListeners_)
    {
      for (HtmlAttributeChangeListener listener : this.attributeListeners_) {
        listener.attributeRemoved(event);
      }
    }
    DomNode parentNode = getParentNode();
    if ((parentNode instanceof HtmlElement)) {
      ((HtmlElement)parentNode).fireHtmlAttributeRemoved(event);
    }
  }
  
  public String getNodeName()
  {
    String prefix = getPrefix();
    if (prefix != null)
    {
      StringBuilder name = new StringBuilder(prefix.toLowerCase(Locale.ENGLISH));
      name.append(':');
      name.append(getLocalName().toLowerCase(Locale.ENGLISH));
      return name.toString();
    }
    return getLocalName().toLowerCase(Locale.ENGLISH);
  }
  
  public final void setId(String newId)
  {
    setAttribute("id", newId);
  }
  
  public Short getTabIndex()
  {
    String index = getAttribute("tabindex");
    if ((index == null) || (index.isEmpty())) {
      return null;
    }
    try
    {
      long l = Long.parseLong(index);
      if ((l >= 0L) && (l <= 32767L)) {
        return Short.valueOf((short)(int)l);
      }
      return TAB_INDEX_OUT_OF_BOUNDS;
    }
    catch (NumberFormatException e) {}
    return null;
  }
  
  public HtmlElement getEnclosingElement(String tagName)
  {
    String tagNameLC = tagName.toLowerCase(Locale.ENGLISH);
    for (DomNode currentNode = getParentNode(); currentNode != null; currentNode = currentNode.getParentNode()) {
      if (((currentNode instanceof HtmlElement)) && (currentNode.getNodeName().equals(tagNameLC))) {
        return (HtmlElement)currentNode;
      }
    }
    return null;
  }
  
  public HtmlForm getEnclosingForm()
  {
    if (this.owningForm_ != null) {
      return this.owningForm_;
    }
    return (HtmlForm)getEnclosingElement("form");
  }
  
  public HtmlForm getEnclosingFormOrDie()
    throws IllegalStateException
  {
    HtmlForm form = getEnclosingForm();
    if (form == null) {
      throw new IllegalStateException("Element is not contained within a form: " + this);
    }
    return form;
  }
  
  public void type(String text)
    throws IOException
  {
    for (char ch : text.toCharArray()) {
      type(ch);
    }
  }
  
  public void type(String text, boolean shiftKey, boolean ctrlKey, boolean altKey)
    throws IOException
  {
    for (char ch : text.toCharArray()) {
      type(ch, shiftKey, ctrlKey, altKey);
    }
  }
  
  public Page type(char c)
    throws IOException
  {
    return type(c, false, false, false);
  }
  
  public Page type(char c, boolean shiftKey, boolean ctrlKey, boolean altKey)
    throws IOException
  {
    if (((this instanceof DisabledElement)) && (((DisabledElement)this).isDisabled())) {
      return getPage();
    }
    getPage().getWebClient().setCurrentWindow(getPage().getEnclosingWindow());
    
    HtmlPage page = (HtmlPage)getPage();
    if (page.getFocusedElement() != this) {
      focus();
    }
    Event keyDown = new KeyboardEvent(this, "keydown", c, shiftKey, ctrlKey, altKey);
    ScriptResult keyDownResult = fireEvent(keyDown);
    
    Event keyPress = new KeyboardEvent(this, "keypress", c, shiftKey, ctrlKey, altKey);
    ScriptResult keyPressResult = fireEvent(keyPress);
    if ((!keyDown.isAborted(keyDownResult)) && (!keyPress.isAborted(keyPressResult))) {
      doType(c, shiftKey, ctrlKey, altKey);
    }
    WebClient webClient = page.getWebClient();
    BrowserVersion browserVersion = webClient.getBrowserVersion();
    if ((browserVersion.hasFeature(BrowserVersionFeatures.EVENT_INPUT)) && (((this instanceof HtmlTextInput)) || ((this instanceof HtmlTextArea)) || ((this instanceof HtmlPasswordInput))))
    {
      Event input = new KeyboardEvent(this, "input", c, shiftKey, ctrlKey, altKey);
      fireEvent(input);
    }
    Event keyUp = new KeyboardEvent(this, "keyup", c, shiftKey, ctrlKey, altKey);
    fireEvent(keyUp);
    
    HtmlForm form = getEnclosingForm();
    if ((form != null) && (c == '\n') && (isSubmittableByEnter()))
    {
      if (!browserVersion.hasFeature(BrowserVersionFeatures.BUTTON_EMPTY_TYPE_BUTTON))
      {
        HtmlSubmitInput submit = (HtmlSubmitInput)form.getFirstByXPath(".//input[@type='submit']");
        if (submit != null) {
          return submit.click();
        }
      }
      form.submit((SubmittableElement)this);
      webClient.getJavaScriptEngine().processPostponedActions();
    }
    return webClient.getCurrentWindow().getEnclosedPage();
  }
  
  public Page type(int keyCode)
    throws IOException
  {
    return type(keyCode, false, false, false);
  }
  
  public Page type(int keyCode, boolean shiftKey, boolean ctrlKey, boolean altKey)
    throws IOException
  {
    if (((this instanceof DisabledElement)) && (((DisabledElement)this).isDisabled())) {
      return getPage();
    }
    HtmlPage page = (HtmlPage)getPage();
    if (page.getFocusedElement() != this) {
      focus();
    }
    Event keyDown = new KeyboardEvent(this, "keydown", keyCode, shiftKey, ctrlKey, altKey);
    
    ScriptResult keyDownResult = fireEvent(keyDown);
    
    BrowserVersion browserVersion = page.getWebClient().getBrowserVersion();
    ScriptResult keyPressResult;
    if (browserVersion.hasFeature(BrowserVersionFeatures.KEYBOARD_EVENT_SPECIAL_KEYPRESS))
    {
      Event keyPress = new KeyboardEvent(this, "keypress", keyCode, shiftKey, ctrlKey, altKey);
      
      keyPressResult = fireEvent(keyPress);
    }
    if ((browserVersion.hasFeature(BrowserVersionFeatures.EVENT_INPUT)) && (((this instanceof HtmlTextInput)) || ((this instanceof HtmlTextArea)) || ((this instanceof HtmlPasswordInput))))
    {
      Event input = new KeyboardEvent(this, "input", keyCode, shiftKey, ctrlKey, altKey);
      fireEvent(input);
    }
    Event keyUp = new KeyboardEvent(this, "keyup", keyCode, shiftKey, ctrlKey, altKey);
    fireEvent(keyUp);
    
    return page.getWebClient().getCurrentWindow().getEnclosedPage();
  }
  
  protected void doType(char c, boolean shiftKey, boolean ctrlKey, boolean altKey) {}
  
  protected boolean isSubmittableByEnter()
  {
    return false;
  }
  
  public String toString()
  {
    StringWriter writer = new StringWriter();
    PrintWriter printWriter = new PrintWriter(writer);
    
    printWriter.print(ClassUtils.getShortClassName(getClass()));
    printWriter.print("[<");
    printOpeningTagContentAsXml(printWriter);
    printWriter.print(">]");
    printWriter.flush();
    return writer.toString();
  }
  
  public final <E extends HtmlElement> E getOneHtmlElementByAttribute(String elementName, String attributeName, String attributeValue)
    throws ElementNotFoundException
  {
    WebAssert.notNull("elementName", elementName);
    WebAssert.notNull("attributeName", attributeName);
    WebAssert.notNull("attributeValue", attributeValue);
    
    List<E> list = getElementsByAttribute(elementName, attributeName, attributeValue);
    
    int listSize = list.size();
    if (listSize == 0) {
      throw new ElementNotFoundException(elementName, attributeName, attributeValue);
    }
    return (HtmlElement)list.get(0);
  }
  
  @Deprecated
  public <E extends HtmlElement> E getElementById(String id)
    throws ElementNotFoundException
  {
    return ((HtmlPage)getPage()).getHtmlElementById(id);
  }
  
  @Deprecated
  public boolean hasHtmlElementWithId(String id)
  {
    try
    {
      getElementById(id);
      return true;
    }
    catch (ElementNotFoundException e) {}
    return false;
  }
  
  public final <E extends HtmlElement> List<E> getElementsByAttribute(String elementName, String attributeName, String attributeValue)
  {
    List<E> list = new ArrayList();
    String lowerCaseTagName = elementName.toLowerCase(Locale.ENGLISH);
    for (HtmlElement next : getHtmlElementDescendants()) {
      if (next.getTagName().equals(lowerCaseTagName))
      {
        String attValue = next.getAttribute(attributeName);
        if ((attValue != null) && (attValue.equals(attributeValue))) {
          list.add(next);
        }
      }
    }
    return list;
  }
  
  public final HtmlElement appendChildIfNoneExists(String tagName)
  {
    List<HtmlElement> children = getHtmlElementsByTagName(tagName);
    HtmlElement child;
    if (children.isEmpty())
    {
      HtmlElement child = (HtmlElement)((HtmlPage)getPage()).createElement(tagName);
      appendChild(child);
    }
    else
    {
      child = (HtmlElement)children.get(0);
    }
    return child;
  }
  
  public final void removeChild(String tagName, int i)
  {
    List<HtmlElement> children = getHtmlElementsByTagName(tagName);
    if ((i >= 0) && (i < children.size())) {
      ((HtmlElement)children.get(i)).remove();
    }
  }
  
  public final boolean hasEventHandlers(String eventName)
  {
    HTMLElement jsObj = (HTMLElement)getScriptObject();
    return jsObj.hasEventHandlers(eventName);
  }
  
  public final void setEventHandler(String eventName, Function eventHandler)
  {
    HTMLElement jsObj = (HTMLElement)getScriptObject();
    jsObj.setEventHandler(eventName, eventHandler);
  }
  
  public final void setEventHandler(String eventName, String jsSnippet)
  {
    BaseFunction function = new EventHandler(this, eventName, jsSnippet);
    setEventHandler(eventName, function);
    if (LOG.isDebugEnabled()) {
      LOG.debug("Created event handler " + function.getFunctionName() + " for " + eventName + " on " + this);
    }
  }
  
  public final void removeEventHandler(String eventName)
  {
    setEventHandler(eventName, (Function)null);
  }
  
  public void addHtmlAttributeChangeListener(HtmlAttributeChangeListener listener)
  {
    WebAssert.notNull("listener", listener);
    synchronized (this.attributeListeners_)
    {
      this.attributeListeners_.add(listener);
    }
  }
  
  public void removeHtmlAttributeChangeListener(HtmlAttributeChangeListener listener)
  {
    WebAssert.notNull("listener", listener);
    synchronized (this.attributeListeners_)
    {
      this.attributeListeners_.remove(listener);
    }
  }
  
  public ScriptResult fireEvent(String eventType)
  {
    return fireEvent(new Event(this, eventType));
  }
  
  public ScriptResult fireEvent(final Event event)
  {
    WebClient client = getPage().getWebClient();
    if (!client.getOptions().isJavaScriptEnabled()) {
      return null;
    }
    if (!event.applies(this)) {
      return null;
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("Firing " + event);
    }
    final HTMLElement jsElt = (HTMLElement)getScriptObject();
    ContextAction action = new ContextAction()
    {
      public Object run(Context cx)
      {
        return jsElt.fireEvent(event);
      }
    };
    ContextFactory cf = client.getJavaScriptEngine().getContextFactory();
    ScriptResult result = (ScriptResult)cf.call(action);
    if (event.isAborted(result)) {
      preventDefault();
    }
    return result;
  }
  
  protected void preventDefault() {}
  
  public Page mouseOver()
  {
    return mouseOver(false, false, false, 0);
  }
  
  public Page mouseOver(boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    return doMouseEvent("mouseover", shiftKey, ctrlKey, altKey, button);
  }
  
  public Page mouseMove()
  {
    return mouseMove(false, false, false, 0);
  }
  
  public Page mouseMove(boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    return doMouseEvent("mousemove", shiftKey, ctrlKey, altKey, button);
  }
  
  public Page mouseOut()
  {
    return mouseOut(false, false, false, 0);
  }
  
  public Page mouseOut(boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    return doMouseEvent("mouseout", shiftKey, ctrlKey, altKey, button);
  }
  
  public Page mouseDown()
  {
    return mouseDown(false, false, false, 0);
  }
  
  public Page mouseDown(boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    return doMouseEvent("mousedown", shiftKey, ctrlKey, altKey, button);
  }
  
  public Page mouseUp()
  {
    return mouseUp(false, false, false, 0);
  }
  
  public Page mouseUp(boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    return doMouseEvent("mouseup", shiftKey, ctrlKey, altKey, button);
  }
  
  public Page rightClick()
  {
    return rightClick(false, false, false);
  }
  
  public Page rightClick(boolean shiftKey, boolean ctrlKey, boolean altKey)
  {
    Page mouseDownPage = mouseDown(shiftKey, ctrlKey, altKey, 2);
    if (mouseDownPage != getPage())
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("rightClick() is incomplete, as mouseDown() loaded a different page.");
      }
      return mouseDownPage;
    }
    Page mouseUpPage = mouseUp(shiftKey, ctrlKey, altKey, 2);
    if (mouseUpPage != getPage())
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("rightClick() is incomplete, as mouseUp() loaded a different page.");
      }
      return mouseUpPage;
    }
    return doMouseEvent("contextmenu", shiftKey, ctrlKey, altKey, 2);
  }
  
  private Page doMouseEvent(String eventType, boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    if (((this instanceof DisabledElement)) && (((DisabledElement)this).isDisabled())) {
      return getPage();
    }
    HtmlPage page = (HtmlPage)getPage();
    Event event = new MouseEvent(this, eventType, shiftKey, ctrlKey, altKey, button);
    ScriptResult scriptResult = fireEvent(event);
    Page currentPage;
    Page currentPage;
    if (scriptResult == null) {
      currentPage = page;
    } else {
      currentPage = scriptResult.getNewPage();
    }
    return currentPage;
  }
  
  public void blur()
  {
    ((HtmlPage)getPage()).setFocusedElement(null);
  }
  
  public void focus()
  {
    HtmlPage page = (HtmlPage)getPage();
    page.setFocusedElement(this);
    if (hasFeature(BrowserVersionFeatures.WINDOW_ACTIVE_ELEMENT_FOCUSED))
    {
      HTMLElement jsElt = (HTMLElement)getScriptObject();
      jsElt.setActive();
    }
  }
  
  protected void checkChildHierarchy(Node childNode)
    throws DOMException
  {
    if ((!(childNode instanceof Element)) && (!(childNode instanceof Text)) && (!(childNode instanceof Comment)) && (!(childNode instanceof ProcessingInstruction)) && (!(childNode instanceof CDATASection)) && (!(childNode instanceof EntityReference))) {
      throw new DOMException((short)3, "The Element may not have a child of this type: " + childNode.getNodeType());
    }
    super.checkChildHierarchy(childNode);
  }
  
  void setOwningForm(HtmlForm form)
  {
    this.owningForm_ = form;
  }
  
  void removeFocus() {}
  
  protected boolean isAttributeCaseSensitive()
  {
    return false;
  }
  
  public <P extends Page> P click()
    throws IOException
  {
    return click(false, false, false);
  }
  
  public <P extends Page> P click(boolean shiftKey, boolean ctrlKey, boolean altKey)
    throws IOException
  {
    SgmlPage page = getPage();
    page.getWebClient().setCurrentWindow(page.getEnclosingWindow());
    if (((this instanceof DisabledElement)) && (((DisabledElement)this).isDisabled())) {
      return page;
    }
    synchronized (page)
    {
      mouseDown(shiftKey, ctrlKey, altKey, 0);
      
      HtmlElement elementToFocus = null;
      if (((this instanceof SubmittableElement)) || ((this instanceof HtmlAnchor))) {
        elementToFocus = this;
      } else if ((this instanceof HtmlOption)) {
        elementToFocus = ((HtmlOption)this).getEnclosingSelect();
      }
      ((HtmlPage)page).setFocusedElement(elementToFocus);
      
      mouseUp(shiftKey, ctrlKey, altKey, 0);
      
      Event event = new MouseEvent(getEventTargetElement(), "click", shiftKey, ctrlKey, altKey, 0);
      
      return click(event);
    }
  }
  
  protected DomNode getEventTargetElement()
  {
    return this;
  }
  
  public <P extends Page> P click(Event event)
    throws IOException
  {
    SgmlPage page = getPage();
    if (((this instanceof DisabledElement)) && (((DisabledElement)this).isDisabled())) {
      return page;
    }
    Page contentPage = page.getEnclosingWindow().getEnclosedPage();
    
    boolean stateUpdated = false;
    boolean changed = false;
    if (isStateUpdateFirst())
    {
      changed = doClickStateUpdate();
      stateUpdated = true;
    }
    JavaScriptEngine jsEngine = page.getWebClient().getJavaScriptEngine();
    jsEngine.holdPosponedActions();
    try
    {
      ScriptResult scriptResult = doClickFireClickEvent(event);
      boolean eventIsAborted = event.isAborted(scriptResult);
      
      boolean pageAlreadyChanged = contentPage != page.getEnclosingWindow().getEnclosedPage();
      if ((!pageAlreadyChanged) && (!stateUpdated) && (!eventIsAborted)) {
        changed = doClickStateUpdate();
      }
    }
    finally
    {
      jsEngine.processPostponedActions();
    }
    if (changed) {
      doClickFireChangeEvent();
    }
    return getPage().getWebClient().getCurrentWindow().getEnclosedPage();
  }
  
  protected boolean doClickStateUpdate()
    throws IOException
  {
    DomNode parent = getParentNode();
    if ((parent instanceof HtmlElement)) {
      return ((HtmlElement)parent).doClickStateUpdate();
    }
    return false;
  }
  
  protected void doClickFireChangeEvent()
    throws IOException
  {}
  
  protected ScriptResult doClickFireClickEvent(Event event)
    throws IOException
  {
    return fireEvent(event);
  }
  
  public <P extends Page> P dblClick()
    throws IOException
  {
    return dblClick(false, false, false);
  }
  
  public <P extends Page> P dblClick(boolean shiftKey, boolean ctrlKey, boolean altKey)
    throws IOException
  {
    if (((this instanceof DisabledElement)) && (((DisabledElement)this).isDisabled())) {
      return getPage();
    }
    Page clickPage = click(shiftKey, ctrlKey, altKey);
    if (clickPage != getPage())
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("dblClick() is ignored, as click() loaded a different page.");
      }
      return clickPage;
    }
    Event event = new MouseEvent(this, "dblclick", shiftKey, ctrlKey, altKey, 0);
    
    ScriptResult scriptResult = fireEvent(event);
    if (scriptResult == null) {
      return clickPage;
    }
    return scriptResult.getNewPage();
  }
  
  public final String getLangAttribute()
  {
    return getAttribute("lang");
  }
  
  public final String getXmlLangAttribute()
  {
    return getAttribute("xml:lang");
  }
  
  public final String getTextDirectionAttribute()
  {
    return getAttribute("dir");
  }
  
  public final String getOnClickAttribute()
  {
    return getAttribute("onclick");
  }
  
  public final String getOnDblClickAttribute()
  {
    return getAttribute("ondblclick");
  }
  
  public final String getOnMouseDownAttribute()
  {
    return getAttribute("onmousedown");
  }
  
  public final String getOnMouseUpAttribute()
  {
    return getAttribute("onmouseup");
  }
  
  public final String getOnMouseOverAttribute()
  {
    return getAttribute("onmouseover");
  }
  
  public final String getOnMouseMoveAttribute()
  {
    return getAttribute("onmousemove");
  }
  
  public final String getOnMouseOutAttribute()
  {
    return getAttribute("onmouseout");
  }
  
  public final String getOnKeyPressAttribute()
  {
    return getAttribute("onkeypress");
  }
  
  public final String getOnKeyDownAttribute()
  {
    return getAttribute("onkeydown");
  }
  
  public final String getOnKeyUpAttribute()
  {
    return getAttribute("onkeyup");
  }
  
  protected boolean isStateUpdateFirst()
  {
    return false;
  }
  
  public String getCanonicalXPath()
  {
    DomNode parent = getParentNode();
    if (parent.getNodeType() == 9) {
      return "/" + getNodeName();
    }
    return parent.getCanonicalXPath() + '/' + getXPathToken();
  }
  
  private String getXPathToken()
  {
    DomNode parent = getParentNode();
    int total = 0;
    int nodeIndex = 0;
    for (DomNode child : parent.getChildren())
    {
      if ((child.getNodeType() == 1) && (child.getNodeName().equals(getNodeName()))) {
        total++;
      }
      if (child == this) {
        nodeIndex = total;
      }
    }
    if ((nodeIndex == 1) && (total == 1)) {
      return getNodeName();
    }
    return getNodeName() + '[' + nodeIndex + ']';
  }
  
  public DomNodeList<DomNode> querySelectorAll(String selectors)
  {
    return super.querySelectorAll(selectors);
  }
  
  public DomNode querySelector(String selectors)
  {
    return super.querySelector(selectors);
  }
}
