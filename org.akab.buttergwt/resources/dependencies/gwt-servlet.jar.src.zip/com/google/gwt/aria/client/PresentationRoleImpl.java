package com.google.gwt.aria.client;

class PresentationRoleImpl
  extends RoleImpl
  implements PresentationRole
{
  PresentationRoleImpl(String roleName)
  {
    super(roleName);
  }
}
