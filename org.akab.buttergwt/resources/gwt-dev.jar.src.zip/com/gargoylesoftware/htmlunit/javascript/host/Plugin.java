package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
public class Plugin
  extends SimpleArray
{
  private String description_;
  private String filename_;
  private String name_;
  
  public Plugin() {}
  
  public Plugin(String name, String description, String filename)
  {
    this.name_ = name;
    this.description_ = description;
    this.filename_ = filename;
  }
  
  protected String getItemName(Object element)
  {
    return ((MimeType)element).getType();
  }
  
  @JsxGetter
  public String getDescription()
  {
    return this.description_;
  }
  
  @JsxGetter
  public String getFilename()
  {
    return this.filename_;
  }
  
  @JsxGetter
  public String getName()
  {
    return this.name_;
  }
}
