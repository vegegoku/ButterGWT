package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class ListboxRoleImpl
  extends RoleImpl
  implements ListboxRole
{
  ListboxRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaActivedescendantProperty(Element element)
  {
    return Property.ACTIVEDESCENDANT.get(element);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaMultiselectableProperty(Element element)
  {
    return Property.MULTISELECTABLE.get(element);
  }
  
  public String getAriaRequiredProperty(Element element)
  {
    return Property.REQUIRED.get(element);
  }
  
  public void removeAriaActivedescendantProperty(Element element)
  {
    Property.ACTIVEDESCENDANT.remove(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaMultiselectableProperty(Element element)
  {
    Property.MULTISELECTABLE.remove(element);
  }
  
  public void removeAriaRequiredProperty(Element element)
  {
    Property.REQUIRED.remove(element);
  }
  
  public void setAriaActivedescendantProperty(Element element, Id value)
  {
    Property.ACTIVEDESCENDANT.set(element, new Id[] { value });
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaMultiselectableProperty(Element element, boolean value)
  {
    Property.MULTISELECTABLE.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaRequiredProperty(Element element, boolean value)
  {
    Property.REQUIRED.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
}
