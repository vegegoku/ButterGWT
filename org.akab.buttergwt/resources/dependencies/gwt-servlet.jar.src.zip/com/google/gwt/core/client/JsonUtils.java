package com.google.gwt.core.client;

public class JsonUtils
{
  private static JavaScriptObject escapeTable = ;
  private static final boolean hasJsonParse = hasJsonParse();
  
  public static native String escapeJsonForEval(String paramString);
  
  public static native String escapeValue(String paramString);
  
  public static native <T extends JavaScriptObject> T safeEval(String paramString);
  
  public static native boolean safeToEval(String paramString);
  
  public static native <T extends JavaScriptObject> T unsafeEval(String paramString);
  
  static void throwIllegalArgumentException(String message, String data)
  {
    throw new IllegalArgumentException(message + "\n" + data);
  }
  
  private static native String escapeChar(String paramString);
  
  private static native boolean hasJsonParse();
  
  private static native JavaScriptObject initEscapeTable();
}
