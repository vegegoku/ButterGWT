package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCollection;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLFormElement;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
public class Enumerator
  extends SimpleScriptable
{
  private int index_;
  private HTMLCollection collection_;
  
  @JsxConstructor
  public void jsConstructor(Object o)
  {
    if ((o instanceof HTMLCollection)) {
      this.collection_ = ((HTMLCollection)o);
    } else if ((o instanceof HTMLFormElement)) {
      this.collection_ = ((HTMLFormElement)o).getElements();
    } else {
      throw new IllegalArgumentException(String.valueOf(o));
    }
  }
  
  @JsxFunction
  public boolean atEnd()
  {
    return this.index_ >= this.collection_.getLength();
  }
  
  @JsxFunction
  public Object item()
  {
    if (!atEnd())
    {
      SimpleScriptable scriptable = (SimpleScriptable)this.collection_.get(this.index_, this.collection_);
      scriptable = scriptable.clone();
      scriptable.setCaseSensitive(false);
      return scriptable;
    }
    return Undefined.instance;
  }
  
  @JsxFunction
  public void moveFirst()
  {
    this.index_ = 0;
  }
  
  @JsxFunction
  public void moveNext()
  {
    this.index_ += 1;
  }
}
