package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLObjectElement;
import java.util.Map;

public class HtmlObject
  extends HtmlElement
{
  public static final String TAG_NAME = "object";
  
  HtmlObject(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    if (attributes != null)
    {
      DomAttr classid = (DomAttr)attributes.get("classid");
      if (classid != null) {
        ((HTMLObjectElement)getScriptObject()).setClassid(classid.getValue());
      }
    }
  }
  
  public final String getDeclareAttribute()
  {
    return getAttribute("declare");
  }
  
  public final String getClassIdAttribute()
  {
    return getAttribute("classid");
  }
  
  public final String getCodebaseAttribute()
  {
    return getAttribute("codebase");
  }
  
  public final String getDataAttribute()
  {
    return getAttribute("data");
  }
  
  public final String getTypeAttribute()
  {
    return getAttribute("type");
  }
  
  public final String getCodeTypeAttribute()
  {
    return getAttribute("codetype");
  }
  
  public final String getArchiveAttribute()
  {
    return getAttribute("archive");
  }
  
  public final String getStandbyAttribute()
  {
    return getAttribute("standby");
  }
  
  public final String getHeightAttribute()
  {
    return getAttribute("height");
  }
  
  public final String getWidthAttribute()
  {
    return getAttribute("width");
  }
  
  public final String getUseMapAttribute()
  {
    return getAttribute("usemap");
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final String getTabIndexAttribute()
  {
    return getAttribute("tabindex");
  }
  
  public final String getAlignAttribute()
  {
    return getAttribute("align");
  }
  
  public final String getBorderAttribute()
  {
    return getAttribute("border");
  }
  
  public final String getHspaceAttribute()
  {
    return getAttribute("hspace");
  }
  
  public final String getVspaceAttribute()
  {
    return getAttribute("vspace");
  }
}
