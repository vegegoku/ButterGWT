package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlBaseFont
  extends HtmlElement
{
  public static final String TAG_NAME = "basefont";
  
  HtmlBaseFont(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public final String getIdAttribute()
  {
    return getAttribute("id");
  }
  
  public final String getSizeAttribute()
  {
    String size = getAttribute("size");
    if (ATTRIBUTE_NOT_DEFINED == size) {
      return "3";
    }
    return size;
  }
  
  public final String getColorAttribute()
  {
    return getAttribute("color");
  }
  
  public final String getFaceAttribute()
  {
    return getAttribute("face");
  }
}
