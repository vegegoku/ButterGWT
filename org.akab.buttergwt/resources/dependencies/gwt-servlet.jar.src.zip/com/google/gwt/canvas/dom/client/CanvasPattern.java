package com.google.gwt.canvas.dom.client;

public class CanvasPattern
  extends FillStrokeStyle
{}
