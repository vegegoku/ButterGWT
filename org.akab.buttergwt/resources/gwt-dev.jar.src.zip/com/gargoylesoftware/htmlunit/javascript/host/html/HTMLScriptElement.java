package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlScript;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(domClasses={HtmlScript.class})
public class HTMLScriptElement
  extends HTMLElement
{
  @JsxGetter
  public String getSrc()
  {
    return getDomNodeOrDie().getAttribute("src");
  }
  
  @JsxSetter
  public void setSrc(String src)
  {
    getDomNodeOrDie().setAttribute("src", src);
  }
  
  @JsxGetter
  public String getText()
  {
    StringBuilder scriptCode = new StringBuilder();
    for (DomNode node : getDomNodeOrDie().getChildren()) {
      if ((node instanceof DomText))
      {
        DomText domText = (DomText)node;
        scriptCode.append(domText.getData());
      }
    }
    return scriptCode.toString();
  }
  
  @JsxSetter
  public void setText(String text)
  {
    HtmlElement htmlElement = getDomNodeOrDie();
    htmlElement.removeAllChildren();
    DomNode textChild = new DomText(htmlElement.getPage(), text);
    htmlElement.appendChild(textChild);
    
    HtmlScript tmpScript = (HtmlScript)htmlElement;
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SCRIPT_ALWAYS_REEXECUTE_ON_SET_TEXT)) {
      tmpScript.resetExecuted();
    }
    tmpScript.executeScriptIfNeeded();
  }
  
  @JsxGetter
  public String getType()
  {
    return getDomNodeOrDie().getAttribute("type");
  }
  
  @JsxSetter
  public void setType(String type)
  {
    getDomNodeOrDie().setAttribute("type", type);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getOnreadystatechange()
  {
    return getEventHandlerProp("onreadystatechange");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOnreadystatechange(Object handler)
  {
    setEventHandlerProp("onreadystatechange", handler);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getOnload()
  {
    return getEventHandlerProp("onload");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOnload(Object handler)
  {
    setEventHandlerProp("onload", handler);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getReadyState()
  {
    return getDomNodeOrDie().getReadyState();
  }
  
  public Object appendChild(Object childObject)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SCRIPT_APPEND_CHILD_THROWS_EXCEPTION)) {
      throw Context.reportRuntimeError("Unexpected call to method or property access");
    }
    HtmlScript tmpScript = (HtmlScript)getDomNodeOrDie();
    boolean wasEmpty = tmpScript.getFirstChild() == null;
    Object result = super.appendChild(childObject);
    if (wasEmpty) {
      tmpScript.executeScriptIfNeeded();
    }
    return result;
  }
  
  protected Object insertBeforeImpl(Object[] args)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_SCRIPT_INSERT_BEFORE_THROWS_EXCEPTION)) {
      throw Context.reportRuntimeError("Unexpected call to method or property access");
    }
    return super.insertBeforeImpl(args);
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "none";
    }
    return "inline";
  }
}
