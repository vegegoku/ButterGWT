package com.google.gwt.core.client;

public abstract interface Callback<T, F>
{
  public abstract void onFailure(F paramF);
  
  public abstract void onSuccess(T paramT);
}
