package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface TabRole
  extends SectionheadRole, WidgetRole
{
  public abstract String getAriaSelectedState(Element paramElement);
  
  public abstract void removeAriaSelectedState(Element paramElement);
  
  public abstract void setAriaSelectedState(Element paramElement, SelectedValue paramSelectedValue);
}
