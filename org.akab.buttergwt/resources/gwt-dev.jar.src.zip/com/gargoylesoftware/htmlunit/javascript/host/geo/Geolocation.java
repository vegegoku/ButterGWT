package com.gargoylesoftware.htmlunit.javascript.host.geo;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.background.BackgroundJavaScriptFactory;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptJob;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptJobManager;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@JsxClass
public class Geolocation
  extends SimpleScriptable
{
  private static final Log LOG = LogFactory.getLog(Geolocation.class);
  private static String PROVIDER_URL_ = "https://maps.googleapis.com/maps/api/browserlocation/json";
  private Function successHandler_;
  private Function errorHandler_;
  
  @JsxFunction
  public void getCurrentPosition(Function successCallback, Object errorCallback, Object options)
  {
    this.successHandler_ = successCallback;
    if ((errorCallback instanceof Function)) {
      this.errorHandler_ = ((Function)errorCallback);
    } else {
      this.errorHandler_ = null;
    }
    WebWindow webWindow = getWindow().getWebWindow();
    if (webWindow.getWebClient().getOptions().isGeolocationEnabled())
    {
      JavaScriptJob job = BackgroundJavaScriptFactory.theFactory().createJavaScriptJob(0, null, new Runnable()
      {
        public void run()
        {
          Geolocation.this.doGetPosition();
        }
      });
      webWindow.getJobManager().addJob(job, getWindow().getWebWindow().getEnclosedPage());
    }
  }
  
  @JsxFunction
  public int watchPosition(Function successCallback, Object errorCallback, Object options)
  {
    return 0;
  }
  
  @JsxFunction
  public void clearWatch(int watchId) {}
  
  public String getClassName()
  {
    if ((getWindow().getWebWindow() != null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GEO_GEOLOCATION))) {
      return "GeoGeolocation";
    }
    return super.getClassName();
  }
  
  private void doGetPosition()
  {
    String os = System.getProperty("os.name").toLowerCase(Locale.ENGLISH);
    String wifiStringString = null;
    if (os.contains("win")) {
      wifiStringString = getWifiStringWindows();
    }
    if (wifiStringString != null)
    {
      String url = PROVIDER_URL_;
      if (url.contains("?")) {
        url = url + '&';
      } else {
        url = url + '?';
      }
      url = url + "browser=firefox&sensor=true";
      url = url + wifiStringString;
      while (url.length() >= 1900) {
        url = url.substring(0, url.lastIndexOf("&wifi="));
      }
      if (LOG.isInfoEnabled()) {
        LOG.info("Invoking URL: " + url);
      }
      WebClient webClient = new WebClient(BrowserVersion.FIREFOX_17);
      try
      {
        Page page = webClient.getPage(url);
        String content = page.getWebResponse().getContentAsString();
        if (LOG.isDebugEnabled()) {
          LOG.debug("Receieved Content: " + content);
        }
        double latitude = Double.parseDouble(getJSONValue(content, "lat"));
        double longitude = Double.parseDouble(getJSONValue(content, "lng"));
        double accuracy = Double.parseDouble(getJSONValue(content, "accuracy"));
        
        Coordinates coordinates = new Coordinates(latitude, longitude, accuracy);
        coordinates.setPrototype(getPrototype(coordinates.getClass()));
        
        Position position = new Position(coordinates);
        position.setPrototype(getPrototype(position.getClass()));
        
        JavaScriptEngine jsEngine = getWindow().getWebWindow().getWebClient().getJavaScriptEngine();
        jsEngine.callFunction((HtmlPage)getWindow().getWebWindow().getEnclosedPage(), this.successHandler_, this, getParentScope(), new Object[] { position });
      }
      catch (Exception e)
      {
        LOG.error("", e);
      }
      finally
      {
        webClient.closeAllWindows();
      }
    }
    else
    {
      LOG.error("Operating System not supported: " + os);
    }
  }
  
  private String getJSONValue(String content, String key)
  {
    StringBuilder builder = new StringBuilder();
    int index = content.indexOf("\"" + key + "\"") + key.length() + 2;
    for (index = content.indexOf(':', index) + 1; index < content.length(); index++)
    {
      char ch = content.charAt(index);
      if ((ch == ',') || (ch == '}')) {
        break;
      }
      builder.append(ch);
    }
    return builder.toString().trim();
  }
  
  String getWifiStringWindows()
  {
    StringBuilder builder = new StringBuilder();
    Iterator<String> it;
    try
    {
      List<String> lines = runCommand("netsh wlan show networks mode=bssid");
      for (it = lines.iterator(); it.hasNext();)
      {
        String line = (String)it.next();
        if (line.startsWith("SSID "))
        {
          String name = line.substring(line.lastIndexOf(' ') + 1);
          if (it.hasNext()) {
            it.next();
          }
          if (it.hasNext()) {
            it.next();
          }
          if (it.hasNext()) {
            it.next();
          }
          while (it.hasNext())
          {
            line = (String)it.next();
            if (line.trim().startsWith("BSSID "))
            {
              String mac = line.substring(line.lastIndexOf(' ') + 1);
              if (it.hasNext())
              {
                line = ((String)it.next()).trim();
                if (line.startsWith("Signal"))
                {
                  String signal = line.substring(line.lastIndexOf(' ') + 1, line.length() - 1);
                  int signalStrength = Integer.parseInt(signal) / 2 - 100;
                  builder.append("&wifi=").append("mac:").append(mac.replace(':', '-')).append("%7C").append("ssid:").append(name).append("%7C").append("ss:").append(signalStrength);
                }
              }
            }
            if (line.trim().isEmpty()) {
              break;
            }
          }
        }
      }
    }
    catch (IOException e) {}
    return builder.toString();
  }
  
  private List<String> runCommand(String command)
    throws IOException
  {
    List<String> list = new ArrayList();
    Process p = Runtime.getRuntime().exec(command);
    BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
    String line;
    while ((line = reader.readLine()) != null) {
      list.add(line);
    }
    reader.close();
    return list;
  }
  
  static void setProviderUrl(String url)
  {
    PROVIDER_URL_ = url;
  }
}
