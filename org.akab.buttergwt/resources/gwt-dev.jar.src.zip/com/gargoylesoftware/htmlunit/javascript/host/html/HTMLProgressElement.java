package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlProgress;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass(domClasses={HtmlProgress.class}, browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F)})
public class HTMLProgressElement
  extends HTMLElement
{
  @JsxGetter
  public double getValue()
  {
    return getAttributeAsDouble("value", 0.0D);
  }
  
  @JsxGetter
  public double getMax()
  {
    return getAttributeAsDouble("max", 1.0D);
  }
  
  private double getAttributeAsDouble(String attributeName, double defaultValue)
  {
    try
    {
      return Double.parseDouble(getDomNodeOrDie().getAttribute(attributeName));
    }
    catch (NumberFormatException e) {}
    return defaultValue;
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline-block";
  }
}
