package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.GWT;

public class SourceMapProperty
{
  static class SourceMapEnabled
    extends SourceMapProperty.SourceMapImpl
  {
    public native boolean doesBrowserSupportSourceMaps();
    
    public boolean isSourceMapGenerationOn()
    {
      return true;
    }
  }
  
  static class SourceMapEmulated
    extends SourceMapProperty.SourceMapEnabled
  {
    public boolean shouldUseSourceMaps()
    {
      return true;
    }
  }
  
  static class SourceMapImpl
  {
    public boolean doesBrowserSupportSourceMaps()
    {
      return false;
    }
    
    public boolean isSourceMapGenerationOn()
    {
      return false;
    }
    
    public boolean shouldUseSourceMaps()
    {
      return (isSourceMapGenerationOn()) && (doesBrowserSupportSourceMaps());
    }
  }
  
  private static final SourceMapImpl IMPL = (SourceMapImpl)GWT.create(SourceMapImpl.class);
  
  public static boolean doesBrowserSupportSourceMaps()
  {
    return IMPL.doesBrowserSupportSourceMaps();
  }
  
  public static boolean isDetailedDeobfuscatedStackTraceSupported()
  {
    return (!GWT.isScript()) || (shouldUseSourceMaps());
  }
  
  public static boolean isSourceMapGenerationOn()
  {
    return IMPL.isSourceMapGenerationOn();
  }
  
  public static boolean shouldUseSourceMaps()
  {
    return IMPL.shouldUseSourceMaps();
  }
}
