package com.google.gwt.core.client;

public abstract interface RunAsyncCallback
{
  public abstract void onFailure(Throwable paramThrowable);
  
  public abstract void onSuccess();
}
