package com.google.gwt.dom.builder.shared;

import com.google.gwt.safehtml.shared.SafeUri;

public class HtmlAnchorBuilder
  extends HtmlElementBuilderBase<AnchorBuilder>
  implements AnchorBuilder
{
  HtmlAnchorBuilder(HtmlBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public AnchorBuilder accessKey(String accessKey)
  {
    return (AnchorBuilder)trustedAttribute("accessKey", accessKey);
  }
  
  public AnchorBuilder href(SafeUri href)
  {
    return href(href.asString());
  }
  
  public AnchorBuilder href(String href)
  {
    return (AnchorBuilder)trustedAttribute("href", href);
  }
  
  public AnchorBuilder hreflang(String hreflang)
  {
    return (AnchorBuilder)trustedAttribute("hreflang", hreflang);
  }
  
  public AnchorBuilder name(String name)
  {
    return (AnchorBuilder)trustedAttribute("name", name);
  }
  
  public AnchorBuilder rel(String rel)
  {
    return (AnchorBuilder)trustedAttribute("rel", rel);
  }
  
  public AnchorBuilder target(String target)
  {
    return (AnchorBuilder)trustedAttribute("target", target);
  }
  
  public AnchorBuilder type(String type)
  {
    return (AnchorBuilder)trustedAttribute("type", type);
  }
}
