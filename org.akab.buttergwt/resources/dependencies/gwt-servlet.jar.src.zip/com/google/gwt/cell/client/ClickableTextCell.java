package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.text.shared.SimpleSafeHtmlRenderer;

public class ClickableTextCell
  extends AbstractSafeHtmlCell<String>
{
  public ClickableTextCell()
  {
    this(SimpleSafeHtmlRenderer.getInstance());
  }
  
  public ClickableTextCell(SafeHtmlRenderer<String> renderer)
  {
    super(renderer, new String[] { "click", "keydown" });
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    if ("click".equals(event.getType())) {
      onEnterKeyDown(context, parent, value, event, valueUpdater);
    }
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    if (valueUpdater != null) {
      valueUpdater.update(value);
    }
  }
  
  protected void render(Cell.Context context, SafeHtml value, SafeHtmlBuilder sb)
  {
    if (value != null) {
      sb.append(value);
    }
  }
}
