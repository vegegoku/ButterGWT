package com.google.gwt.codegen.server;

class PlainStringGenerator
  extends StringGenerator
{
  private boolean firstExpression = true;
  
  PlainStringGenerator(StringBuilder buf)
  {
    super(buf);
  }
  
  protected void afterExpression(StringGenerator.Type type)
  {
    this.firstExpression = false;
  }
  
  protected void beforeExpression(StringGenerator.Type type)
  {
    if (this.firstExpression)
    {
      if (type == StringGenerator.Type.PRIMITIVE) {
        this.buf.append("\"\" + ");
      }
    }
    else {
      this.buf.append(" + ");
    }
  }
  
  protected void finishOutput()
  {
    if (this.firstExpression) {
      this.buf.append("\"\"");
    }
  }
  
  protected void forceStringPrefix()
  {
    if (this.firstExpression) {
      this.buf.append("\"\" + ");
    }
  }
  
  protected void forceStringSuffix() {}
}
