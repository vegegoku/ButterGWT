package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class HeadingRoleImpl
  extends RoleImpl
  implements HeadingRole
{
  HeadingRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaLevelProperty(Element element)
  {
    return Property.LEVEL.get(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaLevelProperty(Element element)
  {
    Property.LEVEL.remove(element);
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaLevelProperty(Element element, int value)
  {
    Property.LEVEL.set(element, new Integer[] { Integer.valueOf(value) });
  }
}
