package com.gargoylesoftware.htmlunit.html;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import org.w3c.dom.DOMException;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

class NamedAttrNodeMapImpl
  implements Map<String, DomAttr>, NamedNodeMap, Serializable
{
  public static final NamedAttrNodeMapImpl EMPTY_MAP = new NamedAttrNodeMapImpl();
  private final Map<String, DomAttr> map_;
  private final List<String> attrPositions_ = new ArrayList();
  private final DomElement domNode_;
  private final boolean caseSensitive_;
  
  private NamedAttrNodeMapImpl()
  {
    this.map_ = new LinkedHashMap();
    this.domNode_ = null;
    this.caseSensitive_ = true;
  }
  
  NamedAttrNodeMapImpl(DomElement domNode, boolean caseSensitive)
  {
    this.map_ = new LinkedHashMap();
    if (domNode == null) {
      throw new IllegalArgumentException("Provided domNode can't be null.");
    }
    this.domNode_ = domNode;
    this.caseSensitive_ = caseSensitive;
  }
  
  NamedAttrNodeMapImpl(DomElement domNode, boolean caseSensitive, Map<String, DomAttr> attributes)
  {
    this(domNode, caseSensitive);
    putAll(attributes);
  }
  
  public int getLength()
  {
    return size();
  }
  
  public DomAttr getNamedItem(String name)
  {
    return get(name);
  }
  
  private String fixName(String name)
  {
    if (this.caseSensitive_) {
      return name;
    }
    return name.toLowerCase(Locale.ENGLISH);
  }
  
  public Node getNamedItemNS(String namespaceURI, String localName)
  {
    if (this.domNode_ == null) {
      return null;
    }
    return get(this.domNode_.getQualifiedName(namespaceURI, fixName(localName)));
  }
  
  public Node item(int index)
  {
    if ((index < 0) || (index >= this.attrPositions_.size())) {
      return null;
    }
    return (Node)this.map_.get(this.attrPositions_.get(index));
  }
  
  public Node removeNamedItem(String name)
    throws DOMException
  {
    return remove(name);
  }
  
  public Node removeNamedItemNS(String namespaceURI, String localName)
  {
    if (this.domNode_ == null) {
      return null;
    }
    return remove(this.domNode_.getQualifiedName(namespaceURI, fixName(localName)));
  }
  
  public DomAttr setNamedItem(Node node)
  {
    return put(node.getLocalName(), (DomAttr)node);
  }
  
  public Node setNamedItemNS(Node node)
    throws DOMException
  {
    return put(node.getNodeName(), (DomAttr)node);
  }
  
  public DomAttr put(String key, DomAttr value)
  {
    String name = fixName(key);
    DomAttr previous = (DomAttr)this.map_.put(name, value);
    if (null == previous) {
      this.attrPositions_.add(name);
    }
    return previous;
  }
  
  public DomAttr remove(Object key)
  {
    if ((key instanceof String))
    {
      String name = fixName((String)key);
      this.attrPositions_.remove(name);
      return (DomAttr)this.map_.remove(name);
    }
    return null;
  }
  
  public void clear()
  {
    this.attrPositions_.clear();
    this.map_.clear();
  }
  
  public void putAll(Map<? extends String, ? extends DomAttr> t)
  {
    for (Map.Entry<? extends String, ? extends DomAttr> entry : t.entrySet()) {
      put((String)entry.getKey(), (DomAttr)entry.getValue());
    }
  }
  
  public boolean containsKey(Object key)
  {
    if ((key instanceof String))
    {
      String name = fixName((String)key);
      return this.map_.containsKey(name);
    }
    return false;
  }
  
  public DomAttr get(Object key)
  {
    if ((key instanceof String))
    {
      String name = fixName((String)key);
      return (DomAttr)this.map_.get(name);
    }
    return null;
  }
  
  public boolean containsValue(Object value)
  {
    return this.map_.containsValue(value);
  }
  
  public Set<Map.Entry<String, DomAttr>> entrySet()
  {
    return this.map_.entrySet();
  }
  
  public boolean isEmpty()
  {
    return this.map_.isEmpty();
  }
  
  public Set<String> keySet()
  {
    return this.map_.keySet();
  }
  
  public int size()
  {
    return this.map_.size();
  }
  
  public Collection<DomAttr> values()
  {
    return this.map_.values();
  }
}
