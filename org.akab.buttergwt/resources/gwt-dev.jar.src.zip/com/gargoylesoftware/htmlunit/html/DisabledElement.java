package com.gargoylesoftware.htmlunit.html;

public abstract interface DisabledElement
{
  public abstract boolean isDisabled();
  
  public abstract String getDisabledAttribute();
}
