package com.google.gwt.codegen.server;

public abstract interface CodeGenContext
{
  public abstract JavaSourceWriterBuilder addClass(String paramString1, String paramString2);
  
  public abstract JavaSourceWriterBuilder addClass(String paramString1, String paramString2, String paramString3);
  
  public abstract void error(String paramString);
  
  public abstract void error(String paramString, Throwable paramThrowable);
  
  public abstract void error(Throwable paramThrowable);
  
  public abstract void warn(String paramString);
  
  public abstract void warn(String paramString, Throwable paramThrowable);
  
  public abstract void warn(Throwable paramThrowable);
  
  public static class AbortCodeGenException
    extends RuntimeException
  {
    public AbortCodeGenException() {}
    
    public AbortCodeGenException(String msg)
    {
      super();
    }
    
    public AbortCodeGenException(String msg, Throwable cause)
    {
      super(cause);
    }
    
    public AbortCodeGenException(Throwable cause)
    {
      super();
    }
  }
}
