package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class SeparatorRoleImpl
  extends RoleImpl
  implements SeparatorRole
{
  SeparatorRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaOrientationProperty(Element element)
  {
    return Property.ORIENTATION.get(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaOrientationProperty(Element element)
  {
    Property.ORIENTATION.remove(element);
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaOrientationProperty(Element element, OrientationValue value)
  {
    Property.ORIENTATION.set(element, new OrientationValue[] { value });
  }
}
