package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TableBuilder;
import com.google.gwt.dom.client.TableElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomTableBuilder
  extends DomElementBuilderBase<TableBuilder, TableElement>
  implements TableBuilder
{
  DomTableBuilder(DomBuilderImpl delegate)
  {
    super(delegate, false);
  }
  
  public TableBuilder border(int border)
  {
    ((TableElement)assertCanAddAttribute()).setBorder(border);
    return this;
  }
  
  public TableBuilder cellPadding(int cellPadding)
  {
    ((TableElement)assertCanAddAttribute()).setCellPadding(cellPadding);
    return this;
  }
  
  public TableBuilder cellSpacing(int cellSpacing)
  {
    ((TableElement)assertCanAddAttribute()).setCellSpacing(cellSpacing);
    return this;
  }
  
  public TableBuilder frame(String frame)
  {
    ((TableElement)assertCanAddAttribute()).setFrame(frame);
    return this;
  }
  
  public TableBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException("Table elements do not support setting inner html. Use startTBody/startTFoot/startTHead() instead to append a table section to the table.");
  }
  
  public TableBuilder rules(String rules)
  {
    ((TableElement)assertCanAddAttribute()).setRules(rules);
    return this;
  }
  
  public TableBuilder text(String text)
  {
    throw new UnsupportedOperationException("Table elements do not support setting inner html. Use startTBody/startTFoot/startTHead() instead to append a table section to the table.");
  }
  
  public TableBuilder width(String width)
  {
    ((TableElement)assertCanAddAttribute()).setWidth(width);
    return this;
  }
}
