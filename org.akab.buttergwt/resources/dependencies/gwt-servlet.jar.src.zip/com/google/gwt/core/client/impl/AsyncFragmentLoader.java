package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.core.client.RunAsyncCallback;

public class AsyncFragmentLoader
{
  public static abstract interface LoadingStrategy
  {
    public abstract void startLoadingFragment(int paramInt, AsyncFragmentLoader.LoadTerminatedHandler paramLoadTerminatedHandler);
  }
  
  public static abstract interface LoadTerminatedHandler
  {
    public abstract void loadTerminated(Throwable paramThrowable);
  }
  
  public static abstract interface Logger
  {
    public abstract void logEventProgress(String paramString1, String paramString2, int paramInt1, int paramInt2);
  }
  
  public static class LwmLabels
  {
    public static final String BEGIN = "begin";
    public static final String END = "end";
    private static final String LEFTOVERS_DOWNLOAD = "leftoversDownload";
    
    private static String downloadGroupForExclusive(int splitPoint)
    {
      return "download" + splitPoint;
    }
  }
  
  public static class StandardLogger
    implements AsyncFragmentLoader.Logger
  {
    private static native boolean stats(JavaScriptObject paramJavaScriptObject);
    
    public void logEventProgress(String eventGroup, String type, int fragment, int size)
    {
      boolean toss = (isStatsAvailable()) && (stats(createStatsEvent(eventGroup, type, fragment, size)));
    }
    
    private native JavaScriptObject createStatsEvent(String paramString1, String paramString2, int paramInt1, int paramInt2);
    
    private native boolean isStatsAvailable();
  }
  
  static class HttpDownloadFailure
    extends RuntimeException
  {
    private final int statusCode;
    
    public HttpDownloadFailure(String url, int statusCode, String statusText)
    {
      super();
      this.statusCode = statusCode;
    }
    
    public int getStatusCode()
    {
      return this.statusCode;
    }
  }
  
  static class HttpInstallFailure
    extends RuntimeException
  {
    public HttpInstallFailure(String url, String text, Throwable rootCause)
    {
      super(rootCause);
    }
  }
  
  private static class BoundedIntQueue
  {
    private final int[] array;
    private int read = 0;
    private int write = 0;
    
    public BoundedIntQueue(int maxPuts)
    {
      this.array = new int[maxPuts];
    }
    
    public void add(int x)
    {
      assert (this.write < this.array.length);
      this.array[(this.write++)] = x;
    }
    
    public void clear()
    {
      this.read = 0;
      this.write = 0;
    }
    
    public int peek()
    {
      assert (this.read < this.write);
      return this.array[this.read];
    }
    
    public int remove()
    {
      assert (this.read < this.write);
      return this.array[(this.read++)];
    }
    
    public int size()
    {
      return this.write - this.read;
    }
  }
  
  private class ResetAfterDownloadFailure
    implements AsyncFragmentLoader.LoadTerminatedHandler
  {
    private final int fragment;
    
    public ResetAfterDownloadFailure(int myFragment)
    {
      this.fragment = myFragment;
    }
    
    public void loadTerminated(Throwable reason)
    {
      if (AsyncFragmentLoader.this.fragmentLoading != this.fragment) {
        return;
      }
      AsyncFragmentLoader.LoadTerminatedHandler[] handlersToRun = AsyncFragmentLoader.this.pendingDownloadErrorHandlers;
      AsyncFragmentLoader.this.pendingDownloadErrorHandlers = new AsyncFragmentLoader.LoadTerminatedHandler[AsyncFragmentLoader.this.numEntries + 1];
      
      AsyncFragmentLoader.this.requestedExclusives.clear();
      
      AsyncFragmentLoader.this.fragmentLoading = -1;
      
      RuntimeException lastException = null;
      for (AsyncFragmentLoader.LoadTerminatedHandler handler : handlersToRun) {
        if (handler != null) {
          try
          {
            handler.loadTerminated(reason);
          }
          catch (RuntimeException e)
          {
            lastException = e;
          }
        }
      }
      if (lastException != null) {
        throw lastException;
      }
    }
  }
  
  public static AsyncFragmentLoader BROWSER_LOADER = makeBrowserLoader(1, new int[0]);
  private final OnSuccessExecutor onSuccessExecutor;
  private final Object[][] allCallbacks;
  
  public static void onLoad(int fragment)
  {
    BROWSER_LOADER.onLoadImpl(fragment);
  }
  
  public static void runAsync(int fragment, RunAsyncCallback callback)
  {
    BROWSER_LOADER.runAsyncImpl(fragment, callback);
  }
  
  private static AsyncFragmentLoader makeBrowserLoader(int numFragments, int[] initialLoad)
  {
    if (GWT.isClient()) {
      return new AsyncFragmentLoader(numFragments, initialLoad, (LoadingStrategy)GWT.create(LoadingStrategy.class), (Logger)GWT.create(Logger.class), (OnSuccessExecutor)GWT.create(OnSuccessExecutor.class));
    }
    return null;
  }
  
  private int fragmentLoading = -1;
  private final int[] initialLoadSequence;
  private final boolean[] isLoaded;
  private final LoadingStrategy loadingStrategy;
  private final Logger logger;
  private final int numEntries;
  private LoadTerminatedHandler[] pendingDownloadErrorHandlers;
  private boolean prefetching = false;
  private BoundedIntQueue prefetchQueue = null;
  private BoundedIntQueue remainingInitialFragments = null;
  private final BoundedIntQueue requestedExclusives;
  
  public AsyncFragmentLoader(int numEntries, int[] initialLoadSequence, LoadingStrategy loadingStrategy, Logger logger, OnSuccessExecutor executor)
  {
    this.numEntries = numEntries;
    this.initialLoadSequence = initialLoadSequence;
    this.loadingStrategy = loadingStrategy;
    this.logger = logger;
    this.onSuccessExecutor = executor;
    int numEntriesPlusOne = numEntries + 1;
    this.allCallbacks = new Object[numEntriesPlusOne][];
    this.requestedExclusives = new BoundedIntQueue(numEntriesPlusOne);
    this.isLoaded = new boolean[numEntriesPlusOne];
    this.pendingDownloadErrorHandlers = new LoadTerminatedHandler[numEntriesPlusOne];
  }
  
  public boolean isAlreadyLoaded(int splitPoint)
  {
    return this.isLoaded[splitPoint];
  }
  
  public void setPrefetchQueue(int... runAsyncSplitPoints)
  {
    if (this.prefetchQueue == null) {
      this.prefetchQueue = new BoundedIntQueue(this.numEntries);
    }
    this.prefetchQueue.clear();
    for (int sp : runAsyncSplitPoints) {
      this.prefetchQueue.add(sp);
    }
    startLoadingNextFragment();
  }
  
  public void startPrefetching()
  {
    this.prefetching = true;
    startLoadingNextFragment();
  }
  
  public void stopPrefetching()
  {
    this.prefetching = false;
  }
  
  void fragmentHasLoaded(int fragment)
  {
    logFragmentLoaded(fragment);
    if (fragment < this.pendingDownloadErrorHandlers.length) {
      this.pendingDownloadErrorHandlers[fragment] = null;
    }
    if (isInitial(fragment))
    {
      assert (fragment == this.remainingInitialFragments.peek());
      this.remainingInitialFragments.remove();
    }
    assert (fragment == this.fragmentLoading);
    this.fragmentLoading = -1;
    
    assert (this.isLoaded[fragment] == 0);
    this.isLoaded[fragment] = true;
    
    startLoadingNextFragment();
  }
  
  void inject(int splitPoint, LoadTerminatedHandler loadErrorHandler)
  {
    this.pendingDownloadErrorHandlers[splitPoint] = loadErrorHandler;
    if (!isInitial(splitPoint)) {
      this.requestedExclusives.add(splitPoint);
    }
    startLoadingNextFragment();
  }
  
  void leftoversFragmentHasLoaded()
  {
    onLoadImpl(leftoversFragment());
  }
  
  private boolean anyPrefetchesRequested()
  {
    return (this.prefetching) && (this.prefetchQueue != null) && (this.prefetchQueue.size() > 0);
  }
  
  private void clearRequestsAlreadyLoaded()
  {
    while ((this.requestedExclusives.size() > 0) && (this.isLoaded[this.requestedExclusives.peek()] != 0))
    {
      int offset = this.requestedExclusives.remove();
      if (offset < this.pendingDownloadErrorHandlers.length) {
        this.pendingDownloadErrorHandlers[offset] = null;
      }
    }
    if (this.prefetchQueue != null) {
      while ((this.prefetchQueue.size() > 0) && (this.isLoaded[this.prefetchQueue.peek()] != 0)) {
        this.prefetchQueue.remove();
      }
    }
  }
  
  private String downloadGroup(int fragment)
  {
    return fragment == leftoversFragment() ? "leftoversDownload" : LwmLabels.downloadGroupForExclusive(fragment);
  }
  
  private boolean haveInitialFragmentsLoaded()
  {
    return (this.remainingInitialFragments != null) && (this.remainingInitialFragments.size() == 0);
  }
  
  private void initializeRemainingInitialFragments()
  {
    if (this.remainingInitialFragments == null)
    {
      this.remainingInitialFragments = new BoundedIntQueue(this.initialLoadSequence.length + 1);
      for (int sp : this.initialLoadSequence) {
        this.remainingInitialFragments.add(sp);
      }
      this.remainingInitialFragments.add(leftoversFragment());
    }
  }
  
  private boolean isEmpty(Object[] array)
  {
    for (int i = 0; i < array.length; i++) {
      if (array[i] != null) {
        return false;
      }
    }
    return true;
  }
  
  private boolean isInitial(int splitPoint)
  {
    if (splitPoint == leftoversFragment()) {
      return true;
    }
    for (int sp : this.initialLoadSequence) {
      if (sp == splitPoint) {
        return true;
      }
    }
    return false;
  }
  
  private boolean isLoading(int splitPoint)
  {
    return this.pendingDownloadErrorHandlers[splitPoint] != null;
  }
  
  private int leftoversFragment()
  {
    return this.numEntries;
  }
  
  private void logDownloadStart(int fragment)
  {
    logEventProgress(downloadGroup(fragment), "begin", fragment, -1);
  }
  
  private void logEventProgress(String eventGroup, String type)
  {
    logEventProgress(eventGroup, type, -1, -1);
  }
  
  private void logEventProgress(String eventGroup, String type, int fragment, int size)
  {
    this.logger.logEventProgress(eventGroup, type, fragment, size);
  }
  
  private void logFragmentLoaded(int fragment)
  {
    String logGroup = downloadGroup(fragment);
    logEventProgress(logGroup, "end", fragment, -1);
  }
  
  private void onLoadImpl(int fragment)
  {
    fragmentHasLoaded(fragment);
    Object[] callbacks = this.allCallbacks[fragment];
    if (callbacks != null)
    {
      logEventProgress("runCallbacks" + fragment, "begin");
      this.allCallbacks[fragment] = null;
      for (Object callback : callbacks) {
        try
        {
          ((RunAsyncCallback)callback).onSuccess();
        }
        catch (Throwable t)
        {
          GWT.reportUncaughtException(t);
        }
      }
      logEventProgress("runCallbacks" + fragment, "end");
    }
  }
  
  private void runAsyncImpl(final int fragment, RunAsyncCallback callback)
  {
    if (this.isLoaded[fragment] != 0)
    {
      assert (this.allCallbacks[fragment] == null);
      this.onSuccessExecutor.execute(this, callback);
      return;
    }
    Object[] callbacks = this.allCallbacks[fragment];
    if (callbacks == null) {
      callbacks = this.allCallbacks[fragment] = new RunAsyncCallback[0];
    }
    assert (GWT.isScript());
    callbacks[callbacks.length] = callback;
    if (!isLoading(fragment)) {
      inject(fragment, new LoadTerminatedHandler()
      {
        public void loadTerminated(Throwable reason)
        {
          Object[] callbacks = AsyncFragmentLoader.this.allCallbacks[fragment];
          if (callbacks != null)
          {
            AsyncFragmentLoader.this.allCallbacks[fragment] = null;
            for (Object callback : callbacks) {
              ((RunAsyncCallback)callback).onFailure(reason);
            }
          }
        }
      });
    }
  }
  
  void executeOnSuccess0(RunAsyncCallback callback)
  {
    callback.onSuccess();
  }
  
  private void startLoadingFragment(int fragment)
  {
    assert (this.fragmentLoading < 0);
    this.fragmentLoading = fragment;
    logDownloadStart(fragment);
    this.loadingStrategy.startLoadingFragment(fragment, new ResetAfterDownloadFailure(fragment));
  }
  
  private void startLoadingNextFragment()
  {
    if (this.fragmentLoading >= 0) {
      return;
    }
    initializeRemainingInitialFragments();
    clearRequestsAlreadyLoaded();
    if ((isEmpty(this.pendingDownloadErrorHandlers)) && (!anyPrefetchesRequested())) {
      return;
    }
    if (this.remainingInitialFragments.size() > 0)
    {
      startLoadingFragment(this.remainingInitialFragments.peek());
      return;
    }
    assert (haveInitialFragmentsLoaded());
    if (this.requestedExclusives.size() > 0)
    {
      startLoadingFragment(this.requestedExclusives.remove());
      return;
    }
    if (anyPrefetchesRequested())
    {
      startLoadingFragment(this.prefetchQueue.remove());
      return;
    }
    if (!$assertionsDisabled) {
      throw new AssertionError();
    }
  }
}
