package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface DocumentRole
  extends StructureRole
{
  public abstract String getAriaExpandedState(Element paramElement);
  
  public abstract void removeAriaExpandedState(Element paramElement);
  
  public abstract void setAriaExpandedState(Element paramElement, ExpandedValue paramExpandedValue);
}
