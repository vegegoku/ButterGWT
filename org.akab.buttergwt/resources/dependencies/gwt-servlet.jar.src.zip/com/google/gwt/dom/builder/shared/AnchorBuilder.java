package com.google.gwt.dom.builder.shared;

import com.google.gwt.safehtml.shared.SafeUri;

public abstract interface AnchorBuilder
  extends ElementBuilderBase<AnchorBuilder>
{
  public abstract AnchorBuilder accessKey(String paramString);
  
  public abstract AnchorBuilder href(SafeUri paramSafeUri);
  
  public abstract AnchorBuilder href(String paramString);
  
  public abstract AnchorBuilder hreflang(String paramString);
  
  public abstract AnchorBuilder name(String paramString);
  
  public abstract AnchorBuilder rel(String paramString);
  
  public abstract AnchorBuilder target(String paramString);
  
  public abstract AnchorBuilder type(String paramString);
}
