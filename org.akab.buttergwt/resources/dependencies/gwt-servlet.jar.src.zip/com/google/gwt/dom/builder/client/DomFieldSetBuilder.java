package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.FieldSetBuilder;
import com.google.gwt.dom.client.FieldSetElement;

public class DomFieldSetBuilder
  extends DomElementBuilderBase<FieldSetBuilder, FieldSetElement>
  implements FieldSetBuilder
{
  DomFieldSetBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
