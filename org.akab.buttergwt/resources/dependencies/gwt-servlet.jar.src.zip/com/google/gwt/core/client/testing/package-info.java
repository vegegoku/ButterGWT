package com.google.gwt.core.client.testing;

import com.google.gwt.util.PreventSpuriousRebuilds;

@PreventSpuriousRebuilds
abstract interface package-info {}
