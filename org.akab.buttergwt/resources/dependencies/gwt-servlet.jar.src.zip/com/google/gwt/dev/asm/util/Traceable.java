package com.google.gwt.dev.asm.util;

import java.util.Map;

public abstract interface Traceable
{
  public abstract void trace(StringBuffer paramStringBuffer, Map paramMap);
}
