package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.StyleBuilder;
import com.google.gwt.dom.client.StyleElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomStyleBuilder
  extends DomElementBuilderBase<StyleBuilder, StyleElement>
  implements StyleBuilder
{
  DomStyleBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public StyleBuilder cssText(String cssText)
  {
    ((StyleElement)assertCanAddAttribute()).setCssText(cssText);
    
    getDelegate().lockCurrentElement();
    return this;
  }
  
  public StyleBuilder disabled()
  {
    ((StyleElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public StyleBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException("Style elements do not support setting inner html or inner text.  Use cssText() instead.");
  }
  
  public boolean isChildElementSupported()
  {
    return false;
  }
  
  public StyleBuilder media(String media)
  {
    ((StyleElement)assertCanAddAttribute()).setMedia(media);
    return this;
  }
  
  public StyleBuilder text(String text)
  {
    throw new UnsupportedOperationException("Style elements do not support setting inner html or inner text.  Use cssText() instead.");
  }
  
  public StyleBuilder type(String type)
  {
    ((StyleElement)assertCanAddAttribute()).setType(type);
    return this;
  }
}
