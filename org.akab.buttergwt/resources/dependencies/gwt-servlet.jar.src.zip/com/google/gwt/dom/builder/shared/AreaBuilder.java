package com.google.gwt.dom.builder.shared;

public abstract interface AreaBuilder
  extends ElementBuilderBase<AreaBuilder>
{
  public abstract AreaBuilder accessKey(String paramString);
  
  public abstract AreaBuilder alt(String paramString);
  
  public abstract AreaBuilder coords(String paramString);
  
  public abstract AreaBuilder href(String paramString);
  
  public abstract AreaBuilder shape(String paramString);
  
  public abstract AreaBuilder target(String paramString);
}
