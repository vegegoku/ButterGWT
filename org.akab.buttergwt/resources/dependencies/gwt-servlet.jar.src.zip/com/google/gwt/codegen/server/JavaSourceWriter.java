package com.google.gwt.codegen.server;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JavaSourceWriter
  extends SourceWriterBase
{
  private static final Pattern PKG_REGEX_BOTH = Pattern.compile("(com\\.google|javax?)\\..*");
  private static final Pattern PKG_REGEX_GOOGLE = Pattern.compile("com\\.google\\..*");
  private static final Pattern PKG_REGEX_JAVA = Pattern.compile("javax?\\..*");
  private final AbortablePrintWriter printWriter;
  
  public JavaSourceWriter(AbortablePrintWriter printWriter, String targetPackageName, Iterable<String> imports, boolean isClass, String classJavaDocComment, Iterable<String> annotationDeclarations, String targetClassShortName, String superClassName, Iterable<String> interfaceNames)
  {
    this.printWriter = printWriter;
    if (targetPackageName == null) {
      throw new IllegalArgumentException("Cannot supply a null package name to" + targetClassShortName);
    }
    if (targetPackageName.length() > 0) {
      println("package " + targetPackageName + ";");
    }
    writeImportGroup(imports, PKG_REGEX_GOOGLE, true);
    writeImportGroup(imports, PKG_REGEX_BOTH, false);
    writeImportGroup(imports, PKG_REGEX_JAVA, true);
    if (classJavaDocComment != null)
    {
      beginJavaDocComment();
      print(classJavaDocComment);
      endJavaDocComment();
    }
    else
    {
      println();
    }
    for (String annotation : annotationDeclarations) {
      println('@' + annotation);
    }
    if (isClass) {
      emitClassDecl(targetClassShortName, superClassName, interfaceNames);
    } else {
      emitInterfaceDecl(targetClassShortName, superClassName, interfaceNames);
    }
    println(" {");
    indent();
  }
  
  public void abort()
  {
    this.printWriter.abort();
  }
  
  public void close()
  {
    super.close();
    this.printWriter.close();
  }
  
  protected void writeString(String s)
  {
    this.printWriter.print(s);
  }
  
  private void emitClassDecl(String targetClassShortName, String superClassName, Iterable<String> interfaceNames)
  {
    print("public class " + targetClassShortName);
    if (superClassName != null) {
      print(" extends " + superClassName);
    }
    boolean first = true;
    for (String interfaceName : interfaceNames)
    {
      if (first)
      {
        print(" implements ");
        first = false;
      }
      else
      {
        print(", ");
      }
      print(interfaceName);
    }
  }
  
  private void emitInterfaceDecl(String targetClassShortName, String superClassName, Iterable<String> interfaceNames)
  {
    if (superClassName != null) {
      throw new IllegalArgumentException("Cannot set superclass name " + superClassName + " on a interface.");
    }
    print("public interface " + targetClassShortName);
    boolean first = true;
    for (String interfaceName : interfaceNames)
    {
      if (first)
      {
        print(" extends ");
        first = false;
      }
      else
      {
        print(", ");
      }
      print(interfaceName);
    }
  }
  
  private void writeImportGroup(Iterable<String> imports, Pattern regex, boolean includeMatches)
  {
    boolean firstOfGroup = true;
    for (String importEntry : imports)
    {
      Matcher matcher = regex.matcher(importEntry);
      if (matcher.matches() == includeMatches)
      {
        if (firstOfGroup)
        {
          println();
          firstOfGroup = false;
        }
        println("import " + importEntry + ";");
      }
    }
  }
}
