package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.impl.SelectableTextInput;
import com.gargoylesoftware.htmlunit.html.impl.SelectionDelegate;
import java.util.Map;

public class HtmlPasswordInput
  extends HtmlInput
  implements SelectableTextInput
{
  private final SelectionDelegate selectionDelegate_ = new SelectionDelegate(this);
  private final DoTypeProcessor doTypeProcessor_ = new DoTypeProcessor()
  {
    void typeDone(String newValue, int newCursorPosition)
    {
      if (newValue.length() > HtmlPasswordInput.this.getMaxLength()) {
        return;
      }
      HtmlPasswordInput.this.setAttribute("value", newValue);
      HtmlPasswordInput.this.setSelectionStart(newCursorPosition);
      HtmlPasswordInput.this.setSelectionEnd(newCursorPosition);
    }
  };
  
  HtmlPasswordInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  protected boolean isSubmittableByEnter()
  {
    return true;
  }
  
  public void select()
  {
    this.selectionDelegate_.select();
  }
  
  public String getSelectedText()
  {
    return this.selectionDelegate_.getSelectedText();
  }
  
  public String getText()
  {
    return getValueAttribute();
  }
  
  public void setText(String text)
  {
    setValueAttribute(text);
  }
  
  public int getSelectionStart()
  {
    return this.selectionDelegate_.getSelectionStart();
  }
  
  public void setSelectionStart(int selectionStart)
  {
    this.selectionDelegate_.setSelectionStart(selectionStart);
  }
  
  public int getSelectionEnd()
  {
    return this.selectionDelegate_.getSelectionEnd();
  }
  
  public void setSelectionEnd(int selectionEnd)
  {
    this.selectionDelegate_.setSelectionEnd(selectionEnd);
  }
  
  protected void doType(char c, boolean shiftKey, boolean ctrlKey, boolean altKey)
  {
    this.doTypeProcessor_.doType(getValueAttribute(), getSelectionStart(), getSelectionEnd(), c, shiftKey, ctrlKey, altKey);
  }
  
  protected Object clone()
    throws CloneNotSupportedException
  {
    return new HtmlPasswordInput(getNamespaceURI(), getQualifiedName(), getPage(), getAttributesMap());
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
    if ((null != getHtmlPageOrNull()) && ("value".equals(qualifiedName)))
    {
      setSelectionStart(attributeValue.length());
      setSelectionEnd(attributeValue.length());
    }
  }
  
  public void setDefaultValue(String defaultValue)
  {
    boolean modifyValue = hasFeature(BrowserVersionFeatures.HTMLINPUT_SET_DEFAULT_VALUE_UPDATES_VALUE);
    modifyValue = (modifyValue) && (getValueAttribute().equals(getDefaultValue()));
    setDefaultValue(defaultValue, modifyValue);
  }
}
