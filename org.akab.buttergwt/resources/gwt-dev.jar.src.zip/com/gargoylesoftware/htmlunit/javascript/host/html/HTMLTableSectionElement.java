package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlTableBody;
import com.gargoylesoftware.htmlunit.html.HtmlTableFooter;
import com.gargoylesoftware.htmlunit.html.HtmlTableHeader;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.RowContainer;

@JsxClass(domClasses={HtmlTableBody.class, HtmlTableHeader.class, HtmlTableFooter.class})
public class HTMLTableSectionElement
  extends RowContainer
{
  private static final String[] VALIGN_VALID_VALUES_IE = { "top", "bottom", "middle", "baseline" };
  private static final String VALIGN_DEFAULT_VALUE = "top";
  
  @JsxGetter
  public String getVAlign()
  {
    return getVAlign(getValidVAlignValues(), "top");
  }
  
  @JsxSetter
  public void setVAlign(Object vAlign)
  {
    setVAlign(vAlign, getValidVAlignValues());
  }
  
  private String[] getValidVAlignValues()
  {
    String[] valid;
    String[] valid;
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TABLE_VALIGN_SUPPORTS_IE_VALUES)) {
      valid = VALIGN_VALID_VALUES_IE;
    } else {
      valid = null;
    }
    return valid;
  }
  
  @JsxGetter
  public String getCh()
  {
    return super.getCh();
  }
  
  @JsxSetter
  public void setCh(String ch)
  {
    super.setCh(ch);
  }
  
  @JsxGetter
  public String getChOff()
  {
    return super.getChOff();
  }
  
  @JsxSetter
  public void setChOff(String chOff)
  {
    super.setChOff(chOff);
  }
  
  public String getDefaultStyleDisplay()
  {
    String tagName = getTagName();
    if ("TFOOT".equals(tagName)) {
      return "table-footer-group";
    }
    if ("THEAD".equals(tagName)) {
      return "table-header-group";
    }
    return "table-row-group";
  }
}
