package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ElementBuilder;
import com.google.gwt.dom.builder.shared.ElementBuilderFactory;
import com.google.gwt.dom.builder.shared.InputBuilder;
import com.google.gwt.dom.builder.shared.TableColBuilder;

public class DomBuilderFactory
  extends ElementBuilderFactory
{
  private static DomBuilderFactory instance;
  
  public static DomBuilderFactory get()
  {
    if (instance == null) {
      instance = new DomBuilderFactory();
    }
    return instance;
  }
  
  public DomAnchorBuilder createAnchorBuilder()
  {
    return impl().startAnchor();
  }
  
  public DomAreaBuilder createAreaBuilder()
  {
    return impl().startArea();
  }
  
  public DomAudioBuilder createAudioBuilder()
  {
    return impl().startAudio();
  }
  
  public DomBaseBuilder createBaseBuilder()
  {
    return impl().startBase();
  }
  
  public DomQuoteBuilder createBlockQuoteBuilder()
  {
    return impl().startBlockQuote();
  }
  
  public DomBodyBuilder createBodyBuilder()
  {
    return impl().startBody();
  }
  
  public DomBRBuilder createBRBuilder()
  {
    return impl().startBR();
  }
  
  public InputBuilder createButtonInputBuilder()
  {
    return impl().startButtonInput();
  }
  
  public DomCanvasBuilder createCanvasBuilder()
  {
    return impl().startCanvas();
  }
  
  public InputBuilder createCheckboxInputBuilder()
  {
    return impl().startCheckboxInput();
  }
  
  public DomTableColBuilder createColBuilder()
  {
    return impl().startCol();
  }
  
  public TableColBuilder createColGroupBuilder()
  {
    return impl().startColGroup();
  }
  
  public DomDivBuilder createDivBuilder()
  {
    return impl().startDiv();
  }
  
  public DomDListBuilder createDListBuilder()
  {
    return impl().startDList();
  }
  
  public DomFieldSetBuilder createFieldSetBuilder()
  {
    return impl().startFieldSet();
  }
  
  public InputBuilder createFileInputBuilder()
  {
    return impl().startFileInput();
  }
  
  public DomFormBuilder createFormBuilder()
  {
    return impl().startForm();
  }
  
  public DomFrameBuilder createFrameBuilder()
  {
    return impl().startFrame();
  }
  
  public DomFrameSetBuilder createFrameSetBuilder()
  {
    return impl().startFrameSet();
  }
  
  public DomHeadingBuilder createH1Builder()
  {
    return impl().startH1();
  }
  
  public DomHeadingBuilder createH2Builder()
  {
    return impl().startH2();
  }
  
  public DomHeadingBuilder createH3Builder()
  {
    return impl().startH3();
  }
  
  public DomHeadingBuilder createH4Builder()
  {
    return impl().startH4();
  }
  
  public DomHeadingBuilder createH5Builder()
  {
    return impl().startH5();
  }
  
  public DomHeadingBuilder createH6Builder()
  {
    return impl().startH6();
  }
  
  public DomHeadBuilder createHeadBuilder()
  {
    return impl().startHead();
  }
  
  public InputBuilder createHiddenInputBuilder()
  {
    return impl().startHiddenInput();
  }
  
  public DomHRBuilder createHRBuilder()
  {
    return impl().startHR();
  }
  
  public DomIFrameBuilder createIFrameBuilder()
  {
    return impl().startIFrame();
  }
  
  public DomImageBuilder createImageBuilder()
  {
    return impl().startImage();
  }
  
  public InputBuilder createImageInputBuilder()
  {
    return impl().startImageInput();
  }
  
  public DomLabelBuilder createLabelBuilder()
  {
    return impl().startLabel();
  }
  
  public DomLegendBuilder createLegendBuilder()
  {
    return impl().startLegend();
  }
  
  public DomLIBuilder createLIBuilder()
  {
    return impl().startLI();
  }
  
  public DomLinkBuilder createLinkBuilder()
  {
    return impl().startLink();
  }
  
  public DomMapBuilder createMapBuilder()
  {
    return impl().startMap();
  }
  
  public DomMetaBuilder createMetaBuilder()
  {
    return impl().startMeta();
  }
  
  public DomOListBuilder createOListBuilder()
  {
    return impl().startOList();
  }
  
  public DomOptGroupBuilder createOptGroupBuilder()
  {
    return impl().startOptGroup();
  }
  
  public DomOptionBuilder createOptionBuilder()
  {
    return impl().startOption();
  }
  
  public DomParagraphBuilder createParagraphBuilder()
  {
    return impl().startParagraph();
  }
  
  public DomParamBuilder createParamBuilder()
  {
    return impl().startParam();
  }
  
  public InputBuilder createPasswordInputBuilder()
  {
    return impl().startPasswordInput();
  }
  
  public DomPreBuilder createPreBuilder()
  {
    return impl().startPre();
  }
  
  public DomButtonBuilder createPushButtonBuilder()
  {
    return impl().startPushButton();
  }
  
  public DomQuoteBuilder createQuoteBuilder()
  {
    return impl().startQuote();
  }
  
  public InputBuilder createRadioInputBuilder(String name)
  {
    return impl().startRadioInput(name);
  }
  
  public DomButtonBuilder createResetButtonBuilder()
  {
    return impl().startResetButton();
  }
  
  public InputBuilder createResetInputBuilder()
  {
    return impl().startResetInput();
  }
  
  public DomScriptBuilder createScriptBuilder()
  {
    return impl().startScript();
  }
  
  public DomSelectBuilder createSelectBuilder()
  {
    return impl().startSelect();
  }
  
  public DomSourceBuilder createSourceBuilder()
  {
    return impl().startSource();
  }
  
  public DomSpanBuilder createSpanBuilder()
  {
    return impl().startSpan();
  }
  
  public DomStyleBuilder createStyleBuilder()
  {
    return impl().startStyle();
  }
  
  public DomButtonBuilder createSubmitButtonBuilder()
  {
    return impl().startSubmitButton();
  }
  
  public InputBuilder createSubmitInputBuilder()
  {
    return impl().startSubmitInput();
  }
  
  public DomTableBuilder createTableBuilder()
  {
    return impl().startTable();
  }
  
  public DomTableCaptionBuilder createTableCaptionBuilder()
  {
    return impl().startTableCaption();
  }
  
  public DomTableSectionBuilder createTBodyBuilder()
  {
    return impl().startTBody();
  }
  
  public DomTableCellBuilder createTDBuilder()
  {
    return impl().startTD();
  }
  
  public DomTextAreaBuilder createTextAreaBuilder()
  {
    return impl().startTextArea();
  }
  
  public InputBuilder createTextInputBuilder()
  {
    return impl().startTextInput();
  }
  
  public DomTableSectionBuilder createTFootBuilder()
  {
    return impl().startTFoot();
  }
  
  public DomTableCellBuilder createTHBuilder()
  {
    return impl().startTH();
  }
  
  public DomTableSectionBuilder createTHeadBuilder()
  {
    return impl().startTHead();
  }
  
  public DomTableRowBuilder createTRBuilder()
  {
    return impl().startTR();
  }
  
  public DomUListBuilder createUListBuilder()
  {
    return impl().startUList();
  }
  
  public DomVideoBuilder createVideoBuilder()
  {
    return impl().startVideo();
  }
  
  public ElementBuilder trustedCreate(String tagName)
  {
    return impl().trustedStart(tagName);
  }
  
  private DomBuilderImpl impl()
  {
    return new DomBuilderImpl();
  }
}
