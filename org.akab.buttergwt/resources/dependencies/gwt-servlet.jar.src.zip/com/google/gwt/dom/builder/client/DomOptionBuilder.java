package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.OptionBuilder;
import com.google.gwt.dom.client.OptionElement;

public class DomOptionBuilder
  extends DomElementBuilderBase<OptionBuilder, OptionElement>
  implements OptionBuilder
{
  DomOptionBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public OptionBuilder defaultSelected()
  {
    ((OptionElement)assertCanAddAttribute()).setDefaultSelected(true);
    return this;
  }
  
  public OptionBuilder disabled()
  {
    ((OptionElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public OptionBuilder label(String label)
  {
    ((OptionElement)assertCanAddAttribute()).setLabel(label);
    return this;
  }
  
  public OptionBuilder selected()
  {
    ((OptionElement)assertCanAddAttribute()).setSelected(true);
    return this;
  }
  
  public OptionBuilder value(String value)
  {
    ((OptionElement)assertCanAddAttribute()).setValue(value);
    return this;
  }
}
