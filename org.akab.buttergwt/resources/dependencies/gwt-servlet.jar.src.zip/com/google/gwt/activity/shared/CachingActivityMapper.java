package com.google.gwt.activity.shared;

import com.google.gwt.place.shared.Place;

public class CachingActivityMapper
  implements ActivityMapper
{
  private final ActivityMapper wrapped;
  private Place lastPlace;
  private Activity lastActivity;
  
  public CachingActivityMapper(ActivityMapper wrapped)
  {
    this.wrapped = wrapped;
  }
  
  public Activity getActivity(Place place)
  {
    if (!place.equals(this.lastPlace))
    {
      this.lastPlace = place;
      this.lastActivity = this.wrapped.getActivity(place);
    }
    return this.lastActivity;
  }
}
