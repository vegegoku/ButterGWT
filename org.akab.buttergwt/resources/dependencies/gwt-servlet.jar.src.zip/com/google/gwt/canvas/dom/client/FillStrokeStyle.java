package com.google.gwt.canvas.dom.client;

import com.google.gwt.core.client.JavaScriptObject;

public class FillStrokeStyle
  extends JavaScriptObject
{
  public static final int TYPE_CSSCOLOR = 0;
  public static final int TYPE_GRADIENT = 1;
  public static final int TYPE_PATTERN = 2;
  
  public final native int getType();
}
