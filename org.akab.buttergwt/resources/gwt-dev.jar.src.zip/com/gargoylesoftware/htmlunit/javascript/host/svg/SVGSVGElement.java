package com.gargoylesoftware.htmlunit.javascript.host.svg;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.svg.SvgSvg;

@JsxClass(domClasses={SvgSvg.class}, browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=9.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class SVGSVGElement
  extends SVGElement
{
  @JsxFunction
  public SVGMatrix createSVGMatrix()
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix getScreenCTM()
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGRect createSVGRect()
  {
    SVGRect rect = new SVGRect();
    rect.setPrototype(getPrototype(rect.getClass()));
    rect.setParentScope(getParentScope());
    return rect;
  }
}
