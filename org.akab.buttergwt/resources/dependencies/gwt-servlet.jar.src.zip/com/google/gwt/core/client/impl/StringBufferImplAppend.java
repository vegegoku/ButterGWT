package com.google.gwt.core.client.impl;

public class StringBufferImplAppend
  extends StringBufferImpl
{
  private String string = "";
  
  public void append(Object data, boolean x)
  {
    this.string += x;
  }
  
  public void append(Object data, double x)
  {
    this.string += x;
  }
  
  public void append(Object data, float x)
  {
    this.string += x;
  }
  
  public void append(Object data, int x)
  {
    this.string += x;
  }
  
  public void append(Object data, Object x)
  {
    this.string += x;
  }
  
  public void append(Object data, String x)
  {
    this.string += x;
  }
  
  public void appendNonNull(Object data, String x)
  {
    this.string += x;
  }
  
  public Object createData()
  {
    return null;
  }
  
  public int length(Object data)
  {
    return this.string.length();
  }
  
  public void replace(Object data, int start, int end, String toInsert)
  {
    this.string = (this.string.substring(0, start) + toInsert + this.string.substring(end));
  }
  
  public void reverse(Object data)
  {
    this.string = reverseString(this.string);
  }
  
  public String toString(Object data)
  {
    return this.string;
  }
}
