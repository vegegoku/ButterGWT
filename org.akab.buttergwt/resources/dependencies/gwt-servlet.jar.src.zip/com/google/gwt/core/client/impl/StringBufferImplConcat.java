package com.google.gwt.core.client.impl;

public class StringBufferImplConcat
  extends StringBufferImplArrayBase
{
  public native void append(Object paramObject, String paramString);
  
  protected native String takeString(Object paramObject);
}
