package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface Role
{
  public abstract String getAriaAtomicProperty(Element paramElement);
  
  public abstract String getAriaBusyState(Element paramElement);
  
  public abstract String getAriaControlsProperty(Element paramElement);
  
  public abstract String getAriaDescribedbyProperty(Element paramElement);
  
  public abstract String getAriaDisabledState(Element paramElement);
  
  public abstract String getAriaDropeffectProperty(Element paramElement);
  
  public abstract String getAriaFlowtoProperty(Element paramElement);
  
  public abstract String getAriaGrabbedState(Element paramElement);
  
  public abstract String getAriaHaspopupProperty(Element paramElement);
  
  public abstract String getAriaHiddenState(Element paramElement);
  
  public abstract String getAriaInvalidState(Element paramElement);
  
  public abstract String getAriaLabelledbyProperty(Element paramElement);
  
  public abstract String getAriaLabelProperty(Element paramElement);
  
  public abstract String getAriaLiveProperty(Element paramElement);
  
  public abstract String getAriaOwnsProperty(Element paramElement);
  
  public abstract String getAriaRelevantProperty(Element paramElement);
  
  public abstract String getName();
  
  public abstract String getTabindexExtraAttribute(Element paramElement);
  
  public abstract void remove(Element paramElement);
  
  public abstract void removeAriaAtomicProperty(Element paramElement);
  
  public abstract void removeAriaBusyState(Element paramElement);
  
  public abstract void removeAriaControlsProperty(Element paramElement);
  
  public abstract void removeAriaDescribedbyProperty(Element paramElement);
  
  public abstract void removeAriaDisabledState(Element paramElement);
  
  public abstract void removeAriaDropeffectProperty(Element paramElement);
  
  public abstract void removeAriaFlowtoProperty(Element paramElement);
  
  public abstract void removeAriaGrabbedState(Element paramElement);
  
  public abstract void removeAriaHaspopupProperty(Element paramElement);
  
  public abstract void removeAriaHiddenState(Element paramElement);
  
  public abstract void removeAriaInvalidState(Element paramElement);
  
  public abstract void removeAriaLabelledbyProperty(Element paramElement);
  
  public abstract void removeAriaLabelProperty(Element paramElement);
  
  public abstract void removeAriaLiveProperty(Element paramElement);
  
  public abstract void removeAriaOwnsProperty(Element paramElement);
  
  public abstract void removeAriaRelevantProperty(Element paramElement);
  
  public abstract void removeTabindexExtraAttribute(Element paramElement);
  
  public abstract void set(Element paramElement);
  
  public abstract void setAriaAtomicProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaBusyState(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaControlsProperty(Element paramElement, Id... paramVarArgs);
  
  public abstract void setAriaDescribedbyProperty(Element paramElement, Id... paramVarArgs);
  
  public abstract void setAriaDisabledState(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaDropeffectProperty(Element paramElement, DropeffectValue... paramVarArgs);
  
  public abstract void setAriaFlowtoProperty(Element paramElement, Id... paramVarArgs);
  
  public abstract void setAriaGrabbedState(Element paramElement, GrabbedValue paramGrabbedValue);
  
  public abstract void setAriaHaspopupProperty(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaHiddenState(Element paramElement, boolean paramBoolean);
  
  public abstract void setAriaInvalidState(Element paramElement, InvalidValue paramInvalidValue);
  
  public abstract void setAriaLabelledbyProperty(Element paramElement, Id... paramVarArgs);
  
  public abstract void setAriaLabelProperty(Element paramElement, String paramString);
  
  public abstract void setAriaLiveProperty(Element paramElement, LiveValue paramLiveValue);
  
  public abstract void setAriaOwnsProperty(Element paramElement, Id... paramVarArgs);
  
  public abstract void setAriaRelevantProperty(Element paramElement, RelevantValue... paramVarArgs);
  
  public abstract void setTabindexExtraAttribute(Element paramElement, int paramInt);
}
