package com.google.gwt.animation.client;

import com.google.gwt.dom.client.Element;

class AnimationSchedulerImplMozilla
  extends AnimationSchedulerImpl
{
  private class AnimationHandleImpl
    extends AnimationScheduler.AnimationHandle
  {
    private boolean canceled;
    
    private AnimationHandleImpl() {}
    
    public void cancel()
    {
      this.canceled = true;
    }
  }
  
  public AnimationScheduler.AnimationHandle requestAnimationFrame(AnimationScheduler.AnimationCallback callback, Element element)
  {
    AnimationHandleImpl handle = new AnimationHandleImpl(null);
    requestAnimationFrameImpl(callback, handle);
    return handle;
  }
  
  protected native boolean isNativelySupported();
  
  private native void requestAnimationFrameImpl(AnimationScheduler.AnimationCallback paramAnimationCallback, AnimationHandleImpl paramAnimationHandleImpl);
}
