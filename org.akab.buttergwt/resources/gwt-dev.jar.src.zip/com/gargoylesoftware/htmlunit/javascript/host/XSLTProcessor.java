package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomDocumentFragment;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLSerializer;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import com.gargoylesoftware.htmlunit.xml.XmlUtil;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMResult;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

@JsxClass
public class XSLTProcessor
  extends SimpleScriptable
{
  private Node style_;
  private Node input_;
  private Object output_;
  private Map<String, Object> parameters_ = new HashMap();
  
  @JsxConstructor
  public void jsConstructor() {}
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void importStylesheet(Node style)
  {
    this.style_ = style;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public XMLDocument transformToDocument(Node source)
  {
    XMLDocument doc = new XMLDocument();
    doc.setPrototype(getPrototype(doc.getClass()));
    doc.setParentScope(getParentScope());
    
    Object transformResult = transform(source);
    org.w3c.dom.Node node;
    org.w3c.dom.Node node;
    if ((transformResult instanceof org.w3c.dom.Node))
    {
      org.w3c.dom.Node transformedDoc = (org.w3c.dom.Node)transformResult;
      node = transformedDoc.getFirstChild();
    }
    else
    {
      node = null;
    }
    XmlPage page = new XmlPage(node, getWindow().getWebWindow());
    doc.setDomNode(page);
    return doc;
  }
  
  private Object transform(Node source)
  {
    try
    {
      Source xmlSource = new DOMSource(source.getDomNodeOrDie());
      Source xsltSource = new DOMSource(this.style_.getDomNodeOrDie());
      
      org.w3c.dom.Document containerDocument = DocumentBuilderFactory.newInstance().newDocumentBuilder().newDocument();
      
      Element containerElement = containerDocument.createElement("container");
      containerDocument.appendChild(containerElement);
      
      DOMResult result = new DOMResult(containerElement);
      
      Transformer transformer = TransformerFactory.newInstance().newTransformer(xsltSource);
      for (Map.Entry<String, Object> entry : this.parameters_.entrySet()) {
        transformer.setParameter((String)entry.getKey(), entry.getValue());
      }
      transformer.transform(xmlSource, result);
      
      org.w3c.dom.Node transformedNode = result.getNode();
      if (transformedNode.getFirstChild().getNodeType() == 1) {
        return transformedNode;
      }
      xmlSource = new DOMSource(source.getDomNodeOrDie());
      StringWriter writer = new StringWriter();
      Result streamResult = new StreamResult(writer);
      transformer.transform(xmlSource, streamResult);
      return writer.toString();
    }
    catch (Exception e)
    {
      throw Context.reportRuntimeError("Exception: " + e);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public DocumentFragment transformToFragment(Node source, Object output)
  {
    SgmlPage page = (SgmlPage)((Document)output).getDomNodeOrDie();
    
    DomDocumentFragment fragment = page.createDomDocumentFragment();
    DocumentFragment rv = new DocumentFragment();
    rv.setPrototype(getPrototype(rv.getClass()));
    rv.setParentScope(getParentScope());
    rv.setDomNode(fragment);
    
    transform(source, fragment);
    return rv;
  }
  
  private void transform(Node source, DomNode parent)
  {
    Object result = transform(source);
    if ((result instanceof org.w3c.dom.Node))
    {
      SgmlPage parentPage = parent.getPage();
      NodeList children = ((org.w3c.dom.Node)result).getChildNodes();
      for (int i = 0; i < children.getLength(); i++) {
        XmlUtil.appendChild(parentPage, parent, children.item(i));
      }
    }
    else
    {
      DomText text = new DomText(parent.getPage(), (String)result);
      parent.appendChild(text);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setParameter(String namespaceURI, String localName, Object value)
  {
    this.parameters_.put(getQualifiedName(namespaceURI, localName), value);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getParameter(String namespaceURI, String localName)
  {
    return this.parameters_.get(getQualifiedName(namespaceURI, localName));
  }
  
  private String getQualifiedName(String namespaceURI, String localName)
  {
    String qualifiedName;
    String qualifiedName;
    if ((namespaceURI != null) && (!namespaceURI.isEmpty()) && (!"null".equals(namespaceURI))) {
      qualifiedName = '{' + namespaceURI + '}' + localName;
    } else {
      qualifiedName = localName;
    }
    return qualifiedName;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setInput(Node input)
  {
    this.input_ = input;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Node getInput()
  {
    return this.input_;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOutput(Object output)
  {
    this.output_ = output;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getOutput()
  {
    return this.output_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void addParameter(String baseName, Object parameter, Object namespaceURI)
  {
    String nsString;
    String nsString;
    if ((namespaceURI instanceof String)) {
      nsString = (String)namespaceURI;
    } else {
      nsString = null;
    }
    setParameter(nsString, baseName, parameter);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void transform()
  {
    Node input = this.input_;
    SgmlPage page = input.getDomNodeOrDie().getPage();
    if ((this.output_ == null) || (!(this.output_ instanceof Node)))
    {
      DomDocumentFragment fragment = page.createDomDocumentFragment();
      DocumentFragment node = new DocumentFragment();
      node.setParentScope(getParentScope());
      node.setPrototype(getPrototype(node.getClass()));
      node.setDomNode(fragment);
      this.output_ = fragment.getScriptObject();
    }
    transform(this.input_, ((Node)this.output_).getDomNodeOrDie());
    XMLSerializer serializer = new XMLSerializer();
    serializer.setParentScope(getParentScope());
    StringBuilder output = new StringBuilder();
    for (DomNode child : ((Node)this.output_).getDomNodeOrDie().getChildren()) {
      if ((child instanceof DomText))
      {
        if (StringUtils.isNotBlank(((DomText)child).getData())) {
          output.append(((DomText)child).getData());
        }
      }
      else
      {
        String serializedString = serializer.serializeToString((Node)child.getScriptObject());
        
        output.append(serializedString.substring(0, serializedString.length() - 2));
      }
    }
    this.output_ = output.toString();
  }
}
