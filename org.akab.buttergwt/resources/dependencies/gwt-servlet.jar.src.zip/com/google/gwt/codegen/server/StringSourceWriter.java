package com.google.gwt.codegen.server;

public class StringSourceWriter
  extends SourceWriterBase
{
  private final StringBuilder buf = new StringBuilder();
  private boolean aborted = false;
  
  public void abort()
  {
    this.aborted = true;
  }
  
  public String toString()
  {
    return this.aborted ? null : this.buf.toString();
  }
  
  protected void writeString(String s)
  {
    this.buf.append(s);
  }
}
