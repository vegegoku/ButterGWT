package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlParagraph;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlParagraph.class})
public class HTMLParagraphElement
  extends HTMLElement
{
  @JsxGetter
  public String getAlign()
  {
    return getAlign(true);
  }
  
  @JsxSetter
  public void setAlign(String align)
  {
    setAlign(align, false);
  }
  
  public String getDefaultStyleDisplay()
  {
    String tagName = getTagName();
    if ("PROGRESS".equals(tagName)) {
      return "inline";
    }
    return super.getDefaultStyleDisplay();
  }
}
