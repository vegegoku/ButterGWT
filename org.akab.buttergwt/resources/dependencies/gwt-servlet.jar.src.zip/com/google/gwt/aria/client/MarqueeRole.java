package com.google.gwt.aria.client;

public abstract interface MarqueeRole
  extends SectionRole
{}
