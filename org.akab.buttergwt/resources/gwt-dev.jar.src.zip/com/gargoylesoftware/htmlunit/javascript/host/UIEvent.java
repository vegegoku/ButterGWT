package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass
public class UIEvent
  extends Event
{
  private long detail_;
  private boolean metaKey_;
  
  public UIEvent() {}
  
  public UIEvent(DomNode domNode, String type)
  {
    super(domNode, type);
  }
  
  public UIEvent(SimpleScriptable scriptable, String type)
  {
    super(scriptable, type);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public long getDetail()
  {
    return this.detail_;
  }
  
  protected void setDetail(long detail)
  {
    this.detail_ = detail;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getView()
  {
    return getWindow();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void initUIEvent(String type, boolean bubbles, boolean cancelable, Object view, int detail)
  {
    initEvent(type, bubbles, cancelable);
    
    setDetail(detail);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getMetaKey()
  {
    return this.metaKey_;
  }
  
  protected void setMetaKey(boolean metaKey)
  {
    this.metaKey_ = metaKey;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getAltKey()
  {
    return super.getAltKey();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getCtrlKey()
  {
    return super.getCtrlKey();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getShiftKey()
  {
    return super.getShiftKey();
  }
}
