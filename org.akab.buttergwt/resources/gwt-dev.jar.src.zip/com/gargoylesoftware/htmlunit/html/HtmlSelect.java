package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.w3c.dom.Node;

public class HtmlSelect
  extends HtmlElement
  implements DisabledElement, SubmittableElement, FormFieldWithNameHistory
{
  public static final String TAG_NAME = "select";
  private final String originalName_;
  private Collection<String> previousNames_ = Collections.emptySet();
  
  HtmlSelect(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    this.originalName_ = getNameAttribute();
  }
  
  protected void onAllChildrenAddedToPage(boolean postponed)
  {
    int size;
    try
    {
      size = Integer.parseInt(getSizeAttribute());
      if (size < 0)
      {
        removeAttribute("size");
        size = 0;
      }
    }
    catch (NumberFormatException e)
    {
      removeAttribute("size");
      size = 0;
    }
    if ((getSelectedOptions().isEmpty()) && (size <= 1) && (!isMultipleSelectEnabled()))
    {
      List<HtmlOption> options = getOptions();
      if (!options.isEmpty())
      {
        HtmlOption first = (HtmlOption)options.get(0);
        first.setSelectedInternal(true);
      }
    }
  }
  
  public List<HtmlOption> getSelectedOptions()
  {
    List<HtmlOption> result;
    List<HtmlOption> result;
    if (isMultipleSelectEnabled())
    {
      result = new ArrayList();
      for (HtmlElement element : getHtmlElementDescendants()) {
        if (((element instanceof HtmlOption)) && (((HtmlOption)element).isSelected())) {
          result.add((HtmlOption)element);
        }
      }
    }
    else
    {
      result = new ArrayList(1);
      HtmlOption lastSelected = null;
      for (HtmlElement element : getHtmlElementDescendants()) {
        if ((element instanceof HtmlOption))
        {
          HtmlOption option = (HtmlOption)element;
          if (option.isSelected()) {
            lastSelected = option;
          }
        }
      }
      if (lastSelected != null) {
        result.add(lastSelected);
      }
    }
    return Collections.unmodifiableList(result);
  }
  
  public List<HtmlOption> getOptions()
  {
    return Collections.unmodifiableList(getHtmlElementsByTagName("option"));
  }
  
  public HtmlOption getOption(int index)
  {
    return (HtmlOption)getHtmlElementsByTagName("option").get(index);
  }
  
  public int getOptionSize()
  {
    return getHtmlElementsByTagName("option").size();
  }
  
  public void setOptionSize(int newLength)
  {
    List<HtmlElement> elementList = getHtmlElementsByTagName("option");
    for (int i = elementList.size() - 1; i >= newLength; i--) {
      ((HtmlElement)elementList.get(i)).remove();
    }
  }
  
  public void removeOption(int index)
  {
    DomElement.ChildElementsIterator iterator = new DomElement.ChildElementsIterator(this);
    for (int i = 0; iterator.hasNext();)
    {
      DomElement element = iterator.nextElement();
      if ((element instanceof HtmlOption))
      {
        if (i == index)
        {
          element.remove();
          return;
        }
        i++;
      }
    }
  }
  
  public void replaceOption(int index, HtmlOption newOption)
  {
    DomElement.ChildElementsIterator iterator = new DomElement.ChildElementsIterator(this);
    for (int i = 0; iterator.hasNext();)
    {
      DomElement element = iterator.nextElement();
      if ((element instanceof HtmlOption))
      {
        if (i == index)
        {
          element.replace(newOption);
          return;
        }
        i++;
      }
    }
    if (newOption.isSelected()) {
      setSelectedAttribute(newOption, true);
    }
  }
  
  public void appendOption(HtmlOption newOption)
  {
    appendChild(newOption);
  }
  
  public DomNode appendChild(Node node)
  {
    DomNode response = super.appendChild(node);
    if ((node instanceof HtmlOption))
    {
      HtmlOption option = (HtmlOption)node;
      if (option.isSelected()) {
        doSelectOption(option, true);
      }
    }
    return response;
  }
  
  public <P extends Page> P setSelectedAttribute(String optionValue, boolean isSelected)
  {
    try
    {
      return setSelectedAttribute(getOptionByValue(optionValue), isSelected);
    }
    catch (ElementNotFoundException e)
    {
      if (hasFeature(BrowserVersionFeatures.SELECT_DESELECT_ALL_IF_SWITCHING_UNKNOWN)) {
        for (HtmlOption o : getSelectedOptions()) {
          o.setSelected(false);
        }
      }
    }
    return getPage();
  }
  
  public <P extends Page> P setSelectedAttribute(HtmlOption selectedOption, boolean isSelected)
  {
    return setSelectedAttribute(selectedOption, isSelected, true);
  }
  
  public <P extends Page> P setSelectedAttribute(HtmlOption selectedOption, boolean isSelected, boolean invokeOnFocus)
  {
    if ((isSelected) && (invokeOnFocus)) {
      ((HtmlPage)getPage()).setFocusedElement(this);
    }
    boolean changeSelectedState = selectedOption.isSelected() != isSelected;
    if (changeSelectedState)
    {
      doSelectOption(selectedOption, isSelected);
      HtmlInput.executeOnChangeHandlerIfAppropriate(this);
    }
    return getPage().getWebClient().getCurrentWindow().getEnclosedPage();
  }
  
  private void doSelectOption(HtmlOption selectedOption, boolean isSelected)
  {
    if (isMultipleSelectEnabled()) {
      selectedOption.setSelectedInternal(isSelected);
    } else {
      for (HtmlOption option : getOptions()) {
        option.setSelectedInternal((option == selectedOption) && (isSelected));
      }
    }
  }
  
  public NameValuePair[] getSubmitKeyValuePairs()
  {
    String name = getNameAttribute();
    
    List<HtmlOption> selectedOptions = getSelectedOptions();
    
    NameValuePair[] pairs = new NameValuePair[selectedOptions.size()];
    
    int i = 0;
    for (HtmlOption option : selectedOptions) {
      pairs[(i++)] = new NameValuePair(name, option.getValueAttribute());
    }
    return pairs;
  }
  
  boolean isValidForSubmission()
  {
    return getOptionSize() > 0;
  }
  
  public void reset()
  {
    for (HtmlOption option : getOptions()) {
      option.reset();
    }
    onAllChildrenAddedToPage(false);
  }
  
  public void setDefaultValue(String defaultValue)
  {
    setSelectedAttribute(defaultValue, true);
  }
  
  public String getDefaultValue()
  {
    List<HtmlOption> options = getSelectedOptions();
    if (options.size() > 0) {
      return ((HtmlOption)options.get(0)).getValueAttribute();
    }
    return "";
  }
  
  public void setDefaultChecked(boolean defaultChecked) {}
  
  public boolean isDefaultChecked()
  {
    return false;
  }
  
  public boolean isMultipleSelectEnabled()
  {
    return getAttribute("multiple") != ATTRIBUTE_NOT_DEFINED;
  }
  
  public HtmlOption getOptionByValue(String value)
    throws ElementNotFoundException
  {
    WebAssert.notNull("value", value);
    for (HtmlOption option : getOptions()) {
      if (option.getValueAttribute().equals(value)) {
        return option;
      }
    }
    throw new ElementNotFoundException("option", "value", value);
  }
  
  public HtmlOption getOptionByText(String text)
    throws ElementNotFoundException
  {
    WebAssert.notNull("text", text);
    for (HtmlOption option : getOptions()) {
      if (option.getText().equals(text)) {
        return option;
      }
    }
    throw new ElementNotFoundException("option", "text", text);
  }
  
  public String asText()
  {
    List<HtmlOption> options;
    List<HtmlOption> options;
    if (isMultipleSelectEnabled()) {
      options = getOptions();
    } else {
      options = getSelectedOptions();
    }
    StringBuilder buffer = new StringBuilder();
    for (Iterator<HtmlOption> i = options.iterator(); i.hasNext();)
    {
      HtmlOption currentOption = (HtmlOption)i.next();
      if (currentOption != null) {
        buffer.append(currentOption.asText());
      }
      if (i.hasNext()) {
        buffer.append("\n");
      }
    }
    return buffer.toString();
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final String getSizeAttribute()
  {
    return getAttribute("size");
  }
  
  public final String getMultipleAttribute()
  {
    return getAttribute("multiple");
  }
  
  public final String getDisabledAttribute()
  {
    return getAttribute("disabled");
  }
  
  public final boolean isDisabled()
  {
    return hasAttribute("disabled");
  }
  
  public final String getTabIndexAttribute()
  {
    return getAttribute("tabindex");
  }
  
  public final String getOnFocusAttribute()
  {
    return getAttribute("onfocus");
  }
  
  public final String getOnBlurAttribute()
  {
    return getAttribute("onblur");
  }
  
  public final String getOnChangeAttribute()
  {
    return getAttribute("onchange");
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ("name".equals(qualifiedName))
    {
      if (this.previousNames_.isEmpty()) {
        this.previousNames_ = new HashSet();
      }
      this.previousNames_.add(attributeValue);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
  
  public String getOriginalName()
  {
    return this.originalName_;
  }
  
  public Collection<String> getPreviousNames()
  {
    return this.previousNames_;
  }
}
