package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface SpinbuttonRole
  extends InputRole, RangeRole
{
  public abstract String getAriaRequiredProperty(Element paramElement);
  
  public abstract void removeAriaRequiredProperty(Element paramElement);
  
  public abstract void setAriaRequiredProperty(Element paramElement, boolean paramBoolean);
}
