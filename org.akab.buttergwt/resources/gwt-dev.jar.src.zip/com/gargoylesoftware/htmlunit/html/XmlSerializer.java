package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.util.MimeType;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

class XmlSerializer
{
  private static final String FILE_SEPARATOR = "/";
  private static final Pattern CREATE_FILE_PATTERN = Pattern.compile(".*/");
  private final StringBuilder buffer_ = new StringBuilder();
  private final StringBuilder indent_ = new StringBuilder();
  private File outputDir_;
  
  public void save(HtmlPage page, File file)
    throws IOException
  {
    String fileName = file.getName();
    if ((!fileName.endsWith(".htm")) && (!fileName.endsWith(".html"))) {
      fileName = fileName + ".html";
    }
    File outputFile = new File(file.getParentFile(), fileName);
    if (outputFile.exists()) {
      throw new IOException("File already exists: " + outputFile);
    }
    fileName = fileName.substring(0, fileName.lastIndexOf('.'));
    this.outputDir_ = new File(file.getParentFile(), fileName);
    FileUtils.writeStringToFile(outputFile, asXml(page.getDocumentElement()));
  }
  
  public String asXml(HtmlElement node)
    throws IOException
  {
    this.buffer_.setLength(0);
    this.indent_.setLength(0);
    String charsetName = null;
    if ((node.getPage() instanceof HtmlPage)) {
      charsetName = node.getPage().getPageEncoding();
    }
    if ((charsetName != null) && ((node instanceof HtmlHtml))) {
      this.buffer_.append("<?xml version=\"1.0\" encoding=\"").append(charsetName).append("\"?>").append('\n');
    }
    printXml(node);
    String response = this.buffer_.toString();
    this.buffer_.setLength(0);
    return response;
  }
  
  protected void printXml(DomElement node)
    throws IOException
  {
    if (!isExcluded(node))
    {
      boolean hasChildren = node.getFirstChild() != null;
      this.buffer_.append(this.indent_).append('<');
      printOpeningTag(node);
      if ((!hasChildren) && (!node.isEmptyXmlTagExpanded()))
      {
        this.buffer_.append("/>").append('\n');
      }
      else
      {
        this.buffer_.append(">").append('\n');
        for (DomNode child = node.getFirstChild(); child != null; child = child.getNextSibling())
        {
          this.indent_.append("  ");
          if ((child instanceof DomElement)) {
            printXml((DomElement)child);
          } else {
            this.buffer_.append(child);
          }
          this.indent_.setLength(this.indent_.length() - 2);
        }
        this.buffer_.append(this.indent_).append("</").append(node.getTagName()).append('>').append('\n');
      }
    }
  }
  
  protected void printOpeningTag(DomElement node)
    throws IOException
  {
    this.buffer_.append(node.getTagName());
    Map<String, DomAttr> attributes = readAttributes(node);
    for (Map.Entry<String, DomAttr> entry : attributes.entrySet())
    {
      this.buffer_.append(" ");
      this.buffer_.append((String)entry.getKey());
      this.buffer_.append("=\"");
      String value = ((DomAttr)entry.getValue()).getNodeValue();
      this.buffer_.append(com.gargoylesoftware.htmlunit.util.StringUtils.escapeXmlAttributeValue(value));
      this.buffer_.append('"');
    }
  }
  
  private Map<String, DomAttr> readAttributes(DomElement node)
    throws IOException
  {
    if ((node instanceof HtmlImage)) {
      return getAttributesFor((HtmlImage)node);
    }
    if ((node instanceof HtmlLink)) {
      return getAttributesFor((HtmlLink)node);
    }
    if ((node instanceof BaseFrameElement)) {
      return getAttributesFor((BaseFrameElement)node);
    }
    Map<String, DomAttr> attributes = node.getAttributesMap();
    if ((node instanceof HtmlOption))
    {
      attributes = new HashMap(attributes);
      HtmlOption option = (HtmlOption)node;
      if (option.isSelected())
      {
        if (!attributes.containsKey("selected")) {
          attributes.put("selected", new DomAttr(node.getPage(), null, "selected", "selected", false));
        }
      }
      else {
        attributes.remove("selected");
      }
    }
    return attributes;
  }
  
  private Map<String, DomAttr> getAttributesFor(BaseFrameElement frame)
    throws IOException
  {
    Map<String, DomAttr> map = createAttributesCopyWithClonedAttribute(frame, "src");
    DomAttr srcAttr = (DomAttr)map.get("src");
    if (srcAttr == null) {
      return map;
    }
    Page enclosedPage = frame.getEnclosedPage();
    String suffix = getFileExtension(enclosedPage);
    File file = createFile(srcAttr.getValue(), "." + suffix);
    if ((enclosedPage != null) && (enclosedPage.isHtmlPage()))
    {
      file.delete();
      
      ((HtmlPage)enclosedPage).save(file);
    }
    else
    {
      InputStream is = enclosedPage.getWebResponse().getContentAsStream();
      FileOutputStream fos = new FileOutputStream(file);
      IOUtils.copyLarge(is, fos);
      IOUtils.closeQuietly(is);
      IOUtils.closeQuietly(fos);
    }
    srcAttr.setValue(file.getParentFile().getName() + "/" + file.getName());
    return map;
  }
  
  private String getFileExtension(Page enclosedPage)
  {
    if ((enclosedPage != null) && (enclosedPage.isHtmlPage())) {
      return "html";
    }
    URL url = enclosedPage.getUrl();
    if (url.getPath().contains(".")) {
      return org.apache.commons.lang3.StringUtils.substringAfterLast(url.getPath(), ".");
    }
    return ".unknown";
  }
  
  protected Map<String, DomAttr> getAttributesFor(HtmlLink link)
    throws IOException
  {
    Map<String, DomAttr> map = createAttributesCopyWithClonedAttribute(link, "href");
    DomAttr hrefAttr = (DomAttr)map.get("href");
    if ((null != hrefAttr) && (org.apache.commons.lang3.StringUtils.isNotBlank(hrefAttr.getValue())))
    {
      File file = createFile(hrefAttr.getValue(), ".css");
      FileUtils.writeStringToFile(file, link.getWebResponse(true).getContentAsString());
      hrefAttr.setValue(this.outputDir_.getName() + "/" + file.getName());
    }
    return map;
  }
  
  protected Map<String, DomAttr> getAttributesFor(HtmlImage image)
    throws IOException
  {
    Map<String, DomAttr> map = createAttributesCopyWithClonedAttribute(image, "src");
    DomAttr srcAttr = (DomAttr)map.get("src");
    if ((null != srcAttr) && (org.apache.commons.lang3.StringUtils.isNotBlank(srcAttr.getValue())))
    {
      WebResponse response = image.getWebResponse(true);
      
      File file = createFile(srcAttr.getValue(), "." + getSuffix(response));
      FileUtils.copyInputStreamToFile(response.getContentAsStream(), file);
      String valueOnFileSystem = this.outputDir_.getName() + "/" + file.getName();
      srcAttr.setValue(valueOnFileSystem);
    }
    return map;
  }
  
  private String getSuffix(WebResponse response)
  {
    String url = response.getWebRequest().getUrl().toString();
    String fileName = org.apache.commons.lang3.StringUtils.substringAfterLast(org.apache.commons.lang3.StringUtils.substringBefore(url, "?"), "/");
    
    String suffix = org.apache.commons.lang3.StringUtils.substringAfterLast(fileName, ".");
    if ((suffix.length() > 1) && (suffix.length() < 5)) {
      return suffix;
    }
    return MimeType.getFileExtension(response.getContentType());
  }
  
  private Map<String, DomAttr> createAttributesCopyWithClonedAttribute(HtmlElement elt, String attrName)
  {
    Map<String, DomAttr> newMap = new HashMap(elt.getAttributesMap());
    
    DomAttr attr = (DomAttr)newMap.get(attrName);
    if (null == attr) {
      return newMap;
    }
    DomAttr clonedAttr = new DomAttr(attr.getPage(), attr.getNamespaceURI(), attr.getQualifiedName(), attr.getValue(), attr.getSpecified());
    
    newMap.put(attrName, clonedAttr);
    
    return newMap;
  }
  
  protected boolean isExcluded(DomElement element)
  {
    return element instanceof HtmlScript;
  }
  
  private File createFile(String url, String extension)
    throws IOException
  {
    String name = url.replaceFirst("/$", "");
    name = CREATE_FILE_PATTERN.matcher(name).replaceAll("");
    name = org.apache.commons.lang3.StringUtils.substringBefore(name, "?");
    name = org.apache.commons.lang3.StringUtils.substringBefore(name, ";");
    name = org.apache.commons.lang3.StringUtils.substring(name, 0, 30);
    if (!name.endsWith(extension)) {
      name = name + extension;
    }
    int counter = 0;
    for (;;)
    {
      String fileName;
      String fileName;
      if (counter != 0) {
        fileName = org.apache.commons.lang3.StringUtils.substringBeforeLast(name, ".") + "_" + counter + "." + org.apache.commons.lang3.StringUtils.substringAfterLast(name, ".");
      } else {
        fileName = name;
      }
      this.outputDir_.mkdirs();
      File f = new File(this.outputDir_, fileName);
      if (f.createNewFile()) {
        return f;
      }
      counter++;
    }
  }
}
