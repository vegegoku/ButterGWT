package com.google.gwt.core.shared;

import com.google.gwt.core.shared.impl.ThrowableTypeResolver;

public final class SerializableThrowable
  extends Throwable
{
  private String typeName;
  private boolean exactTypeKnown;
  private transient Throwable originalThrowable;
  private StackTraceElement[] dummyFieldToIncludeTheTypeInSerialization;
  
  public static SerializableThrowable fromThrowable(Throwable throwable)
  {
    if ((throwable instanceof SerializableThrowable)) {
      return (SerializableThrowable)throwable;
    }
    if (throwable != null) {
      return createSerializable(throwable);
    }
    return null;
  }
  
  public SerializableThrowable(String designatedType, String message)
  {
    super(message);
    this.typeName = designatedType;
  }
  
  public Throwable fillInStackTrace()
  {
    return this;
  }
  
  public void setDesignatedType(String typeName, boolean isExactType)
  {
    this.typeName = typeName;
    this.exactTypeKnown = isExactType;
  }
  
  public String getDesignatedType()
  {
    return this.typeName;
  }
  
  public boolean isExactDesignatedTypeKnown()
  {
    return this.exactTypeKnown;
  }
  
  public Throwable initCause(Throwable cause)
  {
    return super.initCause(fromThrowable(cause));
  }
  
  public Throwable getOriginalThrowable()
  {
    return this.originalThrowable;
  }
  
  public String toString()
  {
    String type = this.typeName + "(EXACT TYPE UNKNOWN)";
    String msg = getMessage();
    return type + ": " + msg;
  }
  
  private static SerializableThrowable createSerializable(Throwable t)
  {
    SerializableThrowable throwable = new SerializableThrowable(null, t.getMessage());
    throwable.setStackTrace(t.getStackTrace());
    throwable.initCause(t.getCause());
    throwable.originalThrowable = t;
    ThrowableTypeResolver.resolveDesignatedType(throwable, t);
    return throwable;
  }
}
