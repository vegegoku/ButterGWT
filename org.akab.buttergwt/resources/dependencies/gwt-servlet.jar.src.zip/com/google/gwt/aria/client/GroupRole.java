package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface GroupRole
  extends SectionRole
{
  public abstract String getAriaActivedescendantProperty(Element paramElement);
  
  public abstract void removeAriaActivedescendantProperty(Element paramElement);
  
  public abstract void setAriaActivedescendantProperty(Element paramElement, Id paramId);
}
