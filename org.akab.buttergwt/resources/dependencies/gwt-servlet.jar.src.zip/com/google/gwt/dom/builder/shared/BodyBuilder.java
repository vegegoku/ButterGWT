package com.google.gwt.dom.builder.shared;

public abstract interface BodyBuilder
  extends ElementBuilderBase<BodyBuilder>
{}
