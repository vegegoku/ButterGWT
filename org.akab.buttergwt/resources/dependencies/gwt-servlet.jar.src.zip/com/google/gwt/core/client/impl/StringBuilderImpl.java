package com.google.gwt.core.client.impl;

public class StringBuilderImpl
{
  private static native String join(String[] paramArrayOfString);
  
  private static native String setLength(String[] paramArrayOfString, int paramInt);
  
  public static class ImplArray
    extends StringBuilderImpl
  {
    private String[] array = new String[0];
    
    private static native void setArrayLength(String[] paramArrayOfString, int paramInt);
    
    public ImplArray()
    {
      setArrayLength(this.array, 0);
    }
    
    public native void append(String paramString);
    
    public int length()
    {
      return toString().length();
    }
    
    public void replace(int start, int end, String toInsert)
    {
      String s = toString();
      this.array = new String[] { s.substring(0, start), toInsert, s.substring(end) };
    }
    
    public native String toString();
  }
  
  public static class ImplPush
    extends StringBuilderImpl
  {
    private String[] array = new String[0];
    
    public native void append(String paramString);
    
    public int length()
    {
      return toString().length();
    }
    
    public void replace(int start, int end, String toInsert)
    {
      String s = toString();
      this.array = new String[] { s.substring(0, start), toInsert, s.substring(end) };
    }
    
    public native String toString();
  }
  
  public static class ImplStringAppend
    extends StringBuilderImpl
  {
    private String string = "";
    
    public void append(String s)
    {
      this.string += s;
    }
    
    public int length()
    {
      return this.string.length();
    }
    
    public void replace(int start, int end, String toInsert)
    {
      this.string = (this.string.substring(0, start) + toInsert + this.string.substring(end));
    }
    
    public String toString()
    {
      return this.string;
    }
  }
  
  private int arrayLen = 0;
  private String[] stringArray = new String[0];
  private int stringLength = 0;
  
  public void append(String toAppend)
  {
    if (toAppend == null) {
      toAppend = "null";
    }
    int appendLength = toAppend.length();
    if (appendLength > 0)
    {
      this.stringArray[(this.arrayLen++)] = toAppend;
      this.stringLength += appendLength;
      if (this.arrayLen > 1024)
      {
        toString();
        
        setLength(this.stringArray, 1024);
      }
    }
  }
  
  public int length()
  {
    return this.stringLength;
  }
  
  public void replace(int start, int end, String toInsert)
  {
    String s = toString();
    
    this.stringArray = new String[] { s.substring(0, start), toInsert, s.substring(end) };
    
    this.arrayLen = 3;
    
    this.stringLength += toInsert.length() - (end - start);
  }
  
  public String toString()
  {
    if (this.arrayLen != 1)
    {
      setLength(this.stringArray, this.arrayLen);
      String s = join(this.stringArray);
      
      this.stringArray = new String[] { s };
      this.arrayLen = 1;
    }
    return this.stringArray[0];
  }
}
