package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public abstract class AbstractEditableCell<C, V>
  extends AbstractCell<C>
{
  private final Map<Object, V> viewDataMap = new HashMap();
  
  public AbstractEditableCell(String... consumedEvents)
  {
    super(consumedEvents);
  }
  
  public AbstractEditableCell(Set<String> consumedEvents)
  {
    super(consumedEvents);
  }
  
  public void clearViewData(Object key)
  {
    if (key != null) {
      this.viewDataMap.remove(key);
    }
  }
  
  public V getViewData(Object key)
  {
    return key == null ? null : this.viewDataMap.get(key);
  }
  
  public abstract boolean isEditing(Cell.Context paramContext, Element paramElement, C paramC);
  
  public void setViewData(Object key, V viewData)
  {
    if (key == null) {
      return;
    }
    if (viewData == null) {
      clearViewData(key);
    } else {
      this.viewDataMap.put(key, viewData);
    }
  }
}
