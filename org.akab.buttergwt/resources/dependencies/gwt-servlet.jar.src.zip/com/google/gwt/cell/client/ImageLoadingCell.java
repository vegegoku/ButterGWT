package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.dom.client.Node;
import com.google.gwt.dom.client.Style;
import com.google.gwt.dom.client.Style.Display;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.AbstractSafeHtmlRenderer;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.user.client.ui.AbstractImagePrototype;

public class ImageLoadingCell
  extends AbstractCell<String>
{
  private static Template template;
  private final SafeHtmlRenderer<String> errorRenderer;
  private final SafeHtmlRenderer<String> imageRenderer;
  private final SafeHtmlRenderer<String> loadingRenderer;
  
  static abstract interface Resources
    extends ClientBundle
  {
    public abstract ImageResource loading();
  }
  
  public static class DefaultRenderers
    implements ImageLoadingCell.Renderers
  {
    private static SafeHtmlRenderer<String> IMAGE_RENDERER;
    private static SafeHtmlRenderer<String> LOADING_RENDERER;
    
    public DefaultRenderers()
    {
      if (IMAGE_RENDERER == null) {
        IMAGE_RENDERER = new AbstractSafeHtmlRenderer()
        {
          public SafeHtml render(String object)
          {
            return ImageLoadingCell.template.img(object);
          }
        };
      }
      if (LOADING_RENDERER == null)
      {
        ImageLoadingCell.Resources resources = (ImageLoadingCell.Resources)GWT.create(ImageLoadingCell.Resources.class);
        ImageResource res = resources.loading();
        final SafeHtml loadingHtml = AbstractImagePrototype.create(res).getSafeHtml();
        LOADING_RENDERER = new AbstractSafeHtmlRenderer()
        {
          public SafeHtml render(String object)
          {
            return loadingHtml;
          }
        };
      }
    }
    
    public SafeHtmlRenderer<String> getErrorRenderer()
    {
      return getImageRenderer();
    }
    
    public SafeHtmlRenderer<String> getImageRenderer()
    {
      return IMAGE_RENDERER;
    }
    
    public SafeHtmlRenderer<String> getLoadingRenderer()
    {
      return LOADING_RENDERER;
    }
  }
  
  public ImageLoadingCell()
  {
    this((Renderers)GWT.create(DefaultRenderers.class));
  }
  
  public ImageLoadingCell(Renderers renderers)
  {
    super(new String[] { "load", "error" });
    if (template == null) {
      template = (Template)GWT.create(Template.class);
    }
    this.errorRenderer = renderers.getErrorRenderer();
    this.imageRenderer = renderers.getImageRenderer();
    this.loadingRenderer = renderers.getLoadingRenderer();
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    String type = event.getType();
    if (("load".equals(type)) && (eventOccurredOnImage(event, parent)))
    {
      parent.getFirstChildElement().getStyle().setDisplay(Style.Display.NONE);
      
      Element imgWrapper = (Element)parent.getChild(1).cast();
      imgWrapper.getStyle().setProperty("height", "auto");
      imgWrapper.getStyle().setProperty("width", "auto");
      imgWrapper.getStyle().setProperty("overflow", "auto");
    }
    else if (("error".equals(type)) && (eventOccurredOnImage(event, parent)))
    {
      parent.getFirstChildElement().setInnerSafeHtml(this.errorRenderer.render(value));
    }
  }
  
  public void render(Cell.Context context, String value, SafeHtmlBuilder sb)
  {
    if (value != null)
    {
      sb.append(template.loading(this.loadingRenderer.render(value)));
      sb.append(template.image(this.imageRenderer.render(value)));
    }
  }
  
  private boolean eventOccurredOnImage(NativeEvent event, Element parent)
  {
    EventTarget eventTarget = event.getEventTarget();
    if (!Element.is(eventTarget)) {
      return false;
    }
    Element target = (Element)eventTarget.cast();
    
    Element imgWrapper = parent.getFirstChildElement().getNextSiblingElement();
    return imgWrapper.isOrHasChild(target);
  }
  
  static abstract interface Template
    extends SafeHtmlTemplates
  {
    @SafeHtmlTemplates.Template("<div style='height:0px;width:0px;overflow:hidden;'>{0}</div>")
    public abstract SafeHtml image(SafeHtml paramSafeHtml);
    
    @SafeHtmlTemplates.Template("<img src=\"{0}\"/>")
    public abstract SafeHtml img(String paramString);
    
    @SafeHtmlTemplates.Template("<div>{0}</div>")
    public abstract SafeHtml loading(SafeHtml paramSafeHtml);
  }
  
  public static abstract interface Renderers
  {
    public abstract SafeHtmlRenderer<String> getErrorRenderer();
    
    public abstract SafeHtmlRenderer<String> getImageRenderer();
    
    public abstract SafeHtmlRenderer<String> getLoadingRenderer();
  }
}
