package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.dom.client.Node;
import com.google.gwt.dom.client.SelectElement;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SelectionCell
  extends AbstractInputCell<String, String>
{
  private static Template template;
  private HashMap<String, Integer> indexForOption = new HashMap();
  private final List<String> options;
  
  public SelectionCell(List<String> options)
  {
    super(new String[] { "change" });
    if (template == null) {
      template = (Template)GWT.create(Template.class);
    }
    this.options = new ArrayList(options);
    int index = 0;
    for (String option : options) {
      this.indexForOption.put(option, Integer.valueOf(index++));
    }
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    String type = event.getType();
    if ("change".equals(type))
    {
      Object key = context.getKey();
      SelectElement select = (SelectElement)parent.getFirstChild().cast();
      String newValue = (String)this.options.get(select.getSelectedIndex());
      setViewData(key, newValue);
      finishEditing(parent, newValue, key, valueUpdater);
      if (valueUpdater != null) {
        valueUpdater.update(newValue);
      }
    }
  }
  
  public void render(Cell.Context context, String value, SafeHtmlBuilder sb)
  {
    Object key = context.getKey();
    String viewData = (String)getViewData(key);
    if ((viewData != null) && (viewData.equals(value)))
    {
      clearViewData(key);
      viewData = null;
    }
    int selectedIndex = getSelectedIndex(viewData == null ? value : viewData);
    sb.appendHtmlConstant("<select tabindex=\"-1\">");
    int index = 0;
    for (String option : this.options) {
      if (index++ == selectedIndex) {
        sb.append(template.selected(option));
      } else {
        sb.append(template.deselected(option));
      }
    }
    sb.appendHtmlConstant("</select>");
  }
  
  private int getSelectedIndex(String value)
  {
    Integer index = (Integer)this.indexForOption.get(value);
    if (index == null) {
      return -1;
    }
    return index.intValue();
  }
  
  static abstract interface Template
    extends SafeHtmlTemplates
  {
    @SafeHtmlTemplates.Template("<option value=\"{0}\">{0}</option>")
    public abstract SafeHtml deselected(String paramString);
    
    @SafeHtmlTemplates.Template("<option value=\"{0}\" selected=\"selected\">{0}</option>")
    public abstract SafeHtml selected(String paramString);
  }
}
