package com.gargoylesoftware.htmlunit.javascript;

import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

class FunctionWrapper
  implements Function
{
  private final Function wrapped_;
  
  FunctionWrapper(Function wrapped)
  {
    this.wrapped_ = wrapped;
  }
  
  public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
  {
    return this.wrapped_.call(cx, scope, thisObj, args);
  }
  
  public String getClassName()
  {
    return this.wrapped_.getClassName();
  }
  
  public Scriptable construct(Context cx, Scriptable scope, Object[] args)
  {
    return this.wrapped_.construct(cx, scope, args);
  }
  
  public Object get(String name, Scriptable start)
  {
    return this.wrapped_.get(name, start);
  }
  
  public Object get(int index, Scriptable start)
  {
    return this.wrapped_.get(index, start);
  }
  
  public boolean has(String name, Scriptable start)
  {
    return this.wrapped_.has(name, start);
  }
  
  public boolean has(int index, Scriptable start)
  {
    return this.wrapped_.has(index, start);
  }
  
  public void put(String name, Scriptable start, Object value)
  {
    this.wrapped_.put(name, start, value);
  }
  
  public void put(int index, Scriptable start, Object value)
  {
    this.wrapped_.put(index, start, value);
  }
  
  public void delete(String name)
  {
    this.wrapped_.delete(name);
  }
  
  public void delete(int index)
  {
    this.wrapped_.delete(index);
  }
  
  public Scriptable getPrototype()
  {
    return this.wrapped_.getPrototype();
  }
  
  public void setPrototype(Scriptable prototype)
  {
    this.wrapped_.setPrototype(prototype);
  }
  
  public Scriptable getParentScope()
  {
    return this.wrapped_.getParentScope();
  }
  
  public void setParentScope(Scriptable parent)
  {
    this.wrapped_.setParentScope(parent);
  }
  
  public Object[] getIds()
  {
    return this.wrapped_.getIds();
  }
  
  public Object getDefaultValue(Class<?> hint)
  {
    return this.wrapped_.getDefaultValue(hint);
  }
  
  public boolean hasInstance(Scriptable instance)
  {
    return this.wrapped_.hasInstance(instance);
  }
}
