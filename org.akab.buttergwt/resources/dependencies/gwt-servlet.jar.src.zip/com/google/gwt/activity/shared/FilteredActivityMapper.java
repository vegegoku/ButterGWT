package com.google.gwt.activity.shared;

import com.google.gwt.place.shared.Place;

public class FilteredActivityMapper
  implements ActivityMapper
{
  private final Filter filter;
  private final ActivityMapper wrapped;
  
  public FilteredActivityMapper(Filter filter, ActivityMapper wrapped)
  {
    this.filter = filter;
    this.wrapped = wrapped;
  }
  
  public Activity getActivity(Place place)
  {
    return this.wrapped.getActivity(this.filter.filter(place));
  }
  
  public static abstract interface Filter
  {
    public abstract Place filter(Place paramPlace);
  }
}
