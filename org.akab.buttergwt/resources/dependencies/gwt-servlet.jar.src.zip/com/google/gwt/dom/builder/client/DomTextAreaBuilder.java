package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TextAreaBuilder;
import com.google.gwt.dom.client.TextAreaElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomTextAreaBuilder
  extends DomElementBuilderBase<TextAreaBuilder, TextAreaElement>
  implements TextAreaBuilder
{
  DomTextAreaBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public TextAreaBuilder accessKey(String accessKey)
  {
    ((TextAreaElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
  
  public TextAreaBuilder cols(int cols)
  {
    ((TextAreaElement)assertCanAddAttribute()).setCols(cols);
    return this;
  }
  
  public TextAreaBuilder defaultValue(String defaultValue)
  {
    ((TextAreaElement)assertCanAddAttribute()).setDefaultValue(defaultValue);
    return this;
  }
  
  public TextAreaBuilder disabled()
  {
    ((TextAreaElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public TextAreaBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException("TextArea elements do not support setting inner html.  Use text() instead.");
  }
  
  public boolean isChildElementSupported()
  {
    return false;
  }
  
  public TextAreaBuilder name(String name)
  {
    ((TextAreaElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public TextAreaBuilder readOnly()
  {
    ((TextAreaElement)assertCanAddAttribute()).setReadOnly(true);
    return this;
  }
  
  public TextAreaBuilder rows(int rows)
  {
    ((TextAreaElement)assertCanAddAttribute()).setRows(rows);
    return this;
  }
  
  public TextAreaBuilder value(String value)
  {
    ((TextAreaElement)assertCanAddAttribute()).setValue(value);
    return this;
  }
}
