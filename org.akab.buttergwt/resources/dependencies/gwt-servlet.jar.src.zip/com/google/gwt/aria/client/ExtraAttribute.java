package com.google.gwt.aria.client;

public final class ExtraAttribute
{
  public static final Attribute<Integer> TABINDEX = new PrimitiveValueAttribute("tabIndex", "");
}
