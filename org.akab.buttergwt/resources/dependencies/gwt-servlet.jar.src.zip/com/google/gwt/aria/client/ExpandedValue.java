package com.google.gwt.aria.client;

public enum ExpandedValue
  implements AriaAttributeType
{
  TRUE,  FALSE,  UNDEFINED;
  
  private ExpandedValue() {}
  
  public static ExpandedValue of(boolean value)
  {
    return value ? TRUE : FALSE;
  }
  
  public String getAriaValue()
  {
    switch (this)
    {
    case TRUE: 
      return "true";
    case FALSE: 
      return "false";
    case UNDEFINED: 
      return "undefined";
    }
    return null;
  }
}
