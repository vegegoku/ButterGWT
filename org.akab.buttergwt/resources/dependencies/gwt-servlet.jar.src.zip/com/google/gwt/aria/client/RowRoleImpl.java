package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class RowRoleImpl
  extends RoleImpl
  implements RowRole
{
  RowRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaActivedescendantProperty(Element element)
  {
    return Property.ACTIVEDESCENDANT.get(element);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaLevelProperty(Element element)
  {
    return Property.LEVEL.get(element);
  }
  
  public String getAriaSelectedState(Element element)
  {
    return State.SELECTED.get(element);
  }
  
  public void removeAriaActivedescendantProperty(Element element)
  {
    Property.ACTIVEDESCENDANT.remove(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaLevelProperty(Element element)
  {
    Property.LEVEL.remove(element);
  }
  
  public void removeAriaSelectedState(Element element)
  {
    State.SELECTED.remove(element);
  }
  
  public void setAriaActivedescendantProperty(Element element, Id value)
  {
    Property.ACTIVEDESCENDANT.set(element, new Id[] { value });
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaLevelProperty(Element element, int value)
  {
    Property.LEVEL.set(element, new Integer[] { Integer.valueOf(value) });
  }
  
  public void setAriaSelectedState(Element element, SelectedValue value)
  {
    State.SELECTED.set(element, new SelectedValue[] { value });
  }
}
