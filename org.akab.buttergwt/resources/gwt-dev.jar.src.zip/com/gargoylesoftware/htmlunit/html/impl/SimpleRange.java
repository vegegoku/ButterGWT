package com.gargoylesoftware.htmlunit.html.impl;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomDocumentFragment;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomNodeList;
import com.gargoylesoftware.htmlunit.html.DomText;
import java.io.Serializable;
import java.util.Iterator;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ranges.Range;
import org.w3c.dom.ranges.RangeException;

public class SimpleRange
  implements Range, Serializable
{
  private Node startContainer_;
  private Node endContainer_;
  private int startOffset_;
  private int endOffset_;
  
  public SimpleRange() {}
  
  public SimpleRange(Node node)
  {
    this.startContainer_ = node;
    this.endContainer_ = node;
    this.startOffset_ = 0;
    this.endOffset_ = getMaxOffset(node);
  }
  
  public SimpleRange(Node node, int offset)
  {
    this.startContainer_ = node;
    this.endContainer_ = node;
    this.startOffset_ = offset;
    this.endOffset_ = offset;
  }
  
  public SimpleRange(Node startNode, int startOffset, Node endNode, int endOffset)
  {
    this.startContainer_ = startNode;
    this.endContainer_ = endNode;
    this.startOffset_ = startOffset;
    this.endOffset_ = endOffset;
    if ((startNode == endNode) && (startOffset > endOffset)) {
      this.endOffset_ = startOffset;
    }
  }
  
  public DomDocumentFragment cloneContents()
    throws DOMException
  {
    DomNode ancestor = (DomNode)getCommonAncestorContainer();
    if (ancestor == null) {
      return new DomDocumentFragment(null);
    }
    DomNode ancestorClone = ancestor.cloneNode(true);
    
    DomNode startClone = null;
    DomNode endClone = null;
    DomNode start = (DomNode)this.startContainer_;
    DomNode end = (DomNode)this.endContainer_;
    if (start == ancestor) {
      startClone = ancestorClone;
    }
    if (end == ancestor) {
      endClone = ancestorClone;
    }
    Iterable<DomNode> descendants = ancestor.getDescendants();
    if ((startClone == null) || (endClone == null))
    {
      Iterator<DomNode> i = descendants.iterator();
      Iterator<DomNode> ci = ancestorClone.getDescendants().iterator();
      while (i.hasNext())
      {
        DomNode e = (DomNode)i.next();
        DomNode ce = (DomNode)ci.next();
        if (start == e)
        {
          startClone = ce;
        }
        else if (end == e)
        {
          endClone = ce;
          break;
        }
      }
    }
    if (endClone == null) {
      throw Context.reportRuntimeError("Unable to find end node clone.");
    }
    deleteAfter(endClone, this.endOffset_);
    for (DomNode n = endClone; n != null; n = n.getParentNode()) {
      while (n.getNextSibling() != null) {
        n.getNextSibling().remove();
      }
    }
    if (startClone == null) {
      throw Context.reportRuntimeError("Unable to find start node clone.");
    }
    deleteBefore(startClone, this.startOffset_);
    for (DomNode n = startClone; n != null; n = n.getParentNode()) {
      while (n.getPreviousSibling() != null) {
        n.getPreviousSibling().remove();
      }
    }
    SgmlPage page = ancestor.getPage();
    DomDocumentFragment fragment = new DomDocumentFragment(page);
    if (start == end) {
      fragment.appendChild(ancestorClone);
    } else {
      for (DomNode n : ancestorClone.getChildNodes()) {
        fragment.appendChild(n);
      }
    }
    return fragment;
  }
  
  public Range cloneRange()
    throws DOMException
  {
    return new SimpleRange(this.startContainer_, this.startOffset_, this.endContainer_, this.endOffset_);
  }
  
  public void collapse(boolean toStart)
    throws DOMException
  {
    if (toStart)
    {
      this.endContainer_ = this.startContainer_;
      this.endOffset_ = this.startOffset_;
    }
    else
    {
      this.startContainer_ = this.endContainer_;
      this.startOffset_ = this.endOffset_;
    }
  }
  
  public short compareBoundaryPoints(short how, Range sourceRange)
    throws DOMException
  {
    throw new RuntimeException("Not implemented!");
  }
  
  public void deleteContents()
    throws DOMException
  {
    DomNode ancestor = (DomNode)getCommonAncestorContainer();
    if (ancestor != null) {
      deleteContents(ancestor);
    }
  }
  
  private void deleteContents(DomNode ancestor)
  {
    DomNode start;
    if (isOffsetChars(this.startContainer_))
    {
      DomNode start = (DomNode)this.startContainer_;
      String text = getText(start);
      text = text.substring(0, this.startOffset_);
      setText(start, text);
    }
    else
    {
      DomNode start;
      if (this.startContainer_.getChildNodes().getLength() > this.startOffset_) {
        start = (DomNode)this.startContainer_.getChildNodes().item(this.startOffset_);
      } else {
        start = (DomNode)this.startContainer_.getNextSibling();
      }
    }
    DomNode end;
    if (isOffsetChars(this.endContainer_))
    {
      DomNode end = (DomNode)this.endContainer_;
      String text = getText(end);
      text = text.substring(this.endOffset_);
      setText(end, text);
    }
    else
    {
      DomNode end;
      if (this.endContainer_.getChildNodes().getLength() > this.endOffset_) {
        end = (DomNode)this.endContainer_.getChildNodes().item(this.endOffset_);
      } else {
        end = (DomNode)this.endContainer_.getNextSibling();
      }
    }
    boolean foundStart = false;
    boolean started = false;
    Iterator<DomNode> i = ancestor.getDescendants().iterator();
    while (i.hasNext())
    {
      DomNode n = (DomNode)i.next();
      if (n == end) {
        break;
      }
      if (n == start) {
        foundStart = true;
      }
      if ((foundStart) && ((n != start) || (!isOffsetChars(this.startContainer_)))) {
        started = true;
      }
      if ((started) && (!n.isAncestorOf(end))) {
        i.remove();
      }
    }
  }
  
  public void detach()
    throws DOMException
  {
    throw new RuntimeException("Not implemented!");
  }
  
  public DomDocumentFragment extractContents()
    throws DOMException
  {
    DomDocumentFragment fragment = cloneContents();
    
    deleteContents();
    
    return fragment;
  }
  
  public boolean getCollapsed()
    throws DOMException
  {
    return (this.startContainer_ == this.endContainer_) && (this.startOffset_ == this.endOffset_);
  }
  
  public Node getCommonAncestorContainer()
    throws DOMException
  {
    if ((this.startContainer_ != null) && (this.endContainer_ != null)) {
      for (Node p1 = this.startContainer_; p1 != null; p1 = p1.getParentNode()) {
        for (Node p2 = this.endContainer_; p2 != null; p2 = p2.getParentNode()) {
          if (p1 == p2) {
            return p1;
          }
        }
      }
    }
    return null;
  }
  
  public Node getEndContainer()
    throws DOMException
  {
    return this.endContainer_;
  }
  
  public int getEndOffset()
    throws DOMException
  {
    return this.endOffset_;
  }
  
  public Node getStartContainer()
    throws DOMException
  {
    return this.startContainer_;
  }
  
  public int getStartOffset()
    throws DOMException
  {
    return this.startOffset_;
  }
  
  public void insertNode(Node newNode)
    throws DOMException, RangeException
  {
    if (isOffsetChars(this.startContainer_))
    {
      Node split = this.startContainer_.cloneNode(false);
      String text = getText(this.startContainer_);
      text = text.substring(0, this.startOffset_);
      setText(this.startContainer_, text);
      text = getText(split);
      text = text.substring(this.startOffset_);
      setText(split, text);
      insertNodeOrDocFragment(this.startContainer_.getParentNode(), split, this.startContainer_.getNextSibling());
      insertNodeOrDocFragment(this.startContainer_.getParentNode(), newNode, split);
    }
    else
    {
      insertNodeOrDocFragment(this.startContainer_, newNode, this.startContainer_.getChildNodes().item(this.startOffset_));
    }
    setStart(newNode, 0);
  }
  
  private static void insertNodeOrDocFragment(Node parent, Node newNode, Node refNode)
  {
    if ((newNode instanceof DocumentFragment))
    {
      DocumentFragment fragment = (DocumentFragment)newNode;
      
      NodeList childNodes = fragment.getChildNodes();
      while (childNodes.getLength() > 0)
      {
        Node item = childNodes.item(0);
        parent.insertBefore(item, refNode);
      }
    }
    else
    {
      parent.insertBefore(newNode, refNode);
    }
  }
  
  public void selectNode(Node node)
    throws RangeException, DOMException
  {
    this.startContainer_ = node;
    this.startOffset_ = 0;
    this.endContainer_ = node;
    this.endOffset_ = getMaxOffset(node);
  }
  
  public void selectNodeContents(Node node)
    throws RangeException, DOMException
  {
    this.startContainer_ = node.getFirstChild();
    this.startOffset_ = 0;
    this.endContainer_ = node.getLastChild();
    this.endOffset_ = getMaxOffset(node.getLastChild());
  }
  
  public void setEnd(Node refNode, int offset)
    throws RangeException, DOMException
  {
    this.endContainer_ = refNode;
    this.endOffset_ = offset;
  }
  
  public void setEndAfter(Node refNode)
    throws RangeException, DOMException
  {
    throw new RuntimeException("Not implemented!");
  }
  
  public void setEndBefore(Node refNode)
    throws RangeException, DOMException
  {
    throw new RuntimeException("Not implemented!");
  }
  
  public void setStart(Node refNode, int offset)
    throws RangeException, DOMException
  {
    this.startContainer_ = refNode;
    this.startOffset_ = offset;
  }
  
  public void setStartAfter(Node refNode)
    throws RangeException, DOMException
  {
    throw new RuntimeException("Not implemented!");
  }
  
  public void setStartBefore(Node refNode)
    throws RangeException, DOMException
  {
    throw new RuntimeException("Not implemented!");
  }
  
  public void surroundContents(Node newParent)
    throws DOMException, RangeException
  {
    newParent.appendChild(extractContents());
    insertNode(newParent);
    setStart(newParent, 0);
    setEnd(newParent, getMaxOffset(newParent));
  }
  
  public boolean equals(Object obj)
  {
    if (!(obj instanceof SimpleRange)) {
      return false;
    }
    SimpleRange other = (SimpleRange)obj;
    return new EqualsBuilder().append(this.startContainer_, other.startContainer_).append(this.endContainer_, other.endContainer_).append(this.startOffset_, other.startOffset_).append(this.endOffset_, other.endOffset_).isEquals();
  }
  
  public int hashCode()
  {
    return new HashCodeBuilder().append(this.startContainer_).append(this.endContainer_).append(this.startOffset_).append(this.endOffset_).toHashCode();
  }
  
  public String toString()
  {
    DomDocumentFragment fragment = cloneContents();
    if (fragment.getPage() != null) {
      return fragment.asText();
    }
    return "";
  }
  
  private static boolean isOffsetChars(Node node)
  {
    return ((node instanceof DomText)) || ((node instanceof SelectableTextInput));
  }
  
  private static String getText(Node node)
  {
    if ((node instanceof SelectableTextInput)) {
      return ((SelectableTextInput)node).getText();
    }
    return node.getTextContent();
  }
  
  private static void setText(Node node, String text)
  {
    if ((node instanceof SelectableTextInput)) {
      ((SelectableTextInput)node).setText(text);
    } else {
      node.setTextContent(text);
    }
  }
  
  private static void deleteBefore(DomNode node, int offset)
  {
    if (isOffsetChars(node))
    {
      String text = getText(node);
      if (offset < text.length()) {
        text = text.substring(offset);
      } else {
        text = "";
      }
      setText(node, text);
    }
    else
    {
      DomNodeList<DomNode> children = node.getChildNodes();
      for (int i = 0; (i < offset) && (i < children.getLength()); i++)
      {
        DomNode child = (DomNode)children.get(i);
        child.remove();
        i--;
        offset--;
      }
    }
  }
  
  private static void deleteAfter(DomNode node, int offset)
  {
    if (isOffsetChars(node))
    {
      String text = getText(node);
      if (offset < text.length())
      {
        text = text.substring(0, offset);
        setText(node, text);
      }
    }
    else
    {
      DomNodeList<DomNode> children = node.getChildNodes();
      for (int i = offset; i < children.getLength(); i++)
      {
        DomNode child = (DomNode)children.get(i);
        child.remove();
        i--;
      }
    }
  }
  
  private static int getMaxOffset(Node node)
  {
    return isOffsetChars(node) ? getText(node).length() : node.getChildNodes().getLength();
  }
}
