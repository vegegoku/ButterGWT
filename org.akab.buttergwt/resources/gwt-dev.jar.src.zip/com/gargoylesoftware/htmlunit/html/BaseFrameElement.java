package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.FailingHttpStatusCodeException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.PostponedAction;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public abstract class BaseFrameElement
  extends HtmlElement
{
  private static final Log LOG = LogFactory.getLog(BaseFrameElement.class);
  private FrameWindow enclosedWindow_;
  private boolean contentLoaded_ = false;
  private boolean createdByJavascript_ = false;
  private boolean loadSrcWhenAddedToPage_ = false;
  
  protected BaseFrameElement(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    
    init();
  }
  
  private void init()
  {
    FrameWindow enclosedWindow = null;
    try
    {
      HtmlPage htmlPage = getHtmlPageOrNull();
      if (null != htmlPage)
      {
        enclosedWindow = new FrameWindow(this);
        
        WebClient webClient = htmlPage.getWebClient();
        HtmlPage temporaryPage = (HtmlPage)webClient.getPage(enclosedWindow, new WebRequest(WebClient.URL_ABOUT_BLANK));
        
        temporaryPage.setReadyState("loading");
      }
    }
    catch (FailingHttpStatusCodeException e) {}catch (IOException e) {}
    this.enclosedWindow_ = enclosedWindow;
  }
  
  public void loadInnerPage()
    throws FailingHttpStatusCodeException
  {
    String source = getSrcAttribute();
    if (source.isEmpty()) {
      source = "about:blank";
    }
    loadInnerPageIfPossible(source);
    
    Page enclosedPage = getEnclosedPage();
    if ((enclosedPage != null) && (enclosedPage.isHtmlPage()))
    {
      final HtmlPage htmlPage = (HtmlPage)enclosedPage;
      JavaScriptEngine jsEngine = getPage().getWebClient().getJavaScriptEngine();
      if (jsEngine.isScriptRunning())
      {
        PostponedAction action = new PostponedAction(getPage())
        {
          public void execute()
            throws Exception
          {
            htmlPage.setReadyState("complete");
          }
        };
        jsEngine.addPostponedAction(action);
      }
      else
      {
        htmlPage.setReadyState("complete");
      }
    }
  }
  
  boolean isContentLoaded()
  {
    return this.contentLoaded_;
  }
  
  void setContentLoaded()
  {
    this.contentLoaded_ = true;
  }
  
  private void loadInnerPageIfPossible(String src)
    throws FailingHttpStatusCodeException
  {
    setContentLoaded();
    if (!src.isEmpty())
    {
      URL url;
      try
      {
        url = ((HtmlPage)getPage()).getFullyQualifiedUrl(src);
      }
      catch (MalformedURLException e)
      {
        notifyIncorrectness("Invalid src attribute of " + getTagName() + ": url=[" + src + "]. Ignored.");
        return;
      }
      if (isAlreadyLoadedByAncestor(url))
      {
        notifyIncorrectness("Recursive src attribute of " + getTagName() + ": url=[" + src + "]. Ignored.");
        return;
      }
      try
      {
        WebRequest request = new WebRequest(url);
        request.setAdditionalHeader("Referer", getPage().getUrl().toExternalForm());
        getPage().getEnclosingWindow().getWebClient().getPage(this.enclosedWindow_, request);
      }
      catch (IOException e)
      {
        LOG.error("IOException when getting content for " + getTagName() + ": url=[" + url + "]", e);
      }
    }
  }
  
  private boolean isAlreadyLoadedByAncestor(URL url)
  {
    WebWindow window = getPage().getEnclosingWindow();
    while (window != null)
    {
      if (url.sameFile(window.getEnclosedPage().getUrl())) {
        return true;
      }
      if (window == window.getParentWindow()) {
        window = null;
      } else {
        window = window.getParentWindow();
      }
    }
    return false;
  }
  
  public final String getLongDescAttribute()
  {
    return getAttribute("longdesc");
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final void setNameAttribute(String name)
  {
    setAttribute("name", name);
  }
  
  public final String getSrcAttribute()
  {
    return getAttribute("src");
  }
  
  public final String getFrameBorderAttribute()
  {
    return getAttribute("frameborder");
  }
  
  public final String getMarginWidthAttribute()
  {
    return getAttribute("marginwidth");
  }
  
  public final String getMarginHeightAttribute()
  {
    return getAttribute("marginheight");
  }
  
  public final String getNoResizeAttribute()
  {
    return getAttribute("noresize");
  }
  
  public final String getScrollingAttribute()
  {
    return getAttribute("scrolling");
  }
  
  public final String getOnLoadAttribute()
  {
    return getAttribute("onload");
  }
  
  public Page getEnclosedPage()
  {
    return getEnclosedWindow().getEnclosedPage();
  }
  
  public FrameWindow getEnclosedWindow()
  {
    return this.enclosedWindow_;
  }
  
  public final void setSrcAttribute(String attribute)
  {
    setAttribute("src", attribute);
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ("src".equals(qualifiedName)) {
      attributeValue = attributeValue.trim();
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
    if (("src".equals(qualifiedName)) && (!"about:blank".equals(attributeValue))) {
      if (isDirectlyAttachedToPage()) {
        loadSrc();
      } else {
        this.loadSrcWhenAddedToPage_ = true;
      }
    }
  }
  
  private void loadSrc()
  {
    this.loadSrcWhenAddedToPage_ = false;
    final String src = getSrcAttribute();
    
    JavaScriptEngine jsEngine = getPage().getWebClient().getJavaScriptEngine();
    if ((!jsEngine.isScriptRunning()) || (src.startsWith("javascript:")))
    {
      loadInnerPageIfPossible(src);
    }
    else
    {
      PostponedAction action = new PostponedAction(getPage())
      {
        public void execute()
          throws Exception
        {
          if (BaseFrameElement.this.getSrcAttribute().equals(src)) {
            BaseFrameElement.this.loadInnerPage();
          }
        }
      };
      jsEngine.addPostponedAction(action);
    }
  }
  
  protected void onAddedToPage()
  {
    super.onAddedToPage();
    if (this.loadSrcWhenAddedToPage_) {
      loadSrc();
    }
  }
  
  public void markAsCreatedByJavascript()
  {
    this.createdByJavascript_ = true;
  }
  
  public void unmarkAsCreatedByJavascript()
  {
    this.createdByJavascript_ = false;
  }
  
  public boolean wasCreatedByJavascript()
  {
    return this.createdByJavascript_;
  }
  
  public DomNode cloneNode(boolean deep)
  {
    BaseFrameElement clone = (BaseFrameElement)super.cloneNode(deep);
    clone.init();
    return clone;
  }
  
  public void remove()
  {
    super.remove();
    getEnclosedWindow().close();
  }
}
