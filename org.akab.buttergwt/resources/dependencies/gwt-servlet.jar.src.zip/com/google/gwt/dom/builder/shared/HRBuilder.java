package com.google.gwt.dom.builder.shared;

public abstract interface HRBuilder
  extends ElementBuilderBase<HRBuilder>
{}
