package org.aopalliance.intercept;

import java.lang.reflect.Constructor;

public abstract interface ConstructorInvocation
  extends Invocation
{
  public abstract Constructor getConstructor();
}
