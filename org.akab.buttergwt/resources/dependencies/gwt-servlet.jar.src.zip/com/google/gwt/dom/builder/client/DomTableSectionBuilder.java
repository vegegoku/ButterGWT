package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TableSectionBuilder;
import com.google.gwt.dom.client.TableSectionElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomTableSectionBuilder
  extends DomElementBuilderBase<TableSectionBuilder, TableSectionElement>
  implements TableSectionBuilder
{
  DomTableSectionBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public TableSectionBuilder align(String align)
  {
    ((TableSectionElement)assertCanAddAttribute()).setAlign(align);
    return this;
  }
  
  public TableSectionBuilder ch(String ch)
  {
    ((TableSectionElement)assertCanAddAttribute()).setCh(ch);
    return this;
  }
  
  public TableSectionBuilder chOff(String chOff)
  {
    ((TableSectionElement)assertCanAddAttribute()).setChOff(chOff);
    return this;
  }
  
  public TableSectionBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException("Table section elements do not support setting inner html or text. Use startTR() instead to append a table row to the section.");
  }
  
  public TableSectionBuilder text(String text)
  {
    throw new UnsupportedOperationException("Table section elements do not support setting inner html or text. Use startTR() instead to append a table row to the section.");
  }
  
  public TableSectionBuilder vAlign(String vAlign)
  {
    ((TableSectionElement)assertCanAddAttribute()).setVAlign(vAlign);
    return this;
  }
}
