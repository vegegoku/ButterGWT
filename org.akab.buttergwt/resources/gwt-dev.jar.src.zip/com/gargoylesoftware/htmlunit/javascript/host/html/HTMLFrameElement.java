package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.BaseFrameElement;
import com.gargoylesoftware.htmlunit.html.FrameWindow;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlFrame;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.WindowProxy;

@JsxClass(domClasses={HtmlFrame.class})
public class HTMLFrameElement
  extends HTMLElement
{
  @JsxGetter
  public String getSrc()
  {
    return getFrame().getSrcAttribute();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public DocumentProxy getContentDocument()
  {
    return ((Window)getFrame().getEnclosedWindow().getScriptObject()).getDocument_js();
  }
  
  @JsxGetter
  public WindowProxy getContentWindow()
  {
    return Window.getProxy(getFrame().getEnclosedWindow());
  }
  
  @JsxSetter
  public void setSrc(String src)
  {
    getFrame().setSrcAttribute(src);
  }
  
  @JsxGetter
  public String getName()
  {
    return getFrame().getNameAttribute();
  }
  
  @JsxSetter
  public void setName(String name)
  {
    getFrame().setNameAttribute(name);
  }
  
  private BaseFrameElement getFrame()
  {
    return (BaseFrameElement)getDomNodeOrDie();
  }
  
  @JsxSetter
  public void setOnload(Object eventHandler)
  {
    setEventHandlerProp("onload", eventHandler);
  }
  
  @JsxGetter
  public Object getOnload()
  {
    return getEventHandlerProp("onload");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBorder()
  {
    String border = getDomNodeOrDie().getAttribute("border");
    return border;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setBorder(String border)
  {
    getDomNodeOrDie().setAttribute("border", border);
  }
  
  protected boolean isEndTagForbidden()
  {
    return true;
  }
}
