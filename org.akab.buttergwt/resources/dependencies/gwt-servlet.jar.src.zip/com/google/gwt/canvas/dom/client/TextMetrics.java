package com.google.gwt.canvas.dom.client;

import com.google.gwt.core.client.JavaScriptObject;

public class TextMetrics
  extends JavaScriptObject
{
  public final native double getWidth();
}
