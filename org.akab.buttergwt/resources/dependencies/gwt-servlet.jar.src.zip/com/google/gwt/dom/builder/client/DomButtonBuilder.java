package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ButtonBuilder;
import com.google.gwt.dom.client.ButtonElement;

public class DomButtonBuilder
  extends DomElementBuilderBase<ButtonBuilder, ButtonElement>
  implements ButtonBuilder
{
  DomButtonBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public ButtonBuilder accessKey(String accessKey)
  {
    ((ButtonElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
  
  public ButtonBuilder disabled()
  {
    ((ButtonElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public ButtonBuilder name(String name)
  {
    ((ButtonElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public ButtonBuilder value(String value)
  {
    ((ButtonElement)assertCanAddAttribute()).setValue(value);
    return this;
  }
}
