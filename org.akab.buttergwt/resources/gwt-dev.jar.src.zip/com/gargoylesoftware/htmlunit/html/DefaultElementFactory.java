package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.configuration.JavaScriptConfiguration;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.xml.sax.Attributes;

class DefaultElementFactory
  implements ElementFactory
{
  static final List<String> SUPPORTED_TAGS_ = Arrays.asList(new String[] { "abbr", "acronym", "a", "address", "applet", "area", "audio", "bgsound", "base", "basefont", "bdo", "big", "blink", "blockquote", "body", "b", "br", "button", "canvas", "caption", "center", "cite", "code", "dfn", "dd", "del", "dir", "div", "dl", "dt", "embed", "em", "fieldset", "font", "form", "frame", "frameset", "h1", "h2", "h3", "h4", "h5", "h6", "head", "hr", "html", "iframe", "q", "img", "ins", "isindex", "i", "kbd", "label", "legend", "listing", "li", "link", "map", "marquee", "menu", "meta", "meter", "multicol", "nobr", "noembed", "noframes", "noscript", "object", "ol", "optgroup", "option", "p", "param", "plaintext", "pre", "progress", "s", "samp", "script", "select", "small", "source", "spacer", "span", "strike", "strong", "style", "sub", "sup", "table", "col", "colgroup", "tbody", "td", "th", "tr", "textarea", "tfoot", "thead", "tt", "title", "u", "ul", "var", "video", "wbr", "xmp" });
  
  public HtmlElement createElement(SgmlPage page, String tagName, Attributes attributes)
  {
    return createElementNS(page, null, tagName, attributes);
  }
  
  public HtmlElement createElementNS(SgmlPage page, String namespaceURI, String qualifiedName, Attributes attributes)
  {
    return createElementNS(page, namespaceURI, qualifiedName, attributes, false);
  }
  
  public HtmlElement createElementNS(SgmlPage page, String namespaceURI, String qualifiedName, Attributes attributes, boolean checkBrowserCompatibility)
  {
    Map<String, DomAttr> attributeMap = setAttributes(page, attributes);
    
    int colonIndex = qualifiedName.indexOf(':');
    String tagName;
    String tagName;
    if (colonIndex == -1) {
      tagName = qualifiedName.toLowerCase(Locale.ENGLISH);
    } else {
      tagName = qualifiedName.substring(colonIndex + 1).toLowerCase(Locale.ENGLISH);
    }
    HtmlElement element;
    if (tagName.equals("abbr"))
    {
      element = new HtmlAbbreviated(namespaceURI, qualifiedName, page, attributeMap);
    }
    else
    {
      HtmlElement element;
      if (tagName.equals("acronym"))
      {
        element = new HtmlAcronym(namespaceURI, qualifiedName, page, attributeMap);
      }
      else
      {
        HtmlElement element;
        if (tagName.equals("address"))
        {
          element = new HtmlAddress(namespaceURI, qualifiedName, page, attributeMap);
        }
        else
        {
          HtmlElement element;
          if (tagName.equals("a"))
          {
            element = new HtmlAnchor(namespaceURI, qualifiedName, page, attributeMap);
          }
          else
          {
            HtmlElement element;
            if (tagName.equals("applet"))
            {
              element = new HtmlApplet(namespaceURI, qualifiedName, page, attributeMap);
            }
            else
            {
              HtmlElement element;
              if (tagName.equals("area"))
              {
                element = new HtmlArea(namespaceURI, qualifiedName, page, attributeMap);
              }
              else if (tagName.equals("audio"))
              {
                HtmlElement element;
                if (page.getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.HTML5_TAGS)) {
                  element = new HtmlAudio(namespaceURI, qualifiedName, page, attributeMap);
                } else {
                  return UnknownElementFactory.instance.createElementNS(page, namespaceURI, qualifiedName, attributes);
                }
              }
              else
              {
                HtmlElement element;
                if (tagName.equals("bgsound"))
                {
                  element = new HtmlBackgroundSound(namespaceURI, qualifiedName, page, attributeMap);
                }
                else
                {
                  HtmlElement element;
                  if (tagName.equals("base"))
                  {
                    element = new HtmlBase(namespaceURI, qualifiedName, page, attributeMap);
                  }
                  else
                  {
                    HtmlElement element;
                    if (tagName.equals("basefont"))
                    {
                      HtmlElement element;
                      if (page.getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLBASEFONT_SUPPORTED)) {
                        element = new HtmlBaseFont(namespaceURI, qualifiedName, page, attributeMap);
                      } else {
                        element = new HtmlSpan(namespaceURI, qualifiedName, page, attributeMap);
                      }
                    }
                    else
                    {
                      HtmlElement element;
                      if (tagName.equals("bdo"))
                      {
                        element = new HtmlBidirectionalOverride(namespaceURI, qualifiedName, page, attributeMap);
                      }
                      else
                      {
                        HtmlElement element;
                        if (tagName.equals("big"))
                        {
                          element = new HtmlBig(namespaceURI, qualifiedName, page, attributeMap);
                        }
                        else
                        {
                          HtmlElement element;
                          if (tagName.equals("blink"))
                          {
                            element = new HtmlBlink(namespaceURI, qualifiedName, page, attributeMap);
                          }
                          else
                          {
                            HtmlElement element;
                            if (tagName.equals("blockquote"))
                            {
                              element = new HtmlBlockQuote(namespaceURI, qualifiedName, page, attributeMap);
                            }
                            else
                            {
                              HtmlElement element;
                              if (tagName.equals("body"))
                              {
                                element = new HtmlBody(namespaceURI, qualifiedName, page, attributeMap, false);
                              }
                              else
                              {
                                HtmlElement element;
                                if (tagName.equals("b"))
                                {
                                  element = new HtmlBold(namespaceURI, qualifiedName, page, attributeMap);
                                }
                                else
                                {
                                  HtmlElement element;
                                  if (tagName.equals("br"))
                                  {
                                    element = new HtmlBreak(namespaceURI, qualifiedName, page, attributeMap);
                                  }
                                  else
                                  {
                                    HtmlElement element;
                                    if (tagName.equals("button"))
                                    {
                                      element = new HtmlButton(namespaceURI, qualifiedName, page, attributeMap);
                                    }
                                    else if (tagName.equals("canvas"))
                                    {
                                      HtmlElement element;
                                      if (page.getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.CANVAS)) {
                                        element = new HtmlCanvas(namespaceURI, qualifiedName, page, attributeMap);
                                      } else {
                                        return UnknownElementFactory.instance.createElementNS(page, namespaceURI, qualifiedName, attributes);
                                      }
                                    }
                                    else
                                    {
                                      HtmlElement element;
                                      if (tagName.equals("caption"))
                                      {
                                        element = new HtmlCaption(namespaceURI, qualifiedName, page, attributeMap);
                                      }
                                      else
                                      {
                                        HtmlElement element;
                                        if (tagName.equals("center"))
                                        {
                                          element = new HtmlCenter(namespaceURI, qualifiedName, page, attributeMap);
                                        }
                                        else
                                        {
                                          HtmlElement element;
                                          if (tagName.equals("cite"))
                                          {
                                            element = new HtmlCitation(namespaceURI, qualifiedName, page, attributeMap);
                                          }
                                          else
                                          {
                                            HtmlElement element;
                                            if (tagName.equals("code"))
                                            {
                                              element = new HtmlCode(namespaceURI, qualifiedName, page, attributeMap);
                                            }
                                            else
                                            {
                                              HtmlElement element;
                                              if (tagName.equals("dfn"))
                                              {
                                                element = new HtmlDefinition(namespaceURI, qualifiedName, page, attributeMap);
                                              }
                                              else
                                              {
                                                HtmlElement element;
                                                if (tagName.equals("dd"))
                                                {
                                                  element = new HtmlDefinitionDescription(namespaceURI, qualifiedName, page, attributeMap);
                                                }
                                                else
                                                {
                                                  HtmlElement element;
                                                  if (tagName.equals("dl"))
                                                  {
                                                    element = new HtmlDefinitionList(namespaceURI, qualifiedName, page, attributeMap);
                                                  }
                                                  else
                                                  {
                                                    HtmlElement element;
                                                    if (tagName.equals("dt"))
                                                    {
                                                      element = new HtmlDefinitionTerm(namespaceURI, qualifiedName, page, attributeMap);
                                                    }
                                                    else
                                                    {
                                                      HtmlElement element;
                                                      if (tagName.equals("del"))
                                                      {
                                                        element = new HtmlDeletedText(namespaceURI, qualifiedName, page, attributeMap);
                                                      }
                                                      else
                                                      {
                                                        HtmlElement element;
                                                        if (tagName.equals("div"))
                                                        {
                                                          element = new HtmlDivision(namespaceURI, qualifiedName, page, attributeMap);
                                                        }
                                                        else
                                                        {
                                                          HtmlElement element;
                                                          if (tagName.equals("embed"))
                                                          {
                                                            element = new HtmlEmbed(namespaceURI, qualifiedName, page, attributeMap);
                                                          }
                                                          else
                                                          {
                                                            HtmlElement element;
                                                            if (tagName.equals("em"))
                                                            {
                                                              element = new HtmlEmphasis(namespaceURI, qualifiedName, page, attributeMap);
                                                            }
                                                            else
                                                            {
                                                              HtmlElement element;
                                                              if (tagName.equals("fieldset"))
                                                              {
                                                                element = new HtmlFieldSet(namespaceURI, qualifiedName, page, attributeMap);
                                                              }
                                                              else
                                                              {
                                                                HtmlElement element;
                                                                if (tagName.equals("font"))
                                                                {
                                                                  element = new HtmlFont(namespaceURI, qualifiedName, page, attributeMap);
                                                                }
                                                                else
                                                                {
                                                                  HtmlElement element;
                                                                  if (tagName.equals("form"))
                                                                  {
                                                                    element = new HtmlForm(namespaceURI, qualifiedName, page, attributeMap);
                                                                  }
                                                                  else
                                                                  {
                                                                    HtmlElement element;
                                                                    if (tagName.equals("frame"))
                                                                    {
                                                                      if (attributeMap != null)
                                                                      {
                                                                        DomAttr srcAttribute = (DomAttr)attributeMap.get("src");
                                                                        if (srcAttribute != null) {
                                                                          srcAttribute.setValue(srcAttribute.getValue().trim());
                                                                        }
                                                                      }
                                                                      element = new HtmlFrame(namespaceURI, qualifiedName, page, attributeMap);
                                                                    }
                                                                    else
                                                                    {
                                                                      HtmlElement element;
                                                                      if (tagName.equals("frameset"))
                                                                      {
                                                                        element = new HtmlFrameSet(namespaceURI, qualifiedName, page, attributeMap);
                                                                      }
                                                                      else
                                                                      {
                                                                        HtmlElement element;
                                                                        if (tagName.equals("head"))
                                                                        {
                                                                          element = new HtmlHead(namespaceURI, qualifiedName, page, attributeMap);
                                                                        }
                                                                        else
                                                                        {
                                                                          HtmlElement element;
                                                                          if (tagName.equals("h1"))
                                                                          {
                                                                            element = new HtmlHeading1(namespaceURI, qualifiedName, page, attributeMap);
                                                                          }
                                                                          else
                                                                          {
                                                                            HtmlElement element;
                                                                            if (tagName.equals("h2"))
                                                                            {
                                                                              element = new HtmlHeading2(namespaceURI, qualifiedName, page, attributeMap);
                                                                            }
                                                                            else
                                                                            {
                                                                              HtmlElement element;
                                                                              if (tagName.equals("h3"))
                                                                              {
                                                                                element = new HtmlHeading3(namespaceURI, qualifiedName, page, attributeMap);
                                                                              }
                                                                              else
                                                                              {
                                                                                HtmlElement element;
                                                                                if (tagName.equals("h4"))
                                                                                {
                                                                                  element = new HtmlHeading4(namespaceURI, qualifiedName, page, attributeMap);
                                                                                }
                                                                                else
                                                                                {
                                                                                  HtmlElement element;
                                                                                  if (tagName.equals("h5"))
                                                                                  {
                                                                                    element = new HtmlHeading5(namespaceURI, qualifiedName, page, attributeMap);
                                                                                  }
                                                                                  else
                                                                                  {
                                                                                    HtmlElement element;
                                                                                    if (tagName.equals("h6"))
                                                                                    {
                                                                                      element = new HtmlHeading6(namespaceURI, qualifiedName, page, attributeMap);
                                                                                    }
                                                                                    else
                                                                                    {
                                                                                      HtmlElement element;
                                                                                      if (tagName.equals("hr"))
                                                                                      {
                                                                                        element = new HtmlHorizontalRule(namespaceURI, qualifiedName, page, attributeMap);
                                                                                      }
                                                                                      else
                                                                                      {
                                                                                        HtmlElement element;
                                                                                        if (tagName.equals("html"))
                                                                                        {
                                                                                          element = new HtmlHtml(namespaceURI, qualifiedName, page, attributeMap);
                                                                                        }
                                                                                        else
                                                                                        {
                                                                                          HtmlElement element;
                                                                                          if (tagName.equals("img"))
                                                                                          {
                                                                                            element = new HtmlImage(namespaceURI, qualifiedName, page, attributeMap);
                                                                                          }
                                                                                          else
                                                                                          {
                                                                                            HtmlElement element;
                                                                                            if (tagName.equals("iframe"))
                                                                                            {
                                                                                              if (attributeMap != null)
                                                                                              {
                                                                                                DomAttr srcAttribute = (DomAttr)attributeMap.get("src");
                                                                                                if (srcAttribute != null) {
                                                                                                  srcAttribute.setValue(srcAttribute.getValue().trim());
                                                                                                }
                                                                                              }
                                                                                              element = new HtmlInlineFrame(namespaceURI, qualifiedName, page, attributeMap);
                                                                                            }
                                                                                            else
                                                                                            {
                                                                                              HtmlElement element;
                                                                                              if (tagName.equals("q"))
                                                                                              {
                                                                                                element = new HtmlInlineQuotation(namespaceURI, qualifiedName, page, attributeMap);
                                                                                              }
                                                                                              else
                                                                                              {
                                                                                                HtmlElement element;
                                                                                                if (tagName.equals("ins"))
                                                                                                {
                                                                                                  element = new HtmlInsertedText(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                }
                                                                                                else
                                                                                                {
                                                                                                  HtmlElement element;
                                                                                                  if (tagName.equals("isindex"))
                                                                                                  {
                                                                                                    element = new HtmlIsIndex(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                  }
                                                                                                  else
                                                                                                  {
                                                                                                    HtmlElement element;
                                                                                                    if (tagName.equals("i"))
                                                                                                    {
                                                                                                      element = new HtmlItalic(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                    }
                                                                                                    else
                                                                                                    {
                                                                                                      HtmlElement element;
                                                                                                      if (tagName.equals("kbd"))
                                                                                                      {
                                                                                                        element = new HtmlKeyboard(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                      }
                                                                                                      else
                                                                                                      {
                                                                                                        HtmlElement element;
                                                                                                        if (tagName.equals("label"))
                                                                                                        {
                                                                                                          element = new HtmlLabel(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                          HtmlElement element;
                                                                                                          if (tagName.equals("legend"))
                                                                                                          {
                                                                                                            element = new HtmlLegend(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                          }
                                                                                                          else
                                                                                                          {
                                                                                                            HtmlElement element;
                                                                                                            if (tagName.equals("link"))
                                                                                                            {
                                                                                                              element = new HtmlLink(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                            }
                                                                                                            else
                                                                                                            {
                                                                                                              HtmlElement element;
                                                                                                              if (tagName.equals("listing"))
                                                                                                              {
                                                                                                                element = new HtmlListing(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                              }
                                                                                                              else
                                                                                                              {
                                                                                                                HtmlElement element;
                                                                                                                if (tagName.equals("li"))
                                                                                                                {
                                                                                                                  element = new HtmlListItem(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                }
                                                                                                                else
                                                                                                                {
                                                                                                                  HtmlElement element;
                                                                                                                  if (tagName.equals("map"))
                                                                                                                  {
                                                                                                                    element = new HtmlMap(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                  }
                                                                                                                  else
                                                                                                                  {
                                                                                                                    HtmlElement element;
                                                                                                                    if (tagName.equals("marquee"))
                                                                                                                    {
                                                                                                                      element = new HtmlMarquee(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                    }
                                                                                                                    else
                                                                                                                    {
                                                                                                                      HtmlElement element;
                                                                                                                      if (tagName.equals("menu"))
                                                                                                                      {
                                                                                                                        element = new HtmlMenu(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                      }
                                                                                                                      else
                                                                                                                      {
                                                                                                                        HtmlElement element;
                                                                                                                        if (tagName.equals("meta"))
                                                                                                                        {
                                                                                                                          element = new HtmlMeta(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                        }
                                                                                                                        else if (tagName.equals("meter"))
                                                                                                                        {
                                                                                                                          HtmlElement element;
                                                                                                                          if (page.getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.HTML5_TAGS)) {
                                                                                                                            element = new HtmlMeter(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                          } else {
                                                                                                                            return UnknownElementFactory.instance.createElementNS(page, namespaceURI, qualifiedName, attributes);
                                                                                                                          }
                                                                                                                        }
                                                                                                                        else
                                                                                                                        {
                                                                                                                          HtmlElement element;
                                                                                                                          if (tagName.equals("multicol"))
                                                                                                                          {
                                                                                                                            element = new HtmlMultiColumn(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                          }
                                                                                                                          else
                                                                                                                          {
                                                                                                                            HtmlElement element;
                                                                                                                            if (tagName.equals("nobr"))
                                                                                                                            {
                                                                                                                              element = new HtmlNoBreak(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                            }
                                                                                                                            else
                                                                                                                            {
                                                                                                                              HtmlElement element;
                                                                                                                              if (tagName.equals("noembed"))
                                                                                                                              {
                                                                                                                                element = new HtmlNoEmbed(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                              }
                                                                                                                              else
                                                                                                                              {
                                                                                                                                HtmlElement element;
                                                                                                                                if (tagName.equals("noframes"))
                                                                                                                                {
                                                                                                                                  element = new HtmlNoFrames(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                }
                                                                                                                                else
                                                                                                                                {
                                                                                                                                  HtmlElement element;
                                                                                                                                  if (tagName.equals("noscript"))
                                                                                                                                  {
                                                                                                                                    element = new HtmlNoScript(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                  }
                                                                                                                                  else
                                                                                                                                  {
                                                                                                                                    HtmlElement element;
                                                                                                                                    if (tagName.equals("object"))
                                                                                                                                    {
                                                                                                                                      element = new HtmlObject(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                    }
                                                                                                                                    else
                                                                                                                                    {
                                                                                                                                      HtmlElement element;
                                                                                                                                      if (tagName.equals("option"))
                                                                                                                                      {
                                                                                                                                        element = new HtmlOption(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                      }
                                                                                                                                      else
                                                                                                                                      {
                                                                                                                                        HtmlElement element;
                                                                                                                                        if (tagName.equals("optgroup"))
                                                                                                                                        {
                                                                                                                                          element = new HtmlOptionGroup(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                        }
                                                                                                                                        else
                                                                                                                                        {
                                                                                                                                          HtmlElement element;
                                                                                                                                          if (tagName.equals("ol"))
                                                                                                                                          {
                                                                                                                                            element = new HtmlOrderedList(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                          }
                                                                                                                                          else
                                                                                                                                          {
                                                                                                                                            HtmlElement element;
                                                                                                                                            if (tagName.equals("p"))
                                                                                                                                            {
                                                                                                                                              element = new HtmlParagraph(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                            }
                                                                                                                                            else
                                                                                                                                            {
                                                                                                                                              HtmlElement element;
                                                                                                                                              if (tagName.equals("param"))
                                                                                                                                              {
                                                                                                                                                element = new HtmlParameter(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                              }
                                                                                                                                              else
                                                                                                                                              {
                                                                                                                                                HtmlElement element;
                                                                                                                                                if (tagName.equals("plaintext"))
                                                                                                                                                {
                                                                                                                                                  element = new HtmlPlainText(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                }
                                                                                                                                                else
                                                                                                                                                {
                                                                                                                                                  HtmlElement element;
                                                                                                                                                  if (tagName.equals("pre"))
                                                                                                                                                  {
                                                                                                                                                    element = new HtmlPreformattedText(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                  }
                                                                                                                                                  else
                                                                                                                                                  {
                                                                                                                                                    HtmlElement element;
                                                                                                                                                    if (tagName.equals("progress"))
                                                                                                                                                    {
                                                                                                                                                      element = new HtmlProgress(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                    }
                                                                                                                                                    else
                                                                                                                                                    {
                                                                                                                                                      HtmlElement element;
                                                                                                                                                      if (tagName.equals("s"))
                                                                                                                                                      {
                                                                                                                                                        element = new HtmlS(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                      }
                                                                                                                                                      else
                                                                                                                                                      {
                                                                                                                                                        HtmlElement element;
                                                                                                                                                        if (tagName.equals("samp"))
                                                                                                                                                        {
                                                                                                                                                          element = new HtmlSample(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                        }
                                                                                                                                                        else
                                                                                                                                                        {
                                                                                                                                                          HtmlElement element;
                                                                                                                                                          if (tagName.equals("script"))
                                                                                                                                                          {
                                                                                                                                                            element = new HtmlScript(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                          }
                                                                                                                                                          else
                                                                                                                                                          {
                                                                                                                                                            HtmlElement element;
                                                                                                                                                            if (tagName.equals("select"))
                                                                                                                                                            {
                                                                                                                                                              element = new HtmlSelect(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                            }
                                                                                                                                                            else
                                                                                                                                                            {
                                                                                                                                                              HtmlElement element;
                                                                                                                                                              if (tagName.equals("small"))
                                                                                                                                                              {
                                                                                                                                                                element = new HtmlSmall(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                              }
                                                                                                                                                              else if (tagName.equals("source"))
                                                                                                                                                              {
                                                                                                                                                                HtmlElement element;
                                                                                                                                                                if (page.getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.HTML5_TAGS)) {
                                                                                                                                                                  element = new HtmlSource(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                } else {
                                                                                                                                                                  return UnknownElementFactory.instance.createElementNS(page, namespaceURI, qualifiedName, attributes);
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                              else
                                                                                                                                                              {
                                                                                                                                                                HtmlElement element;
                                                                                                                                                                if (tagName.equals("spacer"))
                                                                                                                                                                {
                                                                                                                                                                  element = new HtmlSpacer(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                }
                                                                                                                                                                else
                                                                                                                                                                {
                                                                                                                                                                  HtmlElement element;
                                                                                                                                                                  if (tagName.equals("span"))
                                                                                                                                                                  {
                                                                                                                                                                    element = new HtmlSpan(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                  }
                                                                                                                                                                  else
                                                                                                                                                                  {
                                                                                                                                                                    HtmlElement element;
                                                                                                                                                                    if (tagName.equals("strike"))
                                                                                                                                                                    {
                                                                                                                                                                      element = new HtmlStrike(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                    }
                                                                                                                                                                    else
                                                                                                                                                                    {
                                                                                                                                                                      HtmlElement element;
                                                                                                                                                                      if (tagName.equals("strong"))
                                                                                                                                                                      {
                                                                                                                                                                        element = new HtmlStrong(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                      }
                                                                                                                                                                      else
                                                                                                                                                                      {
                                                                                                                                                                        HtmlElement element;
                                                                                                                                                                        if (tagName.equals("style"))
                                                                                                                                                                        {
                                                                                                                                                                          element = new HtmlStyle(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                        }
                                                                                                                                                                        else
                                                                                                                                                                        {
                                                                                                                                                                          HtmlElement element;
                                                                                                                                                                          if (tagName.equals("sub"))
                                                                                                                                                                          {
                                                                                                                                                                            element = new HtmlSubscript(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                          }
                                                                                                                                                                          else
                                                                                                                                                                          {
                                                                                                                                                                            HtmlElement element;
                                                                                                                                                                            if (tagName.equals("sup"))
                                                                                                                                                                            {
                                                                                                                                                                              element = new HtmlSuperscript(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                            }
                                                                                                                                                                            else
                                                                                                                                                                            {
                                                                                                                                                                              HtmlElement element;
                                                                                                                                                                              if (tagName.equals("table"))
                                                                                                                                                                              {
                                                                                                                                                                                element = new HtmlTable(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                              }
                                                                                                                                                                              else
                                                                                                                                                                              {
                                                                                                                                                                                HtmlElement element;
                                                                                                                                                                                if (tagName.equals("tbody"))
                                                                                                                                                                                {
                                                                                                                                                                                  element = new HtmlTableBody(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                }
                                                                                                                                                                                else
                                                                                                                                                                                {
                                                                                                                                                                                  HtmlElement element;
                                                                                                                                                                                  if (tagName.equals("col"))
                                                                                                                                                                                  {
                                                                                                                                                                                    element = new HtmlTableColumn(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                  }
                                                                                                                                                                                  else
                                                                                                                                                                                  {
                                                                                                                                                                                    HtmlElement element;
                                                                                                                                                                                    if (tagName.equals("colgroup"))
                                                                                                                                                                                    {
                                                                                                                                                                                      element = new HtmlTableColumnGroup(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                    }
                                                                                                                                                                                    else
                                                                                                                                                                                    {
                                                                                                                                                                                      HtmlElement element;
                                                                                                                                                                                      if (tagName.equals("td"))
                                                                                                                                                                                      {
                                                                                                                                                                                        element = new HtmlTableDataCell(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                      }
                                                                                                                                                                                      else
                                                                                                                                                                                      {
                                                                                                                                                                                        HtmlElement element;
                                                                                                                                                                                        if (tagName.equals("tfoot"))
                                                                                                                                                                                        {
                                                                                                                                                                                          element = new HtmlTableFooter(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                        }
                                                                                                                                                                                        else
                                                                                                                                                                                        {
                                                                                                                                                                                          HtmlElement element;
                                                                                                                                                                                          if (tagName.equals("thead"))
                                                                                                                                                                                          {
                                                                                                                                                                                            element = new HtmlTableHeader(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                          }
                                                                                                                                                                                          else
                                                                                                                                                                                          {
                                                                                                                                                                                            HtmlElement element;
                                                                                                                                                                                            if (tagName.equals("th"))
                                                                                                                                                                                            {
                                                                                                                                                                                              element = new HtmlTableHeaderCell(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                            }
                                                                                                                                                                                            else
                                                                                                                                                                                            {
                                                                                                                                                                                              HtmlElement element;
                                                                                                                                                                                              if (tagName.equals("tr"))
                                                                                                                                                                                              {
                                                                                                                                                                                                element = new HtmlTableRow(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                              }
                                                                                                                                                                                              else
                                                                                                                                                                                              {
                                                                                                                                                                                                HtmlElement element;
                                                                                                                                                                                                if (tagName.equals("tt"))
                                                                                                                                                                                                {
                                                                                                                                                                                                  element = new HtmlTeletype(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                }
                                                                                                                                                                                                else
                                                                                                                                                                                                {
                                                                                                                                                                                                  HtmlElement element;
                                                                                                                                                                                                  if (tagName.equals("textarea"))
                                                                                                                                                                                                  {
                                                                                                                                                                                                    element = new HtmlTextArea(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                  }
                                                                                                                                                                                                  else
                                                                                                                                                                                                  {
                                                                                                                                                                                                    HtmlElement element;
                                                                                                                                                                                                    if (tagName.equals("dir"))
                                                                                                                                                                                                    {
                                                                                                                                                                                                      element = new HtmlDirectory(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                    }
                                                                                                                                                                                                    else
                                                                                                                                                                                                    {
                                                                                                                                                                                                      HtmlElement element;
                                                                                                                                                                                                      if (tagName.equals("title"))
                                                                                                                                                                                                      {
                                                                                                                                                                                                        element = new HtmlTitle(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                      }
                                                                                                                                                                                                      else
                                                                                                                                                                                                      {
                                                                                                                                                                                                        HtmlElement element;
                                                                                                                                                                                                        if (tagName.equals("u"))
                                                                                                                                                                                                        {
                                                                                                                                                                                                          element = new HtmlUnderlined(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                        }
                                                                                                                                                                                                        else
                                                                                                                                                                                                        {
                                                                                                                                                                                                          HtmlElement element;
                                                                                                                                                                                                          if (tagName.equals("ul"))
                                                                                                                                                                                                          {
                                                                                                                                                                                                            element = new HtmlUnorderedList(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                          }
                                                                                                                                                                                                          else
                                                                                                                                                                                                          {
                                                                                                                                                                                                            HtmlElement element;
                                                                                                                                                                                                            if (tagName.equals("var"))
                                                                                                                                                                                                            {
                                                                                                                                                                                                              element = new HtmlVariable(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                            }
                                                                                                                                                                                                            else if (tagName.equals("video"))
                                                                                                                                                                                                            {
                                                                                                                                                                                                              HtmlElement element;
                                                                                                                                                                                                              if (page.getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.HTML5_TAGS)) {
                                                                                                                                                                                                                element = new HtmlVideo(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                              } else {
                                                                                                                                                                                                                return UnknownElementFactory.instance.createElementNS(page, namespaceURI, qualifiedName, attributes);
                                                                                                                                                                                                              }
                                                                                                                                                                                                            }
                                                                                                                                                                                                            else
                                                                                                                                                                                                            {
                                                                                                                                                                                                              HtmlElement element;
                                                                                                                                                                                                              if (tagName.equals("wbr"))
                                                                                                                                                                                                              {
                                                                                                                                                                                                                element = new HtmlWordBreak(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                              }
                                                                                                                                                                                                              else
                                                                                                                                                                                                              {
                                                                                                                                                                                                                HtmlElement element;
                                                                                                                                                                                                                if (tagName.equals("xmp")) {
                                                                                                                                                                                                                  element = new HtmlExample(namespaceURI, qualifiedName, page, attributeMap);
                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                  throw new IllegalStateException("Cannot find HtmlElement for " + qualifiedName);
                                                                                                                                                                                                                }
                                                                                                                                                                                                              }
                                                                                                                                                                                                            }
                                                                                                                                                                                                          }
                                                                                                                                                                                                        }
                                                                                                                                                                                                      }
                                                                                                                                                                                                    }
                                                                                                                                                                                                  }
                                                                                                                                                                                                }
                                                                                                                                                                                              }
                                                                                                                                                                                            }
                                                                                                                                                                                          }
                                                                                                                                                                                        }
                                                                                                                                                                                      }
                                                                                                                                                                                    }
                                                                                                                                                                                  }
                                                                                                                                                                                }
                                                                                                                                                                              }
                                                                                                                                                                            }
                                                                                                                                                                          }
                                                                                                                                                                        }
                                                                                                                                                                      }
                                                                                                                                                                    }
                                                                                                                                                                  }
                                                                                                                                                                }
                                                                                                                                                              }
                                                                                                                                                            }
                                                                                                                                                          }
                                                                                                                                                        }
                                                                                                                                                      }
                                                                                                                                                    }
                                                                                                                                                  }
                                                                                                                                                }
                                                                                                                                              }
                                                                                                                                            }
                                                                                                                                          }
                                                                                                                                        }
                                                                                                                                      }
                                                                                                                                    }
                                                                                                                                  }
                                                                                                                                }
                                                                                                                              }
                                                                                                                            }
                                                                                                                          }
                                                                                                                        }
                                                                                                                      }
                                                                                                                    }
                                                                                                                  }
                                                                                                                }
                                                                                                              }
                                                                                                            }
                                                                                                          }
                                                                                                        }
                                                                                                      }
                                                                                                    }
                                                                                                  }
                                                                                                }
                                                                                              }
                                                                                            }
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                    }
                                                                                  }
                                                                                }
                                                                              }
                                                                            }
                                                                          }
                                                                        }
                                                                      }
                                                                    }
                                                                  }
                                                                }
                                                              }
                                                            }
                                                          }
                                                        }
                                                      }
                                                    }
                                                  }
                                                }
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    HtmlElement element;
    JavaScriptConfiguration config = page.getWebClient().getJavaScriptEngine().getJavaScriptConfiguration();
    if ((!"td".equals(tagName)) && (!"th".equals(tagName)) && (checkBrowserCompatibility) && (config.getDomJavaScriptMapping().get(element.getClass()) == null)) {
      return UnknownElementFactory.instance.createElementNS(page, namespaceURI, qualifiedName, attributes);
    }
    return element;
  }
  
  static Map<String, DomAttr> setAttributes(SgmlPage page, Attributes attributes)
  {
    Map<String, DomAttr> attributeMap = null;
    if (attributes != null)
    {
      attributeMap = new LinkedHashMap(attributes.getLength());
      for (int i = 0; i < attributes.getLength(); i++)
      {
        String qName = attributes.getQName(i);
        if (!attributeMap.containsKey(qName))
        {
          String namespaceURI = attributes.getURI(i);
          if ((namespaceURI != null) && (namespaceURI.isEmpty())) {
            namespaceURI = null;
          }
          DomAttr newAttr = new DomAttr(page, namespaceURI, qName, attributes.getValue(i), true);
          attributeMap.put(qName, newAttr);
        }
      }
    }
    return attributeMap;
  }
}
