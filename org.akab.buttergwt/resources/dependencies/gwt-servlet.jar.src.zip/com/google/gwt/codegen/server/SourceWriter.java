package com.google.gwt.codegen.server;

public abstract interface SourceWriter
{
  public abstract void abort();
  
  public abstract void beginJavaDocComment();
  
  public abstract void close();
  
  public abstract void endJavaDocComment();
  
  public abstract void indent();
  
  public abstract void indentln(String paramString);
  
  public abstract void indentln(String paramString, Object... paramVarArgs);
  
  public abstract void outdent();
  
  public abstract void print(String paramString);
  
  public abstract void print(String paramString, Object... paramVarArgs);
  
  public abstract void println();
  
  public abstract void println(String paramString);
  
  public abstract void println(String paramString, Object... paramVarArgs);
}
