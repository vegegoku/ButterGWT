package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlTable;
import com.gargoylesoftware.htmlunit.html.HtmlTableCell;
import com.gargoylesoftware.htmlunit.html.HtmlTableRow;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import java.util.ArrayList;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;

@JsxClass(domClasses={HtmlTableRow.class})
public class HTMLTableRowElement
  extends HTMLTableComponent
{
  private HTMLCollection cells_;
  
  @JsxGetter
  public int getRowIndex()
  {
    HtmlTableRow row = (HtmlTableRow)getDomNodeOrDie();
    HtmlTable table = row.getEnclosingTable();
    if (table == null) {
      return -1;
    }
    return table.getRows().indexOf(row);
  }
  
  @JsxGetter
  public int getSectionRowIndex()
  {
    DomNode row = getDomNodeOrDie();
    HtmlTable table = ((HtmlTableRow)row).getEnclosingTable();
    if (table == null)
    {
      if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_108)) {
        return -1;
      }
      return 5461640;
    }
    int index = -1;
    while (row != null)
    {
      if ((row instanceof HtmlTableRow)) {
        index++;
      }
      row = row.getPreviousSibling();
    }
    return index;
  }
  
  @JsxGetter
  public Object getCells()
  {
    if (this.cells_ == null)
    {
      final HtmlTableRow row = (HtmlTableRow)getDomNodeOrDie();
      this.cells_ = new HTMLCollection(row, false, "cells")
      {
        protected List<Object> computeElements()
        {
          return new ArrayList(row.getCells());
        }
      };
    }
    return this.cells_;
  }
  
  @JsxGetter
  public String getBgColor()
  {
    return getDomNodeOrDie().getAttribute("bgColor");
  }
  
  @JsxSetter
  public void setBgColor(String bgColor)
  {
    setColorAttribute("bgColor", bgColor);
  }
  
  @JsxFunction
  public Object insertCell(Object index)
  {
    int position = -1;
    if (index != Undefined.instance) {
      position = (int)Context.toNumber(index);
    }
    HtmlTableRow htmlRow = (HtmlTableRow)getDomNodeOrDie();
    
    boolean indexValid = (position >= -1) && (position <= htmlRow.getCells().size());
    if (indexValid)
    {
      DomElement newCell = ((HtmlPage)htmlRow.getPage()).createElement("td");
      if ((position == -1) || (position == htmlRow.getCells().size())) {
        htmlRow.appendChild(newCell);
      } else {
        htmlRow.getCell(position).insertBefore(newCell);
      }
      return getScriptableFor(newCell);
    }
    throw Context.reportRuntimeError("Index or size is negative or greater than the allowed amount");
  }
  
  @JsxFunction
  public void deleteCell(Object index)
  {
    int position = -1;
    if (index != Undefined.instance) {
      position = (int)Context.toNumber(index);
    } else if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_172)) {
      throw Context.reportRuntimeError("No enough arguments");
    }
    HtmlTableRow htmlRow = (HtmlTableRow)getDomNodeOrDie();
    if (position == -1) {
      position = htmlRow.getCells().size() - 1;
    }
    boolean indexValid = (position >= -1) && (position <= htmlRow.getCells().size());
    if (!indexValid) {
      throw Context.reportRuntimeError("Index or size is negative or greater than the allowed amount");
    }
    htmlRow.getCell(position).remove();
  }
  
  public String getDefaultStyleDisplay()
  {
    return "table-row";
  }
}
