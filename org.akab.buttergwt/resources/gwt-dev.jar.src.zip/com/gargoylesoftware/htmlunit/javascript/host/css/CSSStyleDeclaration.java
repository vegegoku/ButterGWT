package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.javascript.ScriptableWithFallbackGetter;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCanvasElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLHtmlElement;
import com.steadystate.css.dom.CSSValueImpl;
import com.steadystate.css.parser.CSSOMParser;
import com.steadystate.css.parser.SACParserCSS3;
import java.awt.Color;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.EvaluatorException;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;
import net.sourceforge.htmlunit.corejs.javascript.WrappedException;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.css.sac.ErrorHandler;
import org.w3c.css.sac.InputSource;

@JsxClass
public class CSSStyleDeclaration
  extends SimpleScriptable
  implements ScriptableWithFallbackGetter
{
  protected static final String PRIORITY_IMPORTANT = "important";
  private static final String BACKGROUND = "background";
  private static final String BACKGROUND_ATTACHMENT = "background-attachment";
  private static final String BACKGROUND_COLOR = "background-color";
  private static final String BACKGROUND_IMAGE = "background-image";
  private static final String BACKGROUND_POSITION = "background-position";
  private static final String BACKGROUND_POSITION_X = "background-position-x";
  private static final String BACKGROUND_POSITION_Y = "background-position-y";
  private static final String BACKGROUND_REPEAT = "background-repeat";
  private static final String BEHAVIOR = "behavior";
  private static final String BORDER = "border";
  private static final String BORDER_BOTTOM = "border-bottom";
  private static final String BORDER_BOTTOM_COLOR = "border-bottom-color";
  private static final String BORDER_BOTTOM_STYLE = "border-bottom-style";
  private static final String BORDER_BOTTOM_WIDTH = "border-bottom-width";
  private static final String BORDER_COLLAPSE = "border-collapse";
  private static final String BORDER_COLOR = "border-color";
  private static final String BORDER_LEFT = "border-left";
  private static final String BORDER_LEFT_COLOR = "border-left-color";
  private static final String BORDER_LEFT_STYLE = "border-left-style";
  private static final String BORDER_WIDTH = "border-width";
  private static final String BORDER_LEFT_WIDTH = "border-left-width";
  private static final String BORDER_RIGHT = "border-right";
  private static final String BORDER_RIGHT_COLOR = "border-right-color";
  private static final String BORDER_RIGHT_STYLE = "border-right-style";
  private static final String BORDER_RIGHT_WIDTH = "border-right-width";
  private static final String BORDER_SPACING = "border-spacing";
  private static final String BORDER_STYLE = "border-style";
  private static final String BORDER_TOP = "border-top";
  private static final String BORDER_TOP_COLOR = "border-top-color";
  private static final String BORDER_TOP_STYLE = "border-top-style";
  private static final String BORDER_TOP_WIDTH = "border-top-width";
  private static final String BOTTOM = "bottom";
  private static final String BOX_SIZING = "box-sizing";
  private static final String CAPTION_SIDE = "caption-side";
  private static final String CLEAR = "clear";
  private static final String CLIP = "clip";
  private static final String COLOR = "color";
  private static final String CONTENT = "content";
  private static final String COUNTER_INCREMENT = "counter-increment";
  private static final String COUNTER_RESET = "counter-reset";
  private static final String CURSOR = "cursor";
  private static final String DIRECTION = "direction";
  private static final String DISPLAY = "display";
  private static final String EMPTY_CELLS = "empty-cells";
  private static final String FONT = "font";
  private static final String FONT_FAMILY = "font-family";
  private static final String FONT_SIZE = "font-size";
  private static final String FONT_SIZE_ADJUST = "font-size-adjust";
  private static final String FONT_STRETCH = "font-stretch";
  private static final String FONT_STYLE = "font-style";
  private static final String FONT_VARIANT = "font-variant";
  private static final String FONT_WEIGHT = "font-weight";
  private static final String HEIGHT = "height";
  private static final String IME_MODE = "ime-mode";
  private static final String LAYOUT_FLOW = "layout-flow";
  private static final String LAYOUT_GRID = "layout-grid";
  private static final String LAYOUT_GRID_CHAR = "layout-grid-char";
  private static final String LAYOUT_GRID_LINE = "layout-grid-line";
  private static final String LAYOUT_GRID_MODE = "layout-grid-mode";
  private static final String LAYOUT_GRID_TYPE = "layout-grid-type";
  private static final String LEFT = "left";
  private static final String LETTER_SPACING = "letter-spacing";
  private static final String LINE_BREAK = "line-break";
  private static final String LIST_STYLE = "list-style";
  private static final String LIST_STYLE_IMAGE = "list-style-image";
  private static final String LIST_STYLE_POSITION = "list-style-position";
  private static final String LIST_STYLE_TYPE = "list-style-type";
  private static final String MARGIN_BOTTOM = "margin-bottom";
  private static final String MARGIN_LEFT = "margin-left";
  private static final String MARGIN_RIGHT = "margin-right";
  private static final String MARGIN = "margin";
  private static final String MARGIN_TOP = "margin-top";
  private static final String MARKER_OFFSET = "marker-offset";
  private static final String MARKS = "marks";
  private static final String MAX_HEIGHT = "max-height";
  private static final String MAX_WIDTH = "max-width";
  private static final String MIN_HEIGHT = "min-height";
  private static final String MIN_WIDTH = "min-width";
  private static final String MS_BLOCK_PROGRESSION = "ms-block-progression";
  private static final String MS_INTERPOLATION_MODE = "ms-interpolation-mode";
  private static final String OPACITY = "opacity";
  private static final String ORPHANS = "orphans";
  private static final String OUTLINE = "outline";
  private static final String OUTLINE_COLOR = "outline-color";
  private static final String OUTLINE_OFFSET = "outline-offset";
  private static final String OUTLINE_STYLE = "outline-style";
  private static final String OUTLINE_WIDTH = "outline-width";
  private static final String OVERFLOW = "overflow";
  private static final String OVERFLOW_X = "overflow-x";
  private static final String OVERFLOW_Y = "overflow-y";
  private static final String PADDING_BOTTOM = "padding-bottom";
  private static final String PADDING_LEFT = "padding-left";
  private static final String PADDING_RIGHT = "padding-right";
  private static final String PADDING = "padding";
  private static final String PADDING_TOP = "padding-top";
  private static final String PAGE = "page";
  private static final String PAGE_BREAK_AFTER = "page-break-after";
  private static final String PAGE_BREAK_BEFORE = "page-break-before";
  private static final String PAGE_BREAK_INSIDE = "page-break-inside";
  private static final String POINTER_EVENTS = "pointer-events";
  private static final String POSITION = "position";
  private static final String RIGHT = "right";
  private static final String RUBY_ALIGN = "ruby-align";
  private static final String RUBY_OVERHANG = "ruby-overhang";
  private static final String RUBY_POSITION = "ruby-position";
  private static final String SCROLLBAR3D_LIGHT_COLOR = "scrollbar3d-light-color";
  private static final String SCROLLBAR_ARROW_COLOR = "scrollbar-arrow-color";
  private static final String SCROLLBAR_BASE_COLOR = "scrollbar-base-color";
  private static final String SCROLLBAR_DARK_SHADOW_COLOR = "scrollbar-dark-shadow-color";
  private static final String SCROLLBAR_FACE_COLOR = "scrollbar-face-color";
  private static final String SCROLLBAR_HIGHLIGHT_COLOR = "scrollbar-highlight-color";
  private static final String SCROLLBAR_SHADOW_COLOR = "scrollbar-shadow-color";
  private static final String SCROLLBAR_TRACK_COLOR = "scrollbar-track-color";
  private static final String SIZE = "size";
  private static final String FLOAT = "float";
  private static final String TABLE_LAYOUT = "table-layout";
  private static final String TEXT_ALIGN = "text-align";
  private static final String TEXT_ALIGN_LAST = "text-align-last";
  private static final String TEXT_AUTOSPACE = "text-autospace";
  private static final String TEXT_DECORATION = "text-decoration";
  private static final String TEXT_INDENT = "text-indent";
  private static final String TEXT_JUSTIFY = "text-justify";
  private static final String TEXT_JUSTIFY_TRIM = "text-justify-trim";
  private static final String TEXT_KASHIDA = "text-kashida";
  private static final String TEXT_KASHIDA_SPACE = "text-kashida-space";
  private static final String TEXT_OVERFLOW = "text-overflow";
  private static final String TEXT_SHADOW = "text-shadow";
  private static final String TEXT_TRANSFORM = "text-transform";
  private static final String TEXT_UNDERLINE_POSITION = "text-underline-position";
  private static final String TOP = "top";
  private static final String VERTICAL_ALIGN = "vertical-align";
  private static final String VISIBILITY = "visibility";
  private static final String WHITE_SPACE = "white-space";
  private static final String WIDOWS = "widows";
  private static final String WORD_SPACING = "word-spacing";
  private static final String WORD_WRAP = "word-wrap";
  private static final String WRITING_MODE = "writing-mode";
  private static final String Z_INDEX = "z-index";
  private static final String ZOOM = "zoom";
  protected static final String WIDTH = "width";
  private static final Pattern TO_INT_PATTERN = Pattern.compile("(\\d+).*");
  private static final Pattern URL_PATTERN = Pattern.compile("url\\(\\s*[\"']?(.*?)[\"']?\\s*\\)");
  private static final Pattern POSITION_PATTERN = Pattern.compile("(\\d+\\s*(%|px|cm|mm|in|pt|pc|em|ex))\\s*(\\d+\\s*(%|px|cm|mm|in|pt|pc|em|ex)|top|bottom|center)");
  private static final Pattern POSITION_PATTERN2 = Pattern.compile("(left|right|center)\\s*(\\d+\\s*(%|px|cm|mm|in|pt|pc|em|ex)|top|bottom|center)");
  private static final Pattern POSITION_PATTERN3 = Pattern.compile("(top|bottom|center)\\s*(\\d+\\s*(%|px|cm|mm|in|pt|pc|em|ex)|left|right|center)");
  private static final Log LOG = LogFactory.getLog(CSSStyleDeclaration.class);
  private static final Map<String, String> CSSColors_ = new HashMap();
  private static final Map<String, String> CamelizeCache_ = new ConcurrentHashMap(400, 0.75F, 2);
  
  private static enum Shorthand
  {
    TOP("top"),  RIGHT("right"),  BOTTOM("bottom"),  LEFT("left");
    
    private final String string_;
    
    private Shorthand(String stringRepresentation)
    {
      this.string_ = stringRepresentation;
    }
    
    public String toString()
    {
      return this.string_;
    }
  }
  
  private static final MessageFormat URL_FORMAT = new MessageFormat("url({0})");
  private Element jsElement_;
  private org.w3c.dom.css.CSSStyleDeclaration styleDeclaration_;
  private String styleString_ = new String();
  private Map<String, StyleElement> styleMap_;
  private long currentElementIndex_;
  
  static
  {
    CSSColors_.put("aqua", "rgb(0, 255, 255)");
    CSSColors_.put("black", "rgb(0, 0, 0)");
    CSSColors_.put("blue", "rgb(0, 0, 255)");
    CSSColors_.put("fuchsia", "rgb(255, 0, 255)");
    CSSColors_.put("gray", "rgb(128, 128, 128)");
    CSSColors_.put("green", "rgb(0, 128, 0)");
    CSSColors_.put("lime", "rgb(0, 255, 0)");
    CSSColors_.put("maroon", "rgb(128, 0, 0)");
    CSSColors_.put("navy", "rgb(0, 0, 128)");
    CSSColors_.put("olive", "rgb(128, 128, 0)");
    CSSColors_.put("purple", "rgb(128, 0, 128)");
    CSSColors_.put("red", "rgb(255, 0, 0)");
    CSSColors_.put("silver", "rgb(192, 192, 192)");
    CSSColors_.put("teal", "rgb(0, 128, 128)");
    CSSColors_.put("white", "rgb(255, 255, 255)");
    CSSColors_.put("yellow", "rgb(255, 255, 0)");
  }
  
  public CSSStyleDeclaration(Element element)
  {
    setParentScope(element.getParentScope());
    setPrototype(getPrototype(getClass()));
    initialize(element);
  }
  
  CSSStyleDeclaration(Scriptable parentScope, org.w3c.dom.css.CSSStyleDeclaration styleDeclaration)
  {
    setParentScope(parentScope);
    setPrototype(getPrototype(getClass()));
    this.styleDeclaration_ = styleDeclaration;
  }
  
  void initialize(Element element)
  {
    WebAssert.notNull("htmlElement", element);
    this.jsElement_ = element;
    setDomNode(element.getDomNodeOrNull(), false);
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_SUPPORTS_BEHAVIOR_PROPERTY)) && ((element instanceof HTMLElement)))
    {
      HTMLElement htmlElement = (HTMLElement)element;
      String behavior = getStyleAttribute("behavior");
      if (org.apache.commons.lang3.StringUtils.isNotBlank(behavior)) {
        try
        {
          Object[] url = URL_FORMAT.parse(behavior);
          if (url.length > 0) {
            htmlElement.addBehavior((String)url[0]);
          }
        }
        catch (ParseException e)
        {
          LOG.warn("Invalid behavior: '" + behavior + "'.");
        }
      }
    }
  }
  
  public Object getWithFallback(String name)
  {
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_STYLE_UNSUPPORTED_PROPERTY_GETTER)) && 
      (null != this.jsElement_))
    {
      StyleElement element = getStyleElement(name);
      if ((element != null) && (element.getValue() != null)) {
        return element.getValue();
      }
    }
    return NOT_FOUND;
  }
  
  protected Element getElement()
  {
    return this.jsElement_;
  }
  
  protected String getStyleAttribute(String name)
  {
    if (this.styleDeclaration_ != null) {
      return this.styleDeclaration_.getPropertyValue(name);
    }
    StyleElement element = getStyleElement(name);
    if ((element != null) && (element.getValue() != null)) {
      return element.getValue();
    }
    return "";
  }
  
  protected StyleElement getStyleElement(String name)
  {
    return (StyleElement)getStyleMap().get(name);
  }
  
  private StyleElement getStyleElementCaseInSensitive(String name)
  {
    Map<String, StyleElement> map = getStyleMap();
    for (String key : map.keySet()) {
      if (key.equalsIgnoreCase(name)) {
        return (StyleElement)map.get(key);
      }
    }
    return null;
  }
  
  private String getStyleAttribute(String name1, String name2, Shorthand shorthand)
  {
    String value;
    String value;
    if (this.styleDeclaration_ != null)
    {
      String value1 = this.styleDeclaration_.getPropertyValue(name1);
      String value2 = this.styleDeclaration_.getPropertyValue(name2);
      if (("".equals(value1)) && ("".equals(value2))) {
        return "";
      }
      if ((!"".equals(value1)) && ("".equals(value2))) {
        return value1;
      }
      value = value2;
    }
    else
    {
      StyleElement element1 = getStyleElement(name1);
      StyleElement element2 = getStyleElement(name2);
      if ((element1 == null) && (element2 == null)) {
        return "";
      }
      if ((element1 != null) && (element2 == null)) {
        return element1.getValue();
      }
      String value;
      if ((element1 == null) && (element2 != null))
      {
        value = element2.getValue();
      }
      else
      {
        if (element1.getIndex() > element2.getIndex()) {
          return element1.getValue();
        }
        value = element2.getValue();
      }
    }
    String[] values = org.apache.commons.lang3.StringUtils.split(value);
    switch (shorthand)
    {
    case TOP: 
      return values[0];
    case RIGHT: 
      if (values.length > 1) {
        return values[1];
      }
      return values[0];
    case BOTTOM: 
      if (values.length > 2) {
        return values[2];
      }
      return values[0];
    case LEFT: 
      if (values.length > 3) {
        return values[3];
      }
      if (values.length > 1) {
        return values[1];
      }
      return values[0];
    }
    throw new IllegalStateException("Unknown shorthand value: " + shorthand);
  }
  
  protected void setStyleAttribute(String name, String newValue)
  {
    if (this.styleDeclaration_ != null)
    {
      this.styleDeclaration_.setProperty(name, newValue, null);
      return;
    }
    replaceStyleAttribute(name, newValue);
  }
  
  private void replaceStyleAttribute(String name, String value)
  {
    if (org.apache.commons.lang3.StringUtils.isBlank(value))
    {
      removeStyleAttribute(name);
    }
    else
    {
      Map<String, StyleElement> styleMap = getStyleMap();
      StyleElement old = (StyleElement)styleMap.get(name);
      long index;
      long index;
      if (old != null) {
        index = old.getIndex();
      } else {
        index = getCurrentElementIndex();
      }
      StyleElement element = new StyleElement(name, value, index);
      styleMap.put(name, element);
      writeToElement(styleMap);
    }
  }
  
  private String removeStyleAttribute(String name)
  {
    if (null != this.styleDeclaration_) {
      return this.styleDeclaration_.removeProperty(name);
    }
    Map<String, StyleElement> styleMap = getStyleMap();
    StyleElement value = (StyleElement)styleMap.get(name);
    if (value == null) {
      return "";
    }
    styleMap.remove(name);
    writeToElement(styleMap);
    return value.getValue();
  }
  
  private Map<String, StyleElement> getStyleMap()
  {
    String styleAttribute = this.jsElement_.getDomNodeOrDie().getAttribute("style");
    if (this.styleString_ == styleAttribute) {
      return this.styleMap_;
    }
    Map<String, StyleElement> styleMap = new LinkedHashMap();
    if ((DomElement.ATTRIBUTE_NOT_DEFINED == styleAttribute) || (DomElement.ATTRIBUTE_VALUE_EMPTY == styleAttribute))
    {
      this.styleMap_ = styleMap;
      this.styleString_ = styleAttribute;
      return this.styleMap_;
    }
    for (String token : org.apache.commons.lang3.StringUtils.split(styleAttribute, ';'))
    {
      int index = token.indexOf(":");
      if (index != -1)
      {
        String key = token.substring(0, index).trim().toLowerCase(Locale.ENGLISH);
        String value = token.substring(index + 1).trim();
        String priority = "";
        if (org.apache.commons.lang3.StringUtils.endsWithIgnoreCase(value, "!important"))
        {
          priority = "important";
          value = value.substring(0, value.length() - 10);
          value = value.trim();
        }
        StyleElement element = new StyleElement(key, value, priority, SelectorSpecificity.FROM_STYLE_ATTRIBUTE, getCurrentElementIndex());
        
        styleMap.put(key, element);
      }
    }
    this.styleMap_ = styleMap;
    this.styleString_ = styleAttribute;
    return this.styleMap_;
  }
  
  private void writeToElement(Map<String, StyleElement> styleMap)
  {
    StringBuilder buffer = new StringBuilder();
    SortedSet<StyleElement> sortedValues = new TreeSet(styleMap.values());
    for (StyleElement e : sortedValues)
    {
      if (buffer.length() > 0) {
        buffer.append(" ");
      }
      buffer.append(e.getName());
      buffer.append(": ");
      buffer.append(e.getValue());
      buffer.append(";");
    }
    this.jsElement_.getDomNodeOrDie().setAttribute("style", buffer.toString());
  }
  
  protected long getCurrentElementIndex()
  {
    return this.currentElementIndex_++;
  }
  
  protected static String camelize(String string)
  {
    if (string == null) {
      return null;
    }
    String result = (String)CamelizeCache_.get(string);
    if (null != result) {
      return result;
    }
    int pos = string.indexOf('-');
    if ((pos == -1) || (pos == string.length() - 1))
    {
      CamelizeCache_.put(string, string);
      return string;
    }
    StringBuilder buffer = new StringBuilder(string);
    buffer.deleteCharAt(pos);
    buffer.setCharAt(pos, Character.toUpperCase(buffer.charAt(pos)));
    for (int i = pos + 1; i < buffer.length() - 1; i++) {
      if (buffer.charAt(i) == '-')
      {
        buffer.deleteCharAt(i);
        buffer.setCharAt(i, Character.toUpperCase(buffer.charAt(i)));
      }
    }
    result = buffer.toString();
    CamelizeCache_.put(string, result);
    
    return result;
  }
  
  @JsxGetter
  public String getBackground()
  {
    return getStyleAttribute("background");
  }
  
  @JsxSetter
  public void setBackground(String background)
  {
    setStyleAttribute("background", background);
  }
  
  @JsxGetter
  public String getBackgroundAttachment()
  {
    String value = getStyleAttribute("background-attachment");
    if (org.apache.commons.lang3.StringUtils.isBlank(value))
    {
      String bg = getStyleAttribute("background");
      if (org.apache.commons.lang3.StringUtils.isNotBlank(bg))
      {
        value = findAttachment(bg);
        if (value == null) {
          return "scroll";
        }
        return value;
      }
      return "";
    }
    return value;
  }
  
  @JsxSetter
  public void setBackgroundAttachment(String backgroundAttachment)
  {
    setStyleAttribute("background-attachment", backgroundAttachment);
  }
  
  @JsxGetter
  public String getBackgroundColor()
  {
    String value = getStyleAttribute("background-color");
    if (org.apache.commons.lang3.StringUtils.isBlank(value))
    {
      String bg = getStyleAttribute("background");
      if (org.apache.commons.lang3.StringUtils.isBlank(bg)) {
        return "";
      }
      value = findColor(bg);
      if (value == null) {
        return "transparent";
      }
      return value;
    }
    if (org.apache.commons.lang3.StringUtils.isBlank(value)) {
      return "";
    }
    return value;
  }
  
  @JsxSetter
  public void setBackgroundColor(String backgroundColor)
  {
    setStyleAttribute("background-color", backgroundColor);
  }
  
  @JsxGetter
  public String getBackgroundImage()
  {
    String value = getStyleAttribute("background-image");
    if (org.apache.commons.lang3.StringUtils.isBlank(value))
    {
      String bg = getStyleAttribute("background");
      if (org.apache.commons.lang3.StringUtils.isNotBlank(bg))
      {
        value = findImageUrl(bg);
        if (value == null) {
          return "none";
        }
        return value;
      }
      return "";
    }
    return value;
  }
  
  @JsxSetter
  public void setBackgroundImage(String backgroundImage)
  {
    setStyleAttribute("background-image", backgroundImage);
  }
  
  @JsxGetter
  public String getBackgroundPosition()
  {
    String value = getStyleAttribute("background-position");
    if (value == null) {
      return null;
    }
    if (org.apache.commons.lang3.StringUtils.isBlank(value))
    {
      String bg = getStyleAttribute("background");
      if (bg == null) {
        return null;
      }
      if (org.apache.commons.lang3.StringUtils.isNotBlank(bg))
      {
        value = findPosition(bg);
        if (value == null) {
          return "0% 0%";
        }
        return value;
      }
      return "";
    }
    return value;
  }
  
  @JsxSetter
  public void setBackgroundPosition(String backgroundPosition)
  {
    setStyleAttribute("background-position", backgroundPosition);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBackgroundPositionX()
  {
    return getStyleAttribute("background-position-x");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setBackgroundPositionX(String backgroundPositionX)
  {
    setStyleAttribute("background-position-x", backgroundPositionX);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBackgroundPositionY()
  {
    return getStyleAttribute("background-position-y");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setBackgroundPositionY(String backgroundPositionY)
  {
    setStyleAttribute("background-position-y", backgroundPositionY);
  }
  
  @JsxGetter
  public String getBackgroundRepeat()
  {
    String value = getStyleAttribute("background-repeat");
    if (org.apache.commons.lang3.StringUtils.isBlank(value))
    {
      String bg = getStyleAttribute("background");
      if (org.apache.commons.lang3.StringUtils.isNotBlank(bg))
      {
        value = findRepeat(bg);
        if (value == null) {
          return "repeat";
        }
        return value;
      }
      return "";
    }
    return value;
  }
  
  @JsxSetter
  public void setBackgroundRepeat(String backgroundRepeat)
  {
    setStyleAttribute("background-repeat", backgroundRepeat);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBehavior()
  {
    return getStyleAttribute("behavior");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setBehavior(String behavior)
  {
    setStyleAttribute("behavior", behavior);
    if (!(this.jsElement_ instanceof HTMLElement)) {
      throw new RuntimeException("Bug! behavior can be set for Element too!!!");
    }
    HTMLElement htmlElement = (HTMLElement)this.jsElement_;
    htmlElement.removeBehavior(0);
    htmlElement.removeBehavior(1);
    htmlElement.removeBehavior(2);
    if (!behavior.isEmpty()) {
      try
      {
        Object[] url = URL_FORMAT.parse(behavior);
        if (url.length > 0) {
          htmlElement.addBehavior((String)url[0]);
        }
      }
      catch (ParseException e)
      {
        LOG.warn("Invalid behavior: '" + behavior + "'.");
      }
    }
  }
  
  @JsxGetter
  public String getBorder()
  {
    return getStyleAttribute("border");
  }
  
  @JsxSetter
  public void setBorder(String border)
  {
    setStyleAttribute("border", border);
  }
  
  @JsxGetter
  public String getBorderBottom()
  {
    return getStyleAttribute("border-bottom");
  }
  
  @JsxSetter
  public void setBorderBottom(String borderBottom)
  {
    setStyleAttribute("border-bottom", borderBottom);
  }
  
  @JsxGetter
  public String getBorderBottomColor()
  {
    String value = getStyleAttribute("border-bottom-color");
    if (value.isEmpty())
    {
      value = findColor(getStyleAttribute("border-bottom"));
      if (value == null) {
        value = findColor(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderBottomColor(String borderBottomColor)
  {
    setStyleAttribute("border-bottom-color", borderBottomColor);
  }
  
  @JsxGetter
  public String getBorderBottomStyle()
  {
    String value = getStyleAttribute("border-bottom-style");
    if (value.isEmpty())
    {
      value = findBorderStyle(getStyleAttribute("border-bottom"));
      if (value == null) {
        value = findBorderStyle(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderBottomStyle(String borderBottomStyle)
  {
    setStyleAttribute("border-bottom-style", borderBottomStyle);
  }
  
  @JsxGetter
  public String getBorderBottomWidth()
  {
    return getBorderWidth(Shorthand.BOTTOM);
  }
  
  @JsxSetter
  public void setBorderBottomWidth(String borderBottomWidth)
  {
    setStyleAttributePixel("border-bottom-width", borderBottomWidth);
  }
  
  @JsxGetter
  public String getBorderCollapse()
  {
    return getStyleAttribute("border-collapse");
  }
  
  @JsxSetter
  public void setBorderCollapse(String borderCollapse)
  {
    setStyleAttribute("border-collapse", borderCollapse);
  }
  
  @JsxGetter
  public String getBorderColor()
  {
    return getStyleAttribute("border-color");
  }
  
  @JsxSetter
  public void setBorderColor(String borderColor)
  {
    setStyleAttribute("border-color", borderColor);
  }
  
  @JsxGetter
  public String getBorderLeft()
  {
    return getStyleAttribute("border-left");
  }
  
  @JsxSetter
  public void setBorderLeft(String borderLeft)
  {
    setStyleAttribute("border-left", borderLeft);
  }
  
  @JsxGetter
  public String getBorderLeftColor()
  {
    String value = getStyleAttribute("border-left-color");
    if (value.isEmpty())
    {
      value = findColor(getStyleAttribute("border-left"));
      if (value == null) {
        value = findColor(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderLeftColor(String borderLeftColor)
  {
    setStyleAttribute("border-left-color", borderLeftColor);
  }
  
  @JsxGetter
  public String getBorderLeftStyle()
  {
    String value = getStyleAttribute("border-left-style");
    if (value.isEmpty())
    {
      value = findBorderStyle(getStyleAttribute("border-left"));
      if (value == null) {
        value = findBorderStyle(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderLeftStyle(String borderLeftStyle)
  {
    setStyleAttribute("border-left-style", borderLeftStyle);
  }
  
  @JsxGetter
  public String getBorderLeftWidth()
  {
    return getBorderWidth(Shorthand.LEFT);
  }
  
  private String getBorderWidth(Shorthand side)
  {
    String value = getStyleAttribute("border-" + side + "-width");
    if (value.isEmpty())
    {
      value = findBorderWidth(getStyleAttribute("border-" + side));
      if (value == null)
      {
        String borderWidth = getStyleAttribute("border-width");
        if (!org.apache.commons.lang3.StringUtils.isEmpty(borderWidth))
        {
          String[] values = org.apache.commons.lang3.StringUtils.split(borderWidth);
          if (values.length > side.ordinal()) {
            value = values[side.ordinal()];
          }
        }
      }
      if (value == null) {
        value = findBorderWidth(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderLeftWidth(String borderLeftWidth)
  {
    setStyleAttributePixel("border-left-width", borderLeftWidth);
  }
  
  @JsxGetter
  public String getBorderRight()
  {
    return getStyleAttribute("border-right");
  }
  
  @JsxSetter
  public void setBorderRight(String borderRight)
  {
    setStyleAttribute("border-right", borderRight);
  }
  
  @JsxGetter
  public String getBorderRightColor()
  {
    String value = getStyleAttribute("border-right-color");
    if (value.isEmpty())
    {
      value = findColor(getStyleAttribute("border-right"));
      if (value == null) {
        value = findColor(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderRightColor(String borderRightColor)
  {
    setStyleAttribute("border-right-color", borderRightColor);
  }
  
  @JsxGetter
  public String getBorderRightStyle()
  {
    String value = getStyleAttribute("border-right-style");
    if (value.isEmpty())
    {
      value = findBorderStyle(getStyleAttribute("border-right"));
      if (value == null) {
        value = findBorderStyle(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderRightStyle(String borderRightStyle)
  {
    setStyleAttribute("border-right-style", borderRightStyle);
  }
  
  @JsxGetter
  public String getBorderRightWidth()
  {
    return getBorderWidth(Shorthand.RIGHT);
  }
  
  @JsxSetter
  public void setBorderRightWidth(String borderRightWidth)
  {
    setStyleAttributePixel("border-right-width", borderRightWidth);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getBorderSpacing()
  {
    return getStyleAttribute("border-spacing");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setBorderSpacing(String borderSpacing)
  {
    setStyleAttribute("border-spacing", borderSpacing);
  }
  
  @JsxGetter
  public String getBorderStyle()
  {
    return getStyleAttribute("border-style");
  }
  
  @JsxSetter
  public void setBorderStyle(String borderStyle)
  {
    setStyleAttribute("border-style", borderStyle);
  }
  
  @JsxGetter
  public String getBorderTop()
  {
    return getStyleAttribute("border-top");
  }
  
  @JsxSetter
  public void setBorderTop(String borderTop)
  {
    setStyleAttribute("border-top", borderTop);
  }
  
  @JsxGetter
  public String getBorderTopColor()
  {
    String value = getStyleAttribute("border-top-color");
    if (value.isEmpty())
    {
      value = findColor(getStyleAttribute("border-top"));
      if (value == null) {
        value = findColor(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderTopColor(String borderTopColor)
  {
    setStyleAttribute("border-top-color", borderTopColor);
  }
  
  @JsxGetter
  public String getBorderTopStyle()
  {
    String value = getStyleAttribute("border-top-style");
    if (value.isEmpty())
    {
      value = findBorderStyle(getStyleAttribute("border-top"));
      if (value == null) {
        value = findBorderStyle(getStyleAttribute("border"));
      }
      if (value == null) {
        value = "";
      }
    }
    return value;
  }
  
  @JsxSetter
  public void setBorderTopStyle(String borderTopStyle)
  {
    setStyleAttribute("border-top-style", borderTopStyle);
  }
  
  @JsxGetter
  public String getBorderTopWidth()
  {
    return getBorderWidth(Shorthand.TOP);
  }
  
  @JsxSetter
  public void setBorderTopWidth(String borderTopWidth)
  {
    setStyleAttributePixel("border-top-width", borderTopWidth);
  }
  
  @JsxGetter
  public String getBorderWidth()
  {
    return getStyleAttribute("border-width");
  }
  
  @JsxSetter
  public void setBorderWidth(String borderWidth)
  {
    setStyleAttribute("border-width", borderWidth);
  }
  
  @JsxGetter
  public String getBottom()
  {
    return getStyleAttribute("bottom");
  }
  
  @JsxSetter
  public void setBottom(String bottom)
  {
    setStyleAttributePixel("bottom", bottom);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F)})
  public String getBoxSizing()
  {
    return getStyleAttribute("box-sizing");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F)})
  public void setBoxSizing(String boxSizing)
  {
    setStyleAttribute("box-sizing", boxSizing);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCaptionSide()
  {
    return getStyleAttribute("caption-side");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setCaptionSide(String captionSide)
  {
    setStyleAttribute("caption-side", captionSide);
  }
  
  @JsxGetter
  public String getClear()
  {
    return getStyleAttribute("clear");
  }
  
  @JsxSetter
  public void setClear(String clear)
  {
    setStyleAttribute("clear", clear);
  }
  
  @JsxGetter
  public String getClip()
  {
    return getStyleAttribute("clip");
  }
  
  @JsxSetter
  public void setClip(String clip)
  {
    setStyleAttribute("clip", clip);
  }
  
  @JsxGetter
  public String getColor()
  {
    return getStyleAttribute("color");
  }
  
  @JsxSetter
  public void setColor(String color)
  {
    setStyleAttribute("color", color);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getContent()
  {
    return getStyleAttribute("content");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setContent(String content)
  {
    setStyleAttribute("content", content);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCounterIncrement()
  {
    return getStyleAttribute("counter-increment");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setCounterIncrement(String counterIncrement)
  {
    setStyleAttribute("counter-increment", counterIncrement);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCounterReset()
  {
    return getStyleAttribute("counter-reset");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setCounterReset(String counterReset)
  {
    setStyleAttribute("counter-reset", counterReset);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCssFloat()
  {
    return getStyleAttribute("float");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setCssFloat(String value)
  {
    setStyleAttribute("float", value);
  }
  
  @JsxGetter
  public String getCssText()
  {
    return this.jsElement_.getDomNodeOrDie().getAttribute("style");
  }
  
  @JsxSetter
  public void setCssText(String value)
  {
    this.jsElement_.getDomNodeOrDie().setAttribute("style", value);
  }
  
  @JsxGetter
  public String getCursor()
  {
    return getStyleAttribute("cursor");
  }
  
  @JsxSetter
  public void setCursor(String cursor)
  {
    setStyleAttribute("cursor", cursor);
  }
  
  @JsxGetter
  public String getDirection()
  {
    return getStyleAttribute("direction");
  }
  
  @JsxSetter
  public void setDirection(String direction)
  {
    setStyleAttribute("direction", direction);
  }
  
  @JsxGetter
  public String getDisplay()
  {
    return getStyleAttribute("display");
  }
  
  @JsxSetter
  public void setDisplay(String display)
  {
    setStyleAttribute("display", display);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getEmptyCells()
  {
    return getStyleAttribute("empty-cells");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setEmptyCells(String emptyCells)
  {
    setStyleAttribute("empty-cells", emptyCells);
  }
  
  @JsxGetter
  public String getFont()
  {
    return getStyleAttribute("font");
  }
  
  @JsxSetter
  public void setFont(String font)
  {
    setStyleAttribute("font", font);
  }
  
  @JsxGetter
  public String getFontFamily()
  {
    return getStyleAttribute("font-family");
  }
  
  @JsxSetter
  public void setFontFamily(String fontFamily)
  {
    setStyleAttribute("font-family", fontFamily);
  }
  
  @JsxGetter
  public String getFontSize()
  {
    return getStyleAttribute("font-size");
  }
  
  @JsxSetter
  public void setFontSize(String fontSize)
  {
    setStyleAttributePixel("font-size", fontSize);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getFontSizeAdjust()
  {
    return getStyleAttribute("font-size-adjust");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setFontSizeAdjust(String fontSizeAdjust)
  {
    setStyleAttribute("font-size-adjust", fontSizeAdjust);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getFontStretch()
  {
    return getStyleAttribute("font-stretch");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setFontStretch(String fontStretch)
  {
    setStyleAttribute("font-stretch", fontStretch);
  }
  
  @JsxGetter
  public String getFontStyle()
  {
    return getStyleAttribute("font-style");
  }
  
  @JsxSetter
  public void setFontStyle(String fontStyle)
  {
    setStyleAttribute("font-style", fontStyle);
  }
  
  @JsxGetter
  public String getFontVariant()
  {
    return getStyleAttribute("font-variant");
  }
  
  @JsxSetter
  public void setFontVariant(String fontVariant)
  {
    setStyleAttribute("font-variant", fontVariant);
  }
  
  @JsxGetter
  public String getFontWeight()
  {
    return getStyleAttribute("font-weight");
  }
  
  @JsxSetter
  public void setFontWeight(String fontWeight)
  {
    setStyleAttribute("font-weight", fontWeight);
  }
  
  @JsxGetter
  public String getHeight()
  {
    return getStyleAttribute("height");
  }
  
  @JsxSetter
  public void setHeight(String height)
  {
    setStyleAttributePixel("height", height);
  }
  
  @JsxGetter
  public String getImeMode()
  {
    return getStyleAttribute("ime-mode");
  }
  
  @JsxSetter
  public void setImeMode(String imeMode)
  {
    setStyleAttribute("ime-mode", imeMode);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLayoutFlow()
  {
    return getStyleAttribute("layout-flow");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLayoutFlow(String layoutFlow)
  {
    setStyleAttribute("layout-flow", layoutFlow);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLayoutGrid()
  {
    return getStyleAttribute("layout-grid");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLayoutGrid(String layoutGrid)
  {
    setStyleAttribute("layout-grid-char", layoutGrid);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLayoutGridChar()
  {
    return getStyleAttribute("layout-grid-char");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLayoutGridChar(String layoutGridChar)
  {
    setStyleAttribute("layout-grid-char", layoutGridChar);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLayoutGridLine()
  {
    return getStyleAttribute("layout-grid-line");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLayoutGridLine(String layoutGridLine)
  {
    setStyleAttribute("layout-grid-line", layoutGridLine);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLayoutGridMode()
  {
    return getStyleAttribute("layout-grid-mode");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLayoutGridMode(String layoutGridMode)
  {
    setStyleAttribute("layout-grid-mode", layoutGridMode);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLayoutGridType()
  {
    return getStyleAttribute("layout-grid-type");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLayoutGridType(String layoutGridType)
  {
    setStyleAttribute("layout-grid-type", layoutGridType);
  }
  
  @JsxGetter
  public String getLeft()
  {
    return getStyleAttribute("left");
  }
  
  @JsxSetter
  public void setLeft(String left)
  {
    setStyleAttributePixel("left", left);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getLength()
  {
    return 0;
  }
  
  @JsxGetter
  public String getLetterSpacing()
  {
    return getStyleAttribute("letter-spacing");
  }
  
  @JsxSetter
  public void setLetterSpacing(String letterSpacing)
  {
    setStyleAttributePixel("letter-spacing", letterSpacing);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getLineBreak()
  {
    return getStyleAttribute("line-break");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setLineBreak(String lineBreak)
  {
    setStyleAttribute("line-break", lineBreak);
  }
  
  @JsxGetter
  public String getListStyle()
  {
    return getStyleAttribute("list-style");
  }
  
  @JsxSetter
  public void setListStyle(String listStyle)
  {
    setStyleAttribute("list-style", listStyle);
  }
  
  @JsxGetter
  public String getListStyleImage()
  {
    return getStyleAttribute("list-style-image");
  }
  
  @JsxSetter
  public void setListStyleImage(String listStyleImage)
  {
    setStyleAttribute("list-style-image", listStyleImage);
  }
  
  @JsxGetter
  public String getListStylePosition()
  {
    return getStyleAttribute("list-style-position");
  }
  
  @JsxSetter
  public void setListStylePosition(String listStylePosition)
  {
    setStyleAttribute("list-style-position", listStylePosition);
  }
  
  @JsxGetter
  public String getListStyleType()
  {
    return getStyleAttribute("list-style-type");
  }
  
  @JsxSetter
  public void setListStyleType(String listStyleType)
  {
    setStyleAttribute("list-style-type", listStyleType);
  }
  
  @JsxGetter
  public String getMargin()
  {
    return getStyleAttribute("margin");
  }
  
  @JsxSetter
  public void setMargin(String margin)
  {
    setStyleAttribute("margin", margin);
  }
  
  @JsxGetter
  public String getMarginBottom()
  {
    return getStyleAttribute("margin-bottom", "margin", Shorthand.BOTTOM);
  }
  
  @JsxSetter
  public void setMarginBottom(String marginBottom)
  {
    setStyleAttributePixel("margin-bottom", marginBottom);
  }
  
  @JsxGetter
  public String getMarginLeft()
  {
    return getStyleAttribute("margin-left", "margin", Shorthand.LEFT);
  }
  
  @JsxSetter
  public void setMarginLeft(String marginLeft)
  {
    setStyleAttributePixel("margin-left", marginLeft);
  }
  
  @JsxGetter
  public String getMarginRight()
  {
    return getStyleAttribute("margin-right", "margin", Shorthand.RIGHT);
  }
  
  @JsxSetter
  public void setMarginRight(String marginRight)
  {
    setStyleAttributePixel("margin-right", marginRight);
  }
  
  @JsxGetter
  public String getMarginTop()
  {
    return getStyleAttribute("margin-top", "margin", Shorthand.TOP);
  }
  
  @JsxSetter
  public void setMarginTop(String marginTop)
  {
    setStyleAttributePixel("margin-top", marginTop);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getMarkerOffset()
  {
    return getStyleAttribute("marker-offset");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setMarkerOffset(String markerOffset)
  {
    setStyleAttribute("marker-offset", markerOffset);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getMarks()
  {
    return getStyleAttribute("marks");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setMarks(String marks)
  {
    setStyleAttribute("marks", marks);
  }
  
  @JsxGetter
  public String getMaxHeight()
  {
    return getStyleAttribute("max-height");
  }
  
  @JsxSetter
  public void setMaxHeight(String maxHeight)
  {
    setStyleAttributePixel("max-height", maxHeight);
  }
  
  @JsxGetter
  public String getMaxWidth()
  {
    return getStyleAttribute("max-width");
  }
  
  @JsxSetter
  public void setMaxWidth(String maxWidth)
  {
    setStyleAttributePixel("max-width", maxWidth);
  }
  
  @JsxGetter
  public String getMinHeight()
  {
    return getStyleAttribute("min-height");
  }
  
  @JsxSetter
  public void setMinHeight(String minHeight)
  {
    setStyleAttributePixel("min-height", minHeight);
  }
  
  @JsxGetter
  public String getMinWidth()
  {
    return getStyleAttribute("min-width");
  }
  
  @JsxSetter
  public void setMinWidth(String minWidth)
  {
    setStyleAttributePixel("min-width", minWidth);
  }
  
  public Object get(String name, Scriptable start)
  {
    if (this != start) {
      return super.get(name, start);
    }
    StyleAttributes.Definition style = StyleAttributes.getDefinition(name, getBrowserVersion());
    if (style != null) {
      return getStyleAttributeValue(style);
    }
    return super.get(name, start);
  }
  
  protected String getStyleAttributeValue(StyleAttributes.Definition style)
  {
    return getStyleAttribute(style.getAttributeName());
  }
  
  public void put(String name, Scriptable start, Object value)
  {
    if (this != start)
    {
      super.put(name, start, value);
      return;
    }
    if (getDomNodeOrNull() != null)
    {
      StyleAttributes.Definition style = StyleAttributes.getDefinition(name, getBrowserVersion());
      if (style != null)
      {
        String stringValue = Context.toString(value);
        setStyleAttribute(style.getPropertyName(), stringValue);
        return;
      }
    }
    super.put(name, start, value);
  }
  
  public boolean has(String name, Scriptable start)
  {
    if (this != start) {
      return super.has(name, start);
    }
    StyleAttributes.Definition style = StyleAttributes.getDefinition(name, getBrowserVersion());
    if (style != null) {
      return true;
    }
    return super.has(name, start);
  }
  
  public Object[] getIds()
  {
    List<Object> ids = new ArrayList();
    for (StyleAttributes.Definition styleAttribute : StyleAttributes.getDefinitions(getBrowserVersion())) {
      ids.add(styleAttribute.getPropertyName());
    }
    Object[] normalIds = super.getIds();
    for (Object o : normalIds) {
      if (!ids.contains(o)) {
        ids.add(o);
      }
    }
    return ids.toArray();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F)})
  public String getMsBlockProgression()
  {
    return getStyleAttribute("ms-block-progression");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F)})
  public void setMsBlockProgression(String msBlockProgression)
  {
    setStyleAttribute("ms-block-progression", msBlockProgression);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getMsInterpolationMode()
  {
    return getStyleAttribute("ms-interpolation-mode");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setMsInterpolationMode(String msInterpolationMode)
  {
    setStyleAttribute("ms-interpolation-mode", msInterpolationMode);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getOpacity()
  {
    String opacity = getStyleAttribute("opacity");
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_OPACITY_ACCEPTS_ARBITRARY_VALUES)) {
      return opacity;
    }
    if ((opacity == null) || (opacity.isEmpty())) {
      return "";
    }
    String trimedOpacity = opacity.trim();
    try
    {
      float value = Float.parseFloat(trimedOpacity);
      if (value % 1.0F == 0.0F) {
        return Integer.toString((int)value);
      }
      return Float.toString(value);
    }
    catch (NumberFormatException e) {}
    return "";
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void setOpacity(String opacity)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_OPACITY_ACCEPTS_ARBITRARY_VALUES))
    {
      setStyleAttribute("opacity", opacity);
      return;
    }
    if (opacity.isEmpty()) {
      setStyleAttribute("opacity", opacity);
    }
    String trimedOpacity = opacity.trim();
    try
    {
      Float.parseFloat(trimedOpacity);
      setStyleAttribute("opacity", trimedOpacity);
    }
    catch (NumberFormatException e) {}
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOrphans()
  {
    return getStyleAttribute("orphans");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOrphans(String orphans)
  {
    setStyleAttribute("orphans", orphans);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOutline()
  {
    return getStyleAttribute("outline");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOutline(String outline)
  {
    setStyleAttribute("outline", outline);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOutlineColor()
  {
    return getStyleAttribute("outline-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOutlineColor(String outlineColor)
  {
    setStyleAttribute("outline-color", outlineColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOutlineOffset()
  {
    return getStyleAttribute("outline-offset");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOutlineOffset(String outlineOffset)
  {
    setStyleAttribute("outline-offset", outlineOffset);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOutlineStyle()
  {
    return getStyleAttribute("outline-style");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOutlineStyle(String outlineStyle)
  {
    setStyleAttribute("outline-style", outlineStyle);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOutlineWidth()
  {
    return getStyleAttribute("outline-width");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setOutlineWidth(String outlineWidth)
  {
    setStyleAttributePixel("outline-width", outlineWidth);
  }
  
  @JsxGetter
  public String getOverflow()
  {
    return getStyleAttribute("overflow");
  }
  
  @JsxSetter
  public void setOverflow(String overflow)
  {
    setStyleAttribute("overflow", overflow);
  }
  
  @JsxGetter
  public String getOverflowX()
  {
    return getStyleAttribute("overflow-x");
  }
  
  @JsxSetter
  public void setOverflowX(String overflowX)
  {
    setStyleAttribute("overflow-x", overflowX);
  }
  
  @JsxGetter
  public String getOverflowY()
  {
    return getStyleAttribute("overflow-y");
  }
  
  @JsxSetter
  public void setOverflowY(String overflowY)
  {
    setStyleAttribute("overflow-y", overflowY);
  }
  
  @JsxGetter
  public String getPadding()
  {
    return getStyleAttribute("padding");
  }
  
  @JsxSetter
  public void setPadding(String padding)
  {
    setStyleAttribute("padding", padding);
  }
  
  @JsxGetter
  public String getPaddingBottom()
  {
    return getStyleAttribute("padding-bottom", "padding", Shorthand.BOTTOM);
  }
  
  @JsxSetter
  public void setPaddingBottom(String paddingBottom)
  {
    setStyleAttributePixel("padding-bottom", paddingBottom);
  }
  
  @JsxGetter
  public String getPaddingLeft()
  {
    return getStyleAttribute("padding-left", "padding", Shorthand.LEFT);
  }
  
  @JsxSetter
  public void setPaddingLeft(String paddingLeft)
  {
    setStyleAttributePixel("padding-left", paddingLeft);
  }
  
  @JsxGetter
  public String getPaddingRight()
  {
    return getStyleAttribute("padding-right", "padding", Shorthand.RIGHT);
  }
  
  @JsxSetter
  public void setPaddingRight(String paddingRight)
  {
    setStyleAttributePixel("padding-right", paddingRight);
  }
  
  @JsxGetter
  public String getPaddingTop()
  {
    return getStyleAttribute("padding-top", "padding", Shorthand.TOP);
  }
  
  @JsxSetter
  public void setPaddingTop(String paddingTop)
  {
    setStyleAttributePixel("padding-top", paddingTop);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPage()
  {
    return getStyleAttribute("page");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setPage(String page)
  {
    setStyleAttribute("page", page);
  }
  
  @JsxGetter
  public String getPageBreakAfter()
  {
    return getStyleAttribute("page-break-after");
  }
  
  @JsxSetter
  public void setPageBreakAfter(String pageBreakAfter)
  {
    setStyleAttribute("page-break-after", pageBreakAfter);
  }
  
  @JsxGetter
  public String getPageBreakBefore()
  {
    return getStyleAttribute("page-break-before");
  }
  
  @JsxSetter
  public void setPageBreakBefore(String pageBreakBefore)
  {
    setStyleAttribute("page-break-before", pageBreakBefore);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPageBreakInside()
  {
    return getStyleAttribute("page-break-inside");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setPageBreakInside(String pageBreakInside)
  {
    setStyleAttribute("page-break-inside", pageBreakInside);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPointerEvents()
  {
    return getStyleAttribute("pointer-events");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setPointerEvents(String pointerEvents)
  {
    setStyleAttribute("pointer-events", pointerEvents);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPixelBottom()
  {
    return pixelValue(getBottom());
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPixelBottom(int pixelBottom)
  {
    setBottom(pixelBottom + "px");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPixelLeft()
  {
    return pixelValue(getLeft());
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPixelLeft(int pixelLeft)
  {
    setLeft(pixelLeft + "px");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPixelRight()
  {
    return pixelValue(getRight());
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPixelRight(int pixelRight)
  {
    setRight(pixelRight + "px");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPixelTop()
  {
    return pixelValue(getTop());
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPixelTop(int pixelTop)
  {
    setTop(pixelTop + "px");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPosBottom()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPosHeight()
  {
    return 0;
  }
  
  @JsxGetter
  public String getPosition()
  {
    return getStyleAttribute("position");
  }
  
  @JsxSetter
  public void setPosition(String position)
  {
    setStyleAttribute("position", position);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPosLeft()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPosRight()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPosTop()
  {
    return 0;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public int getPosWidth()
  {
    return 0;
  }
  
  @JsxGetter
  public String getRight()
  {
    return getStyleAttribute("right");
  }
  
  @JsxSetter
  public void setRight(String right)
  {
    setStyleAttributePixel("right", right);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getRubyAlign()
  {
    return getStyleAttribute("ruby-align");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setRubyAlign(String rubyAlign)
  {
    setStyleAttribute("ruby-align", rubyAlign);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getRubyOverhang()
  {
    return getStyleAttribute("ruby-overhang");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setRubyOverhang(String rubyOverhang)
  {
    setStyleAttribute("ruby-overhang", rubyOverhang);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getRubyPosition()
  {
    return getStyleAttribute("ruby-position");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setRubyPosition(String rubyPosition)
  {
    setStyleAttribute("ruby-position", rubyPosition);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbar3dLightColor()
  {
    return getStyleAttribute("scrollbar3d-light-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbar3dLightColor(String scrollbar3dLightColor)
  {
    setStyleAttribute("scrollbar3d-light-color", scrollbar3dLightColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarArrowColor()
  {
    return getStyleAttribute("scrollbar-arrow-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarArrowColor(String scrollbarArrowColor)
  {
    setStyleAttribute("scrollbar-arrow-color", scrollbarArrowColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarBaseColor()
  {
    return getStyleAttribute("scrollbar-base-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarBaseColor(String scrollbarBaseColor)
  {
    setStyleAttribute("scrollbar-base-color", scrollbarBaseColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarDarkShadowColor()
  {
    return getStyleAttribute("scrollbar-dark-shadow-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarDarkShadowColor(String scrollbarDarkShadowColor)
  {
    setStyleAttribute("scrollbar-dark-shadow-color", scrollbarDarkShadowColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarFaceColor()
  {
    return getStyleAttribute("scrollbar-face-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarFaceColor(String scrollbarFaceColor)
  {
    setStyleAttribute("scrollbar-face-color", scrollbarFaceColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarHighlightColor()
  {
    return getStyleAttribute("scrollbar-highlight-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarHighlightColor(String scrollbarHighlightColor)
  {
    setStyleAttribute("scrollbar-highlight-color", scrollbarHighlightColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarShadowColor()
  {
    return getStyleAttribute("scrollbar-shadow-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarShadowColor(String scrollbarShadowColor)
  {
    setStyleAttribute("scrollbar-shadow-color", scrollbarShadowColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getScrollbarTrackColor()
  {
    return getStyleAttribute("scrollbar-track-color");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setScrollbarTrackColor(String scrollbarTrackColor)
  {
    setStyleAttribute("scrollbar-track-color", scrollbarTrackColor);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getSize()
  {
    return getStyleAttribute("size");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSize(String size)
  {
    setStyleAttribute("size", size);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getStyleFloat()
  {
    return getStyleAttribute("float");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setStyleFloat(String value)
  {
    setStyleAttribute("float", value);
  }
  
  @JsxGetter
  public String getTableLayout()
  {
    return getStyleAttribute("table-layout");
  }
  
  @JsxSetter
  public void setTableLayout(String tableLayout)
  {
    setStyleAttribute("table-layout", tableLayout);
  }
  
  @JsxGetter
  public String getTextAlign()
  {
    return getStyleAttribute("text-align");
  }
  
  @JsxSetter
  public void setTextAlign(String textAlign)
  {
    setStyleAttribute("text-align", textAlign);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextAlignLast()
  {
    return getStyleAttribute("text-align-last");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextAlignLast(String textAlignLast)
  {
    setStyleAttribute("text-align-last", textAlignLast);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextAutospace()
  {
    return getStyleAttribute("text-autospace");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextAutospace(String textAutospace)
  {
    setStyleAttribute("text-autospace", textAutospace);
  }
  
  @JsxGetter
  public String getTextDecoration()
  {
    return getStyleAttribute("text-decoration");
  }
  
  @JsxSetter
  public void setTextDecoration(String textDecoration)
  {
    setStyleAttribute("text-decoration", textDecoration);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean getTextDecorationBlink()
  {
    return false;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean getTextDecorationLineThrough()
  {
    return false;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean getTextDecorationNone()
  {
    return false;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean getTextDecorationOverline()
  {
    return false;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean getTextDecorationUnderline()
  {
    return false;
  }
  
  @JsxGetter
  public String getTextIndent()
  {
    return getStyleAttribute("text-indent");
  }
  
  @JsxSetter
  public void setTextIndent(String textIndent)
  {
    setStyleAttributePixel("text-indent", textIndent);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextJustify()
  {
    return getStyleAttribute("text-justify");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextJustify(String textJustify)
  {
    setStyleAttribute("text-justify", textJustify);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextJustifyTrim()
  {
    return getStyleAttribute("text-justify-trim");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextJustifyTrim(String textJustifyTrim)
  {
    setStyleAttribute("text-justify-trim", textJustifyTrim);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextKashida()
  {
    return getStyleAttribute("text-kashida");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextKashida(String textKashida)
  {
    setStyleAttribute("text-kashida", textKashida);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextKashidaSpace()
  {
    return getStyleAttribute("text-kashida-space");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextKashidaSpace(String textKashidaSpace)
  {
    setStyleAttribute("text-kashida-space", textKashidaSpace);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextOverflow()
  {
    return getStyleAttribute("text-overflow");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextOverflow(String textOverflow)
  {
    setStyleAttribute("text-overflow", textOverflow);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getTextShadow()
  {
    return getStyleAttribute("text-shadow");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setTextShadow(String textShadow)
  {
    setStyleAttribute("text-shadow", textShadow);
  }
  
  @JsxGetter
  public String getTextTransform()
  {
    return getStyleAttribute("text-transform");
  }
  
  @JsxSetter
  public void setTextTransform(String textTransform)
  {
    setStyleAttribute("text-transform", textTransform);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getTextUnderlinePosition()
  {
    return getStyleAttribute("text-underline-position");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextUnderlinePosition(String textUnderlinePosition)
  {
    setStyleAttribute("text-underline-position", textUnderlinePosition);
  }
  
  @JsxGetter
  public String getTop()
  {
    return getStyleAttribute("top");
  }
  
  @JsxSetter
  public void setTop(String top)
  {
    setStyleAttributePixel("top", top);
  }
  
  @JsxGetter
  public String getVerticalAlign()
  {
    return getStyleAttribute("vertical-align");
  }
  
  @JsxSetter
  public void setVerticalAlign(String verticalAlign)
  {
    setStyleAttributePixel("vertical-align", verticalAlign);
  }
  
  @JsxGetter
  public String getVisibility()
  {
    return getStyleAttribute("visibility");
  }
  
  @JsxSetter
  public void setVisibility(String visibility)
  {
    setStyleAttribute("visibility", visibility);
  }
  
  @JsxGetter
  public String getWhiteSpace()
  {
    return getStyleAttribute("white-space");
  }
  
  @JsxSetter
  public void setWhiteSpace(String whiteSpace)
  {
    setStyleAttribute("white-space", whiteSpace);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getWidows()
  {
    return getStyleAttribute("widows");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setWidows(String widows)
  {
    setStyleAttribute("widows", widows);
  }
  
  @JsxGetter
  public String getWidth()
  {
    return getStyleAttribute("width");
  }
  
  @JsxSetter
  public void setWidth(String width)
  {
    setStyleAttributePixel("width", width);
  }
  
  @JsxGetter
  public String getWordSpacing()
  {
    return getStyleAttribute("word-spacing");
  }
  
  @JsxSetter
  public void setWordSpacing(String wordSpacing)
  {
    setStyleAttributePixel("word-spacing", wordSpacing);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getWordWrap()
  {
    return getStyleAttribute("word-wrap");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setWordWrap(String wordWrap)
  {
    setStyleAttribute("word-wrap", wordWrap);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getWritingMode()
  {
    return getStyleAttribute("writing-mode");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setWritingMode(String writingMode)
  {
    setStyleAttribute("writing-mode", writingMode);
  }
  
  @JsxGetter
  public Object getZIndex()
  {
    String value = getStyleAttribute("z-index");
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_ZINDEX_TYPE_NUMBER))
    {
      if ((value == null) || (Context.getUndefinedValue().equals(value)) || (org.apache.commons.lang3.StringUtils.isEmpty(value.toString()))) {
        return Integer.valueOf(0);
      }
      try
      {
        Double numericValue = Double.valueOf(value);
        return Integer.valueOf(numericValue.intValue());
      }
      catch (NumberFormatException e)
      {
        return Integer.valueOf(0);
      }
    }
    try
    {
      Integer.parseInt(value);
      return value;
    }
    catch (NumberFormatException e) {}
    return "";
  }
  
  @JsxSetter
  public void setZIndex(Object zIndex)
  {
    if ((zIndex == null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_ZINDEX_UNDEFINED_OR_NULL_THROWS_ERROR))) {
      throw new EvaluatorException("Null is invalid for z-index.");
    }
    if ((zIndex == null) || (org.apache.commons.lang3.StringUtils.isEmpty(zIndex.toString())))
    {
      setStyleAttribute("z-index", "");
      return;
    }
    if (Context.getUndefinedValue().equals(zIndex))
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_ZINDEX_UNDEFINED_OR_NULL_THROWS_ERROR)) {
        throw new EvaluatorException("Undefind is invalid for z-index.");
      }
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_ZINDEX_UNDEFINED_FORCES_RESET)) {
        setStyleAttribute("z-index", "");
      }
      return;
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_ZINDEX_TYPE_NUMBER))
    {
      Double d;
      Double d;
      if ((zIndex instanceof Double)) {
        d = (Double)zIndex;
      } else {
        try
        {
          d = Double.valueOf(zIndex.toString());
        }
        catch (NumberFormatException e)
        {
          throw new WrappedException(e);
        }
      }
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_ZINDEX_ROUNDED)) {
        setStyleAttribute("z-index", Integer.toString(Math.round(d.floatValue() - 1.0E-5F)));
      } else {
        setStyleAttribute("z-index", Integer.toString(d.intValue()));
      }
      return;
    }
    if ((zIndex instanceof Number))
    {
      Number number = (Number)zIndex;
      if (number.doubleValue() % 1.0D == 0.0D) {
        setStyleAttribute("z-index", Integer.toString(number.intValue()));
      }
      return;
    }
    try
    {
      int i = Integer.parseInt(zIndex.toString());
      setStyleAttribute("z-index", Integer.toString(i));
    }
    catch (NumberFormatException e) {}
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getZoom()
  {
    return getStyleAttribute("zoom");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setZoom(String zoom)
  {
    setStyleAttribute("zoom", zoom);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getPropertyValue(String name)
  {
    if ((name != null) && (name.contains("-")))
    {
      Object value = getProperty(this, camelize(name));
      if ((value instanceof String)) {
        return (String)value;
      }
    }
    return getStyleAttribute(name);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public CSSValue getPropertyCSSValue(String name)
  {
    LOG.info("getPropertyCSSValue(" + name + "): getPropertyCSSValue support is experimental");
    if (this.styleDeclaration_ == null)
    {
      String uri = getDomNodeOrDie().getPage().getWebResponse().getWebRequest().getUrl().toExternalForm();
      
      String styleAttribute = this.jsElement_.getDomNodeOrDie().getAttribute("style");
      InputSource source = new InputSource(new StringReader(styleAttribute));
      source.setURI(uri);
      ErrorHandler errorHandler = getWindow().getWebWindow().getWebClient().getCssErrorHandler();
      CSSOMParser parser = new CSSOMParser(new SACParserCSS3());
      parser.setErrorHandler(errorHandler);
      try
      {
        this.styleDeclaration_ = parser.parseStyleDeclaration(source);
      }
      catch (IOException e)
      {
        throw new RuntimeException(e);
      }
    }
    org.w3c.dom.css.CSSValue cssValue = this.styleDeclaration_.getPropertyCSSValue(name);
    if (cssValue == null)
    {
      CSSValueImpl newValue = new CSSValueImpl();
      newValue.setFloatValue((short)5, 0.0F);
      cssValue = newValue;
    }
    String cssText = cssValue.getCssText();
    if (cssText.startsWith("rgb("))
    {
      String formatedCssText = org.apache.commons.lang3.StringUtils.replace(cssText, ",", ", ");
      cssValue.setCssText(formatedCssText);
    }
    return new CSSPrimitiveValue(this.jsElement_, (org.w3c.dom.css.CSSPrimitiveValue)cssValue);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String removeProperty(String name)
  {
    return removeStyleAttribute(name);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean removeExpression(String propertyName)
  {
    return true;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getAttribute(String name, int flag)
  {
    if (flag == 1) {
      return getStyleAttribute(name);
    }
    StyleElement style = getStyleElementCaseInSensitive(name);
    if (null == style) {
      return "";
    }
    return style.getValue();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setAttribute(String name, String value, Object flag)
  {
    int flagInt;
    int flagInt;
    if (flag == Undefined.instance) {
      flagInt = 1;
    } else {
      flagInt = (int)Context.toNumber(flag);
    }
    if (flagInt == 0)
    {
      StyleElement style = getStyleElementCaseInSensitive(name);
      if (null != style) {
        setStyleAttribute(style.getName(), value);
      }
    }
    else if (getStyleAttribute(name).length() > 0)
    {
      setStyleAttribute(name, value);
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean removeAttribute(String name, Object flag)
  {
    int flagInt;
    int flagInt;
    if (flag == Undefined.instance) {
      flagInt = 1;
    } else {
      flagInt = (int)Context.toNumber(flag);
    }
    if (flagInt == 0)
    {
      StyleElement style = getStyleElementCaseInSensitive(name);
      if (style != null)
      {
        removeStyleAttribute(style.getName());
        return true;
      }
      return false;
    }
    String s = getStyleAttribute(name);
    if (s.length() > 0)
    {
      removeStyleAttribute(name);
      return true;
    }
    return false;
  }
  
  private String findColor(String text)
  {
    Color tmpColor = com.gargoylesoftware.htmlunit.util.StringUtils.findColorRGB(text);
    if (tmpColor != null) {
      return com.gargoylesoftware.htmlunit.util.StringUtils.formatColor(tmpColor);
    }
    String[] tokens = org.apache.commons.lang3.StringUtils.split(text, ' ');
    for (String token : tokens)
    {
      if (isColorKeyword(token)) {
        return token;
      }
      tmpColor = com.gargoylesoftware.htmlunit.util.StringUtils.asColorHexadecimal(token);
      if (tmpColor != null)
      {
        if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_GET_BACKGROUND_COLOR_FOR_COMPUTED_STYLE_AS_RGB)) {
          return com.gargoylesoftware.htmlunit.util.StringUtils.formatColor(tmpColor);
        }
        return token;
      }
    }
    return null;
  }
  
  private String findImageUrl(String text)
  {
    Matcher m = URL_PATTERN.matcher(text);
    if (m.find())
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_IMAGE_URL_QUOTED)) {
        return "url(\"" + m.group(1) + "\")";
      }
      return "url(" + m.group(1) + ")";
    }
    return null;
  }
  
  private static String findPosition(String text)
  {
    Matcher m = POSITION_PATTERN.matcher(text);
    if (m.find()) {
      return m.group(1) + " " + m.group(3);
    }
    m = POSITION_PATTERN2.matcher(text);
    if (m.find()) {
      return m.group(1) + " " + m.group(2);
    }
    m = POSITION_PATTERN3.matcher(text);
    if (m.find()) {
      return m.group(2) + " " + m.group(1);
    }
    return null;
  }
  
  private static String findRepeat(String text)
  {
    if (text.contains("repeat-x")) {
      return "repeat-x";
    }
    if (text.contains("repeat-y")) {
      return "repeat-y";
    }
    if (text.contains("no-repeat")) {
      return "no-repeat";
    }
    if (text.contains("repeat")) {
      return "repeat";
    }
    return null;
  }
  
  private static String findAttachment(String text)
  {
    if (text.contains("scroll")) {
      return "scroll";
    }
    if (text.contains("fixed")) {
      return "fixed";
    }
    return null;
  }
  
  private static String findBorderStyle(String text)
  {
    for (String token : org.apache.commons.lang3.StringUtils.split(text, ' ')) {
      if (isBorderStyle(token)) {
        return token;
      }
    }
    return null;
  }
  
  private static String findBorderWidth(String text)
  {
    for (String token : org.apache.commons.lang3.StringUtils.split(text, ' ')) {
      if (isBorderWidth(token)) {
        return token;
      }
    }
    return null;
  }
  
  private static boolean isColorKeyword(String token)
  {
    return CSSColors_.containsKey(token.toLowerCase(Locale.ENGLISH));
  }
  
  public static String toRGBColor(String color)
  {
    String rgbValue = (String)CSSColors_.get(color.toLowerCase(Locale.ENGLISH));
    if (rgbValue != null) {
      return rgbValue;
    }
    return color;
  }
  
  private static boolean isBorderStyle(String token)
  {
    return ("none".equalsIgnoreCase(token)) || ("hidden".equalsIgnoreCase(token)) || ("dotted".equalsIgnoreCase(token)) || ("dashed".equalsIgnoreCase(token)) || ("solid".equalsIgnoreCase(token)) || ("double".equalsIgnoreCase(token)) || ("groove".equalsIgnoreCase(token)) || ("ridge".equalsIgnoreCase(token)) || ("inset".equalsIgnoreCase(token)) || ("outset".equalsIgnoreCase(token));
  }
  
  private static boolean isBorderWidth(String token)
  {
    return ("thin".equalsIgnoreCase(token)) || ("medium".equalsIgnoreCase(token)) || ("thick".equalsIgnoreCase(token)) || (isLength(token));
  }
  
  private static boolean isLength(String token)
  {
    if ((token.endsWith("em")) || (token.endsWith("ex")) || (token.endsWith("px")) || (token.endsWith("in")) || (token.endsWith("cm")) || (token.endsWith("mm")) || (token.endsWith("pt")) || (token.endsWith("pc")) || (token.endsWith("%")))
    {
      if (token.endsWith("%")) {
        token = token.substring(0, token.length() - 1);
      } else {
        token = token.substring(0, token.length() - 2);
      }
      try
      {
        Float.parseFloat(token);
        return true;
      }
      catch (NumberFormatException e) {}
    }
    return false;
  }
  
  protected static int pixelValue(Element element, CssValue value)
  {
    String s = value.get(element);
    if ((s.endsWith("%")) || ((s.isEmpty()) && ((element instanceof HTMLHtmlElement))))
    {
      int i = NumberUtils.toInt(TO_INT_PATTERN.matcher(s).replaceAll("$1"), 100);
      Element parent = element.getParentElement();
      int absoluteValue = parent == null ? value.getWindowDefaultValue() : pixelValue(parent, value);
      return (int)(i / 100.0D * absoluteValue);
    }
    if ((s.isEmpty()) && ((element instanceof HTMLCanvasElement))) {
      return value.getWindowDefaultValue();
    }
    return pixelValue(s);
  }
  
  protected static int pixelValue(String value)
  {
    int i = NumberUtils.toInt(TO_INT_PATTERN.matcher(value).replaceAll("$1"), 0);
    if (value.length() < 2) {
      return i;
    }
    if (!value.endsWith("px")) {
      if (value.endsWith("em")) {
        i *= 16;
      } else if (value.endsWith("ex")) {
        i *= 10;
      } else if (value.endsWith("in")) {
        i *= 150;
      } else if (value.endsWith("cm")) {
        i *= 50;
      } else if (value.endsWith("mm")) {
        i *= 5;
      } else if (value.endsWith("pt")) {
        i *= 2;
      } else if (value.endsWith("pc")) {
        i *= 24;
      }
    }
    return i;
  }
  
  protected static abstract class CssValue
  {
    private final int windowDefaultValue_;
    
    public CssValue(int windowDefaultValue)
    {
      this.windowDefaultValue_ = windowDefaultValue;
    }
    
    public int getWindowDefaultValue()
    {
      return this.windowDefaultValue_;
    }
    
    public final String get(Element element)
    {
      ComputedCSSStyleDeclaration style = element.getCurrentStyle();
      String value = get(style);
      return value;
    }
    
    public abstract String get(ComputedCSSStyleDeclaration paramComputedCSSStyleDeclaration);
  }
  
  public String toString()
  {
    if (this.jsElement_ == null) {
      return "CSSStyleDeclaration for 'null'";
    }
    String style = this.jsElement_.getDomNodeOrDie().getAttribute("style");
    return "CSSStyleDeclaration for '" + style + "'";
  }
  
  public static class StyleElement
    implements Comparable<StyleElement>
  {
    private final String name_;
    private final String value_;
    private final String priority_;
    private final long index_;
    private final SelectorSpecificity specificity_;
    
    protected StyleElement(String name, String value, String priority, SelectorSpecificity specificity, long index)
    {
      this.name_ = name;
      this.value_ = value;
      this.priority_ = priority;
      this.index_ = index;
      this.specificity_ = specificity;
    }
    
    protected StyleElement(String name, String value, long index)
    {
      this(name, value, "", SelectorSpecificity.FROM_STYLE_ATTRIBUTE, index);
    }
    
    protected StyleElement(String name, String value)
    {
      this(name, value, Long.MIN_VALUE);
    }
    
    public String getName()
    {
      return this.name_;
    }
    
    public String getValue()
    {
      return this.value_;
    }
    
    public String getPriority()
    {
      return this.priority_;
    }
    
    public SelectorSpecificity getSpecificity()
    {
      return this.specificity_;
    }
    
    public long getIndex()
    {
      return this.index_;
    }
    
    public boolean isDefault()
    {
      return this.index_ == Long.MIN_VALUE;
    }
    
    public String toString()
    {
      return "[" + this.index_ + "]" + this.name_ + "=" + this.value_;
    }
    
    public int compareTo(StyleElement e)
    {
      if (e != null)
      {
        long styleIndex = e.index_;
        
        return this.index_ == styleIndex ? 0 : this.index_ < styleIndex ? -1 : 1;
      }
      return 1;
    }
  }
  
  protected void setStyleAttributePixel(String name, String value)
  {
    if (value.endsWith("px")) {
      value = value.substring(0, value.length() - 2);
    }
    try
    {
      float floatValue = Float.parseFloat(value);
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_PIXEL_VALUES_INT_ONLY)) {
        value = Integer.toString((int)floatValue) + "px";
      } else if (floatValue % 1.0F == 0.0F) {
        value = Integer.toString((int)floatValue) + "px";
      } else {
        value = Float.toString(floatValue) + "px";
      }
    }
    catch (Exception e) {}
    setStyleAttribute(name, value);
  }
  
  public CSSStyleDeclaration() {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPosBottom(int posBottom) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPosHeight(int posHeight) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPosLeft(int posLeft) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPosRight(int posRight) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPosTop(int posTop) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setPosWidth(int posWidth) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextDecorationBlink(boolean textDecorationBlink) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextDecorationLineThrough(boolean textDecorationLineThrough) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextDecorationNone(boolean textDecorationNone) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextDecorationOverline(boolean textDecorationOverline) {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setTextDecorationUnderline(boolean textDecorationUnderline) {}
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setExpression(String propertyName, String expression, String language) {}
}
