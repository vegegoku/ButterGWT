package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlTableColumn;
import com.gargoylesoftware.htmlunit.html.HtmlTableColumnGroup;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(domClasses={HtmlTableColumn.class, HtmlTableColumnGroup.class})
public class HTMLTableColElement
  extends HTMLTableComponent
{
  @JsxGetter
  public int getSpan()
  {
    String span = getDomNodeOrDie().getAttribute("span");
    int i;
    try
    {
      i = Integer.parseInt(span);
      if (i < 1) {
        i = 1;
      }
    }
    catch (NumberFormatException e)
    {
      i = 1;
    }
    return i;
  }
  
  @JsxSetter
  public void setSpan(Object span)
  {
    double d = Context.toNumber(span);
    int i = (int)d;
    if (i < 1) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.TABLE_COLUMN_SPAN_THROWS_EXCEPTION_IF_LESS_THAN_ONE))
      {
        Exception e = new Exception("Cannot set the span property to invalid value: " + span);
        Context.throwAsScriptRuntimeEx(e);
      }
      else
      {
        i = 1;
      }
    }
    getDomNodeOrDie().setAttribute("span", Integer.toString(i));
  }
  
  @JsxGetter(propertyName="width")
  public String getWidth_js()
  {
    boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.TABLE_COLUMN_WIDTH_DOES_NOT_RETURN_NEGATIVE_VALUES);
    Boolean returnNegativeValues = ie ? Boolean.FALSE : null;
    return getWidthOrHeight("width", returnNegativeValues);
  }
  
  @JsxSetter
  public void setWidth(Object width)
  {
    setWidthOrHeight("width", width == null ? "" : Context.toString(width), false);
  }
  
  protected boolean isEndTagForbidden()
  {
    return getDomNodeOrDie() instanceof HtmlTableColumn;
  }
  
  public String getDefaultStyleDisplay()
  {
    String tagName = getTagName();
    if ("COLGROUP".equals(tagName)) {
      return "table-column-group";
    }
    return "table-column";
  }
}
