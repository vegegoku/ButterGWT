package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.event.logical.shared.CloseEvent;
import com.google.gwt.event.logical.shared.CloseHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.i18n.client.DateTimeFormat.PredefinedFormat;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.text.shared.SimpleSafeHtmlRenderer;
import com.google.gwt.user.client.Event.NativePreviewEvent;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.PopupPanel.PositionCallback;
import com.google.gwt.user.datepicker.client.DatePicker;
import java.util.Date;

public class DatePickerCell
  extends AbstractEditableCell<Date, Date>
{
  private static final int ESCAPE = 27;
  private final DatePicker datePicker;
  private final DateTimeFormat format;
  private int offsetX = 10;
  private int offsetY = 10;
  private Object lastKey;
  private Element lastParent;
  private int lastIndex;
  private int lastColumn;
  private Date lastValue;
  private PopupPanel panel;
  private final SafeHtmlRenderer<String> renderer;
  private ValueUpdater<Date> valueUpdater;
  
  public DatePickerCell()
  {
    this(DateTimeFormat.getFullDateFormat(), SimpleSafeHtmlRenderer.getInstance());
  }
  
  public DatePickerCell(DateTimeFormat format)
  {
    this(format, SimpleSafeHtmlRenderer.getInstance());
  }
  
  public DatePickerCell(SafeHtmlRenderer<String> renderer)
  {
    this(DateTimeFormat.getFormat(DateTimeFormat.PredefinedFormat.DATE_FULL), renderer);
  }
  
  public DatePickerCell(DateTimeFormat format, SafeHtmlRenderer<String> renderer)
  {
    super(new String[] { "click", "keydown" });
    if (format == null) {
      throw new IllegalArgumentException("format == null");
    }
    if (renderer == null) {
      throw new IllegalArgumentException("renderer == null");
    }
    this.format = format;
    this.renderer = renderer;
    
    this.datePicker = new DatePicker();
    this.panel = new PopupPanel(true, true)
    {
      protected void onPreviewNativeEvent(Event.NativePreviewEvent event)
      {
        if ((512 == event.getTypeInt()) && 
          (event.getNativeEvent().getKeyCode() == 27)) {
          DatePickerCell.this.panel.hide();
        }
      }
    };
    this.panel.addCloseHandler(new CloseHandler()
    {
      public void onClose(CloseEvent<PopupPanel> event)
      {
        DatePickerCell.this.lastKey = null;
        DatePickerCell.this.lastValue = null;
        DatePickerCell.this.lastIndex = -1;
        DatePickerCell.this.lastColumn = -1;
        if ((DatePickerCell.this.lastParent != null) && (!event.isAutoClosed())) {
          DatePickerCell.this.lastParent.focus();
        }
        DatePickerCell.this.lastParent = null;
      }
    });
    this.panel.add(this.datePicker);
    
    this.datePicker.addValueChangeHandler(new ValueChangeHandler()
    {
      public void onValueChange(ValueChangeEvent<Date> event)
      {
        Element cellParent = DatePickerCell.this.lastParent;
        Date oldValue = DatePickerCell.this.lastValue;
        Object key = DatePickerCell.this.lastKey;
        int index = DatePickerCell.this.lastIndex;
        int column = DatePickerCell.this.lastColumn;
        DatePickerCell.this.panel.hide();
        
        Date date = (Date)event.getValue();
        DatePickerCell.this.setViewData(key, date);
        DatePickerCell.this.setValue(new Cell.Context(index, column, key), cellParent, oldValue);
        if (DatePickerCell.this.valueUpdater != null) {
          DatePickerCell.this.valueUpdater.update(date);
        }
      }
    });
  }
  
  public DatePicker getDatePicker()
  {
    return this.datePicker;
  }
  
  public boolean isEditing(Cell.Context context, Element parent, Date value)
  {
    return (this.lastKey != null) && (this.lastKey.equals(context.getKey()));
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, Date value, NativeEvent event, ValueUpdater<Date> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    if ("click".equals(event.getType())) {
      onEnterKeyDown(context, parent, value, event, valueUpdater);
    }
  }
  
  public void render(Cell.Context context, Date value, SafeHtmlBuilder sb)
  {
    Object key = context.getKey();
    Date viewData = (Date)getViewData(key);
    if ((viewData != null) && (viewData.equals(value)))
    {
      clearViewData(key);
      viewData = null;
    }
    String s = null;
    if (viewData != null) {
      s = this.format.format(viewData);
    } else if (value != null) {
      s = this.format.format(value);
    }
    if (s != null) {
      sb.append(this.renderer.render(s));
    }
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, Date value, NativeEvent event, ValueUpdater<Date> valueUpdater)
  {
    this.lastKey = context.getKey();
    this.lastParent = parent;
    this.lastValue = value;
    this.lastIndex = context.getIndex();
    this.lastColumn = context.getColumn();
    this.valueUpdater = valueUpdater;
    
    Date viewData = (Date)getViewData(this.lastKey);
    Date date = viewData == null ? this.lastValue : viewData;
    this.datePicker.setCurrentMonth(date);
    this.datePicker.setValue(date);
    this.panel.setPopupPositionAndShow(new PopupPanel.PositionCallback()
    {
      public void setPosition(int offsetWidth, int offsetHeight)
      {
        DatePickerCell.this.panel.setPopupPosition(DatePickerCell.this.lastParent.getAbsoluteLeft() + DatePickerCell.this.offsetX, DatePickerCell.this.lastParent.getAbsoluteTop() + DatePickerCell.this.offsetY);
      }
    });
  }
}
