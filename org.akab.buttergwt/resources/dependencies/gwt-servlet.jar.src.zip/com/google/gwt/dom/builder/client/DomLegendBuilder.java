package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.LegendBuilder;
import com.google.gwt.dom.client.LegendElement;

public class DomLegendBuilder
  extends DomElementBuilderBase<LegendBuilder, LegendElement>
  implements LegendBuilder
{
  DomLegendBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public LegendBuilder accessKey(String accessKey)
  {
    ((LegendElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
}
