package com.google.gwt.cell.client;

import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.text.shared.SimpleSafeHtmlRenderer;

public class TextCell
  extends AbstractSafeHtmlCell<String>
{
  public TextCell()
  {
    super(SimpleSafeHtmlRenderer.getInstance(), new String[0]);
  }
  
  public TextCell(SafeHtmlRenderer<String> renderer)
  {
    super(renderer, new String[0]);
  }
  
  public void render(Cell.Context context, SafeHtml value, SafeHtmlBuilder sb)
  {
    if (value != null) {
      sb.append(value);
    }
  }
}
