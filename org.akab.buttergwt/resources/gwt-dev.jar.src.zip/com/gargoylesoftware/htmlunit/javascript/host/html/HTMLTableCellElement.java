package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlTableCell;
import com.gargoylesoftware.htmlunit.html.HtmlTableRow;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.MouseEvent;
import com.gargoylesoftware.htmlunit.javascript.host.css.ComputedCSSStyleDeclaration;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(domClasses={HtmlTableCell.class})
public class HTMLTableCellElement
  extends HTMLTableComponent
{
  public void setAttribute(String name, String value)
  {
    if (("noWrap".equals(name)) && (value != null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_92))) {
      value = "true";
    }
    super.setAttribute(name, value);
  }
  
  public int getOffsetHeight()
  {
    MouseEvent event = MouseEvent.getCurrentMouseEvent();
    if (isAncestorOfEventTarget(event)) {
      return super.getOffsetHeight();
    }
    ComputedCSSStyleDeclaration style = getCurrentStyle();
    boolean includeBorder = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_93);
    return style.getCalculatedHeight(includeBorder, true);
  }
  
  public int getOffsetWidth()
  {
    float w = super.getOffsetWidth();
    MouseEvent event = MouseEvent.getCurrentMouseEvent();
    if (isAncestorOfEventTarget(event)) {
      return (int)w;
    }
    ComputedCSSStyleDeclaration style = getCurrentStyle();
    if ("collapse".equals(style.getBorderCollapse()))
    {
      HtmlTableRow row = getRow();
      if (row != null)
      {
        HtmlElement thiz = getDomNodeOrDie();
        List<HtmlTableCell> cells = row.getCells();
        boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_94);
        boolean leftmost = cells.indexOf(thiz) == 0;
        boolean rightmost = cells.indexOf(thiz) == cells.size() - 1;
        w = (float)(w - ((ie) && (leftmost) ? 0.0D : 0.5D) * style.getBorderLeftValue());
        w = (float)(w - ((ie) && (rightmost) ? 0.0D : 0.5D) * style.getBorderRightValue());
      }
    }
    return (int)w;
  }
  
  @JsxGetter
  public Integer getCellIndex()
  {
    HtmlTableCell cell = (HtmlTableCell)getDomNodeOrDie();
    HtmlTableRow row = cell.getEnclosingRow();
    if (row == null) {
      return Integer.valueOf(-1);
    }
    return Integer.valueOf(row.getCells().indexOf(cell));
  }
  
  @JsxGetter
  public String getAbbr()
  {
    return getDomNodeOrDie().getAttribute("abbr");
  }
  
  @JsxSetter
  public void setAbbr(String abbr)
  {
    getDomNodeOrDie().setAttribute("abbr", abbr);
  }
  
  @JsxGetter
  public String getAxis()
  {
    return getDomNodeOrDie().getAttribute("axis");
  }
  
  @JsxSetter
  public void setAxis(String axis)
  {
    getDomNodeOrDie().setAttribute("axis", axis);
  }
  
  @JsxGetter
  public String getBgColor()
  {
    return getDomNodeOrDie().getAttribute("bgColor");
  }
  
  @JsxSetter
  public void setBgColor(String bgColor)
  {
    setColorAttribute("bgColor", bgColor);
  }
  
  @JsxGetter
  public int getColSpan()
  {
    String s = getDomNodeOrDie().getAttribute("colSpan");
    try
    {
      return Integer.parseInt(s);
    }
    catch (NumberFormatException e) {}
    return 1;
  }
  
  @JsxSetter
  public void setColSpan(String colSpan)
  {
    String s;
    try
    {
      int i = (int)Double.parseDouble(colSpan);
      String s;
      if (i > 0) {
        s = Integer.toString(i);
      } else {
        throw new NumberFormatException(colSpan);
      }
    }
    catch (NumberFormatException e)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_95)) {
        throw Context.throwAsScriptRuntimeEx(e);
      }
      s = "1";
    }
    getDomNodeOrDie().setAttribute("colSpan", s);
  }
  
  @JsxGetter
  public int getRowSpan()
  {
    String s = getDomNodeOrDie().getAttribute("rowSpan");
    try
    {
      return Integer.parseInt(s);
    }
    catch (NumberFormatException e) {}
    return 1;
  }
  
  @JsxSetter
  public void setRowSpan(String rowSpan)
  {
    String s;
    try
    {
      int i = (int)Double.parseDouble(rowSpan);
      String s;
      if (i > 0) {
        s = Integer.toString(i);
      } else {
        throw new NumberFormatException(rowSpan);
      }
    }
    catch (NumberFormatException e)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_96)) {
        throw Context.throwAsScriptRuntimeEx(e);
      }
      s = "1";
    }
    getDomNodeOrDie().setAttribute("rowSpan", s);
  }
  
  @JsxGetter
  public boolean getNoWrap()
  {
    return getDomNodeOrDie().hasAttribute("noWrap");
  }
  
  @JsxSetter
  public void setNoWrap(boolean noWrap)
  {
    if (noWrap)
    {
      String value = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_97) ? "true" : "";
      getDomNodeOrDie().setAttribute("noWrap", value);
    }
    else
    {
      getDomNodeOrDie().removeAttribute("noWrap");
    }
  }
  
  private HtmlTableRow getRow()
  {
    DomNode node = getDomNodeOrDie();
    while ((node != null) && (!(node instanceof HtmlTableRow))) {
      node = node.getParentNode();
    }
    return (HtmlTableRow)node;
  }
  
  @JsxGetter(propertyName="width")
  public String getWidth_js()
  {
    boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_98);
    Boolean returnNegativeValues = ie ? Boolean.TRUE : null;
    return getWidthOrHeight("width", returnNegativeValues);
  }
  
  @JsxSetter
  public void setWidth(String width)
  {
    setWidthOrHeight("width", width, !getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_99));
  }
  
  @JsxGetter(propertyName="height")
  public String getHeight_js()
  {
    boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_100);
    Boolean returnNegativeValues = ie ? Boolean.TRUE : null;
    return getWidthOrHeight("height", returnNegativeValues);
  }
  
  @JsxSetter
  public void setHeight(String height)
  {
    setWidthOrHeight("height", height, !getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_101));
  }
  
  public String getDefaultStyleDisplay()
  {
    return "table-cell";
  }
}
