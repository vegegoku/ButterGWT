package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.SpanBuilder;
import com.google.gwt.dom.client.SpanElement;

public class DomSpanBuilder
  extends DomElementBuilderBase<SpanBuilder, SpanElement>
  implements SpanBuilder
{
  DomSpanBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
