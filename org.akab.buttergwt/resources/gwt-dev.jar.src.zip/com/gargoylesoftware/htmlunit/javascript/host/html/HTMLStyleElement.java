package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.Cache;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlStyle;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import java.io.StringReader;
import java.net.URL;
import org.w3c.css.sac.InputSource;

@JsxClass(domClasses={HtmlStyle.class})
public class HTMLStyleElement
  extends HTMLElement
{
  private com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet sheet_;
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet getSheet()
  {
    if (this.sheet_ != null) {
      return this.sheet_;
    }
    HtmlStyle style = (HtmlStyle)getDomNodeOrDie();
    String css = style.getTextContent();
    
    Cache cache = getWindow().getWebWindow().getWebClient().getCache();
    org.w3c.dom.css.CSSStyleSheet cached = cache.getCachedStyleSheet(css);
    String uri = getDomNodeOrDie().getPage().getWebResponse().getWebRequest().getUrl().toExternalForm();
    if (cached != null)
    {
      this.sheet_ = new com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet(this, cached, uri);
    }
    else
    {
      InputSource source = new InputSource(new StringReader(css));
      this.sheet_ = new com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet(this, source, uri);
      cache.cache(css, this.sheet_.getWrappedSheet());
    }
    return this.sheet_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet getStyleSheet()
  {
    return getSheet();
  }
  
  @JsxGetter
  public String getType()
  {
    HtmlStyle style = (HtmlStyle)getDomNodeOrDie();
    return style.getTypeAttribute();
  }
  
  @JsxSetter
  public void setType(String type)
  {
    HtmlStyle style = (HtmlStyle)getDomNodeOrDie();
    style.setTypeAttribute(type);
  }
  
  @JsxGetter
  public String getMedia()
  {
    HtmlStyle style = (HtmlStyle)getDomNodeOrDie();
    return style.getAttribute("media");
  }
}
