package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlHeading1;
import com.gargoylesoftware.htmlunit.html.HtmlHeading2;
import com.gargoylesoftware.htmlunit.html.HtmlHeading3;
import com.gargoylesoftware.htmlunit.html.HtmlHeading4;
import com.gargoylesoftware.htmlunit.html.HtmlHeading5;
import com.gargoylesoftware.htmlunit.html.HtmlHeading6;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlHeading1.class, HtmlHeading2.class, HtmlHeading3.class, HtmlHeading4.class, HtmlHeading5.class, HtmlHeading6.class})
public class HTMLHeadingElement
  extends HTMLElement
{
  @JsxGetter
  public String getAlign()
  {
    return getAlign(false);
  }
  
  @JsxSetter
  public void setAlign(String align)
  {
    setAlign(align, false);
  }
}
