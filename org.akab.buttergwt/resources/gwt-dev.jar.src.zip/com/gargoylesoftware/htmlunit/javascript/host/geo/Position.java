package com.gargoylesoftware.htmlunit.javascript.host.geo;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass
public class Position
  extends SimpleScriptable
{
  private Coordinates coordinates_;
  
  public Position() {}
  
  Position(Coordinates coordinates)
  {
    this.coordinates_ = coordinates;
  }
  
  @JsxGetter
  public Coordinates getCoords()
  {
    return this.coordinates_;
  }
}
