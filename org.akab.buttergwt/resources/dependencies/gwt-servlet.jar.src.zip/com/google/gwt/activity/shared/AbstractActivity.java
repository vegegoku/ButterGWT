package com.google.gwt.activity.shared;

public abstract class AbstractActivity
  implements Activity
{
  public String mayStop()
  {
    return null;
  }
  
  public void onCancel() {}
  
  public void onStop() {}
}
