package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import java.io.IOException;
import java.util.Map;

public class HtmlCheckBoxInput
  extends HtmlInput
{
  private static final String DEFAULT_VALUE = "on";
  private boolean defaultCheckedState_;
  private boolean forceChecked_;
  
  HtmlCheckBoxInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, addValueIfNeeded(page, attributes));
    if (getAttribute("value") == "on") {
      setDefaultValue(ATTRIBUTE_NOT_DEFINED, false);
    }
    this.defaultCheckedState_ = hasAttribute("checked");
  }
  
  private static Map<String, DomAttr> addValueIfNeeded(SgmlPage page, Map<String, DomAttr> attributes)
  {
    for (String key : attributes.keySet()) {
      if ("value".equalsIgnoreCase(key)) {
        return attributes;
      }
    }
    DomAttr newAttr = new DomAttr(page, null, "value", "on", true);
    attributes.put("value", newAttr);
    
    return attributes;
  }
  
  public void reset()
  {
    setChecked(this.defaultCheckedState_);
  }
  
  public Page setChecked(boolean isChecked)
  {
    if (isChecked) {
      setAttribute("checked", "checked");
    } else {
      removeAttribute("checked");
    }
    if (hasFeature(BrowserVersionFeatures.EVENT_ONCHANGE_LOSING_FOCUS)) {
      return getPage();
    }
    return executeOnChangeHandlerIfAppropriate(this);
  }
  
  public String asText()
  {
    return super.asText();
  }
  
  protected boolean doClickStateUpdate()
    throws IOException
  {
    boolean isChecked = !isChecked();
    if (isChecked) {
      setAttribute("checked", "checked");
    } else {
      removeAttribute("checked");
    }
    super.doClickStateUpdate();
    return true;
  }
  
  protected void doClickFireChangeEvent()
    throws IOException
  {
    if (!hasFeature(BrowserVersionFeatures.EVENT_ONCHANGE_LOSING_FOCUS)) {
      executeOnChangeHandlerIfAppropriate(this);
    }
  }
  
  protected boolean isStateUpdateFirst()
  {
    return true;
  }
  
  protected void preventDefault()
  {
    setChecked(!isChecked());
  }
  
  public void setDefaultValue(String defaultValue)
  {
    super.setDefaultValue(defaultValue);
    setValueAttribute(defaultValue);
  }
  
  public void setDefaultChecked(boolean defaultChecked)
  {
    this.defaultCheckedState_ = defaultChecked;
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_DEFAULT_CHECKED_UPDATES_CHECKED)) {
      setChecked(defaultChecked);
    }
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_CHECKED_TO_FALSE_WHEN_CLONE))
    {
      reset();
      this.forceChecked_ = true;
    }
  }
  
  public boolean isDefaultChecked()
  {
    return this.defaultCheckedState_;
  }
  
  protected void onAddedToPage()
  {
    super.onAddedToPage();
    if (this.forceChecked_)
    {
      reset();
      this.forceChecked_ = wasCreatedByJavascript();
    }
  }
  
  protected void onAddedToDocumentFragment()
  {
    super.onAddedToDocumentFragment();
    if (this.forceChecked_)
    {
      reset();
      this.forceChecked_ = false;
    }
  }
  
  public DomNode cloneNode(boolean deep)
  {
    HtmlCheckBoxInput clone = (HtmlCheckBoxInput)super.cloneNode(deep);
    if ((wasCreatedByJavascript()) && (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_CHECKED_TO_FALSE_WHEN_CLONE)))
    {
      clone.removeAttribute("checked");
      clone.forceChecked_ = isDefaultChecked();
    }
    if (hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_DEFAULT_VALUE_WHEN_CLONE)) {
      clone.setDefaultValue(getValueAttribute(), false);
    }
    return clone;
  }
  
  Object getInternalValue()
  {
    return Boolean.valueOf(isChecked());
  }
  
  void handleFocusLostValueChanged()
  {
    boolean fireOnChange = hasFeature(BrowserVersionFeatures.EVENT_ONCHANGE_LOSING_FOCUS);
    if (fireOnChange) {
      executeOnChangeHandlerIfAppropriate(this);
    }
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ((hasFeature(BrowserVersionFeatures.HTMLCHECKEDINPUT_SET_DEFAULT_CHECKED_UPDATES_CHECKED)) && ("value".equals(qualifiedName))) {
      setDefaultValue(attributeValue, false);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
}
