package com.gargoylesoftware.htmlunit.javascript.background;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DefaultJavaScriptExecutor
  implements JavaScriptExecutor
{
  private static final long serialVersionUID = 5677978210585334168L;
  private final transient WeakReference<WebClient> webClient_;
  private final transient List<WeakReference<JavaScriptJobManager>> jobManagerList_;
  private volatile boolean shutdown_ = false;
  private transient Thread eventLoopThread_ = null;
  private static final Log LOG = LogFactory.getLog(DefaultJavaScriptExecutor.class);
  
  public DefaultJavaScriptExecutor(WebClient webClient)
  {
    this.jobManagerList_ = new LinkedList();
    this.webClient_ = new WeakReference(webClient);
  }
  
  protected void startThreadIfNeeded()
  {
    if (this.eventLoopThread_ == null)
    {
      this.eventLoopThread_ = new Thread(this, getThreadName());
      this.eventLoopThread_.setDaemon(true);
      this.eventLoopThread_.start();
    }
  }
  
  protected String getThreadName()
  {
    return "JS executor for " + this.webClient_.get();
  }
  
  private void killThread()
  {
    if (this.eventLoopThread_ == null) {
      return;
    }
    try
    {
      this.eventLoopThread_.interrupt();
      this.eventLoopThread_.join(10000L);
    }
    catch (InterruptedException e)
    {
      LOG.warn("InterruptedException while waiting for the eventLoop thread to join ", e);
    }
    if (this.eventLoopThread_.isAlive()) {
      LOG.warn("Event loop thread " + this.eventLoopThread_.getName() + " still alive at " + System.currentTimeMillis());
    }
  }
  
  protected synchronized JavaScriptJobManager getJobManagerWithEarliestJob()
  {
    JavaScriptJobManager javaScriptJobManager = null;
    JavaScriptJob earliestJob = null;
    
    Iterator<WeakReference<JavaScriptJobManager>> managers = this.jobManagerList_.iterator();
    while (managers.hasNext())
    {
      JavaScriptJobManager jobManager = (JavaScriptJobManager)((WeakReference)managers.next()).get();
      if (jobManager == null)
      {
        managers.remove();
      }
      else
      {
        JavaScriptJob newJob = jobManager.getEarliestJob();
        if ((newJob != null) && (
          (earliestJob == null) || (earliestJob.compareTo(newJob) > 0)))
        {
          earliestJob = newJob;
          javaScriptJobManager = jobManager;
        }
      }
    }
    return javaScriptJobManager;
  }
  
  public int pumpEventLoop(long timeoutMillis)
  {
    return 0;
  }
  
  public void run()
  {
    boolean trace = LOG.isTraceEnabled();
    
    long sleepInterval = 10L;
    while ((!this.shutdown_) && (this.webClient_.get() != null))
    {
      if (trace) {
        LOG.trace("started finding earliestJob at " + System.currentTimeMillis());
      }
      JavaScriptJobManager jobManager = getJobManagerWithEarliestJob();
      if (trace) {
        LOG.trace("stopped finding earliestJob at " + System.currentTimeMillis());
      }
      if (jobManager != null)
      {
        JavaScriptJob earliestJob = jobManager.getEarliestJob();
        if (earliestJob != null)
        {
          long waitTime = earliestJob.getTargetExecutionTime() - System.currentTimeMillis();
          if (waitTime < 1L)
          {
            if (trace) {
              LOG.trace("started executing job at " + System.currentTimeMillis());
            }
            jobManager.runSingleJob(earliestJob);
            if (!trace) {
              continue;
            }
            LOG.trace("stopped executing job at " + System.currentTimeMillis()); continue;
          }
        }
      }
      if ((this.shutdown_) || (this.webClient_.get() == null)) {
        break;
      }
      try
      {
        Thread.sleep(10L);
      }
      catch (InterruptedException e) {}
    }
  }
  
  public synchronized void addWindow(WebWindow newWindow)
  {
    JavaScriptJobManager jobManager = newWindow.getJobManager();
    if ((jobManager != null) && (!contains(jobManager)))
    {
      this.jobManagerList_.add(new WeakReference(jobManager));
      startThreadIfNeeded();
    }
  }
  
  private boolean contains(JavaScriptJobManager newJobManager)
  {
    for (WeakReference<JavaScriptJobManager> jobManagerRef : this.jobManagerList_) {
      if (jobManagerRef.get() == newJobManager) {
        return true;
      }
    }
    return false;
  }
  
  public void shutdown()
  {
    this.shutdown_ = true;
    killThread();
  }
}
