package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlAbbreviated;
import com.gargoylesoftware.htmlunit.html.HtmlAcronym;
import com.gargoylesoftware.htmlunit.html.HtmlAddress;
import com.gargoylesoftware.htmlunit.html.HtmlBidirectionalOverride;
import com.gargoylesoftware.htmlunit.html.HtmlBig;
import com.gargoylesoftware.htmlunit.html.HtmlBlink;
import com.gargoylesoftware.htmlunit.html.HtmlBold;
import com.gargoylesoftware.htmlunit.html.HtmlCenter;
import com.gargoylesoftware.htmlunit.html.HtmlCitation;
import com.gargoylesoftware.htmlunit.html.HtmlCode;
import com.gargoylesoftware.htmlunit.html.HtmlDefinition;
import com.gargoylesoftware.htmlunit.html.HtmlDefinitionDescription;
import com.gargoylesoftware.htmlunit.html.HtmlDefinitionTerm;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlEmphasis;
import com.gargoylesoftware.htmlunit.html.HtmlExample;
import com.gargoylesoftware.htmlunit.html.HtmlItalic;
import com.gargoylesoftware.htmlunit.html.HtmlKeyboard;
import com.gargoylesoftware.htmlunit.html.HtmlListing;
import com.gargoylesoftware.htmlunit.html.HtmlMultiColumn;
import com.gargoylesoftware.htmlunit.html.HtmlNoBreak;
import com.gargoylesoftware.htmlunit.html.HtmlPlainText;
import com.gargoylesoftware.htmlunit.html.HtmlS;
import com.gargoylesoftware.htmlunit.html.HtmlSample;
import com.gargoylesoftware.htmlunit.html.HtmlSmall;
import com.gargoylesoftware.htmlunit.html.HtmlSpan;
import com.gargoylesoftware.htmlunit.html.HtmlStrike;
import com.gargoylesoftware.htmlunit.html.HtmlStrong;
import com.gargoylesoftware.htmlunit.html.HtmlSubscript;
import com.gargoylesoftware.htmlunit.html.HtmlSuperscript;
import com.gargoylesoftware.htmlunit.html.HtmlTeletype;
import com.gargoylesoftware.htmlunit.html.HtmlUnderlined;
import com.gargoylesoftware.htmlunit.html.HtmlVariable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.host.ActiveXObject;

@JsxClass(domClasses={HtmlAbbreviated.class, HtmlAcronym.class, HtmlAddress.class, HtmlBidirectionalOverride.class, HtmlBig.class, HtmlBold.class, HtmlBlink.class, HtmlCenter.class, HtmlCitation.class, HtmlCode.class, HtmlDefinition.class, HtmlDefinitionDescription.class, HtmlDefinitionTerm.class, HtmlEmphasis.class, HtmlItalic.class, HtmlKeyboard.class, HtmlListing.class, HtmlMultiColumn.class, HtmlNoBreak.class, HtmlPlainText.class, HtmlS.class, HtmlSample.class, HtmlSmall.class, HtmlSpan.class, HtmlStrike.class, HtmlStrong.class, HtmlSubscript.class, HtmlSuperscript.class, HtmlTeletype.class, HtmlUnderlined.class, HtmlVariable.class, HtmlExample.class})
public class HTMLSpanElement
  extends HTMLElement
{
  private boolean endTagForbidden_;
  
  public void setDomNode(DomNode domNode)
  {
    super.setDomNode(domNode);
    BrowserVersion browser = getBrowserVersion();
    if (!browser.hasFeature(BrowserVersionFeatures.GENERATED_90))
    {
      if ("basefont".equalsIgnoreCase(domNode.getLocalName())) {
        this.endTagForbidden_ = true;
      }
      return;
    }
    if ((((domNode instanceof HtmlAbbreviated)) && (browser.hasFeature(BrowserVersionFeatures.HTMLABBREVIATED))) || ((domNode instanceof HtmlAcronym)) || ((domNode instanceof HtmlBidirectionalOverride)) || ((domNode instanceof HtmlBig)) || ((domNode instanceof HtmlBold)) || ((domNode instanceof HtmlBlink)) || ((domNode instanceof HtmlCitation)) || ((domNode instanceof HtmlCode)) || ((domNode instanceof HtmlDefinition)) || ((domNode instanceof HtmlEmphasis)) || ((domNode instanceof HtmlItalic)) || ((domNode instanceof HtmlKeyboard)) || ((domNode instanceof HtmlNoBreak)) || ((domNode instanceof HtmlS)) || ((domNode instanceof HtmlSample)) || ((domNode instanceof HtmlSmall)) || ((domNode instanceof HtmlStrike)) || ((domNode instanceof HtmlStrong)) || ((domNode instanceof HtmlSubscript)) || ((domNode instanceof HtmlSuperscript)) || ((domNode instanceof HtmlTeletype)) || ((domNode instanceof HtmlUnderlined)) || ((domNode instanceof HtmlVariable)))
    {
      ActiveXObject.addProperty(this, "cite", true, true);
      ActiveXObject.addProperty(this, "dateTime", true, true);
      return;
    }
    if (((domNode instanceof HtmlAddress)) || ((domNode instanceof HtmlCenter)) || ((domNode instanceof HtmlExample)) || ((domNode instanceof HtmlListing)) || ((domNode instanceof HtmlPlainText))) {
      ActiveXObject.addProperty(this, "cite", true, true);
    }
  }
  
  public String getCite()
  {
    String cite = getDomNodeOrDie().getAttribute("cite");
    return cite;
  }
  
  public void setCite(String cite)
  {
    getDomNodeOrDie().setAttribute("cite", cite);
  }
  
  public String getDateTime()
  {
    String dateTime = getDomNodeOrDie().getAttribute("datetime");
    return dateTime;
  }
  
  public void setDateTime(String dateTime)
  {
    getDomNodeOrDie().setAttribute("datetime", dateTime);
  }
  
  protected boolean isLowerCaseInOuterHtml()
  {
    if ((getDomNodeOrDie() instanceof HtmlMultiColumn)) {
      return true;
    }
    return super.isLowerCaseInOuterHtml();
  }
  
  protected boolean isEndTagForbidden()
  {
    return this.endTagForbidden_;
  }
  
  public String getDefaultStyleDisplay()
  {
    String tagName = getTagName();
    if (("ADDRESS".equals(tagName)) || ("CENTER".equals(tagName)) || ("DD".equals(tagName)) || ("DT".equals(tagName))) {
      return super.getDefaultStyleDisplay();
    }
    return "inline";
  }
}
