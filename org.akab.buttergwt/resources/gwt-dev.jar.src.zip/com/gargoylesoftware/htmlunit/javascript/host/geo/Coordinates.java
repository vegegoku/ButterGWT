package com.gargoylesoftware.htmlunit.javascript.host.geo;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass
public class Coordinates
  extends SimpleScriptable
{
  private double latitude_;
  private double longitude_;
  private double accuracy_;
  
  public Coordinates() {}
  
  Coordinates(double latitude, double longitude, double accuracy)
  {
    this.latitude_ = latitude;
    this.longitude_ = longitude;
    this.accuracy_ = accuracy;
  }
  
  @JsxGetter
  public double getLatitude()
  {
    return this.latitude_;
  }
  
  @JsxGetter
  public double getLongitude()
  {
    return this.longitude_;
  }
  
  @JsxGetter
  public double getAccuracy()
  {
    return this.accuracy_;
  }
}
