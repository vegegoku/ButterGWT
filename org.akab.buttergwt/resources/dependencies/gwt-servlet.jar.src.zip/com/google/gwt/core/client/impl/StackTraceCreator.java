package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptException;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.core.client.JsArray;
import com.google.gwt.core.client.JsArrayString;

public class StackTraceCreator
{
  public static final int LINE_NUMBER_UNKNOWN = -1;
  private static final String ANONYMOUS = "anonymous";
  private static native int parseInt(String paramString);
  
  static class Collector
  {
    public native JsArrayString collect();
    
    public void createStackTrace(JavaScriptException e)
    {
      JsArrayString stack = inferFrom(e.getThrown());
      
      StackTraceElement[] stackTrace = new StackTraceElement[stack.length()];
      int i = 0;
      for (int j = stackTrace.length; i < j; i++) {
        stackTrace[i] = new StackTraceElement("Unknown", stack.get(i), null, -1);
      }
      e.setStackTrace(stackTrace);
    }
    
    public void fillInStackTrace(Throwable t)
    {
      JsArrayString stack = StackTraceCreator.createStackTrace();
      StackTraceElement[] stackTrace = new StackTraceElement[stack.length()];
      int i = 0;
      for (int j = stackTrace.length; i < j; i++) {
        stackTrace[i] = new StackTraceElement("Unknown", stack.get(i), null, -1);
      }
      t.setStackTrace(stackTrace);
    }
    
    public native String getProperties(JavaScriptObject paramJavaScriptObject);
    
    public JsArrayString inferFrom(Object e)
    {
      return (JsArrayString)JavaScriptObject.createArray().cast();
    }
    
    protected String extractName(String fnToString)
    {
      return StackTraceCreator.extractNameFromToString(fnToString);
    }
    
    protected native JavaScriptObject makeException();
  }
  
  static class CollectorEmulated
    extends StackTraceCreator.Collector
  {
    public JsArrayString collect()
    {
      JsArrayString toReturn = (JsArrayString)JsArrayString.createArray().cast();
      JsArray<JavaScriptObject> stack = getStack();
      int i = 0;
      for (int j = getStackDepth(); i < j; i++)
      {
        String name = stack.get(i) == null ? "anonymous" : extractName(stack.get(i).toString());
        
        toReturn.set(j - i - 1, name);
      }
      return toReturn;
    }
    
    public void createStackTrace(JavaScriptException e) {}
    
    public void fillInStackTrace(Throwable t)
    {
      JsArrayString stack = collect();
      JsArrayString locations = getLocation();
      StackTraceElement[] stackTrace = new StackTraceElement[stack.length()];
      int i = 0;
      for (int j = stackTrace.length; i < j; i++)
      {
        String location = locations.get(j - i - 1);
        String fileName = null;
        int lineNumber = -1;
        if (location != null)
        {
          int idx = location.indexOf(':');
          if (idx != -1)
          {
            fileName = location.substring(0, idx);
            lineNumber = Integer.parseInt(location.substring(idx + 1));
          }
          else
          {
            lineNumber = Integer.parseInt(location);
          }
        }
        stackTrace[i] = new StackTraceElement("Unknown", stack.get(i), fileName, lineNumber);
      }
      t.setStackTrace(stackTrace);
    }
    
    public String getProperties(JavaScriptObject e)
    {
      return "";
    }
    
    public JsArrayString inferFrom(Object e)
    {
      throw new RuntimeException("Should not reach here");
    }
    
    private native JsArrayString getLocation();
    
    private native JsArray<JavaScriptObject> getStack();
    
    private native int getStackDepth();
  }
  
  static class CollectorMoz
    extends StackTraceCreator.Collector
  {
    public JsArrayString collect()
    {
      return StackTraceCreator.splice(inferFrom(makeException()), toSplice());
    }
    
    public JsArrayString inferFrom(Object e)
    {
      JavaScriptObject jso = (e instanceof JavaScriptObject) ? (JavaScriptObject)e : null;
      JsArrayString stack = getStack(jso);
      int i = 0;
      for (int j = stack.length(); i < j; i++) {
        stack.set(i, extractName(stack.get(i)));
      }
      return stack;
    }
    
    protected native JsArrayString getStack(JavaScriptObject paramJavaScriptObject);
    
    protected int toSplice()
    {
      return 2;
    }
  }
  
  static class CollectorChrome
    extends StackTraceCreator.CollectorMoz
  {
    private static native void increaseChromeStackTraceLimit();
    
    public JsArrayString collect()
    {
      JsArrayString res = super.collect();
      if (res.length() == 0) {
        res = StackTraceCreator.splice(new StackTraceCreator.Collector().collect(), 1);
      }
      return res;
    }
    
    public void createStackTrace(JavaScriptException e)
    {
      JsArrayString stack = inferFrom(e.getThrown());
      parseStackTrace(e, stack);
    }
    
    public void fillInStackTrace(Throwable t)
    {
      JsArrayString stack = StackTraceCreator.createStackTrace();
      parseStackTrace(t, stack);
    }
    
    public JsArrayString inferFrom(Object e)
    {
      JsArrayString stack = super.inferFrom(e);
      if (stack.length() == 0) {
        return new StackTraceCreator.Collector().inferFrom(e);
      }
      if (stack.get(0).startsWith("anonymous@@")) {
        stack = StackTraceCreator.splice(stack, 1);
      }
      return stack;
    }
    
    protected String extractName(String fnToString)
    {
      String extractedName = "anonymous";
      String location = "";
      if (fnToString.length() == 0) {
        return extractedName;
      }
      String toReturn = fnToString.trim();
      if (toReturn.startsWith("at ")) {
        toReturn = toReturn.substring(3);
      }
      int index = toReturn.indexOf("[");
      if (index != -1) {
        toReturn = toReturn.substring(0, index).trim() + toReturn.substring(toReturn.indexOf("]", index) + 1).trim();
      }
      index = toReturn.indexOf("(");
      if (index == -1)
      {
        index = toReturn.indexOf("@");
        if (index == -1)
        {
          location = toReturn;
          toReturn = "";
        }
        else
        {
          location = toReturn.substring(index + 1).trim();
          toReturn = toReturn.substring(0, index).trim();
        }
      }
      else
      {
        int closeParen = toReturn.indexOf(")", index);
        location = toReturn.substring(index + 1, closeParen);
        toReturn = toReturn.substring(0, index).trim();
      }
      index = toReturn.indexOf('.');
      if (index != -1) {
        toReturn = toReturn.substring(index + 1);
      }
      return (toReturn.length() > 0 ? toReturn : "anonymous") + "@@" + location;
    }
    
    protected int replaceIfNoSourceMap(int line)
    {
      return line;
    }
    
    protected int toSplice()
    {
      return 3;
    }
    
    private void parseStackTrace(Throwable e, JsArrayString stack)
    {
      StackTraceElement[] stackTrace = new StackTraceElement[stack.length()];
      int i = 0;
      for (int j = stackTrace.length; i < j; i++)
      {
        String[] stackElements = stack.get(i).split("@@");
        
        int line = -1;
        int col = -1;
        String fileName = "Unknown";
        if ((stackElements.length == 2) && (stackElements[1] != null))
        {
          String location = stackElements[1];
          
          int lastColon = location.lastIndexOf(':');
          
          int endFileUrl = location.lastIndexOf(':', lastColon - 1);
          fileName = location.substring(0, endFileUrl);
          if ((lastColon != -1) && (endFileUrl != -1))
          {
            line = StackTraceCreator.parseInt(location.substring(endFileUrl + 1, lastColon));
            col = StackTraceCreator.parseInt(location.substring(lastColon + 1));
          }
        }
        stackTrace[i] = new StackTraceElement("Unknown", stackElements[0], fileName + "@" + col, replaceIfNoSourceMap(line < 0 ? -1 : line));
      }
      e.setStackTrace(stackTrace);
    }
    
    static {}
  }
  
  static class CollectorChromeNoSourceMap
    extends StackTraceCreator.CollectorChrome
  {
    protected int replaceIfNoSourceMap(int line)
    {
      return -1;
    }
  }
  
  static class CollectorOpera
    extends StackTraceCreator.CollectorMoz
  {
    protected String extractName(String fnToString)
    {
      return fnToString.length() == 0 ? "anonymous" : fnToString;
    }
    
    protected JsArrayString getStack(JavaScriptObject e)
    {
      JsArrayString toReturn = getMessage(e);
      assert (toReturn.length() % 2 == 0) : "Expecting an even number of lines";
      
      int i = 0;int i2 = 0;
      for (int j = toReturn.length(); i2 < j; i2 += 2)
      {
        int idx = toReturn.get(i2).lastIndexOf("function ");
        if (idx == -1) {
          toReturn.set(i, "");
        } else {
          toReturn.set(i, toReturn.get(i2).substring(idx + 9).trim());
        }
        i++;
      }
      setLength(toReturn, i);
      
      return toReturn;
    }
    
    protected int toSplice()
    {
      return 3;
    }
    
    private native JsArrayString getMessage(JavaScriptObject paramJavaScriptObject);
    
    private native void setLength(JsArrayString paramJsArrayString, int paramInt);
  }
  
  static class CollectorNull
    extends StackTraceCreator.Collector
  {
    public JsArrayString collect()
    {
      return (JsArrayString)JsArrayString.createArray().cast();
    }
    
    public void createStackTrace(JavaScriptException e) {}
    
    public void fillInStackTrace(Throwable t) {}
  }
  
  public static void createStackTrace(JavaScriptException e)
  {
    if (!GWT.isScript()) {
      throw new RuntimeException("StackTraceCreator should only be called in Production Mode");
    }
    ((Collector)GWT.create(Collector.class)).createStackTrace(e);
  }
  
  public static void fillInStackTrace(Throwable t)
  {
    if (!GWT.isScript()) {
      throw new RuntimeException("StackTraceCreator should only be called in Production Mode");
    }
    ((Collector)GWT.create(Collector.class)).fillInStackTrace(t);
  }
  
  public static String getProperties(JavaScriptObject e)
  {
    if (!GWT.isScript()) {
      throw new RuntimeException("StackTraceCreator should only be called in Production Mode");
    }
    return ((Collector)GWT.create(Collector.class)).getProperties(e);
  }
  
  static JsArrayString createStackTrace()
  {
    if (!GWT.isScript()) {
      throw new RuntimeException("StackTraceCreator should only be called in Production Mode");
    }
    return ((Collector)GWT.create(Collector.class)).collect();
  }
  
  static String extractNameFromToString(String fnToString)
  {
    String toReturn = "";
    fnToString = fnToString.trim();
    int index = fnToString.indexOf("(");
    int start = fnToString.startsWith("function") ? 8 : 0;
    if (index == -1)
    {
      index = fnToString.indexOf('@');
      
      start = fnToString.startsWith("function ") ? 9 : 0;
    }
    if (index != -1) {
      toReturn = fnToString.substring(start, index).trim();
    }
    return toReturn.length() > 0 ? toReturn : "anonymous";
  }
  
  private static native JsArrayString splice(JsArrayString paramJsArrayString, int paramInt);
}
