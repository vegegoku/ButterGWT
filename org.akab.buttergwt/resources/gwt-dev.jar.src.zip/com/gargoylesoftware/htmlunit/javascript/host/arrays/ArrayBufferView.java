package com.gargoylesoftware.htmlunit.javascript.host.arrays;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass(isJSObject=false, browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class ArrayBufferView
  extends SimpleScriptable
{
  private ArrayBuffer buffer_;
  private int byteLength_;
  private int byteOffset_;
  
  protected void constructor(ArrayBuffer buffer, int byteOffset, int length)
  {
    this.buffer_ = buffer;
    this.byteOffset_ = byteOffset;
    this.byteLength_ = length;
  }
  
  @JsxGetter
  public ArrayBuffer getBuffer()
  {
    return this.buffer_;
  }
  
  protected void setBuffer(ArrayBuffer buffer)
  {
    this.buffer_ = buffer;
  }
  
  @JsxGetter
  public int getByteLength()
  {
    return this.byteLength_;
  }
  
  protected void setByteLength(int byteLength)
  {
    this.byteLength_ = byteLength;
  }
  
  @JsxGetter
  public int getByteOffset()
  {
    return this.byteOffset_;
  }
}
