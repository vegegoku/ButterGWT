package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.HtmlIFrameBuilder;
import com.google.gwt.dom.builder.shared.IFrameBuilder;
import com.google.gwt.dom.client.IFrameElement;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeUri;

public class DomIFrameBuilder
  extends DomElementBuilderBase<IFrameBuilder, IFrameElement>
  implements IFrameBuilder
{
  DomIFrameBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public IFrameBuilder frameBorder(int frameBorder)
  {
    ((IFrameElement)assertCanAddAttribute()).setFrameBorder(frameBorder);
    return this;
  }
  
  public HtmlIFrameBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException();
  }
  
  public boolean isChildElementSupported()
  {
    return false;
  }
  
  public IFrameBuilder marginHeight(int marginHeight)
  {
    ((IFrameElement)assertCanAddAttribute()).setMarginHeight(marginHeight);
    return this;
  }
  
  public IFrameBuilder marginWidth(int marginWidth)
  {
    ((IFrameElement)assertCanAddAttribute()).setMarginWidth(marginWidth);
    return this;
  }
  
  public IFrameBuilder name(String name)
  {
    ((IFrameElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public IFrameBuilder noResize()
  {
    ((IFrameElement)assertCanAddAttribute()).setNoResize(true);
    return this;
  }
  
  public IFrameBuilder scrolling(String scrolling)
  {
    ((IFrameElement)assertCanAddAttribute()).setScrolling(scrolling);
    return this;
  }
  
  public IFrameBuilder src(SafeUri src)
  {
    ((IFrameElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
  
  public IFrameBuilder src(String src)
  {
    ((IFrameElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
  
  public HtmlIFrameBuilder text(String text)
  {
    throw new UnsupportedOperationException();
  }
}
