package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.StringWebResponse;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.WebWindowImpl;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptJobManager;

public class FrameWindow
  extends WebWindowImpl
{
  private final BaseFrameElement frame_;
  
  FrameWindow(BaseFrameElement frame)
  {
    super(frame.getPage().getWebClient());
    this.frame_ = frame;
    WebWindowImpl parent = (WebWindowImpl)getParentWindow();
    performRegistration();
    parent.addChildWindow(this);
  }
  
  public String getName()
  {
    return this.frame_.getNameAttribute();
  }
  
  public void setName(String name)
  {
    this.frame_.setNameAttribute(name);
  }
  
  public WebWindow getParentWindow()
  {
    return this.frame_.getPage().getEnclosingWindow();
  }
  
  public WebWindow getTopWindow()
  {
    return getParentWindow().getTopWindow();
  }
  
  protected boolean isJavaScriptInitializationNeeded()
  {
    return (getScriptObject() == null) || (!(getEnclosedPage().getWebResponse() instanceof StringWebResponse));
  }
  
  public HtmlPage getEnclosingPage()
  {
    return (HtmlPage)this.frame_.getPage();
  }
  
  public void setEnclosedPage(Page page)
  {
    super.setEnclosedPage(page);
    
    WebResponse webResponse = page.getWebResponse();
    if ((webResponse instanceof StringWebResponse))
    {
      StringWebResponse response = (StringWebResponse)webResponse;
      if (response.isFromJavascript())
      {
        BaseFrameElement frame = getFrameElement();
        frame.setContentLoaded();
      }
    }
  }
  
  public BaseFrameElement getFrameElement()
  {
    return this.frame_;
  }
  
  public String toString()
  {
    return "FrameWindow[name=\"" + getName() + "\"]";
  }
  
  public void close()
  {
    setClosed();
    Page page = getEnclosedPage();
    if (page != null) {
      page.cleanUp();
    }
    getJobManager().shutdown();
    destroyChildren();
    getWebClient().deregisterWebWindow(this);
  }
}
