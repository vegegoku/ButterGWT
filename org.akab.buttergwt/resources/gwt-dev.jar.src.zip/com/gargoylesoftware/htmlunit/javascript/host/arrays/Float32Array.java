package com.gargoylesoftware.htmlunit.javascript.host.arrays;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstant;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class Float32Array
  extends ArrayBufferViewBase
{
  @JsxConstant
  public static final int BYTES_PER_ELEMENT = 4;
  
  @JsxConstructor
  public void constructor(Object object, Object byteOffset, Object length)
  {
    super.constructor(object, byteOffset, length);
  }
  
  protected byte[] toArray(Number number)
  {
    ByteBuffer buff = ByteBuffer.allocate(4);
    buff.order(ByteOrder.LITTLE_ENDIAN);
    buff.putFloat(number.floatValue());
    return buff.array();
  }
  
  protected Number fromArray(byte[] array, int offset)
  {
    ByteBuffer buff = ByteBuffer.wrap(array);
    buff.order(ByteOrder.LITTLE_ENDIAN);
    return Float.valueOf(buff.getFloat(offset));
  }
  
  protected int getBytesPerElement()
  {
    return 4;
  }
}
