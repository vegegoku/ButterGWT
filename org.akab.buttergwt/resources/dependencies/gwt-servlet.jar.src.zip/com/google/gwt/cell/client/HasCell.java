package com.google.gwt.cell.client;

public abstract interface HasCell<T, C>
{
  public abstract Cell<C> getCell();
  
  public abstract FieldUpdater<T, C> getFieldUpdater();
  
  public abstract C getValue(T paramT);
}
