package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(isJSObject=false)
public class HTMLListElement
  extends HTMLElement
{
  @JsxGetter
  public boolean getCompact()
  {
    return getDomNodeOrDie().hasAttribute("compact");
  }
  
  @JsxSetter
  public void setCompact(Object compact)
  {
    if (Context.toBoolean(compact)) {
      getDomNodeOrDie().setAttribute("compact", "");
    } else {
      getDomNodeOrDie().removeAttribute("compact");
    }
  }
  
  public Object getAttribute(String attributeName, Integer flags)
  {
    if (("compact".equals(attributeName)) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_85))) {
      return Boolean.valueOf(getCompact());
    }
    return super.getAttribute(attributeName, flags);
  }
}
