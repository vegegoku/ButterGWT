package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
public final class MimeType
  extends SimpleScriptable
{
  private String description_;
  private String suffixes_;
  private String type_;
  private Plugin enabledPlugin_;
  
  public MimeType() {}
  
  public MimeType(String type, String description, String suffixes, Plugin plugin)
  {
    this.type_ = type;
    this.description_ = description;
    this.suffixes_ = suffixes;
    this.enabledPlugin_ = plugin;
  }
  
  @JsxGetter
  public String getDescription()
  {
    return this.description_;
  }
  
  @JsxGetter
  public String getSuffixes()
  {
    return this.suffixes_;
  }
  
  @JsxGetter
  public String getType()
  {
    return this.type_;
  }
  
  @JsxGetter
  public Object getEnabledPlugin()
  {
    return this.enabledPlugin_;
  }
}
