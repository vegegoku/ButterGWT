package com.google.gwt.dom.builder.shared;

public abstract interface DListBuilder
  extends ElementBuilderBase<DListBuilder>
{}
