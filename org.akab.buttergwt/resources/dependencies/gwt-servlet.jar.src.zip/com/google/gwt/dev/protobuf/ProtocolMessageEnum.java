package com.google.gwt.dev.protobuf;

public abstract interface ProtocolMessageEnum
  extends Internal.EnumLite
{
  public abstract int getNumber();
  
  public abstract Descriptors.EnumValueDescriptor getValueDescriptor();
  
  public abstract Descriptors.EnumDescriptor getDescriptorForType();
}
