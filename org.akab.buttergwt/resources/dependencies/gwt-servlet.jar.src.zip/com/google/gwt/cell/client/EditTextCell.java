package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.InputElement;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.dom.client.Node;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.text.shared.SimpleSafeHtmlRenderer;

public class EditTextCell
  extends AbstractEditableCell<String, ViewData>
{
  private static Template template;
  private final SafeHtmlRenderer<String> renderer;
  
  static class ViewData
  {
    private boolean isEditing;
    private boolean isEditingAgain;
    private String original;
    private String text;
    
    public ViewData(String text)
    {
      this.original = text;
      this.text = text;
      this.isEditing = true;
      this.isEditingAgain = false;
    }
    
    public boolean equals(Object o)
    {
      if (o == null) {
        return false;
      }
      ViewData vd = (ViewData)o;
      return (equalsOrBothNull(this.original, vd.original)) && (equalsOrBothNull(this.text, vd.text)) && (this.isEditing == vd.isEditing) && (this.isEditingAgain == vd.isEditingAgain);
    }
    
    public String getOriginal()
    {
      return this.original;
    }
    
    public String getText()
    {
      return this.text;
    }
    
    public int hashCode()
    {
      return this.original.hashCode() + this.text.hashCode() + Boolean.valueOf(this.isEditing).hashCode() * 29 + Boolean.valueOf(this.isEditingAgain).hashCode();
    }
    
    public boolean isEditing()
    {
      return this.isEditing;
    }
    
    public boolean isEditingAgain()
    {
      return this.isEditingAgain;
    }
    
    public void setEditing(boolean isEditing)
    {
      boolean wasEditing = this.isEditing;
      this.isEditing = isEditing;
      if ((!wasEditing) && (isEditing))
      {
        this.isEditingAgain = true;
        this.original = this.text;
      }
    }
    
    public void setText(String text)
    {
      this.text = text;
    }
    
    private boolean equalsOrBothNull(Object o1, Object o2)
    {
      return o1 == null ? false : o2 == null ? true : o1.equals(o2);
    }
  }
  
  public EditTextCell()
  {
    this(SimpleSafeHtmlRenderer.getInstance());
  }
  
  public EditTextCell(SafeHtmlRenderer<String> renderer)
  {
    super(new String[] { "click", "keyup", "keydown", "blur" });
    if (template == null) {
      template = (Template)GWT.create(Template.class);
    }
    if (renderer == null) {
      throw new IllegalArgumentException("renderer == null");
    }
    this.renderer = renderer;
  }
  
  public boolean isEditing(Cell.Context context, Element parent, String value)
  {
    ViewData viewData = (ViewData)getViewData(context.getKey());
    return viewData == null ? false : viewData.isEditing();
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    Object key = context.getKey();
    ViewData viewData = (ViewData)getViewData(key);
    if ((viewData != null) && (viewData.isEditing()))
    {
      editEvent(context, parent, value, viewData, event, valueUpdater);
    }
    else
    {
      String type = event.getType();
      int keyCode = event.getKeyCode();
      boolean enterPressed = ("keyup".equals(type)) && (keyCode == 13);
      if (("click".equals(type)) || (enterPressed))
      {
        if (viewData == null)
        {
          viewData = new ViewData(value);
          setViewData(key, viewData);
        }
        else
        {
          viewData.setEditing(true);
        }
        edit(context, parent, value);
      }
    }
  }
  
  public void render(Cell.Context context, String value, SafeHtmlBuilder sb)
  {
    Object key = context.getKey();
    ViewData viewData = (ViewData)getViewData(key);
    if ((viewData != null) && (!viewData.isEditing()) && (value != null) && (value.equals(viewData.getText())))
    {
      clearViewData(key);
      viewData = null;
    }
    String toRender = value;
    if (viewData != null)
    {
      String text = viewData.getText();
      if (viewData.isEditing())
      {
        sb.append(template.input(text));
        return;
      }
      toRender = text;
    }
    if ((toRender != null) && (toRender.trim().length() > 0)) {
      sb.append(this.renderer.render(toRender));
    } else {
      sb.appendHtmlConstant(" ");
    }
  }
  
  public boolean resetFocus(Cell.Context context, Element parent, String value)
  {
    if (isEditing(context, parent, value))
    {
      getInputElement(parent).focus();
      return true;
    }
    return false;
  }
  
  protected void edit(Cell.Context context, Element parent, String value)
  {
    setValue(context, parent, value);
    InputElement input = getInputElement(parent);
    input.focus();
    input.select();
  }
  
  private void cancel(Cell.Context context, Element parent, String value)
  {
    clearInput(getInputElement(parent));
    setValue(context, parent, value);
  }
  
  private native void clearInput(Element paramElement);
  
  private void commit(Cell.Context context, Element parent, ViewData viewData, ValueUpdater<String> valueUpdater)
  {
    String value = updateViewData(parent, viewData, false);
    clearInput(getInputElement(parent));
    setValue(context, parent, viewData.getOriginal());
    if (valueUpdater != null) {
      valueUpdater.update(value);
    }
  }
  
  private void editEvent(Cell.Context context, Element parent, String value, ViewData viewData, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    String type = event.getType();
    boolean keyUp = "keyup".equals(type);
    boolean keyDown = "keydown".equals(type);
    if ((keyUp) || (keyDown))
    {
      int keyCode = event.getKeyCode();
      if ((keyUp) && (keyCode == 13))
      {
        commit(context, parent, viewData, valueUpdater);
      }
      else if ((keyUp) && (keyCode == 27))
      {
        String originalText = viewData.getOriginal();
        if (viewData.isEditingAgain())
        {
          viewData.setText(originalText);
          viewData.setEditing(false);
        }
        else
        {
          setViewData(context.getKey(), null);
        }
        cancel(context, parent, value);
      }
      else
      {
        updateViewData(parent, viewData, true);
      }
    }
    else if ("blur".equals(type))
    {
      EventTarget eventTarget = event.getEventTarget();
      if (Element.is(eventTarget))
      {
        Element target = Element.as(eventTarget);
        if ("input".equals(target.getTagName().toLowerCase())) {
          commit(context, parent, viewData, valueUpdater);
        }
      }
    }
  }
  
  private InputElement getInputElement(Element parent)
  {
    return (InputElement)parent.getFirstChild().cast();
  }
  
  private String updateViewData(Element parent, ViewData viewData, boolean isEditing)
  {
    InputElement input = (InputElement)parent.getFirstChild();
    String value = input.getValue();
    viewData.setText(value);
    viewData.setEditing(isEditing);
    return value;
  }
  
  static abstract interface Template
    extends SafeHtmlTemplates
  {
    @SafeHtmlTemplates.Template("<input type=\"text\" value=\"{0}\" tabindex=\"-1\"></input>")
    public abstract SafeHtml input(String paramString);
  }
}
