package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.DomNode;
import java.util.ArrayList;
import java.util.List;

class HTMLSubCollection
  extends HTMLCollection
{
  private final HTMLCollection mainCollection_;
  
  public HTMLSubCollection(HTMLCollection mainCollection, String subDescription)
  {
    super(mainCollection.getDomNodeOrDie(), false, mainCollection.toString() + subDescription);
    this.mainCollection_ = mainCollection;
  }
  
  protected List<Object> computeElements()
  {
    List<Object> list = new ArrayList();
    for (Object o : this.mainCollection_.getElements()) {
      if (isMatching((DomNode)o)) {
        list.add(o);
      }
    }
    return list;
  }
}
