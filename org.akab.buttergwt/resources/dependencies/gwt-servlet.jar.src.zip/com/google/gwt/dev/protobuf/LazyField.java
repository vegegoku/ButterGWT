package com.google.gwt.dev.protobuf;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map.Entry;

class LazyField
{
  private final MessageLite defaultInstance;
  private final ExtensionRegistryLite extensionRegistry;
  private ByteString bytes;
  private volatile MessageLite value;
  private volatile boolean isDirty = false;
  
  public LazyField(MessageLite defaultInstance, ExtensionRegistryLite extensionRegistry, ByteString bytes)
  {
    this.defaultInstance = defaultInstance;
    this.extensionRegistry = extensionRegistry;
    this.bytes = bytes;
  }
  
  public MessageLite getValue()
  {
    ensureInitialized();
    return this.value;
  }
  
  public MessageLite setValue(MessageLite value)
  {
    MessageLite originalValue = this.value;
    this.value = value;
    this.bytes = null;
    this.isDirty = true;
    return originalValue;
  }
  
  public int getSerializedSize()
  {
    if (this.isDirty) {
      return this.value.getSerializedSize();
    }
    return this.bytes.size();
  }
  
  public ByteString toByteString()
  {
    if (!this.isDirty) {
      return this.bytes;
    }
    synchronized (this)
    {
      if (!this.isDirty) {
        return this.bytes;
      }
      this.bytes = this.value.toByteString();
      this.isDirty = false;
      return this.bytes;
    }
  }
  
  public int hashCode()
  {
    ensureInitialized();
    return this.value.hashCode();
  }
  
  public boolean equals(Object obj)
  {
    ensureInitialized();
    return this.value.equals(obj);
  }
  
  public String toString()
  {
    ensureInitialized();
    return this.value.toString();
  }
  
  private void ensureInitialized()
  {
    if (this.value != null) {
      return;
    }
    synchronized (this)
    {
      if (this.value != null) {
        return;
      }
      try
      {
        if (this.bytes != null) {
          this.value = ((MessageLite)this.defaultInstance.getParserForType().parseFrom(this.bytes, this.extensionRegistry));
        }
      }
      catch (IOException e) {}
    }
  }
  
  static class LazyEntry<K>
    implements Map.Entry<K, Object>
  {
    private Map.Entry<K, LazyField> entry;
    
    private LazyEntry(Map.Entry<K, LazyField> entry)
    {
      this.entry = entry;
    }
    
    public K getKey()
    {
      return (K)this.entry.getKey();
    }
    
    public Object getValue()
    {
      LazyField field = (LazyField)this.entry.getValue();
      if (field == null) {
        return null;
      }
      return field.getValue();
    }
    
    public LazyField getField()
    {
      return (LazyField)this.entry.getValue();
    }
    
    public Object setValue(Object value)
    {
      if (!(value instanceof MessageLite)) {
        throw new IllegalArgumentException("LazyField now only used for MessageSet, and the value of MessageSet must be an instance of MessageLite");
      }
      return ((LazyField)this.entry.getValue()).setValue((MessageLite)value);
    }
  }
  
  static class LazyIterator<K>
    implements Iterator<Map.Entry<K, Object>>
  {
    private Iterator<Map.Entry<K, Object>> iterator;
    
    public LazyIterator(Iterator<Map.Entry<K, Object>> iterator)
    {
      this.iterator = iterator;
    }
    
    public boolean hasNext()
    {
      return this.iterator.hasNext();
    }
    
    public Map.Entry<K, Object> next()
    {
      Map.Entry<K, ?> entry = (Map.Entry)this.iterator.next();
      if ((entry.getValue() instanceof LazyField)) {
        return new LazyField.LazyEntry(entry, null);
      }
      return entry;
    }
    
    public void remove()
    {
      this.iterator.remove();
    }
  }
}
