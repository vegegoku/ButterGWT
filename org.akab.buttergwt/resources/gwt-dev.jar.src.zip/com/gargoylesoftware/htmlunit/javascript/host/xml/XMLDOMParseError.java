package com.gargoylesoftware.htmlunit.javascript.host.xml;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
public class XMLDOMParseError
  extends SimpleScriptable
{
  private int errorCode_;
  private int filepos_;
  private int line_;
  private int linepos_;
  private String reason_ = "";
  private String srcText_ = "";
  private String url_ = "";
  
  @JsxGetter
  public int getErrorCode()
  {
    return this.errorCode_;
  }
  
  @JsxGetter
  public int getFilepos()
  {
    return this.filepos_;
  }
  
  @JsxGetter
  public int getLine()
  {
    return this.line_;
  }
  
  @JsxGetter
  public int getLinepos()
  {
    return this.linepos_;
  }
  
  @JsxGetter
  public String getReason()
  {
    return this.reason_;
  }
  
  @JsxGetter
  public String getSrcText()
  {
    return this.srcText_;
  }
  
  @JsxGetter
  public String getUrl()
  {
    return this.url_;
  }
  
  void setErrorCode(int errorCode)
  {
    this.errorCode_ = errorCode;
  }
  
  void setFilepos(int filepos)
  {
    this.filepos_ = filepos;
  }
  
  void setLine(int line)
  {
    this.line_ = line;
  }
  
  void setLinepos(int linepos)
  {
    this.linepos_ = linepos;
  }
  
  void setReason(String reason)
  {
    this.reason_ = reason;
  }
  
  void setSrcText(String srcText)
  {
    this.srcText_ = srcText;
  }
  
  void setUrl(String url)
  {
    this.url_ = url;
  }
}
