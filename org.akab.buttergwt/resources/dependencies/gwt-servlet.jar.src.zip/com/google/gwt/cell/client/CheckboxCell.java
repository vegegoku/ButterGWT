package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.InputElement;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.dom.client.Node;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;

public class CheckboxCell
  extends AbstractEditableCell<Boolean, Boolean>
{
  private static final SafeHtml INPUT_CHECKED = SafeHtmlUtils.fromSafeConstant("<input type=\"checkbox\" tabindex=\"-1\" checked/>");
  private static final SafeHtml INPUT_UNCHECKED = SafeHtmlUtils.fromSafeConstant("<input type=\"checkbox\" tabindex=\"-1\"/>");
  private final boolean dependsOnSelection;
  private final boolean handlesSelection;
  
  public CheckboxCell()
  {
    this(false);
  }
  
  @Deprecated
  public CheckboxCell(boolean isSelectBox)
  {
    this(isSelectBox, isSelectBox);
  }
  
  public CheckboxCell(boolean dependsOnSelection, boolean handlesSelection)
  {
    super(new String[] { "change", "keydown" });
    this.dependsOnSelection = dependsOnSelection;
    this.handlesSelection = handlesSelection;
  }
  
  public boolean dependsOnSelection()
  {
    return this.dependsOnSelection;
  }
  
  public boolean handlesSelection()
  {
    return this.handlesSelection;
  }
  
  public boolean isEditing(Cell.Context context, Element parent, Boolean value)
  {
    return false;
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, Boolean value, NativeEvent event, ValueUpdater<Boolean> valueUpdater)
  {
    String type = event.getType();
    
    boolean enterPressed = ("keydown".equals(type)) && (event.getKeyCode() == 13);
    if (("change".equals(type)) || (enterPressed))
    {
      InputElement input = (InputElement)parent.getFirstChild().cast();
      Boolean isChecked = Boolean.valueOf(input.isChecked());
      if ((enterPressed) && ((handlesSelection()) || (!dependsOnSelection())))
      {
        isChecked = Boolean.valueOf(!isChecked.booleanValue());
        input.setChecked(isChecked.booleanValue());
      }
      if ((value != isChecked) && (!dependsOnSelection())) {
        setViewData(context.getKey(), isChecked);
      } else {
        clearViewData(context.getKey());
      }
      if (valueUpdater != null) {
        valueUpdater.update(isChecked);
      }
    }
  }
  
  public void render(Cell.Context context, Boolean value, SafeHtmlBuilder sb)
  {
    Object key = context.getKey();
    Boolean viewData = (Boolean)getViewData(key);
    if ((viewData != null) && (viewData.equals(value)))
    {
      clearViewData(key);
      viewData = null;
    }
    if (value != null) {
      if ((viewData != null ? viewData : value).booleanValue())
      {
        sb.append(INPUT_CHECKED); return;
      }
    }
    sb.append(INPUT_UNCHECKED);
  }
}
