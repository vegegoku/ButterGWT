package com.google.gwt.canvas.dom.client;

import com.google.gwt.core.client.JavaScriptObject;

public class ImageData
  extends JavaScriptObject
{
  private static final int NUM_COLORS = 4;
  private static final int OFFSET_RED = 0;
  private static final int OFFSET_GREEN = 1;
  private static final int OFFSET_BLUE = 2;
  private static final int OFFSET_ALPHA = 3;
  
  public final int getAlphaAt(int x, int y)
  {
    return getColorAt(x, y, 3);
  }
  
  public final int getBlueAt(int x, int y)
  {
    return getColorAt(x, y, 2);
  }
  
  public final native CanvasPixelArray getData();
  
  public final int getGreenAt(int x, int y)
  {
    return getColorAt(x, y, 1);
  }
  
  public final native int getHeight();
  
  public final int getRedAt(int x, int y)
  {
    return getColorAt(x, y, 0);
  }
  
  public final native int getWidth();
  
  public final void setAlphaAt(int alpha, int x, int y)
  {
    setColorAt(alpha, x, y, 3);
  }
  
  public final void setBlueAt(int blue, int x, int y)
  {
    setColorAt(blue, x, y, 2);
  }
  
  public final void setGreenAt(int green, int x, int y)
  {
    setColorAt(green, x, y, 1);
  }
  
  public final void setRedAt(int red, int x, int y)
  {
    setColorAt(red, x, y, 0);
  }
  
  private native int getColorAt(int paramInt1, int paramInt2, int paramInt3);
  
  private native void setColorAt(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}
