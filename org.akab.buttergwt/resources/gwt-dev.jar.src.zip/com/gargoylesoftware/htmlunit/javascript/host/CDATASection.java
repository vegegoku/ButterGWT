package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.html.DomCDataSection;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={DomCDataSection.class})
public final class CDATASection
  extends Text
{}
