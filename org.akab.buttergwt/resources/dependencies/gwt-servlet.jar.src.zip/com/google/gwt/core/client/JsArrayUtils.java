package com.google.gwt.core.client;

public class JsArrayUtils
{
  public static JsArrayInteger readOnlyJsArray(byte[] array)
  {
    if (GWT.isScript()) {
      return (JsArrayInteger)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArrayInteger dest = (JsArrayInteger)JsArrayInteger.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  public static JsArrayNumber readOnlyJsArray(double[] array)
  {
    if (GWT.isScript()) {
      return (JsArrayNumber)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArrayNumber dest = (JsArrayNumber)JsArrayNumber.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  public static JsArrayNumber readOnlyJsArray(float[] array)
  {
    if (GWT.isScript()) {
      return (JsArrayNumber)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArrayNumber dest = (JsArrayNumber)JsArrayNumber.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  public static JsArrayInteger readOnlyJsArray(int[] array)
  {
    if (GWT.isScript()) {
      return (JsArrayInteger)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArrayInteger dest = (JsArrayInteger)JsArrayInteger.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  public static JsArrayNumber readOnlyJsArray(long[] array)
  {
    if (GWT.isScript()) {
      return (JsArrayNumber)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArrayNumber dest = (JsArrayNumber)JsArrayNumber.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  public static JsArrayInteger readOnlyJsArray(short[] array)
  {
    if (GWT.isScript()) {
      return (JsArrayInteger)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArrayInteger dest = (JsArrayInteger)JsArrayInteger.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  public static <T extends JavaScriptObject> JsArray<T> readOnlyJsArray(T[] array)
  {
    if (GWT.isScript()) {
      return (JsArray)arrayAsJsArrayForProdMode(array).cast();
    }
    JsArray<T> dest = (JsArray)JavaScriptObject.createArray().cast();
    for (int i = 0; i < array.length; i++) {
      dest.push(array[i]);
    }
    return dest;
  }
  
  private static native JavaScriptObject arrayAsJsArrayForProdMode(Object paramObject);
}
