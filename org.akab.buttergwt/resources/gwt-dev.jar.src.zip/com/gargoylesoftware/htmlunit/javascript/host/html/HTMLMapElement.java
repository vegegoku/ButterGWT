package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlArea;
import com.gargoylesoftware.htmlunit.html.HtmlMap;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.util.ArrayList;
import java.util.List;

@JsxClass(domClasses={HtmlMap.class})
public class HTMLMapElement
  extends HTMLElement
{
  private HTMLCollection areas_;
  
  @JsxGetter
  public HTMLCollection getAreas()
  {
    if (this.areas_ == null)
    {
      final HtmlMap map = (HtmlMap)getDomNodeOrDie();
      this.areas_ = new HTMLCollection(map, false, "HTMLMapElement.areas")
      {
        protected List<Object> computeElements()
        {
          List<Object> list = new ArrayList();
          for (DomNode node : map.getChildElements()) {
            if ((node instanceof HtmlArea)) {
              list.add(node);
            }
          }
          return list;
        }
      };
    }
    return this.areas_;
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
