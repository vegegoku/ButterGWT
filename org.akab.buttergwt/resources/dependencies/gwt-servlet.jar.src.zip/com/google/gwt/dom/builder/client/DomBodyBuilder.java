package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.BodyBuilder;
import com.google.gwt.dom.client.BodyElement;

public class DomBodyBuilder
  extends DomElementBuilderBase<BodyBuilder, BodyElement>
  implements BodyBuilder
{
  DomBodyBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
