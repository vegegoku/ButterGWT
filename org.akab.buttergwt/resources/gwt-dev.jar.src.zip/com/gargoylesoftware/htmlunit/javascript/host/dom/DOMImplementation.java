package com.gargoylesoftware.htmlunit.javascript.host.dom;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLDocument;
import com.gargoylesoftware.htmlunit.xml.XmlPage;

@JsxClass
public class DOMImplementation
  extends SimpleScriptable
{
  @JsxFunction
  public boolean hasFeature(String feature, String version)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.DOMIMPLEMENTATION_ONLY_HTML))
    {
      if (("HTML".equals(feature)) && ("1.0".equals(version))) {
        return true;
      }
    }
    else
    {
      if (("HTML".equals(feature)) && (("1.0".equals(version)) || ("2.0".equals(version)))) {
        return true;
      }
      if (("XML".equals(feature)) && (("1.0".equals(version)) || ("2.0".equals(version)))) {
        return true;
      }
      if (("CSS2".equals(feature)) && ("2.0".equals(version))) {
        return true;
      }
      if (("XPath".equals(feature)) && ("3.0".equals(version))) {
        return true;
      }
      if (("http://www.w3.org/TR/SVG11/feature#BasicStructure".equals(feature)) && (("1.0".equals(version)) || ("1.1".equals(version)))) {
        return true;
      }
      if (("http://www.w3.org/TR/SVG11/feature#Shape".equals(feature)) && (("1.0".equals(version)) || ("1.1".equals(version)))) {
        return true;
      }
    }
    return false;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public XMLDocument createDocument(String namespaceURI, String qualifiedName, Object doctype)
  {
    XMLDocument document = new XMLDocument(getWindow().getWebWindow());
    document.setParentScope(getParentScope());
    document.setPrototype(getPrototype(document.getClass()));
    if ((qualifiedName != null) && (!qualifiedName.isEmpty()))
    {
      XmlPage page = (XmlPage)document.getDomNodeOrDie();
      page.appendChild(page.createXmlElementNS(namespaceURI, qualifiedName));
    }
    return document;
  }
}
