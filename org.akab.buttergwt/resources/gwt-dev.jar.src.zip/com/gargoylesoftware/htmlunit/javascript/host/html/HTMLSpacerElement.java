package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlSpacer;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={HtmlSpacer.class})
public class HTMLSpacerElement
  extends HTMLElement
{
  protected boolean isLowerCaseInOuterHtml()
  {
    return true;
  }
}
