package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface CheckboxRole
  extends InputRole
{
  public abstract String getAriaCheckedState(Element paramElement);
  
  public abstract void removeAriaCheckedState(Element paramElement);
  
  public abstract void setAriaCheckedState(Element paramElement, CheckedValue paramCheckedValue);
}
