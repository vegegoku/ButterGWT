package com.google.gwt.dom.builder.shared;

public abstract interface CanvasBuilder
  extends ElementBuilderBase<CanvasBuilder>
{
  public abstract CanvasBuilder height(int paramInt);
  
  public abstract CanvasBuilder width(int paramInt);
}
