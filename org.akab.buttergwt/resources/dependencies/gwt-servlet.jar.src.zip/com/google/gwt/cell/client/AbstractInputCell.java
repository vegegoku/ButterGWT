package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import java.util.HashSet;
import java.util.Set;

public abstract class AbstractInputCell<C, V>
  extends AbstractEditableCell<C, V>
{
  private Object focusedKey;
  
  private static Set<String> getConsumedEventsImpl(Set<String> userEvents)
  {
    Set<String> events = new HashSet();
    events.add("focus");
    events.add("blur");
    events.add("keydown");
    if ((userEvents != null) && (userEvents.size() > 0)) {
      events.addAll(userEvents);
    }
    return events;
  }
  
  private static Set<String> getConsumedEventsImpl(String... consumedEvents)
  {
    Set<String> userEvents = new HashSet();
    if (consumedEvents != null) {
      for (String event : consumedEvents) {
        userEvents.add(event);
      }
    }
    return getConsumedEventsImpl(userEvents);
  }
  
  public AbstractInputCell(String... consumedEvents)
  {
    super(getConsumedEventsImpl(consumedEvents));
  }
  
  public AbstractInputCell(Set<String> consumedEvents)
  {
    super(getConsumedEventsImpl(consumedEvents));
  }
  
  public boolean isEditing(Cell.Context context, Element parent, C value)
  {
    return (this.focusedKey != null) && (this.focusedKey.equals(context.getKey()));
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    
    Element target = (Element)event.getEventTarget().cast();
    if (!getInputElement(parent).isOrHasChild(target)) {
      return;
    }
    String eventType = event.getType();
    if ("focus".equals(eventType)) {
      this.focusedKey = context.getKey();
    } else if ("blur".equals(eventType)) {
      this.focusedKey = null;
    }
  }
  
  public boolean resetFocus(Cell.Context context, Element parent, C value)
  {
    if (isEditing(context, parent, value))
    {
      getInputElement(parent).focus();
      return true;
    }
    return false;
  }
  
  protected void finishEditing(Element parent, C value, Object key, ValueUpdater<C> valueUpdater)
  {
    this.focusedKey = null;
    getInputElement(parent).blur();
  }
  
  protected Element getInputElement(Element parent)
  {
    return parent.getFirstChildElement();
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    Element input = getInputElement(parent);
    Element target = (Element)event.getEventTarget().cast();
    Object key = context.getKey();
    if (getInputElement(parent).isOrHasChild(target))
    {
      finishEditing(parent, value, key, valueUpdater);
    }
    else
    {
      this.focusedKey = key;
      input.focus();
    }
  }
}
