package com.google.gwt.aria.client;

class PrimitiveValueAttribute<T>
  extends Attribute<T>
{
  public PrimitiveValueAttribute(String name)
  {
    super(name);
  }
  
  public PrimitiveValueAttribute(String name, String defaultValue)
  {
    super(name, defaultValue);
  }
  
  protected String getSingleValue(T value)
  {
    return String.valueOf(value);
  }
}
