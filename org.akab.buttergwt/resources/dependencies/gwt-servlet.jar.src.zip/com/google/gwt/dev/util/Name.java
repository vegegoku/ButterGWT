package com.google.gwt.dev.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Name
{
  public static class BinaryName
  {
    public static String getClassName(String binaryName)
    {
      assert (Name.isBinaryName(binaryName));
      int lastDot = binaryName.lastIndexOf('.');
      if (lastDot < 0) {
        return binaryName;
      }
      return binaryName.substring(lastDot + 1);
    }
    
    public static String getShortClassName(String binaryName)
    {
      assert (Name.isBinaryName(binaryName));
      String className = getClassName(binaryName);
      int lastDollar = className.lastIndexOf('$', className.length() - 2);
      if (lastDollar < 0) {
        return className;
      }
      return className.substring(lastDollar + 1);
    }
    
    public static String toInternalName(String binaryName)
    {
      assert (Name.isBinaryName(binaryName));
      return binaryName.replace('.', '/');
    }
    
    public static String toSourceName(String binaryName)
    {
      assert (Name.isBinaryName(binaryName));
      
      return Name.NON_TRAILING_DOLLAR.matcher(binaryName).replaceAll(".$1");
    }
  }
  
  public static class InternalName
  {
    public static String getClassName(String name)
    {
      assert (Name.isInternalName(name));
      int lastSlash = name.lastIndexOf('/');
      if (lastSlash < 0) {
        return name;
      }
      return name.substring(lastSlash + 1);
    }
    
    public static String toBinaryName(String internalName)
    {
      assert (Name.isInternalName(internalName));
      return internalName.replace('/', '.');
    }
    
    public static String toSourceName(String internalName)
    {
      assert (Name.isInternalName(internalName));
      
      return Name.NON_TRAILING_DOLLAR_SLASH.matcher(internalName).replaceAll(".$1");
    }
  }
  
  public static class SourceOrBinaryName
  {
    public static String toSourceName(String dottedName)
    {
      return Name.NON_TRAILING_DOLLAR.matcher(dottedName).replaceAll(".$1");
    }
  }
  
  private static final Pattern NON_TRAILING_DOLLAR = Pattern.compile("[$](\\p{javaJavaIdentifierStart})");
  private static final Pattern NON_TRAILING_DOLLAR_SLASH = Pattern.compile("[$/](\\p{javaJavaIdentifierStart})");
  
  public static String getBinaryNameForClass(Class<?> clazz)
  {
    return clazz.getName();
  }
  
  public static String getInternalNameForClass(Class<?> clazz)
  {
    return BinaryName.toInternalName(getBinaryNameForClass(clazz));
  }
  
  public static String getSourceNameForClass(Class<?> clazz)
  {
    return clazz.getCanonicalName();
  }
  
  public static boolean isBinaryName(String name)
  {
    return (name == null) || (!name.contains("/"));
  }
  
  public static boolean isInternalName(String name)
  {
    return (name == null) || (!name.contains("."));
  }
  
  public static boolean isSourceName(String name)
  {
    if (name == null) {
      return true;
    }
    int dollar = name.indexOf('$');
    return (!name.contains("/")) && ((dollar < 0) || (dollar == name.length() - 1));
  }
}
