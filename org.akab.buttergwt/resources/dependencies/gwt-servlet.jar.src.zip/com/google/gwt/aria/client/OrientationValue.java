package com.google.gwt.aria.client;

public enum OrientationValue
  implements AriaAttributeType
{
  HORIZONTAL,  VERTICAL;
  
  private OrientationValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case HORIZONTAL: 
      return "horizontal";
    case VERTICAL: 
      return "vertical";
    }
    return null;
  }
}
