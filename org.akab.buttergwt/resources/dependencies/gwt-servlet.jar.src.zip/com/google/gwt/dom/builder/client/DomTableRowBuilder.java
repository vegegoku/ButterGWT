package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TableRowBuilder;
import com.google.gwt.dom.client.TableRowElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomTableRowBuilder
  extends DomElementBuilderBase<TableRowBuilder, TableRowElement>
  implements TableRowBuilder
{
  DomTableRowBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public TableRowBuilder align(String align)
  {
    ((TableRowElement)assertCanAddAttribute()).setAlign(align);
    return this;
  }
  
  public TableRowBuilder ch(String ch)
  {
    ((TableRowElement)assertCanAddAttribute()).setCh(ch);
    return this;
  }
  
  public TableRowBuilder chOff(String chOff)
  {
    ((TableRowElement)assertCanAddAttribute()).setChOff(chOff);
    return this;
  }
  
  public TableRowBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException("Table row elements do not support setting inner html or text. Use startTD/startTH() instead to append a table cell to the section.");
  }
  
  public TableRowBuilder text(String text)
  {
    throw new UnsupportedOperationException("Table row elements do not support setting inner html or text. Use startTD/startTH() instead to append a table cell to the section.");
  }
  
  public TableRowBuilder vAlign(String vAlign)
  {
    ((TableRowElement)assertCanAddAttribute()).setVAlign(vAlign);
    return this;
  }
}
