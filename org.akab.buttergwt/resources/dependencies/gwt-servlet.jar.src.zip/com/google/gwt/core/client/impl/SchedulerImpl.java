package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.Duration;
import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.JavaScriptObject;
import com.google.gwt.core.client.JsArray;
import com.google.gwt.core.client.Scheduler;
import com.google.gwt.core.client.Scheduler.RepeatingCommand;
import com.google.gwt.core.client.Scheduler.ScheduledCommand;

public class SchedulerImpl
  extends Scheduler
{
  static final class Task
    extends JavaScriptObject
  {
    public static native Task create(Scheduler.RepeatingCommand paramRepeatingCommand);
    
    public static native Task create(Scheduler.ScheduledCommand paramScheduledCommand);
    
    public boolean executeRepeating()
    {
      return getRepeating().execute();
    }
    
    public void executeScheduled()
    {
      getScheduled().execute();
    }
    
    public native Scheduler.RepeatingCommand getRepeating();
    
    public native Scheduler.ScheduledCommand getScheduled();
    
    public native boolean isRepeating();
  }
  
  private final class Flusher
    implements Scheduler.RepeatingCommand
  {
    private Flusher() {}
    
    public boolean execute()
    {
      SchedulerImpl.this.flushRunning = true;
      SchedulerImpl.this.flushPostEventPumpCommands();
      
      SchedulerImpl.this.flushRunning = false;
      return SchedulerImpl.this.shouldBeRunning = SchedulerImpl.this.isWorkQueued();
    }
  }
  
  private final class Rescuer
    implements Scheduler.RepeatingCommand
  {
    private Rescuer() {}
    
    public boolean execute()
    {
      if (SchedulerImpl.this.flushRunning) {
        SchedulerImpl.this.scheduleFixedDelay(SchedulerImpl.this.flusher, 1);
      }
      return SchedulerImpl.this.shouldBeRunning;
    }
  }
  
  public static final SchedulerImpl INSTANCE = (SchedulerImpl)GWT.create(SchedulerImpl.class);
  private static final int FLUSHER_DELAY = 1;
  private static final int RESCUE_DELAY = 50;
  private static final double TIME_SLICE = 100.0D;
  Flusher flusher;
  Rescuer rescue;
  JsArray<Task> deferredCommands;
  JsArray<Task> entryCommands;
  JsArray<Task> finallyCommands;
  JsArray<Task> incrementalCommands;
  
  private static JsArray<Task> createQueue()
  {
    return (JsArray)JavaScriptObject.createArray().cast();
  }
  
  private static boolean execute(Scheduler.RepeatingCommand cmd)
  {
    return cmd.execute();
  }
  
  private static JsArray<Task> push(JsArray<Task> queue, Task task)
  {
    if (queue == null) {
      queue = createQueue();
    }
    queue.push(task);
    return queue;
  }
  
  private static JsArray<Task> runScheduledTasks(JsArray<Task> tasks, JsArray<Task> rescheduled)
  {
    assert (tasks != null) : "tasks";
    
    int i = 0;
    for (int j = tasks.length(); i < j; i++)
    {
      assert (tasks.length() == j) : ("Working array length changed " + tasks.length() + " != " + j);
      
      Task t = (Task)tasks.get(i);
      try
      {
        if (t.isRepeating())
        {
          if (t.executeRepeating()) {
            rescheduled = push(rescheduled, t);
          }
        }
        else {
          t.executeScheduled();
        }
      }
      catch (Throwable e)
      {
        GWT.reportUncaughtException(e);
      }
    }
    return rescheduled;
  }
  
  private boolean flushRunning = false;
  private boolean shouldBeRunning = false;
  
  private static native void scheduleFixedDelayImpl(Scheduler.RepeatingCommand paramRepeatingCommand, int paramInt);
  
  private static native void scheduleFixedPeriodImpl(Scheduler.RepeatingCommand paramRepeatingCommand, int paramInt);
  
  public void flushEntryCommands()
  {
    if (this.entryCommands != null)
    {
      JsArray<Task> rescheduled = null;
      do
      {
        JsArray<Task> oldQueue = this.entryCommands;
        this.entryCommands = null;
        rescheduled = runScheduledTasks(oldQueue, rescheduled);
      } while (this.entryCommands != null);
      this.entryCommands = rescheduled;
    }
  }
  
  public void flushFinallyCommands()
  {
    if (this.finallyCommands != null)
    {
      JsArray<Task> rescheduled = null;
      do
      {
        JsArray<Task> oldQueue = this.finallyCommands;
        this.finallyCommands = null;
        rescheduled = runScheduledTasks(oldQueue, rescheduled);
      } while (this.finallyCommands != null);
      this.finallyCommands = rescheduled;
    }
  }
  
  public void scheduleDeferred(Scheduler.ScheduledCommand cmd)
  {
    this.deferredCommands = push(this.deferredCommands, Task.create(cmd));
    maybeSchedulePostEventPumpCommands();
  }
  
  public void scheduleEntry(Scheduler.RepeatingCommand cmd)
  {
    this.entryCommands = push(this.entryCommands, Task.create(cmd));
  }
  
  public void scheduleEntry(Scheduler.ScheduledCommand cmd)
  {
    this.entryCommands = push(this.entryCommands, Task.create(cmd));
  }
  
  public void scheduleFinally(Scheduler.RepeatingCommand cmd)
  {
    this.finallyCommands = push(this.finallyCommands, Task.create(cmd));
  }
  
  public void scheduleFinally(Scheduler.ScheduledCommand cmd)
  {
    this.finallyCommands = push(this.finallyCommands, Task.create(cmd));
  }
  
  public void scheduleFixedDelay(Scheduler.RepeatingCommand cmd, int delayMs)
  {
    scheduleFixedDelayImpl(cmd, delayMs);
  }
  
  public void scheduleFixedPeriod(Scheduler.RepeatingCommand cmd, int delayMs)
  {
    scheduleFixedPeriodImpl(cmd, delayMs);
  }
  
  public void scheduleIncremental(Scheduler.RepeatingCommand cmd)
  {
    this.deferredCommands = push(this.deferredCommands, Task.create(cmd));
    maybeSchedulePostEventPumpCommands();
  }
  
  Duration createDuration()
  {
    return new Duration();
  }
  
  void flushPostEventPumpCommands()
  {
    if (this.deferredCommands != null)
    {
      JsArray<Task> oldDeferred = this.deferredCommands;
      this.deferredCommands = null;
      if (this.incrementalCommands == null) {
        this.incrementalCommands = createQueue();
      }
      runScheduledTasks(oldDeferred, this.incrementalCommands);
    }
    if (this.incrementalCommands != null) {
      this.incrementalCommands = runRepeatingTasks(this.incrementalCommands);
    }
  }
  
  boolean isWorkQueued()
  {
    return (this.deferredCommands != null) || (this.incrementalCommands != null);
  }
  
  private void maybeSchedulePostEventPumpCommands()
  {
    if (!this.shouldBeRunning)
    {
      this.shouldBeRunning = true;
      if (this.flusher == null) {
        this.flusher = new Flusher(null);
      }
      scheduleFixedDelayImpl(this.flusher, 1);
      if (this.rescue == null) {
        this.rescue = new Rescuer(null);
      }
      scheduleFixedDelayImpl(this.rescue, 50);
    }
  }
  
  private JsArray<Task> runRepeatingTasks(JsArray<Task> tasks)
  {
    assert (tasks != null) : "tasks";
    
    int length = tasks.length();
    if (length == 0) {
      return null;
    }
    boolean canceledSomeTasks = false;
    
    Duration duration = createDuration();
    while (duration.elapsedMillis() < 100.0D)
    {
      boolean executedSomeTask = false;
      for (int i = 0; i < length; i++)
      {
        assert (tasks.length() == length) : ("Working array length changed " + tasks.length() + " != " + length);
        
        Task t = (Task)tasks.get(i);
        if (t != null)
        {
          executedSomeTask = true;
          
          assert (t.isRepeating()) : "Found a non-repeating Task";
          if (!t.executeRepeating())
          {
            tasks.set(i, null);
            canceledSomeTasks = true;
          }
        }
      }
      if (!executedSomeTask) {
        break;
      }
    }
    if (canceledSomeTasks)
    {
      JsArray<Task> newTasks = createQueue();
      for (int i = 0; i < length; i++) {
        if (tasks.get(i) != null) {
          newTasks.push(tasks.get(i));
        }
      }
      assert (newTasks.length() < length);
      return newTasks.length() == 0 ? null : newTasks;
    }
    return tasks;
  }
}
