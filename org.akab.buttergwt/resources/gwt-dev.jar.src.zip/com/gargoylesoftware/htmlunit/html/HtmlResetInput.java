package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import java.io.IOException;
import java.util.Map;

public class HtmlResetInput
  extends HtmlInput
{
  private static final String DEFAULT_VALUE = "Reset";
  
  HtmlResetInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, addValueIfNeeded(page, attributes));
    if ((hasFeature(BrowserVersionFeatures.RESETINPUT_DEFAULT_VALUE_IF_VALUE_NOT_DEFINED)) && (getAttribute("value") == "Reset")) {
      setDefaultValue(ATTRIBUTE_NOT_DEFINED, false);
    }
  }
  
  private static Map<String, DomAttr> addValueIfNeeded(SgmlPage page, Map<String, DomAttr> attributes)
  {
    BrowserVersion browserVersion = page.getWebClient().getBrowserVersion();
    if (browserVersion.hasFeature(BrowserVersionFeatures.RESETINPUT_DEFAULT_VALUE_IF_VALUE_NOT_DEFINED))
    {
      for (String key : attributes.keySet()) {
        if ("value".equalsIgnoreCase(key)) {
          return attributes;
        }
      }
      DomAttr newAttr = new DomAttr(page, null, "value", "Reset", true);
      attributes.put("value", newAttr);
    }
    return attributes;
  }
  
  protected boolean doClickStateUpdate()
    throws IOException
  {
    HtmlForm form = getEnclosingForm();
    if (form != null)
    {
      form.reset();
      return false;
    }
    super.doClickStateUpdate();
    return false;
  }
  
  public void reset() {}
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ((hasFeature(BrowserVersionFeatures.HTMLINPUT_SET_VALUE_UPDATES_DEFAULT_VALUE)) && ("value".equals(qualifiedName))) {
      setDefaultValue(attributeValue, false);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
}
