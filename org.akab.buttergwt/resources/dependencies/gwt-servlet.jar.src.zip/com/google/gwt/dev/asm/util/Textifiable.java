package com.google.gwt.dev.asm.util;

import com.google.gwt.dev.asm.Label;
import java.util.Map;

public abstract interface Textifiable
{
  public abstract void textify(StringBuffer paramStringBuffer, Map<Label, String> paramMap);
}
