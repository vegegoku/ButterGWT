package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.SourceBuilder;
import com.google.gwt.dom.client.SourceElement;

public class DomSourceBuilder
  extends DomElementBuilderBase<SourceBuilder, SourceElement>
  implements SourceBuilder
{
  DomSourceBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public SourceBuilder src(String url)
  {
    ((SourceElement)assertCanAddAttribute()).setSrc(url);
    return this;
  }
  
  public SourceBuilder type(String type)
  {
    ((SourceElement)assertCanAddAttribute()).setType(type);
    return this;
  }
}
