package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.util.KeyDataPair;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.lang3.StringUtils;

public class HtmlFileInput
  extends HtmlInput
{
  private String contentType_;
  private byte[] data_;
  
  HtmlFileInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, addValueIfNeeded(page, attributes));
    if (hasFeature(BrowserVersionFeatures.FILEINPUT_EMPTY_DEFAULT_VALUE)) {
      setDefaultValue("", false);
    } else {
      for (Map.Entry<String, DomAttr> entry : attributes.entrySet()) {
        if ("value".equalsIgnoreCase((String)entry.getKey())) {
          setDefaultValue(((DomAttr)entry.getValue()).getNodeValue(), false);
        }
      }
    }
  }
  
  private static Map<String, DomAttr> addValueIfNeeded(SgmlPage page, Map<String, DomAttr> attributes)
  {
    Map<String, DomAttr> result = new HashMap(attributes);
    DomAttr newAttr = new DomAttr(page, null, "value", "", true);
    result.put("value", newAttr);
    
    return result;
  }
  
  public final byte[] getData()
  {
    return this.data_;
  }
  
  public final void setData(byte[] data)
  {
    this.data_ = data;
  }
  
  public NameValuePair[] getSubmitKeyValuePairs()
  {
    String value = getValueAttribute();
    if (StringUtils.isEmpty(value)) {
      return new NameValuePair[] { new KeyDataPair(getNameAttribute(), new File(""), null, null) };
    }
    File file = null;
    if (value.startsWith("file:/"))
    {
      if ((value.startsWith("file://")) && (!value.startsWith("file:///"))) {
        value = "file:///" + value.substring(7);
      }
      try
      {
        file = new File(new URI(value));
      }
      catch (URISyntaxException e) {}
    }
    if (file == null) {
      file = new File(value);
    }
    String contentType;
    String contentType;
    if (this.contentType_ == null) {
      contentType = getPage().getWebClient().guessContentType(file);
    } else {
      contentType = this.contentType_;
    }
    String charset = getPage().getPageEncoding();
    KeyDataPair keyDataPair = new KeyDataPair(getNameAttribute(), file, contentType, charset);
    keyDataPair.setData(this.data_);
    return new NameValuePair[] { keyDataPair };
  }
  
  public void reset() {}
  
  public void setDefaultValue(String defaultValue)
  {
    setDefaultValue(defaultValue, false);
  }
  
  public void setContentType(String contentType)
  {
    this.contentType_ = contentType;
  }
  
  public String getContentType()
  {
    return this.contentType_;
  }
}
