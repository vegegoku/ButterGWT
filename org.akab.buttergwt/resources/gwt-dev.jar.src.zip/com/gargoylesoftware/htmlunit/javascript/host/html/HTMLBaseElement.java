package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlBase;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlBase.class})
public class HTMLBaseElement
  extends HTMLElement
{
  @JsxGetter
  public String getHref()
  {
    return getDomNodeOrDie().getAttribute("href");
  }
  
  @JsxSetter
  public void setHref(String href)
  {
    getDomNodeOrDie().setAttribute("href", href);
  }
  
  @JsxGetter
  public String getTarget()
  {
    return getDomNodeOrDie().getAttribute("target");
  }
  
  @JsxSetter
  public void setTarget(String target)
  {
    getDomNodeOrDie().setAttribute("target", target);
  }
  
  protected boolean isEndTagForbidden()
  {
    return true;
  }
}
