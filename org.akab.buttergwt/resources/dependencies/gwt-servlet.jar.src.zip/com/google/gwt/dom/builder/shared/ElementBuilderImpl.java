package com.google.gwt.dom.builder.shared;

import com.google.gwt.core.shared.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.regexp.shared.RegExp;
import com.google.gwt.safehtml.shared.SafeHtml;

public abstract class ElementBuilderImpl
{
  private static RegExp HTML_TAG_REGEX;
  private boolean asElementCalled;
  
  private static class StackNode
  {
    private final ElementBuilderBase<?> builder;
    private StackNode next;
    private final String tagName;
    
    public StackNode(String tagName, ElementBuilderBase<?> builder)
    {
      this.builder = builder;
      this.tagName = tagName;
    }
  }
  
  private class FastPeekStack
  {
    private static final String EMPTY_STACK_MESSAGE = "There are no elements on the stack.";
    private ElementBuilderImpl.StackNode top;
    private int size = 0;
    
    private FastPeekStack() {}
    
    public boolean isEmpty()
    {
      return this.top == null;
    }
    
    public ElementBuilderImpl.StackNode peek()
    {
      assertNotEmpty();
      return this.top;
    }
    
    public ElementBuilderImpl.StackNode pop()
    {
      assertNotEmpty();
      ElementBuilderImpl.StackNode toRet = this.top;
      this.top = ElementBuilderImpl.StackNode.access$000(this.top);
      this.size -= 1;
      return toRet;
    }
    
    public void push(ElementBuilderBase<?> builder, String tagName)
    {
      ElementBuilderImpl.StackNode node = new ElementBuilderImpl.StackNode(tagName, builder);
      ElementBuilderImpl.StackNode.access$002(node, this.top);
      this.top = node;
      this.size += 1;
    }
    
    public int size()
    {
      return this.size;
    }
    
    private void assertNotEmpty()
    {
      if (isEmpty()) {
        throw new IllegalStateException("There are no elements on the stack.");
      }
    }
  }
  
  private boolean isEmpty = true;
  private boolean isHtmlOrTextAdded;
  private boolean isStartTagOpen;
  private boolean isStyleClosed;
  private boolean isStyleOpen;
  private final FastPeekStack stack = new FastPeekStack(null);
  
  public ElementBuilderImpl()
  {
    if (HTML_TAG_REGEX == null) {
      HTML_TAG_REGEX = RegExp.compile("^[a-z][a-z0-9]*$", "i");
    }
  }
  
  public void end()
  {
    endImpl(getCurrentTagName());
  }
  
  public void end(String tagName)
  {
    String topItem = getCurrentTagName();
    if (!topItem.equalsIgnoreCase(tagName)) {
      throw new IllegalStateException("Specified tag \"" + tagName + "\" does not match the current element \"" + topItem + "\"");
    }
    endImpl(topItem);
  }
  
  public void endStyle()
  {
    if (!this.isStyleOpen) {
      throw new IllegalStateException("Attempting to close a style attribute, but the style attribute isn't open");
    }
    maybeCloseStyleAttribute();
  }
  
  public Element finish()
  {
    if (!GWT.isClient()) {
      throw new RuntimeException("asElement() can only be called from GWT client code.");
    }
    if (this.asElementCalled) {
      throw new IllegalStateException("asElement() can only be called once.");
    }
    this.asElementCalled = true;
    
    endAllTags();
    
    return doFinishImpl();
  }
  
  public int getDepth()
  {
    return this.stack.size();
  }
  
  public void html(SafeHtml html)
  {
    assertStartTagOpen("html cannot be set on an element that already contains other content or elements.");
    
    lockCurrentElement();
    doHtmlImpl(html);
  }
  
  public void onStart(String tagName, ElementBuilderBase<?> builder)
  {
    if (this.isEmpty)
    {
      this.isEmpty = false;
    }
    else
    {
      if (this.stack.isEmpty()) {
        throw new IllegalStateException("You can only build one top level element.");
      }
      assertEndTagNotForbidden("child elements");
      if (!getCurrentBuilder().isChildElementSupported()) {
        throw new UnsupportedOperationException(getCurrentTagName() + " does not support child elements.");
      }
    }
    if (this.isHtmlOrTextAdded) {
      throw new IllegalStateException("Cannot append an element after setting text of html.");
    }
    assertValidTagName(tagName);
    
    maybeCloseStartTag();
    this.stack.push(builder, tagName);
    this.isStartTagOpen = true;
    this.isStyleOpen = false;
    this.isStyleClosed = false;
    this.isHtmlOrTextAdded = false;
  }
  
  public abstract StylesBuilder style();
  
  public void text(String text)
  {
    assertStartTagOpen("text cannot be set on an element that already contains other content or elements.");
    
    lockCurrentElement();
    doTextImpl(text);
  }
  
  protected void assertCanAddAttributeImpl()
  {
    assertStartTagOpen("Attributes cannot be added after appending HTML or adding a child element.");
    
    maybeCloseStyleAttribute();
  }
  
  protected void assertCanAddStylePropertyImpl()
  {
    assertStartTagOpen("Style properties cannot be added after appending HTML or adding a child element.");
    if (this.isStyleClosed) {
      throw new IllegalStateException("Style properties must be added at the same time. If you already added style properties, you cannot add more after adding non-style attributes.");
    }
    if (!this.isStyleOpen)
    {
      this.isStyleOpen = true;
      doOpenStyleImpl();
    }
  }
  
  protected void assertValidTagName(String tagName)
  {
    if (!HTML_TAG_REGEX.test(tagName)) {
      throw new IllegalArgumentException("The specified tag name is invalid: " + tagName);
    }
  }
  
  protected abstract void doCloseStartTagImpl();
  
  protected abstract void doCloseStyleAttributeImpl();
  
  protected abstract void doEndStartTagImpl();
  
  protected abstract void doEndTagImpl(String paramString);
  
  protected abstract Element doFinishImpl();
  
  protected abstract void doHtmlImpl(SafeHtml paramSafeHtml);
  
  protected abstract void doOpenStyleImpl();
  
  protected abstract void doTextImpl(String paramString);
  
  protected void endAllTags()
  {
    while (!this.stack.isEmpty()) {
      end();
    }
  }
  
  protected void lockCurrentElement()
  {
    maybeCloseStartTag();
    assertEndTagNotForbidden("html");
    this.isHtmlOrTextAdded = true;
  }
  
  private void assertEndTagNotForbidden(String operation)
  {
    if (getCurrentBuilder().isEndTagForbidden()) {
      throw new UnsupportedOperationException(getCurrentTagName() + " does not support " + operation);
    }
  }
  
  private void assertStartTagOpen(String message)
  {
    if (!this.isStartTagOpen) {
      throw new IllegalStateException(message);
    }
  }
  
  private void endImpl(String tagName)
  {
    maybeCloseStartTag();
    if (getCurrentBuilder().isEndTagForbidden()) {
      doEndStartTagImpl();
    } else {
      doEndTagImpl(tagName);
    }
    this.isStartTagOpen = false;
    this.isStyleClosed = true;
    this.stack.pop();
    
    this.isHtmlOrTextAdded = false;
  }
  
  private ElementBuilderBase<?> getCurrentBuilder()
  {
    return this.stack.peek().builder;
  }
  
  private String getCurrentTagName()
  {
    return this.stack.peek().tagName;
  }
  
  private void maybeCloseStartTag()
  {
    maybeCloseStyleAttribute();
    if (this.isStartTagOpen)
    {
      this.isStartTagOpen = false;
      if (!getCurrentBuilder().isEndTagForbidden()) {
        doCloseStartTagImpl();
      }
    }
  }
  
  private void maybeCloseStyleAttribute()
  {
    if (this.isStyleOpen)
    {
      this.isStyleOpen = false;
      this.isStyleClosed = true;
      doCloseStyleAttributeImpl();
    }
  }
}
