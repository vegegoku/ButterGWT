package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public class Id
  implements AriaAttributeType
{
  private String id;
  
  public static Id of(Element element)
  {
    return new Id(element);
  }
  
  public static Id of(String elementId)
  {
    return new Id(elementId);
  }
  
  private Id(Element element)
  {
    assert (element != null) : "Element cannot be null";
    init(element.getId());
  }
  
  private Id(String elementId)
  {
    init(elementId);
  }
  
  public String getAriaValue()
  {
    return this.id;
  }
  
  private void init(String elementId)
  {
    assert ((elementId != null) || (elementId.equals(""))) : "Invalid elementId: cannot be null or empty.";
    this.id = elementId;
  }
}
