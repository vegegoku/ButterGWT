package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ScriptBuilder;
import com.google.gwt.dom.client.ScriptElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomScriptBuilder
  extends DomElementBuilderBase<ScriptBuilder, ScriptElement>
  implements ScriptBuilder
{
  DomScriptBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public ScriptBuilder defer(String defer)
  {
    ((ScriptElement)assertCanAddAttribute()).setDefer(defer);
    return this;
  }
  
  public ScriptBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException("Script elements do not support html.  Use text() instead.");
  }
  
  public boolean isChildElementSupported()
  {
    return false;
  }
  
  public ScriptBuilder src(String src)
  {
    ((ScriptElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
  
  public ScriptBuilder text(String text)
  {
    ((ScriptElement)assertCanAddAttribute()).setText(text);
    
    getDelegate().lockCurrentElement();
    return this;
  }
  
  public ScriptBuilder type(String type)
  {
    ((ScriptElement)assertCanAddAttribute()).setType(type);
    return this;
  }
}
