package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.ClassConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.ClassConfiguration.PropertyInfo;
import com.gargoylesoftware.htmlunit.javascript.configuration.JavaScriptConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.xml.XMLHttpRequest;
import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.FunctionObject;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
public class ActiveXObject
  extends SimpleScriptable
{
  private static final Log LOG = LogFactory.getLog(ActiveXObject.class);
  
  @JsxConstructor
  public static Scriptable jsConstructor(Context cx, Object[] args, Function ctorObj, boolean inNewExpr)
  {
    if ((args.length < 1) || (args.length > 2)) {
      throw Context.reportRuntimeError("ActiveXObject Error: constructor must have one or two String parameters.");
    }
    if (args[0] == Context.getUndefinedValue()) {
      throw Context.reportRuntimeError("ActiveXObject Error: constructor parameter is undefined.");
    }
    if (!(args[0] instanceof String)) {
      throw Context.reportRuntimeError("ActiveXObject Error: constructor parameter must be a String.");
    }
    String activeXName = (String)args[0];
    if (isXMLHttpRequest(activeXName)) {
      return buildXMLHttpRequest();
    }
    if (isXMLDocument(activeXName)) {
      return buildXMLDocument(getWindow(ctorObj).getWebWindow());
    }
    if (isXMLTemplate(activeXName)) {
      return buildXSLTemplate();
    }
    WebClient webClient = getWindow(ctorObj).getWebWindow().getWebClient();
    Map<String, String> map = webClient.getActiveXObjectMap();
    if (map != null)
    {
      Object mapValue = map.get(activeXName);
      if (mapValue != null)
      {
        String xClassString = (String)mapValue;
        Object object = null;
        try
        {
          Class<?> xClass = Class.forName(xClassString);
          object = xClass.newInstance();
        }
        catch (Exception e)
        {
          throw Context.reportRuntimeError("ActiveXObject Error: failed instantiating class " + xClassString + " because " + e.getMessage() + ".");
        }
        return Context.toObject(object, ctorObj);
      }
    }
    if ((webClient.getOptions().isActiveXNative()) && (System.getProperty("os.name").contains("Windows"))) {
      try
      {
        return new ActiveXObjectImpl(activeXName);
      }
      catch (Exception e)
      {
        LOG.warn("Error initiating Jacob", e);
      }
    }
    LOG.warn("Automation server can't create object for '" + activeXName + "'.");
    throw Context.reportRuntimeError("Automation server can't create object for '" + activeXName + "'.");
  }
  
  static boolean isXMLHttpRequest(String name)
  {
    if (name == null) {
      return false;
    }
    name = name.toLowerCase(Locale.ENGLISH);
    return ("microsoft.xmlhttp".equals(name)) || (name.startsWith("msxml2.xmlhttp"));
  }
  
  static boolean isXMLDocument(String name)
  {
    if (name == null) {
      return false;
    }
    name = name.toLowerCase(Locale.ENGLISH);
    return ("microsoft.xmldom".equals(name)) || (name.matches("msxml\\d*\\.domdocument.*")) || (name.matches("msxml\\d*\\.freethreadeddomdocument.*"));
  }
  
  static boolean isXMLTemplate(String name)
  {
    if (name == null) {
      return false;
    }
    name = name.toLowerCase(Locale.ENGLISH);
    return name.matches("msxml\\d*\\.xsltemplate.*");
  }
  
  private static Scriptable buildXMLHttpRequest()
  {
    SimpleScriptable scriptable = new XMLHttpRequest(false);
    
    addProperty(scriptable, "onreadystatechange", true, true);
    addProperty(scriptable, "readyState", true, false);
    addProperty(scriptable, "responseText", true, false);
    addProperty(scriptable, "responseXML", true, false);
    addProperty(scriptable, "status", true, false);
    addProperty(scriptable, "statusText", true, false);
    
    addFunction(scriptable, "abort");
    addFunction(scriptable, "getAllResponseHeaders");
    addFunction(scriptable, "getResponseHeader");
    addFunction(scriptable, "open");
    addFunction(scriptable, "send");
    addFunction(scriptable, "setRequestHeader");
    
    return scriptable;
  }
  
  private static Scriptable buildXSLTemplate()
  {
    SimpleScriptable scriptable = new XSLTemplate();
    
    addProperty(scriptable, "stylesheet", true, true);
    addFunction(scriptable, "createProcessor");
    
    return scriptable;
  }
  
  public static XMLDocument buildXMLDocument(WebWindow enclosingWindow)
  {
    XMLDocument document = new XMLDocument(enclosingWindow);
    
    addProperty(document, "async", true, true);
    addProperty(document, "parseError", true, false);
    addProperty(document, "preserveWhiteSpace", true, true);
    addProperty(document, "xml", true, false);
    
    addFunction(document, "createNode");
    addFunction(document, "createCDATASection");
    addFunction(document, "createProcessingInstruction");
    addFunction(document, "getElementsByTagName");
    addFunction(document, "getProperty");
    addFunction(document, "load");
    addFunction(document, "loadXML");
    addFunction(document, "nodeFromID");
    addFunction(document, "selectNodes");
    addFunction(document, "selectSingleNode");
    addFunction(document, "setProperty");
    
    JavaScriptConfiguration jsConfig = enclosingWindow.getWebClient().getJavaScriptEngine().getJavaScriptConfiguration();
    for (String className = "Document"; StringUtils.isNotBlank(className);)
    {
      ClassConfiguration classConfig = jsConfig.getClassConfiguration(className);
      for (String function : classConfig.functionKeys()) {
        addFunction(document, function);
      }
      for (Map.Entry<String, ClassConfiguration.PropertyInfo> propertyEntry : classConfig.propertyEntries())
      {
        String propertyName = (String)propertyEntry.getKey();
        Method readMethod = ((ClassConfiguration.PropertyInfo)propertyEntry.getValue()).getReadMethod();
        Method writeMethod = ((ClassConfiguration.PropertyInfo)propertyEntry.getValue()).getWriteMethod();
        addProperty(document, propertyName, readMethod != null, writeMethod != null);
      }
      className = classConfig.getExtendedClassName();
    }
    return document;
  }
  
  private static void addFunction(SimpleScriptable scriptable, String methodName)
  {
    Method javaFunction = getMethod(scriptable.getClass(), methodName, JsxFunction.class);
    FunctionObject fo = new FunctionObject(null, javaFunction, scriptable);
    scriptable.defineProperty(methodName, fo, 1);
  }
  
  public static void addProperty(SimpleScriptable scriptable, String propertyName, boolean isGetter, boolean isSetter)
  {
    String initialUpper = Character.toUpperCase(propertyName.charAt(0)) + propertyName.substring(1);
    String getterName = null;
    if (isGetter) {
      getterName = "get" + initialUpper;
    }
    String setterName = null;
    if (isSetter) {
      setterName = "set" + initialUpper;
    }
    addProperty(scriptable, propertyName, getterName, setterName);
  }
  
  static void addProperty(SimpleScriptable scriptable, String propertyName, String getterMethodName, String setterMethodName)
  {
    scriptable.defineProperty(propertyName, null, getMethod(scriptable.getClass(), getterMethodName, JsxGetter.class), getMethod(scriptable.getClass(), setterMethodName, JsxSetter.class), 4);
  }
  
  static Method getMethod(Class<? extends SimpleScriptable> clazz, String name, Class<? extends Annotation> annotationClass)
  {
    if (name == null) {
      return null;
    }
    Method foundMethod = null;
    int foundByNameOnlyCount = 0;
    for (Method method : clazz.getMethods()) {
      if (method.getName().equals(name))
      {
        if (null != method.getAnnotation(annotationClass)) {
          return method;
        }
        foundByNameOnlyCount++;
        foundMethod = method;
      }
    }
    if (foundByNameOnlyCount > 1) {
      throw new IllegalArgumentException("Found " + foundByNameOnlyCount + " methods for name '" + name + "' in class '" + clazz + "'.");
    }
    return foundMethod;
  }
  
  public String getClassName()
  {
    return "ActiveXObject";
  }
}
