package com.google.gwt.aria.client;

public enum SelectedValue
  implements AriaAttributeType
{
  TRUE,  FALSE,  UNDEFINED;
  
  private SelectedValue() {}
  
  public static SelectedValue of(boolean value)
  {
    return value ? TRUE : FALSE;
  }
  
  public String getAriaValue()
  {
    switch (this)
    {
    case TRUE: 
      return "true";
    case FALSE: 
      return "false";
    case UNDEFINED: 
      return "undefined";
    }
    return null;
  }
}
