package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface ListitemRole
  extends SectionRole
{
  public abstract String getAriaLevelProperty(Element paramElement);
  
  public abstract String getAriaPosinsetProperty(Element paramElement);
  
  public abstract String getAriaSetsizeProperty(Element paramElement);
  
  public abstract void removeAriaLevelProperty(Element paramElement);
  
  public abstract void removeAriaPosinsetProperty(Element paramElement);
  
  public abstract void removeAriaSetsizeProperty(Element paramElement);
  
  public abstract void setAriaLevelProperty(Element paramElement, int paramInt);
  
  public abstract void setAriaPosinsetProperty(Element paramElement, int paramInt);
  
  public abstract void setAriaSetsizeProperty(Element paramElement, int paramInt);
}
