package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.html.BaseFrameElement;
import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomComment;
import com.gargoylesoftware.htmlunit.html.DomDocumentFragment;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.html.FrameWindow;
import com.gargoylesoftware.htmlunit.html.HtmlDivision;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.impl.SimpleRange;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.dom.DOMImplementation;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCollection;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import com.gargoylesoftware.htmlunit.xml.XmlUtil;
import java.io.IOException;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.NativeFunction;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.xml.utils.PrefixResolver;

@JsxClass
public class Document
  extends EventNode
{
  private static final Log LOG = LogFactory.getLog(Document.class);
  private static final Pattern TAG_NAME_PATTERN = Pattern.compile("\\w+");
  private Window window_;
  private DOMImplementation implementation_;
  private String designMode_;
  
  public void setWindow(Window window)
  {
    this.window_ = window;
  }
  
  @JsxGetter
  public Location getLocation()
  {
    return this.window_.getLocation();
  }
  
  @JsxSetter
  public void setLocation(String location)
    throws IOException
  {
    this.window_.setLocation(location);
  }
  
  @JsxGetter
  public String getReferrer()
  {
    String referrer = (String)getPage().getWebResponse().getWebRequest().getAdditionalHeaders().get("Referer");
    if (referrer == null) {
      return "";
    }
    return referrer;
  }
  
  @JsxGetter
  public Element getDocumentElement()
  {
    Object documentElement = getPage().getDocumentElement();
    if (documentElement == null) {
      return null;
    }
    return (Element)getScriptableFor(documentElement);
  }
  
  @JsxGetter
  public SimpleScriptable getDoctype()
  {
    Object documentType = getPage().getDoctype();
    if (documentType == null) {
      return null;
    }
    return getScriptableFor(documentType);
  }
  
  @JsxGetter
  public String getDesignMode()
  {
    if (this.designMode_ == null) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCUMENT_DESIGN_MODE_INHERIT))
      {
        if ((getWindow().getWebWindow() instanceof FrameWindow)) {
          this.designMode_ = "Inherit";
        } else {
          this.designMode_ = "Off";
        }
      }
      else {
        this.designMode_ = "off";
      }
    }
    return this.designMode_;
  }
  
  @JsxSetter
  public void setDesignMode(String mode)
  {
    boolean inherit = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCUMENT_DESIGN_MODE_INHERIT);
    if (inherit)
    {
      if ((!"on".equalsIgnoreCase(mode)) && (!"off".equalsIgnoreCase(mode)) && (!"inherit".equalsIgnoreCase(mode))) {
        throw Context.reportRuntimeError("Invalid document.designMode value '" + mode + "'.");
      }
      if (!(getWindow().getWebWindow() instanceof FrameWindow)) {
        return;
      }
      if ("on".equalsIgnoreCase(mode)) {
        this.designMode_ = "On";
      } else if ("off".equalsIgnoreCase(mode)) {
        this.designMode_ = "Off";
      } else if ("inherit".equalsIgnoreCase(mode)) {
        this.designMode_ = "Inherit";
      }
    }
    else if ("on".equalsIgnoreCase(mode))
    {
      this.designMode_ = "on";
      SgmlPage page = getPage();
      if ((page != null) && (page.isHtmlPage()))
      {
        HtmlPage htmlPage = (HtmlPage)page;
        DomNode child = htmlPage.getBody().getFirstChild();
        DomNode rangeNode = child == null ? htmlPage.getBody() : child;
        htmlPage.setSelectionRange(new SimpleRange(rangeNode, 0));
      }
    }
    else if ("off".equalsIgnoreCase(mode))
    {
      this.designMode_ = "off";
    }
  }
  
  protected SgmlPage getPage()
  {
    return (SgmlPage)getDomNodeOrDie();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getDefaultView()
  {
    return getWindow();
  }
  
  @JsxFunction
  public Object createDocumentFragment()
  {
    DomDocumentFragment fragment = getDomNodeOrDie().getPage().createDomDocumentFragment();
    DocumentFragment node = new DocumentFragment();
    node.setParentScope(getParentScope());
    node.setPrototype(getPrototype(node.getClass()));
    node.setDomNode(fragment);
    return getScriptableFor(fragment);
  }
  
  @JsxFunction
  public Attr createAttribute(String attributeName)
  {
    return (Attr)getPage().createAttribute(attributeName).getScriptObject();
  }
  
  public BoxObject getBoxObjectFor(HTMLElement element)
  {
    return element.getBoxObject();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object importNode(Node importedNode, boolean deep)
  {
    DomNode domNode = importedNode.getDomNodeOrDie();
    domNode = domNode.cloneNode(deep);
    domNode.processImportNode(this);
    for (DomNode childNode : domNode.getDescendants()) {
      childNode.processImportNode(this);
    }
    return domNode.getScriptObject();
  }
  
  @JsxGetter
  public DOMImplementation getImplementation()
  {
    if (this.implementation_ == null)
    {
      this.implementation_ = new DOMImplementation();
      this.implementation_.setParentScope(getWindow());
      this.implementation_.setPrototype(getPrototype(this.implementation_.getClass()));
    }
    return this.implementation_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void captureEvents(String type) {}
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public XPathNSResolver createNSResolver(Node nodeResolver)
  {
    XPathNSResolver resolver = new XPathNSResolver();
    resolver.setElement(nodeResolver);
    resolver.setParentScope(getWindow());
    resolver.setPrototype(getPrototype(resolver.getClass()));
    return resolver;
  }
  
  @JsxFunction
  public Object createTextNode(String newData)
  {
    Object result = NOT_FOUND;
    try
    {
      DomNode domNode = new DomText(getDomNodeOrDie().getPage(), newData);
      Object jsElement = getScriptableFor(domNode);
      if (jsElement == NOT_FOUND)
      {
        if (LOG.isDebugEnabled()) {
          LOG.debug("createTextNode(" + newData + ") cannot return a result as there isn't a JavaScript object for the DOM node " + domNode.getClass().getName());
        }
      }
      else {
        result = jsElement;
      }
    }
    catch (ElementNotFoundException e) {}
    return result;
  }
  
  @JsxFunction
  public Object createComment(String comment)
  {
    DomNode domNode = new DomComment(getDomNodeOrDie().getPage(), comment);
    return getScriptableFor(domNode);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public XPathResult evaluate(String expression, Node contextNode, Object resolver, int type, Object result)
  {
    XPathResult xPathResult = (XPathResult)result;
    if (xPathResult == null)
    {
      xPathResult = new XPathResult();
      xPathResult.setParentScope(getParentScope());
      xPathResult.setPrototype(getPrototype(xPathResult.getClass()));
    }
    PrefixResolver prefixResolver = null;
    if ((resolver instanceof NativeFunction)) {
      prefixResolver = new NativeFunctionPrefixResolver((NativeFunction)resolver, contextNode.getParentScope());
    } else if ((resolver instanceof PrefixResolver)) {
      prefixResolver = (PrefixResolver)resolver;
    }
    xPathResult.init(contextNode.getDomNodeOrDie().getByXPath(expression, prefixResolver), type);
    return xPathResult;
  }
  
  @JsxFunction
  public Object createElement(String tagName)
  {
    Object result = NOT_FOUND;
    try
    {
      BrowserVersion browserVersion = getBrowserVersion();
      if ((browserVersion.hasFeature(BrowserVersionFeatures.JS_DOCUMENT_CREATE_ELEMENT_STRICT)) && ((tagName.contains("<")) || (tagName.contains(">"))))
      {
        LOG.info("createElement: Provided string '" + tagName + "' contains an invalid character; '<' and '>' are not allowed");
        
        throw Context.reportRuntimeError("String contains an invalid character");
      }
      if ((!browserVersion.hasFeature(BrowserVersionFeatures.JS_DOCUMENT_CREATE_ELEMENT_EXTENDED_SYNTAX)) && (tagName.startsWith("<")) && (tagName.endsWith(">")))
      {
        tagName = tagName.substring(1, tagName.length() - 1);
        
        Matcher matcher = TAG_NAME_PATTERN.matcher(tagName);
        if (!matcher.matches())
        {
          LOG.info("createElement: Provided string '" + tagName + "' contains an invalid character");
          throw Context.reportRuntimeError("String contains an invalid character");
        }
      }
      SgmlPage page = getPage();
      org.w3c.dom.Element element = page.createElement(tagName);
      if ((element instanceof BaseFrameElement)) {
        ((BaseFrameElement)element).markAsCreatedByJavascript();
      }
      if ((element instanceof HtmlInput)) {
        ((HtmlInput)element).markAsCreatedByJavascript();
      }
      Object jsElement = getScriptableFor(element);
      if (jsElement == NOT_FOUND)
      {
        if (LOG.isDebugEnabled()) {
          LOG.debug("createElement(" + tagName + ") cannot return a result as there isn't a JavaScript object for the element " + element.getClass().getName());
        }
      }
      else {
        result = jsElement;
      }
    }
    catch (ElementNotFoundException e) {}
    return result;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Object createElementNS(String namespaceURI, String qualifiedName)
  {
    BrowserVersion browserVersion = getBrowserVersion();
    org.w3c.dom.Element element;
    org.w3c.dom.Element element;
    if ("http://www.mozilla.org/keymaster/gatekeeper/there.is.only.xul".equals(namespaceURI))
    {
      if (!browserVersion.hasFeature(BrowserVersionFeatures.XUL_SUPPORT)) {
        throw Context.reportRuntimeError("XUL not available");
      }
      element = new HtmlDivision(namespaceURI, qualifiedName, getPage(), null);
    }
    else
    {
      org.w3c.dom.Element element;
      if (("http://www.w3.org/1999/xhtml".equals(namespaceURI)) || ("http://www.w3.org/2000/svg".equals(namespaceURI))) {
        element = getPage().createElementNS(namespaceURI, qualifiedName);
      } else {
        element = new DomElement(namespaceURI, qualifiedName, getPage(), null);
      }
    }
    return getScriptableFor(element);
  }
  
  @JsxFunction
  public HTMLCollection getElementsByTagName(final String tagName)
  {
    String description = "Document.getElementsByTagName('" + tagName + "')";
    HTMLCollection collection;
    HTMLCollection collection;
    if ("*".equals(tagName))
    {
      collection = new HTMLCollection(getDomNodeOrDie(), false, description)
      {
        protected boolean isMatching(DomNode node)
        {
          return true;
        }
      };
    }
    else
    {
      final boolean useLocalName = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_32);
      
      collection = new HTMLCollection(getDomNodeOrDie(), false, description)
      {
        protected boolean isMatching(DomNode node)
        {
          if (useLocalName) {
            return tagName.equalsIgnoreCase(node.getLocalName());
          }
          return tagName.equalsIgnoreCase(node.getNodeName());
        }
      };
    }
    return collection;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getElementsByTagNameNS(Object namespaceURI, final String localName)
  {
    String description = "Document.getElementsByTagNameNS('" + namespaceURI + "', '" + localName + "')";
    String prefix;
    final String prefix;
    if ((namespaceURI != null) && (!"*".equals(namespaceURI))) {
      prefix = XmlUtil.lookupPrefix(getPage().getDocumentElement(), Context.toString(namespaceURI));
    } else {
      prefix = null;
    }
    HTMLCollection collection = new HTMLCollection(getDomNodeOrDie(), false, description)
    {
      protected boolean isMatching(DomNode node)
      {
        if (!localName.equals(node.getLocalName())) {
          return false;
        }
        if (prefix == null) {
          return true;
        }
        return true;
      }
    };
    return collection;
  }
}
