package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.FrameSetBuilder;
import com.google.gwt.dom.client.FrameSetElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomFrameSetBuilder
  extends DomElementBuilderBase<FrameSetBuilder, FrameSetElement>
  implements FrameSetBuilder
{
  DomFrameSetBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public FrameSetBuilder cols(String cols)
  {
    ((FrameSetElement)assertCanAddAttribute()).setCols(cols);
    return this;
  }
  
  public FrameSetBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException();
  }
  
  public FrameSetBuilder rows(String rows)
  {
    ((FrameSetElement)assertCanAddAttribute()).setRows(rows);
    return this;
  }
  
  public FrameSetBuilder text(String text)
  {
    throw new UnsupportedOperationException();
  }
}
