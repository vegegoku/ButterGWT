package com.google.gwt.core.server;

import com.google.gwt.thirdparty.debugging.sourcemap.SourceMapConsumerFactory;
import com.google.gwt.thirdparty.debugging.sourcemap.SourceMapping;
import com.google.gwt.thirdparty.debugging.sourcemap.proto.Mapping.OriginalMapping;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public abstract class StackTraceDeobfuscator
{
  public static StackTraceDeobfuscator fromResource(String symbolMapsPath)
  {
    String basePath = symbolMapsPath + "/";
    final ClassLoader classLoader = StackTraceDeobfuscator.class.getClassLoader();
    new StackTraceDeobfuscator()
    {
      protected InputStream openInputStream(String fileName)
        throws IOException
      {
        String filePath = this.val$basePath + fileName;
        InputStream inputStream = classLoader.getResourceAsStream(filePath);
        if (inputStream == null) {
          throw new IOException("Missing resource: " + filePath);
        }
        return inputStream;
      }
    };
  }
  
  public static StackTraceDeobfuscator fromFileSystem(String symbolMapsDirectory)
  {
    new StackTraceDeobfuscator()
    {
      protected InputStream openInputStream(String fileName)
        throws IOException
      {
        return new FileInputStream(new File(this.val$symbolMapsDirectory, fileName));
      }
    };
  }
  
  public static StackTraceDeobfuscator fromUrl(URL urlPath)
  {
    new StackTraceDeobfuscator()
    {
      protected InputStream openInputStream(String fileName)
        throws IOException
      {
        return new URL(this.val$urlPath, fileName).openStream();
      }
    };
  }
  
  private static class SymbolCache
  {
    private final ConcurrentHashMap<String, HashMap<String, String>> symbolMaps;
    
    SymbolCache()
    {
      this.symbolMaps = new ConcurrentHashMap();
    }
    
    void putAll(String strongName, Map<String, String> symbolMap)
    {
      if ((strongName == null) || (symbolMap.size() == 0)) {
        return;
      }
      this.symbolMaps.putIfAbsent(strongName, new HashMap());
      HashMap<String, String> existingMap = (HashMap)this.symbolMaps.get(strongName);
      synchronized (existingMap)
      {
        existingMap.putAll(symbolMap);
      }
    }
    
    Map<String, String> getAll(String strongName, Set<String> symbols)
    {
      Map<String, String> toReturn = new HashMap();
      if ((strongName == null) || (!this.symbolMaps.containsKey(strongName)) || (symbols.isEmpty())) {
        return toReturn;
      }
      HashMap<String, String> existingMap = (HashMap)this.symbolMaps.get(strongName);
      synchronized (existingMap)
      {
        for (String symbol : symbols) {
          if (existingMap.containsKey(symbol)) {
            toReturn.put(symbol, existingMap.get(symbol));
          }
        }
      }
      return toReturn;
    }
  }
  
  private static final Pattern JsniRefPattern = Pattern.compile("@?([^:]+)::([^(]+)(\\((.*)\\))?");
  private static final Pattern fragmentIdPattern = Pattern.compile(".*(\\d+)\\.js");
  private static final int LINE_NUMBER_UNKNOWN = -1;
  private static final String SYMBOL_DATA_UNKNOWN = "";
  private final Map<String, SourceMapping> sourceMaps = new HashMap();
  private final SymbolCache symbolCache = new SymbolCache();
  private boolean lazyLoad = false;
  
  public void setLazyLoad(boolean lazyLoad)
  {
    this.lazyLoad = lazyLoad;
  }
  
  public final void deobfuscateStackTrace(Throwable throwable, String strongName)
  {
    throwable.setStackTrace(resymbolize(throwable.getStackTrace(), strongName));
    if (throwable.getCause() != null) {
      deobfuscateStackTrace(throwable.getCause(), strongName);
    }
  }
  
  public final StackTraceElement[] resymbolize(StackTraceElement[] st, String strongName)
  {
    if (st == null) {
      return null;
    }
    Set<String> requiredSymbols = new HashSet();
    for (StackTraceElement ste : st) {
      requiredSymbols.add(ste.getMethodName());
    }
    loadSymbolMap(strongName, requiredSymbols);
    
    StackTraceElement[] newSt = new StackTraceElement[st.length];
    for (int i = 0; i < st.length; i++) {
      newSt[i] = resymbolize(st[i], strongName);
    }
    return newSt;
  }
  
  public final StackTraceElement resymbolize(StackTraceElement ste, String strongName)
  {
    String declaringClass = null;
    String methodName = null;
    String filename = null;
    int lineNumber = -1;
    int fragmentId = -1;
    
    String steFilename = ste.getFileName();
    String symbolData = loadOneSymbol(strongName, ste.getMethodName());
    
    boolean sourceMapCapable = false;
    
    int column = 1;
    if (steFilename != null)
    {
      int columnMarkerIndex = steFilename.indexOf("@");
      if (columnMarkerIndex != -1)
      {
        try
        {
          column = Integer.parseInt(steFilename.substring(columnMarkerIndex + 1));
          sourceMapCapable = true;
        }
        catch (NumberFormatException nfe) {}
        steFilename = steFilename.substring(0, columnMarkerIndex);
      }
    }
    if (!symbolData.isEmpty())
    {
      String[] parts = symbolData.split(",");
      if (parts.length == 6)
      {
        String[] ref = parse(parts[0].substring(0, parts[0].lastIndexOf(')') + 1));
        if (ref != null)
        {
          declaringClass = ref[0];
          methodName = ref[1];
        }
        else
        {
          declaringClass = ste.getClassName();
          methodName = ste.getMethodName();
        }
        filename = "Unknown".equals(parts[3]) ? null : parts[3].substring(parts[3].lastIndexOf('/') + 1);
        
        lineNumber = ste.getLineNumber();
        if ((lineNumber == -1) || ((sourceMapCapable) && (column == -1))) {
          lineNumber = Integer.parseInt(parts[4]);
        }
        fragmentId = Integer.parseInt(parts[5]);
      }
    }
    if ((fragmentId == -1) && (steFilename != null))
    {
      Matcher matcher = fragmentIdPattern.matcher(steFilename);
      if (matcher.matches())
      {
        String fragment = matcher.group(1);
        try
        {
          fragmentId = Integer.parseInt(fragment);
        }
        catch (Exception e) {}
      }
      else if (steFilename.contains(strongName))
      {
        fragmentId = 0;
      }
    }
    int jsLineNumber = ste.getLineNumber();
    if ((sourceMapCapable) && (fragmentId != -1) && (column != -1))
    {
      SourceMapping sourceMapping = loadSourceMap(strongName, fragmentId);
      if ((sourceMapping != null) && (ste.getLineNumber() > -1))
      {
        Mapping.OriginalMapping mappingForLine = sourceMapping.getMappingForLine(jsLineNumber, column);
        if (mappingForLine != null)
        {
          if ((declaringClass == null) || (declaringClass.equals(ste.getClassName())))
          {
            declaringClass = mappingForLine.getOriginalFile();
            methodName = mappingForLine.getIdentifier();
          }
          filename = mappingForLine.getOriginalFile();
          lineNumber = mappingForLine.getLineNumber();
        }
      }
    }
    if (declaringClass != null) {
      return new StackTraceElement(declaringClass, methodName, filename, lineNumber);
    }
    return ste;
  }
  
  protected InputStream getSourceMapInputStream(String permutationStrongName, int fragmentNumber)
    throws IOException
  {
    return openInputStream(permutationStrongName + "_sourceMap" + fragmentNumber + ".json");
  }
  
  protected InputStream getSymbolMapInputStream(String permutationStrongName)
    throws IOException
  {
    return openInputStream(permutationStrongName + ".symbolMap");
  }
  
  protected abstract InputStream openInputStream(String paramString)
    throws IOException;
  
  private SourceMapping loadSourceMap(String permutationStrongName, int fragmentId)
  {
    SourceMapping toReturn = (SourceMapping)this.sourceMaps.get(permutationStrongName + fragmentId);
    if (toReturn == null) {
      try
      {
        String sourceMapString = loadStreamAsString(getSourceMapInputStream(permutationStrongName, fragmentId));
        
        toReturn = SourceMapConsumerFactory.parse(sourceMapString);
        this.sourceMaps.put(permutationStrongName + fragmentId, toReturn);
      }
      catch (Exception e) {}
    }
    return toReturn;
  }
  
  private String loadStreamAsString(InputStream stream)
  {
    return new Scanner(stream).useDelimiter("\\A").next();
  }
  
  private String loadOneSymbol(String strongName, String symbol)
  {
    Set<String> symbolSet = new HashSet();
    symbolSet.add(symbol);
    Map<String, String> symbolMap = loadSymbolMap(strongName, symbolSet);
    return (String)symbolMap.get(symbol);
  }
  
  private Map<String, String> loadSymbolMap(String strongName, Set<String> requiredSymbols)
  {
    Map<String, String> toReturn = this.symbolCache.getAll(strongName, requiredSymbols);
    if (toReturn.size() == requiredSymbols.size()) {
      return toReturn;
    }
    Set<String> symbolsLeftToFind = new HashSet(requiredSymbols);
    toReturn = new HashMap();
    try
    {
      BufferedReader bin = new BufferedReader(new InputStreamReader(getSymbolMapInputStream(strongName)));
      try
      {
        String line;
        while (((line = bin.readLine()) != null) && ((symbolsLeftToFind.size() > 0) || (!this.lazyLoad))) {
          if (line.charAt(0) != '#')
          {
            int idx = line.indexOf(',');
            String symbol = line.substring(0, idx);
            String symbolData = line.substring(idx + 1);
            if ((requiredSymbols.contains(symbol)) || (!this.lazyLoad))
            {
              symbolsLeftToFind.remove(symbol);
              toReturn.put(symbol, symbolData);
            }
          }
        }
      }
      finally
      {
        bin.close();
      }
    }
    catch (IOException e) {}
    for (String symbol : symbolsLeftToFind) {
      toReturn.put(symbol, "");
    }
    this.symbolCache.putAll(strongName, toReturn);
    return toReturn;
  }
  
  private String[] parse(String refString)
  {
    Matcher matcher = JsniRefPattern.matcher(refString);
    if (!matcher.matches()) {
      return null;
    }
    String className = matcher.group(1);
    String memberName = matcher.group(2);
    String[] toReturn = { className, memberName };
    return toReturn;
  }
}
