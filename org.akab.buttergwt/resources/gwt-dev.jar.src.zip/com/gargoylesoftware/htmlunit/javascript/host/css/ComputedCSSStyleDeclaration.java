package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.BaseFrameElement;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlButton;
import com.gargoylesoftware.htmlunit.html.HtmlButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlCheckBoxInput;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlHiddenInput;
import com.gargoylesoftware.htmlunit.html.HtmlInlineFrame;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlPasswordInput;
import com.gargoylesoftware.htmlunit.html.HtmlRadioButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlResetInput;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.html.HtmlSubmitInput;
import com.gargoylesoftware.htmlunit.html.HtmlTableRow;
import com.gargoylesoftware.htmlunit.html.HtmlTextArea;
import com.gargoylesoftware.htmlunit.html.HtmlTextInput;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.gargoylesoftware.htmlunit.javascript.host.Text;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLBodyElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCanvasElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.lang3.StringUtils;
import org.w3c.css.sac.Selector;

@JsxClass
public class ComputedCSSStyleDeclaration
  extends CSSStyleDeclaration
{
  private static final int PIXELS_PER_CHAR = 10;
  private static final Set<String> INHERITABLE_ATTRIBUTES = new HashSet(Arrays.asList(new String[] { "azimuth", "border-collapse", "border-spacing", "caption-side", "color", "cursor", "direction", "elevation", "empty-cells", "font-family", "font-size", "font-style", "font-variant", "font-weight", "font", "letter-spacing", "line-height", "list-style-image", "list-style-position", "list-style-type", "list-style", "orphans", "pitch-range", "pitch", "quotes", "richness", "speak-header", "speak-numeral", "speak-punctuation", "speak", "speech-rate", "stress", "text-align", "text-indent", "text-transform", "visibility", "voice-fFamily", "volume", "white-space", "widows", "word-spacing" }));
  private final SortedMap<String, CSSStyleDeclaration.StyleElement> localModifications_ = new TreeMap();
  private Integer width_;
  private Integer height_;
  private Integer height2_;
  private Integer paddingHorizontal_;
  private Integer paddingVertical_;
  private Integer borderHorizontal_;
  private Integer borderVertical_;
  private Integer top_;
  
  public ComputedCSSStyleDeclaration() {}
  
  public ComputedCSSStyleDeclaration(CSSStyleDeclaration style)
  {
    super(style.getElement());
    getElement().setDefaults(this);
  }
  
  protected String getStyleAttribute(String name)
  {
    String s = super.getStyleAttribute(name);
    if ((s.isEmpty()) && (isInheritable(name)))
    {
      Element parent = getElement().getParentElement();
      if (parent != null) {
        s = getWindow().getComputedStyle(parent, null).getStyleAttribute(name);
      }
    }
    return s;
  }
  
  private boolean isInheritable(String name)
  {
    return INHERITABLE_ATTRIBUTES.contains(name);
  }
  
  protected void setStyleAttribute(String name, String newValue) {}
  
  public void applyStyleFromSelector(org.w3c.dom.css.CSSStyleDeclaration declaration, Selector selector)
  {
    SelectorSpecificity specificity = new SelectorSpecificity(selector);
    for (int k = 0; k < declaration.getLength(); k++)
    {
      String name = declaration.item(k);
      String value = declaration.getPropertyValue(name);
      String priority = declaration.getPropertyPriority(name);
      applyLocalStyleAttribute(name, value, priority, specificity);
    }
  }
  
  private void applyLocalStyleAttribute(String name, String newValue, String priority, SelectorSpecificity specificity)
  {
    if (!"important".equals(priority))
    {
      CSSStyleDeclaration.StyleElement existingElement = (CSSStyleDeclaration.StyleElement)this.localModifications_.get(name);
      if (existingElement != null)
      {
        if ("important".equals(existingElement.getPriority())) {
          return;
        }
        if (specificity.compareTo(existingElement.getSpecificity()) < 0) {
          return;
        }
      }
    }
    CSSStyleDeclaration.StyleElement element = new CSSStyleDeclaration.StyleElement(name, newValue, priority, specificity, getCurrentElementIndex());
    this.localModifications_.put(name, element);
  }
  
  public void setDefaultLocalStyleAttribute(String name, String newValue)
  {
    CSSStyleDeclaration.StyleElement element = new CSSStyleDeclaration.StyleElement(name, newValue);
    this.localModifications_.put(name, element);
  }
  
  protected CSSStyleDeclaration.StyleElement getStyleElement(String name)
  {
    CSSStyleDeclaration.StyleElement existent = super.getStyleElement(name);
    if (this.localModifications_ != null)
    {
      CSSStyleDeclaration.StyleElement localStyleMod = (CSSStyleDeclaration.StyleElement)this.localModifications_.get(name);
      if (localStyleMod == null) {
        return existent;
      }
      if (existent == null) {
        return localStyleMod;
      }
      if ("important".equals(localStyleMod.getPriority())) {
        if ("important".equals(existent.getPriority()))
        {
          if (existent.getSpecificity().compareTo(localStyleMod.getSpecificity()) < 0) {
            return localStyleMod;
          }
        }
        else {
          return localStyleMod;
        }
      }
    }
    return existent;
  }
  
  public String getBackgroundAttachment()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBackgroundAttachment(), "scroll");
  }
  
  public String getBackgroundColor()
  {
    String value = super.getBackgroundColor();
    if (StringUtils.isEmpty(value)) {
      value = "transparent";
    } else if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_GET_BACKGROUND_COLOR_FOR_COMPUTED_STYLE_AS_RGB)) {
      value = toRGBColor(value);
    }
    return value;
  }
  
  public String getBackgroundImage()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBackgroundImage(), "none");
  }
  
  public String getBackgroundPosition()
  {
    String bg = super.getBackgroundPosition();
    if (StringUtils.isNotBlank(bg))
    {
      bg = StringUtils.replace(bg, "left", "0%");
      bg = StringUtils.replace(bg, "right", "100%");
      bg = StringUtils.replace(bg, "center", "50%");
      
      bg = StringUtils.replace(bg, "top", "0%");
      bg = StringUtils.replace(bg, "bottom", "100%");
    }
    return (String)StringUtils.defaultIfEmpty(bg, "0% 0%");
  }
  
  public String getBackgroundRepeat()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBackgroundRepeat(), "repeat");
  }
  
  public String getBorderBottomColor()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderBottomColor(), "rgb(0, 0, 0)");
  }
  
  public String getBorderBottomStyle()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderBottomStyle(), "none");
  }
  
  public String getBorderBottomWidth()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getBorderBottomWidth(), "0px"));
  }
  
  public String getBorderCollapse()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderCollapse(), "separate");
  }
  
  public String getBorderLeftColor()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderLeftColor(), "rgb(0, 0, 0)");
  }
  
  public String getBorderLeftStyle()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderLeftStyle(), "none");
  }
  
  public String getBorderLeftWidth()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getBorderLeftWidth(), "0px"));
  }
  
  public String getBorderRightColor()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderRightColor(), "rgb(0, 0, 0)");
  }
  
  public String getBorderRightStyle()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderRightStyle(), "none");
  }
  
  public String getBorderRightWidth()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getBorderRightWidth(), "0px"));
  }
  
  public String getBorderSpacing()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderSpacing(), "0px 0px");
  }
  
  public String getBorderTopColor()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderTopColor(), "rgb(0, 0, 0)");
  }
  
  public String getBorderTopStyle()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBorderTopStyle(), "none");
  }
  
  public String getBorderTopWidth()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getBorderTopWidth(), "0px"));
  }
  
  public String getBottom()
  {
    return (String)StringUtils.defaultIfEmpty(super.getBottom(), "auto");
  }
  
  public String getCaptionSide()
  {
    return (String)StringUtils.defaultIfEmpty(super.getCaptionSide(), "top");
  }
  
  public String getClear()
  {
    return (String)StringUtils.defaultIfEmpty(super.getClear(), "none");
  }
  
  public String getClip()
  {
    return (String)StringUtils.defaultIfEmpty(super.getClip(), "auto");
  }
  
  public String getContent()
  {
    return (String)StringUtils.defaultIfEmpty(super.getContent(), "none");
  }
  
  public String getColor()
  {
    String value = (String)StringUtils.defaultIfEmpty(super.getColor(), "rgb(0, 0, 0)");
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_GET_BACKGROUND_COLOR_FOR_COMPUTED_STYLE_AS_RGB)) {
      value = toRGBColor(value);
    }
    return value;
  }
  
  public String getCounterIncrement()
  {
    return (String)StringUtils.defaultIfEmpty(super.getCounterIncrement(), "none");
  }
  
  public String getCounterReset()
  {
    return (String)StringUtils.defaultIfEmpty(super.getCounterReset(), "none");
  }
  
  public String getCssFloat()
  {
    return (String)StringUtils.defaultIfEmpty(super.getCssFloat(), "none");
  }
  
  public String getCursor()
  {
    return (String)StringUtils.defaultIfEmpty(super.getCursor(), "auto");
  }
  
  public String getDirection()
  {
    return (String)StringUtils.defaultIfEmpty(super.getDirection(), "ltr");
  }
  
  public String getDisplay()
  {
    return (String)StringUtils.defaultIfEmpty(super.getDisplay(), getElement().getDefaultStyleDisplay());
  }
  
  public String getEmptyCells()
  {
    return (String)StringUtils.defaultIfEmpty(super.getEmptyCells(), "-moz-show-background");
  }
  
  public String getFontFamily()
  {
    return (String)StringUtils.defaultIfEmpty(super.getFontFamily(), "serif");
  }
  
  public String getFontSize()
  {
    String value = super.getFontSize();
    if (value.isEmpty())
    {
      Element parent = getElement().getParentElement();
      if (parent != null) {
        value = parent.getCurrentStyle().getFontSize();
      }
    }
    if (value.isEmpty()) {
      value = "16px";
    }
    return value;
  }
  
  public String getFontSizeAdjust()
  {
    return (String)StringUtils.defaultIfEmpty(super.getFontSizeAdjust(), "none");
  }
  
  public String getFontStretch()
  {
    String defaultStretch = "";
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_FONT_STRECH_DEFAULT_NORMAL)) {
      defaultStretch = "normal";
    }
    return (String)StringUtils.defaultIfEmpty(super.getFontStretch(), defaultStretch);
  }
  
  public String getFontStyle()
  {
    return (String)StringUtils.defaultIfEmpty(super.getFontStyle(), "normal");
  }
  
  public String getFontVariant()
  {
    return (String)StringUtils.defaultIfEmpty(super.getFontVariant(), "normal");
  }
  
  public String getFontWeight()
  {
    return (String)StringUtils.defaultIfEmpty(super.getFontWeight(), "400");
  }
  
  public String getHeight()
  {
    pixelString(getElement(), new CSSStyleDeclaration.CssValue(getElement().getWindow().getWebWindow().getInnerHeight())
    {
      public String get(ComputedCSSStyleDeclaration style)
      {
        return (String)StringUtils.defaultIfEmpty(style.getStyleAttribute("height"), "362px");
      }
    });
  }
  
  public String getImeMode()
  {
    return (String)StringUtils.defaultIfEmpty(super.getImeMode(), "auto");
  }
  
  public String getLeft()
  {
    return (String)StringUtils.defaultIfEmpty(super.getLeft(), "auto");
  }
  
  public String getLetterSpacing()
  {
    return (String)StringUtils.defaultIfEmpty(super.getLetterSpacing(), "normal");
  }
  
  public String getListStyleImage()
  {
    return (String)StringUtils.defaultIfEmpty(super.getListStyleImage(), "none");
  }
  
  public String getListStylePosition()
  {
    return (String)StringUtils.defaultIfEmpty(super.getListStylePosition(), "outside");
  }
  
  public String getListStyleType()
  {
    return (String)StringUtils.defaultIfEmpty(super.getListStyleType(), "disc");
  }
  
  public String getMarginBottom()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getMarginBottom(), "0px"));
  }
  
  public String getMarginLeft()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getMarginLeft(), "0px"));
  }
  
  public String getMarginRight()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getMarginRight(), "0px"));
  }
  
  public String getMarginTop()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getMarginTop(), "0px"));
  }
  
  public String getMarkerOffset()
  {
    return (String)StringUtils.defaultIfEmpty(super.getMarkerOffset(), "auto");
  }
  
  public String getMaxHeight()
  {
    return (String)StringUtils.defaultIfEmpty(super.getMaxHeight(), "none");
  }
  
  public String getMaxWidth()
  {
    return (String)StringUtils.defaultIfEmpty(super.getMaxWidth(), "none");
  }
  
  public String getMinHeight()
  {
    return (String)StringUtils.defaultIfEmpty(super.getMinHeight(), "0px");
  }
  
  public String getMinWidth()
  {
    return (String)StringUtils.defaultIfEmpty(super.getMinWidth(), "0px");
  }
  
  protected String getStyleAttributeValue(StyleAttributes.Definition style)
  {
    return (String)StringUtils.defaultIfEmpty(super.getStyleAttributeValue(style), style.getDefaultComputedValue(getBrowserVersion()));
  }
  
  public String getOpacity()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOpacity(), "1");
  }
  
  public String getOutlineColor()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOutlineColor(), "rgb(0, 0, 0)");
  }
  
  public String getOutlineOffset()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOutlineOffset(), "0px");
  }
  
  public String getOutlineStyle()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOutlineStyle(), "none");
  }
  
  public String getOutlineWidth()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOutlineWidth(), "0px");
  }
  
  public String getOverflow()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOverflow(), "visible");
  }
  
  public String getOverflowX()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOverflowX(), "visible");
  }
  
  public String getOverflowY()
  {
    return (String)StringUtils.defaultIfEmpty(super.getOverflowY(), "visible");
  }
  
  public String getPageBreakAfter()
  {
    return (String)StringUtils.defaultIfEmpty(super.getPageBreakAfter(), "auto");
  }
  
  public String getPageBreakBefore()
  {
    return (String)StringUtils.defaultIfEmpty(super.getPageBreakBefore(), "auto");
  }
  
  public String getPaddingBottom()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getPaddingBottom(), "0px"));
  }
  
  public String getPaddingLeft()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getPaddingLeft(), "0px"));
  }
  
  public String getPaddingRight()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getPaddingRight(), "0px"));
  }
  
  public String getPaddingTop()
  {
    return pixelString((String)StringUtils.defaultIfEmpty(super.getPaddingTop(), "0px"));
  }
  
  public String getPointerEvents()
  {
    return (String)StringUtils.defaultIfEmpty(super.getPointerEvents(), "auto");
  }
  
  public String getPosition()
  {
    return (String)StringUtils.defaultIfEmpty(super.getPosition(), "static");
  }
  
  public String getRight()
  {
    return (String)StringUtils.defaultIfEmpty(super.getRight(), "auto");
  }
  
  public String getTableLayout()
  {
    return (String)StringUtils.defaultIfEmpty(super.getTableLayout(), "auto");
  }
  
  public String getTextAlign()
  {
    return (String)StringUtils.defaultIfEmpty(super.getTextAlign(), "start");
  }
  
  public String getTextDecoration()
  {
    return (String)StringUtils.defaultIfEmpty(super.getTextDecoration(), "none");
  }
  
  public String getTextIndent()
  {
    return (String)StringUtils.defaultIfEmpty(super.getTextIndent(), "0px");
  }
  
  public String getTextShadow()
  {
    String shadow = "";
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_TEXT_SHADOW_DEFAULT_NONE)) {
      shadow = "none";
    }
    return (String)StringUtils.defaultIfEmpty(super.getTextShadow(), shadow);
  }
  
  public String getTextTransform()
  {
    return (String)StringUtils.defaultIfEmpty(super.getTextTransform(), "none");
  }
  
  public String getTop()
  {
    return (String)StringUtils.defaultIfEmpty(super.getTop(), "auto");
  }
  
  public String getVerticalAlign()
  {
    return (String)StringUtils.defaultIfEmpty(super.getVerticalAlign(), "baseline");
  }
  
  public String getVisibility()
  {
    return (String)StringUtils.defaultIfEmpty(super.getVisibility(), "visible");
  }
  
  public String getWhiteSpace()
  {
    return (String)StringUtils.defaultIfEmpty(super.getWhiteSpace(), "normal");
  }
  
  public String getWidth()
  {
    if ("none".equals(getDisplay())) {
      return "auto";
    }
    int windowWidth = getElement().getWindow().getWebWindow().getInnerWidth();
    String defaultWidth;
    final String defaultWidth;
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DEFAULT_WIDTH_AUTO)) {
      defaultWidth = "auto";
    } else {
      defaultWidth = windowWidth + "px";
    }
    pixelString(getElement(), new CSSStyleDeclaration.CssValue(windowWidth)
    {
      public String get(ComputedCSSStyleDeclaration style)
      {
        String value = style.getStyleAttribute("width");
        if (StringUtils.isEmpty(value))
        {
          if ((!ComputedCSSStyleDeclaration.this.getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DEFAULT_WIDTH_AUTO)) && ("absolute".equals(ComputedCSSStyleDeclaration.this.getStyleAttribute("position"))))
          {
            DomNode domNode = ComputedCSSStyleDeclaration.this.getDomNodeOrDie();
            String content = domNode.getTextContent();
            if ((null != content) && (content.length() < 13)) {
              return content.length() * 7 + "px";
            }
          }
          return defaultWidth;
        }
        return value;
      }
    });
  }
  
  public int getCalculatedWidth(boolean includeBorder, boolean includePadding)
  {
    int width = getCalculatedWidth();
    if (includeBorder) {
      width += getBorderHorizontal();
    }
    if (includePadding) {
      width += getPaddingHorizontal();
    }
    return width;
  }
  
  private int getCalculatedWidth()
  {
    if (this.width_ != null) {
      return this.width_.intValue();
    }
    DomNode node = getElement().getDomNodeOrDie();
    if (!node.mayBeDisplayed())
    {
      this.width_ = Integer.valueOf(0);
      return 0;
    }
    String display = getDisplay();
    if ("none".equals(display))
    {
      this.width_ = Integer.valueOf(0);
      return 0;
    }
    int windowWidth = getElement().getWindow().getWebWindow().getInnerWidth();
    
    String styleWidth = super.getWidth();
    DomNode parent = node.getParentNode();
    int width;
    int width;
    if ((StringUtils.isEmpty(styleWidth)) && ((parent instanceof HtmlElement)))
    {
      if ((getElement() instanceof HTMLCanvasElement)) {
        return 300;
      }
      String cssFloat = getCssFloat();
      int width;
      if (("right".equals(cssFloat)) || ("left".equals(cssFloat)))
      {
        width = node.getTextContent().length() * 10;
      }
      else if ("block".equals(display))
      {
        HTMLElement parentJS = (HTMLElement)parent.getScriptObject();
        String parentWidth = getWindow().getComputedStyle(parentJS, null).getWidth();
        int width;
        int width;
        if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DEFAULT_WIDTH_AUTO)) && ("auto".equals(parentWidth))) {
          width = windowWidth;
        } else {
          width = pixelValue(parentJS, new CSSStyleDeclaration.CssValue(windowWidth)
          {
            public String get(ComputedCSSStyleDeclaration style)
            {
              return style.getWidth();
            }
          });
        }
        width -= getBorderHorizontal() + getPaddingHorizontal();
      }
      else
      {
        int width;
        if (((node instanceof HtmlSubmitInput)) || ((node instanceof HtmlResetInput)) || ((node instanceof HtmlButtonInput)) || ((node instanceof HtmlButton)))
        {
          String text = node.asText();
          width = 10 + text.length() * 10;
        }
        else
        {
          int width;
          if (((node instanceof HtmlTextInput)) || ((node instanceof HtmlPasswordInput)))
          {
            width = 50;
          }
          else
          {
            int width;
            if (((node instanceof HtmlRadioButtonInput)) || ((node instanceof HtmlCheckBoxInput)))
            {
              width = 20;
            }
            else
            {
              int width;
              if (((node instanceof HtmlTextInput)) || ((node instanceof HtmlPasswordInput)))
              {
                width = 50;
              }
              else
              {
                int width;
                if ((node instanceof HtmlTextArea)) {
                  width = 100;
                } else {
                  width = getContentWidth();
                }
              }
            }
          }
        }
      }
    }
    else
    {
      width = pixelValue(getElement(), new CSSStyleDeclaration.CssValue(windowWidth)
      {
        public String get(ComputedCSSStyleDeclaration style)
        {
          return style.getStyleAttribute("width");
        }
      });
    }
    this.width_ = Integer.valueOf(width);
    return width;
  }
  
  public int getContentWidth()
  {
    int width = 0;
    DomNode domNode = getDomNodeOrDie();
    Iterable<DomNode> childs = domNode.getChildren();
    if ((domNode instanceof BaseFrameElement))
    {
      Page enclosedPage = ((BaseFrameElement)domNode).getEnclosedPage();
      if ((enclosedPage != null) && (enclosedPage.isHtmlPage()))
      {
        HtmlPage htmlPage = (HtmlPage)enclosedPage;
        childs = htmlPage.getChildren();
      }
    }
    for (DomNode child : childs) {
      if ((child.getScriptObject() instanceof HTMLElement))
      {
        HTMLElement e = (HTMLElement)child.getScriptObject();
        int w = e.getCurrentStyle().getCalculatedWidth(true, true);
        width += w;
      }
      else if ((child.getScriptObject() instanceof Text))
      {
        width += child.getTextContent().length() * 10;
      }
    }
    return width;
  }
  
  public int getCalculatedHeight(boolean includeBorder, boolean includePadding)
  {
    int height = getCalculatedHeight();
    if (includeBorder) {
      height += getBorderVertical();
    }
    if (includePadding) {
      height += getPaddingVertical();
    }
    return height;
  }
  
  private int getCalculatedHeight()
  {
    if (this.height_ != null) {
      return this.height_.intValue();
    }
    int elementHeight = getEmptyHeight();
    if (elementHeight == 0)
    {
      this.height_ = Integer.valueOf(elementHeight);
      return elementHeight;
    }
    int contentHeight = getContentHeight();
    boolean useDefaultHeight = getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DEFAULT_ELEMENT_HEIGHT_MARKS_MIN);
    boolean explicitHeightSpecified = super.getHeight().length() > 0;
    int height;
    int height;
    if ((contentHeight > 0) && (((useDefaultHeight) && (contentHeight > elementHeight)) || ((!useDefaultHeight) && (!explicitHeightSpecified)))) {
      height = contentHeight;
    } else {
      height = elementHeight;
    }
    this.height_ = Integer.valueOf(height);
    return height;
  }
  
  private int getEmptyHeight()
  {
    if (this.height2_ != null) {
      return this.height2_.intValue();
    }
    DomNode node = getElement().getDomNodeOrDie();
    if (!node.mayBeDisplayed())
    {
      this.height2_ = Integer.valueOf(0);
      return 0;
    }
    if ("none".equals(getDisplay()))
    {
      this.height2_ = Integer.valueOf(0);
      return 0;
    }
    int windowHeight = getElement().getWindow().getWebWindow().getInnerHeight();
    if ((getElement() instanceof HTMLBodyElement))
    {
      this.height2_ = Integer.valueOf(windowHeight);
      return windowHeight;
    }
    boolean explicitHeightSpecified = super.getHeight().length() > 0;
    int defaultHeight;
    int defaultHeight;
    if (getElement().getFirstChild() == null)
    {
      int defaultHeight;
      if (((node instanceof HtmlButton)) || (((node instanceof HtmlInput)) && (!(node instanceof HtmlHiddenInput))))
      {
        defaultHeight = 20;
      }
      else
      {
        int defaultHeight;
        if ((node instanceof HtmlSelect))
        {
          defaultHeight = 20;
        }
        else
        {
          int defaultHeight;
          if ((node instanceof HtmlTextArea))
          {
            defaultHeight = 49;
          }
          else
          {
            int defaultHeight;
            if ((node instanceof HtmlInlineFrame)) {
              defaultHeight = 154;
            } else {
              defaultHeight = 0;
            }
          }
        }
      }
    }
    else
    {
      int defaultHeight;
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DEFAULT_ELEMENT_HEIGHT_15)) {
        defaultHeight = 15;
      } else {
        defaultHeight = 20;
      }
    }
    int defaultValue = (getElement() instanceof HTMLCanvasElement) ? 150 : windowHeight;
    
    int height = pixelValue(getElement(), new CSSStyleDeclaration.CssValue(defaultValue)
    {
      public String get(ComputedCSSStyleDeclaration style)
      {
        return style.getStyleAttribute("height");
      }
    });
    boolean useDefaultHeight = getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DEFAULT_ELEMENT_HEIGHT_MARKS_MIN);
    if (((height == 0) && (!explicitHeightSpecified)) || ((useDefaultHeight) && (height < defaultHeight))) {
      height = defaultHeight;
    }
    this.height2_ = Integer.valueOf(height);
    return height;
  }
  
  public int getContentHeight()
  {
    DomNode node = getElement().getDomNodeOrDie();
    if (!node.mayBeDisplayed()) {
      return 0;
    }
    ComputedCSSStyleDeclaration lastFlowing = null;
    Set<ComputedCSSStyleDeclaration> styles = new HashSet();
    for (DomNode child : node.getChildren()) {
      if (child.mayBeDisplayed())
      {
        ScriptableObject scriptObj = child.getScriptObject();
        if ((scriptObj instanceof HTMLElement))
        {
          HTMLElement e = (HTMLElement)scriptObj;
          ComputedCSSStyleDeclaration style = e.getCurrentStyle();
          String pos = style.getPositionWithInheritance();
          if (("static".equals(pos)) || ("relative".equals(pos))) {
            lastFlowing = style;
          } else if ("absolute".equals(pos)) {
            styles.add(style);
          }
        }
      }
    }
    if (lastFlowing != null) {
      styles.add(lastFlowing);
    }
    int max = 0;
    for (ComputedCSSStyleDeclaration style : styles)
    {
      int h = style.getTop(true, false, false) + style.getCalculatedHeight(true, true);
      if (h > max) {
        max = h;
      }
    }
    return max;
  }
  
  public boolean isScrollable(boolean horizontal)
  {
    Element node = getElement();
    String overflow = getOverflow();
    boolean scrollable;
    boolean scrollable;
    if (horizontal) {
      scrollable = (((node instanceof HTMLBodyElement)) || ("scroll".equals(overflow)) || ("auto".equals(overflow))) && (getContentWidth() > getCalculatedWidth());
    } else {
      scrollable = (((node instanceof HTMLBodyElement)) || ("scroll".equals(overflow)) || ("auto".equals(overflow))) && (getContentHeight() > getEmptyHeight());
    }
    return scrollable;
  }
  
  public int getTop(boolean includeMargin, boolean includeBorder, boolean includePadding)
  {
    int top = 0;
    if (null == this.top_)
    {
      String p = getPositionWithInheritance();
      if ("absolute".equals(p))
      {
        String t = getTopWithInheritance();
        if (!"auto".equals(t))
        {
          top = pixelValue(t);
        }
        else
        {
          String b = getBottomWithInheritance();
          if (!"auto".equals(b))
          {
            top = 0;
            DomNode child = getElement().getDomNodeOrDie().getParentNode().getFirstChild();
            while (child != null)
            {
              if (((child instanceof HtmlElement)) && (child.mayBeDisplayed())) {
                top += 20;
              }
              child = child.getNextSibling();
            }
            top -= pixelValue(b);
          }
        }
      }
      else
      {
        DomNode prev = getElement().getDomNodeOrDie().getPreviousSibling();
        while ((prev != null) && (!(prev instanceof HtmlElement))) {
          prev = prev.getPreviousSibling();
        }
        if (prev != null)
        {
          HTMLElement e = (HTMLElement)((HtmlElement)prev).getScriptObject();
          ComputedCSSStyleDeclaration style = e.getCurrentStyle();
          top = style.getTop(true, false, false) + style.getCalculatedHeight(true, true);
        }
        if ("relative".equals(p))
        {
          String t = getTopWithInheritance();
          top += pixelValue(t);
        }
      }
      this.top_ = Integer.valueOf(top);
    }
    else
    {
      top = this.top_.intValue();
    }
    if (includeMargin)
    {
      int margin = pixelValue(getMarginTop());
      top += margin;
    }
    if (includeBorder)
    {
      int border = pixelValue(getBorderTopWidth());
      top += border;
    }
    if (includePadding)
    {
      int padding = getPaddingTopValue();
      top += padding;
    }
    return top;
  }
  
  public int getLeft(boolean includeMargin, boolean includeBorder, boolean includePadding)
  {
    String p = getPositionWithInheritance();
    String l = getLeftWithInheritance();
    String r = getRightWithInheritance();
    if (("fixed".equals(p)) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.TREATS_POSITION_FIXED_LIKE_POSITION_STATIC))) {
      p = "static";
    }
    int left;
    int left;
    if (("absolute".equals(p)) && (!"auto".equals(l)))
    {
      left = pixelValue(l);
    }
    else
    {
      int left;
      if (("absolute".equals(p)) && (!"auto".equals(r)))
      {
        HTMLElement parent = (HTMLElement)getElement().getParentElement();
        int parentWidth = parent.getCurrentStyle().getCalculatedWidth(false, false);
        left = parentWidth - pixelValue(r);
      }
      else
      {
        int left;
        if (("fixed".equals(p)) && ("auto".equals(l)))
        {
          HTMLElement parent = (HTMLElement)getElement().getParentElement();
          left = pixelValue(parent.getCurrentStyle().getLeftWithInheritance());
        }
        else if ("static".equals(p))
        {
          int left = 0;
          for (DomNode n = getDomNodeOrDie(); n != null; n = n.getPreviousSibling())
          {
            if ((n.getScriptObject() instanceof HTMLElement))
            {
              HTMLElement e = (HTMLElement)n.getScriptObject();
              ComputedCSSStyleDeclaration style = e.getCurrentStyle();
              String d = style.getDisplay();
              if ("block".equals(d)) {
                break;
              }
              if (!"none".equals(d)) {
                left += style.getCalculatedWidth(true, true);
              }
            }
            else if ((n.getScriptObject() instanceof Text))
            {
              left += n.getTextContent().length() * 10;
            }
            if ((n instanceof HtmlTableRow)) {
              break;
            }
          }
        }
        else
        {
          left = pixelValue(l);
        }
      }
    }
    if (includeMargin)
    {
      int margin = getMarginLeftValue();
      left += margin;
    }
    if (includeBorder)
    {
      int border = pixelValue(getBorderLeftWidth());
      left += border;
    }
    if (includePadding)
    {
      int padding = getPaddingLeftValue();
      left += padding;
    }
    return left;
  }
  
  public String getPositionWithInheritance()
  {
    String p = getPosition();
    if ("inherit".equals(p)) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CAN_INHERIT_CSS_PROPERTY_VALUES))
      {
        HTMLElement parent = (HTMLElement)getElement().getParentElement();
        p = parent != null ? parent.getCurrentStyle().getPositionWithInheritance() : "static";
      }
      else
      {
        p = "static";
      }
    }
    return p;
  }
  
  public String getLeftWithInheritance()
  {
    String left = getLeft();
    if ("inherit".equals(left)) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CAN_INHERIT_CSS_PROPERTY_VALUES))
      {
        HTMLElement parent = (HTMLElement)getElement().getParentElement();
        left = parent != null ? parent.getCurrentStyle().getLeftWithInheritance() : "auto";
      }
      else
      {
        left = "auto";
      }
    }
    return left;
  }
  
  public String getRightWithInheritance()
  {
    String right = getRight();
    if ("inherit".equals(right)) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CAN_INHERIT_CSS_PROPERTY_VALUES))
      {
        HTMLElement parent = (HTMLElement)getElement().getParentElement();
        right = parent != null ? parent.getCurrentStyle().getRightWithInheritance() : "auto";
      }
      else
      {
        right = "auto";
      }
    }
    return right;
  }
  
  public String getTopWithInheritance()
  {
    String top = getTop();
    if ("inherit".equals(top)) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CAN_INHERIT_CSS_PROPERTY_VALUES))
      {
        HTMLElement parent = (HTMLElement)getElement().getParentElement();
        top = parent != null ? parent.getCurrentStyle().getTopWithInheritance() : "auto";
      }
      else
      {
        top = "auto";
      }
    }
    return top;
  }
  
  public String getBottomWithInheritance()
  {
    String bottom = getBottom();
    if ("inherit".equals(bottom)) {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CAN_INHERIT_CSS_PROPERTY_VALUES))
      {
        HTMLElement parent = (HTMLElement)getElement().getParentElement();
        bottom = parent != null ? parent.getCurrentStyle().getBottomWithInheritance() : "auto";
      }
      else
      {
        bottom = "auto";
      }
    }
    return bottom;
  }
  
  public int getMarginLeftValue()
  {
    return pixelValue(getMarginLeft());
  }
  
  public int getMarginRightValue()
  {
    return pixelValue(getMarginRight());
  }
  
  public int getMarginTopValue()
  {
    return pixelValue(getMarginTop());
  }
  
  public int getMarginBottomValue()
  {
    return pixelValue(getMarginBottom());
  }
  
  public int getPaddingLeftValue()
  {
    return pixelValue(getPaddingLeft());
  }
  
  public int getPaddingRightValue()
  {
    return pixelValue(getPaddingRight());
  }
  
  public int getPaddingTopValue()
  {
    return pixelValue(getPaddingTop());
  }
  
  public int getPaddingBottomValue()
  {
    return pixelValue(getPaddingBottom());
  }
  
  private int getPaddingHorizontal()
  {
    if (this.paddingHorizontal_ == null) {
      this.paddingHorizontal_ = Integer.valueOf("none".equals(getDisplay()) ? 0 : getPaddingLeftValue() + getPaddingRightValue());
    }
    return this.paddingHorizontal_.intValue();
  }
  
  private int getPaddingVertical()
  {
    if (this.paddingVertical_ == null) {
      this.paddingVertical_ = Integer.valueOf("none".equals(getDisplay()) ? 0 : getPaddingTopValue() + getPaddingBottomValue());
    }
    return this.paddingVertical_.intValue();
  }
  
  public int getBorderLeftValue()
  {
    return pixelValue(getBorderLeftWidth());
  }
  
  public int getBorderRightValue()
  {
    return pixelValue(getBorderRightWidth());
  }
  
  public int getBorderTopValue()
  {
    return pixelValue(getBorderTopWidth());
  }
  
  public int getBorderBottomValue()
  {
    return pixelValue(getBorderBottomWidth());
  }
  
  private int getBorderHorizontal()
  {
    if (this.borderHorizontal_ == null) {
      this.borderHorizontal_ = Integer.valueOf("none".equals(getDisplay()) ? 0 : getBorderLeftValue() + getBorderRightValue());
    }
    return this.borderHorizontal_.intValue();
  }
  
  private int getBorderVertical()
  {
    if (this.borderVertical_ == null) {
      this.borderVertical_ = Integer.valueOf("none".equals(getDisplay()) ? 0 : getBorderTopValue() + getBorderBottomValue());
    }
    return this.borderVertical_.intValue();
  }
  
  public String getWordSpacing()
  {
    String wordSpacing = "0px";
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_WORD_SPACING_DEFAULT_NORMAL)) {
      wordSpacing = "normal";
    }
    return (String)StringUtils.defaultIfEmpty(super.getWordSpacing(), wordSpacing);
  }
  
  public String getWordWrap()
  {
    return (String)StringUtils.defaultIfEmpty(super.getWordWrap(), "normal");
  }
  
  public Object getZIndex()
  {
    Object response = super.getZIndex();
    if (response.toString().isEmpty()) {
      return "auto";
    }
    return response;
  }
  
  public String getPropertyValue(String name)
  {
    Object property = getProperty(this, camelize(name));
    if (property == NOT_FOUND) {
      return super.getPropertyValue(name);
    }
    return Context.toString(property);
  }
  
  protected String pixelString(String value)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_LENGTH_WITHOUT_PX)) {
      return value;
    }
    if (value.endsWith("px")) {
      return value;
    }
    return pixelValue(value) + "px";
  }
  
  protected String pixelString(Element element, CSSStyleDeclaration.CssValue value)
  {
    String s = value.get(element);
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_LENGTH_WITHOUT_PX)) {
      return s;
    }
    if (s.endsWith("px")) {
      return s;
    }
    return pixelValue(element, value) + "px";
  }
}
