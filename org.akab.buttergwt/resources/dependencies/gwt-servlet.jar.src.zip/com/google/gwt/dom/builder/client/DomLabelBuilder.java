package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.LabelBuilder;
import com.google.gwt.dom.client.LabelElement;

public class DomLabelBuilder
  extends DomElementBuilderBase<LabelBuilder, LabelElement>
  implements LabelBuilder
{
  DomLabelBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public LabelBuilder accessKey(String accessKey)
  {
    ((LabelElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
  
  public LabelBuilder htmlFor(String htmlFor)
  {
    ((LabelElement)assertCanAddAttribute()).setHtmlFor(htmlFor);
    return this;
  }
}
