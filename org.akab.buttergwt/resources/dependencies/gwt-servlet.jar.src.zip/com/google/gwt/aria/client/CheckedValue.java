package com.google.gwt.aria.client;

public enum CheckedValue
  implements AriaAttributeType
{
  TRUE,  FALSE,  MIXED,  UNDEFINED;
  
  private CheckedValue() {}
  
  public static CheckedValue of(boolean value)
  {
    return value ? TRUE : FALSE;
  }
  
  public String getAriaValue()
  {
    switch (this)
    {
    case TRUE: 
      return "true";
    case FALSE: 
      return "false";
    case MIXED: 
      return "mixed";
    case UNDEFINED: 
      return "undefined";
    }
    return null;
  }
}
