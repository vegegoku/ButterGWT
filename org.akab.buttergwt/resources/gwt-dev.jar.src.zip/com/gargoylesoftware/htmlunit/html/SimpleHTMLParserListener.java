package com.gargoylesoftware.htmlunit.html;

import java.net.URL;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

class SimpleHTMLParserListener
  implements HTMLParserListener
{
  private static final Log LOG = LogFactory.getLog(HTMLParserListener.class);
  
  public void error(String message, URL url, String html, int line, int column, String key)
  {
    LOG.error(format(message, url, html, line, column));
  }
  
  public void warning(String message, URL url, String html, int line, int column, String key)
  {
    LOG.warn(format(message, url, html, line, column));
  }
  
  private String format(String message, URL url, String html, int line, int column)
  {
    StringBuilder buffer = new StringBuilder(message);
    buffer.append(" (");
    buffer.append(url.toExternalForm());
    buffer.append(" ");
    buffer.append(line);
    buffer.append(":");
    buffer.append(column);
    if (null != html)
    {
      buffer.append(" htmlSnippet: '");
      buffer.append(html);
      buffer.append("'");
    }
    buffer.append(")");
    return buffer.toString();
  }
}
