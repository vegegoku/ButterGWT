package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlHtml;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.host.Window;

@JsxClass(domClasses={HtmlHtml.class})
public class HTMLHtmlElement
  extends HTMLElement
{
  public Object getParentNode()
  {
    return getWindow().getDocument_js();
  }
  
  public int getClientWidth()
  {
    return getWindow().getInnerWidth();
  }
  
  public int getClientHeight()
  {
    return getWindow().getInnerHeight();
  }
  
  public int getClientLeft()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_BOUNDING_CLIENT_RECT_OFFSET_TWO)) {
      return 2;
    }
    return super.getClientLeft();
  }
  
  public int getClientTop()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_BOUNDING_CLIENT_RECT_OFFSET_TWO)) {
      return 2;
    }
    return super.getClientTop();
  }
}
