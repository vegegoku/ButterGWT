package com.google.gwt.dom.builder.client;

import com.google.gwt.util.PreventSpuriousRebuilds;

@PreventSpuriousRebuilds
abstract interface package-info {}
