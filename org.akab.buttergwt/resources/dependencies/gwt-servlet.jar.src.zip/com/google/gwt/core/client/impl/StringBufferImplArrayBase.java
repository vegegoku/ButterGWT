package com.google.gwt.core.client.impl;

public abstract class StringBufferImplArrayBase
  extends StringBufferImpl
{
  public native void append(Object paramObject, boolean paramBoolean);
  
  public native void append(Object paramObject, double paramDouble);
  
  public native void append(Object paramObject, float paramFloat);
  
  public native void append(Object paramObject, int paramInt);
  
  public final void append(Object a, Object x)
  {
    appendNonNull(a, "" + x);
  }
  
  public void append(Object a, String x)
  {
    appendNonNull(a, x == null ? "null" : x);
  }
  
  public native void appendNonNull(Object paramObject, String paramString);
  
  public final native Object createData();
  
  public int length(Object a)
  {
    return toString(a).length();
  }
  
  public final void replace(Object a, int start, int end, String toInsert)
  {
    String s = takeString(a);
    appendNonNull(a, s.substring(0, start));
    append(a, toInsert);
    appendNonNull(a, s.substring(end));
  }
  
  public void reverse(Object a)
  {
    String s = takeString(a);
    s = reverseString(s);
    appendNonNull(a, s);
  }
  
  public final String toString(Object a)
  {
    String s = takeString(a);
    appendNonNull(a, s);
    return s;
  }
  
  protected native String takeString(Object paramObject);
}
