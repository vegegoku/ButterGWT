package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import java.util.Locale;
import org.apache.commons.lang3.StringUtils;

@JsxClass
public class EventNode
  extends Node
{
  @JsxSetter
  public void setOnclick(Object handler)
  {
    setEventHandlerProp("onclick", handler);
  }
  
  @JsxGetter
  public Object getOnclick()
  {
    return getEventHandlerProp("onclick");
  }
  
  @JsxSetter
  public void setOndblclick(Object handler)
  {
    setEventHandlerProp("ondblclick", handler);
  }
  
  @JsxGetter
  public Object getOndblclick()
  {
    return getEventHandlerProp("ondblclick");
  }
  
  @JsxSetter
  public void setOnblur(Object handler)
  {
    setEventHandlerProp("onblur", handler);
  }
  
  @JsxGetter
  public Object getOnblur()
  {
    return getEventHandlerProp("onblur");
  }
  
  @JsxSetter
  public void setOnfocus(Object handler)
  {
    setEventHandlerProp("onfocus", handler);
  }
  
  @JsxGetter
  public Object getOnfocus()
  {
    return getEventHandlerProp("onfocus");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOnfocusin(Object handler)
  {
    setEventHandlerProp("onfocusin", handler);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getOnfocusin()
  {
    return getEventHandlerProp("onfocusin");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOnfocusout(Object handler)
  {
    setEventHandlerProp("onfocusout", handler);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getOnfocusout()
  {
    return getEventHandlerProp("onfocusout");
  }
  
  @JsxSetter
  public void setOnkeydown(Object handler)
  {
    setEventHandlerProp("onkeydown", handler);
  }
  
  @JsxGetter
  public Object getOnkeydown()
  {
    return getEventHandlerProp("onkeydown");
  }
  
  @JsxSetter
  public void setOnkeypress(Object handler)
  {
    setEventHandlerProp("onkeypress", handler);
  }
  
  @JsxGetter
  public Object getOnkeypress()
  {
    return getEventHandlerProp("onkeypress");
  }
  
  @JsxSetter
  public void setOnkeyup(Object handler)
  {
    setEventHandlerProp("onkeyup", handler);
  }
  
  @JsxGetter
  public Object getOnkeyup()
  {
    return getEventHandlerProp("onkeyup");
  }
  
  @JsxSetter
  public void setOnmousedown(Object handler)
  {
    setEventHandlerProp("onmousedown", handler);
  }
  
  @JsxGetter
  public Object getOnmousedown()
  {
    return getEventHandlerProp("onmousedown");
  }
  
  @JsxSetter
  public void setOnmousemove(Object handler)
  {
    setEventHandlerProp("onmousemove", handler);
  }
  
  @JsxGetter
  public Object getOnmousemove()
  {
    return getEventHandlerProp("onmousemove");
  }
  
  @JsxSetter
  public void setOnmouseout(Object handler)
  {
    setEventHandlerProp("onmouseout", handler);
  }
  
  @JsxGetter
  public Object getOnmouseout()
  {
    return getEventHandlerProp("onmouseout");
  }
  
  @JsxSetter
  public void setOnmouseover(Object handler)
  {
    setEventHandlerProp("onmouseover", handler);
  }
  
  @JsxGetter
  public Object getOnmouseover()
  {
    return getEventHandlerProp("onmouseover");
  }
  
  @JsxSetter
  public void setOnmouseup(Object handler)
  {
    setEventHandlerProp("onmouseup", handler);
  }
  
  @JsxGetter
  public Object getOnmouseup()
  {
    return getEventHandlerProp("onmouseup");
  }
  
  @JsxSetter
  public void setOncontextmenu(Object handler)
  {
    setEventHandlerProp("oncontextmenu", handler);
  }
  
  @JsxGetter
  public Object getOncontextmenu()
  {
    return getEventHandlerProp("oncontextmenu");
  }
  
  @JsxSetter
  public void setOnresize(Object handler)
  {
    setEventHandlerProp("onresize", handler);
  }
  
  @JsxGetter
  public Object getOnresize()
  {
    return getEventHandlerProp("onresize");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setOnpropertychange(Object handler)
  {
    setEventHandlerProp("onpropertychange", handler);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getOnpropertychange()
  {
    return getEventHandlerProp("onpropertychange");
  }
  
  @JsxSetter
  public void setOnerror(Object handler)
  {
    setEventHandlerProp("onerror", handler);
  }
  
  @JsxGetter
  public Object getOnerror()
  {
    return getEventHandlerProp("onerror");
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean fireEvent(String type, Event event)
  {
    if (event == null) {
      event = new MouseEvent();
    }
    String cleanedType = StringUtils.removeStart(type.toLowerCase(Locale.ENGLISH), "on");
    if (MouseEvent.isMouseEvent(cleanedType)) {
      event.setPrototype(getPrototype(MouseEvent.class));
    } else {
      event.setPrototype(getPrototype(Event.class));
    }
    event.setParentScope(getWindow());
    
    event.setCancelBubble(false);
    event.setReturnValue(Boolean.TRUE);
    event.setSrcElement(this);
    event.setEventType(cleanedType);
    
    fireEvent(event);
    return ((Boolean)event.getReturnValue()).booleanValue();
  }
}
