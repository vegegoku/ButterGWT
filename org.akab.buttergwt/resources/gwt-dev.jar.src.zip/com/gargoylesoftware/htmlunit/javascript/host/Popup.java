package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.ElementFactory;
import com.gargoylesoftware.htmlunit.html.HTMLParser;
import com.gargoylesoftware.htmlunit.html.HtmlBody;
import com.gargoylesoftware.htmlunit.html.HtmlHtml;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
public class Popup
  extends SimpleScriptable
{
  private boolean opened_;
  private HTMLDocument document_;
  
  public Popup()
  {
    this.opened_ = false;
  }
  
  void init(Window openerJSWindow)
  {
    this.document_ = new HTMLDocument();
    this.document_.setPrototype(openerJSWindow.getPrototype(HTMLDocument.class));
    this.document_.setParentScope(this);
    
    WebWindow openerWindow = openerJSWindow.getWebWindow();
    
    WebWindow popupPseudoWindow = new PopupPseudoWebWindow(openerWindow.getWebClient());
    
    WebResponse webResponse = openerWindow.getEnclosedPage().getWebResponse();
    HtmlPage popupPage = new HtmlPage(null, webResponse, popupPseudoWindow);
    setDomNode(popupPage);
    popupPseudoWindow.setEnclosedPage(popupPage);
    HtmlHtml html = (HtmlHtml)HTMLParser.getFactory("html").createElement(popupPage, "html", null);
    
    popupPage.appendChild(html);
    HtmlBody body = (HtmlBody)HTMLParser.getFactory("body").createElement(popupPage, "body", null);
    
    html.appendChild(body);
    
    this.document_.setDomNode(popupPage);
  }
  
  @JsxGetter
  public Object getDocument()
  {
    return this.document_;
  }
  
  @JsxGetter
  public boolean getIsOpen()
  {
    return this.opened_;
  }
  
  @JsxFunction
  public void hide()
  {
    this.opened_ = false;
  }
  
  @JsxFunction
  public void show()
  {
    this.opened_ = true;
  }
}
