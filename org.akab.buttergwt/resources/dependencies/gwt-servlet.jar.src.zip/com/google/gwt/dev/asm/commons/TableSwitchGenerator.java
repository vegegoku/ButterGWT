package com.google.gwt.dev.asm.commons;

import com.google.gwt.dev.asm.Label;

public abstract interface TableSwitchGenerator
{
  public abstract void generateCase(int paramInt, Label paramLabel);
  
  public abstract void generateDefault();
}
