package com.google.gwt.core.client;

public class JsArrayBoolean
  extends JavaScriptObject
{
  public final native boolean get(int paramInt);
  
  public final String join()
  {
    return join(",");
  }
  
  public final native String join(String paramString);
  
  public final native int length();
  
  public final native void push(boolean paramBoolean);
  
  public final native void set(int paramInt, boolean paramBoolean);
  
  public final native void setLength(int paramInt);
  
  public final native boolean shift();
  
  public final native void unshift(boolean paramBoolean);
}
