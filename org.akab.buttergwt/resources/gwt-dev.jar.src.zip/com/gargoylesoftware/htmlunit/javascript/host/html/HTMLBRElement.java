package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlBreak;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.lang3.ArrayUtils;

@JsxClass(domClasses={HtmlBreak.class})
public class HTMLBRElement
  extends HTMLElement
{
  private static final String[] VALID_CLEAR_VALUES = { "left", "right", "all", "none" };
  
  @JsxGetter
  public String getClear()
  {
    String clear = getDomNodeOrDie().getAttribute("clear");
    if ((!ArrayUtils.contains(VALID_CLEAR_VALUES, clear)) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_42))) {
      return "";
    }
    return clear;
  }
  
  @JsxSetter
  public void setClear(String clear)
  {
    if ((!ArrayUtils.contains(VALID_CLEAR_VALUES, clear)) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_43))) {
      throw Context.reportRuntimeError("Invalid clear property value: '" + clear + "'.");
    }
    getDomNodeOrDie().setAttribute("clear", clear);
  }
  
  protected boolean isEndTagForbidden()
  {
    return true;
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
