package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlCaption;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlCaption.class})
public class HTMLTableCaptionElement
  extends HTMLElement
{
  private static final String[] VALIGN_VALID_VALUES_IE = { "top", "bottom" };
  private static final String VALIGN_DEFAULT_VALUE = "";
  
  @JsxGetter
  public String getAlign()
  {
    boolean invalidValues = getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLELEMENT_ALIGN_INVALID);
    return getAlign(invalidValues);
  }
  
  @JsxSetter
  public void setAlign(String align)
  {
    setAlign(align, false);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getVAlign()
  {
    return getVAlign(getValidVAlignValues(), "");
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setVAlign(Object vAlign)
  {
    setVAlign(vAlign, getValidVAlignValues());
  }
  
  private String[] getValidVAlignValues()
  {
    String[] valid;
    String[] valid;
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_91)) {
      valid = VALIGN_VALID_VALUES_IE;
    } else {
      valid = null;
    }
    return valid;
  }
  
  public String getDefaultStyleDisplay()
  {
    return "table-caption";
  }
}
