package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlButton;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.FormField;
import java.io.IOException;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(domClasses={HtmlButton.class})
public class HTMLButtonElement
  extends FormField
{
  @JsxSetter
  public void setType(String newType)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_BUTTON_SET_TYPE_THROWS_EXCEPTION)) {
      throw Context.reportRuntimeError("Object doesn't support this action");
    }
    getDomNodeOrDie().setAttribute("type", newType);
  }
  
  @JsxGetter
  public String getType()
  {
    return ((HtmlButton)getDomNodeOrDie()).getTypeAttribute();
  }
  
  @JsxGetter
  public String getValue()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_BUTTON_USE_CONTENT_AS_VALUE)) {
      return getText();
    }
    return super.getValue();
  }
  
  @JsxSetter
  public void setValue(String newValue)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_BUTTON_USE_CONTENT_AS_VALUE)) {
      setInnerText(newValue);
    }
    super.setValue(newValue);
  }
  
  @JsxGetter
  public String getAccessKey()
  {
    return super.getAccessKey();
  }
  
  @JsxSetter
  public void setAccessKey(String accessKey)
  {
    super.setAccessKey(accessKey);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void click()
    throws IOException
  {
    super.click();
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline-block";
  }
}
