package com.gargoylesoftware.htmlunit.javascript.configuration;

public enum CanSetReadOnlyStatus
{
  YES,  IGNORE,  EXCEPTION;
  
  private CanSetReadOnlyStatus() {}
}
