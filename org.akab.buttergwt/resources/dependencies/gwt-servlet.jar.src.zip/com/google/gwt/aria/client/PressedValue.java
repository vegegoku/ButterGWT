package com.google.gwt.aria.client;

public enum PressedValue
  implements AriaAttributeType
{
  TRUE,  FALSE,  MIXED,  UNDEFINED;
  
  private PressedValue() {}
  
  public static PressedValue of(boolean value)
  {
    return value ? TRUE : FALSE;
  }
  
  public String getAriaValue()
  {
    switch (this)
    {
    case TRUE: 
      return "true";
    case FALSE: 
      return "false";
    case MIXED: 
      return "mixed";
    case UNDEFINED: 
      return "undefined";
    }
    return null;
  }
}
