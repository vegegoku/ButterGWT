package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.dom.client.Style.Unit;
import com.google.gwt.event.shared.HandlerRegistration;
import com.google.gwt.i18n.client.LocaleInfo;
import com.google.gwt.resources.client.ClientBundle;
import com.google.gwt.resources.client.ClientBundle.Source;
import com.google.gwt.resources.client.CommonResources;
import com.google.gwt.resources.client.CssResource;
import com.google.gwt.resources.client.CssResource.ImportedWithPrefix;
import com.google.gwt.resources.client.ImageResource;
import com.google.gwt.resources.client.ImageResource.ImageOptions;
import com.google.gwt.resources.client.ImageResource.RepeatStyle;
import com.google.gwt.safecss.shared.SafeStyles;
import com.google.gwt.safecss.shared.SafeStylesBuilder;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import com.google.gwt.user.client.Event;
import com.google.gwt.user.client.Event.NativePreviewEvent;
import com.google.gwt.user.client.Event.NativePreviewHandler;
import com.google.gwt.user.client.ui.AbstractImagePrototype;
import com.google.gwt.user.client.ui.HasEnabled;

public class ButtonCellBase<C>
  extends AbstractCell<C>
  implements IsCollapsible, HasEnabled
{
  private char accessKey;
  private final Appearance<C> appearance;
  
  public static abstract interface Appearance<C>
  {
    public abstract void onPush(Element paramElement);
    
    public abstract void onUnpush(Element paramElement);
    
    public abstract void render(ButtonCellBase<C> paramButtonCellBase, Cell.Context paramContext, C paramC, SafeHtmlBuilder paramSafeHtmlBuilder);
    
    public abstract void setFocus(Element paramElement, boolean paramBoolean);
  }
  
  public static enum Decoration
  {
    DEFAULT,  PRIMARY,  NEGATIVE;
    
    private Decoration() {}
  }
  
  public static class DefaultAppearance<C>
    implements ButtonCellBase.Appearance<C>
  {
    private static final int DEFAULT_ICON_PADDING = 3;
    private static Resources defaultResources;
    private static Template template;
    
    private static Resources getDefaultResources()
    {
      if (defaultResources == null) {
        defaultResources = (Resources)GWT.create(Resources.class);
      }
      return defaultResources;
    }
    
    private SafeHtml iconSafeHtml = SafeHtmlUtils.EMPTY_SAFE_HTML;
    private ImageResource lastIcon;
    private final SafeHtmlRenderer<C> renderer;
    private final Style style;
    
    public DefaultAppearance(SafeHtmlRenderer<C> renderer)
    {
      this(renderer, getDefaultResources());
    }
    
    public DefaultAppearance(SafeHtmlRenderer<C> renderer, Resources resources)
    {
      this.renderer = renderer;
      this.style = resources.buttonCellBaseStyle();
      this.style.ensureInjected();
      if (template == null) {
        template = (Template)GWT.create(Template.class);
      }
    }
    
    public SafeHtmlRenderer<C> getRenderer()
    {
      return this.renderer;
    }
    
    public void onPush(Element parent)
    {
      parent.getFirstChildElement().addClassName(this.style.buttonCellBasePushing());
    }
    
    public void onUnpush(Element parent)
    {
      parent.getFirstChildElement().removeClassName(this.style.buttonCellBasePushing());
    }
    
    public void render(ButtonCellBase<C> cell, Cell.Context context, C value, SafeHtmlBuilder sb)
    {
      SafeHtmlBuilder classes = new SafeHtmlBuilder();
      classes.appendEscaped(this.style.buttonCellBase());
      ButtonCellBase.Decoration decoration = cell.getDecoration();
      if (decoration == ButtonCellBase.Decoration.PRIMARY) {
        classes.appendEscaped(" " + this.style.buttonCellBasePrimary());
      } else if (decoration == ButtonCellBase.Decoration.NEGATIVE) {
        classes.appendEscaped(" " + this.style.buttonCellBaseNegative());
      } else {
        classes.appendEscaped(" " + this.style.buttonCellBaseDefault());
      }
      if (cell.isCollapseLeft()) {
        classes.appendEscaped(" " + this.style.buttonCellBaseCollapseLeft());
      }
      if (cell.isCollapseRight()) {
        classes.appendEscaped(" " + this.style.buttonCellBaseCollapseRight());
      }
      ImageResource icon = cell.getIcon();
      if (icon != this.lastIcon) {
        if (icon == null)
        {
          this.iconSafeHtml = SafeHtmlUtils.EMPTY_SAFE_HTML;
        }
        else
        {
          AbstractImagePrototype proto = AbstractImagePrototype.create(icon);
          SafeHtml iconOnly = SafeHtmlUtils.fromTrustedString(proto.getHTML());
          int halfHeight = (int)Math.round(icon.getHeight() / 2.0D);
          SafeStylesBuilder styles = new SafeStylesBuilder();
          styles.marginTop(-halfHeight, Style.Unit.PX);
          if (LocaleInfo.getCurrentLocale().isRTL()) {
            styles.right(0.0D, Style.Unit.PX);
          } else {
            styles.left(0.0D, Style.Unit.PX);
          }
          this.iconSafeHtml = template.iconWrapper(styles.toSafeStyles(), iconOnly);
        }
      }
      char accessKey = cell.getAccessKey();
      StringBuilder attributes = new StringBuilder();
      if (!cell.isEnabled()) {
        attributes.append("disabled=disabled ");
      }
      if (accessKey != 0)
      {
        attributes.append("accessKey=\"").append(SafeHtmlUtils.htmlEscape("" + accessKey));
        attributes.append("\" ");
      }
      SafeStylesBuilder styles = new SafeStylesBuilder();
      int iconWidth = icon == null ? 0 : icon.getWidth();
      int iconPadding = iconWidth + 3;
      if (LocaleInfo.getCurrentLocale().isRTL()) {
        styles.paddingRight(iconPadding, Style.Unit.PX);
      } else {
        styles.paddingLeft(iconPadding, Style.Unit.PX);
      }
      SafeHtml safeValue = this.renderer.render(value);
      SafeHtml content = template.iconContentLayout(CommonResources.getInlineBlockStyle(), styles.toSafeStyles(), this.iconSafeHtml, safeValue);
      
      int tabIndex = cell.getTabIndex();
      StringBuilder openTag = new StringBuilder();
      openTag.append("<button type=\"button\"");
      openTag.append(" class=\"" + classes.toSafeHtml().asString() + "\"");
      openTag.append(" tabindex=\"" + tabIndex + "\" ");
      openTag.append(attributes.toString()).append(">");
      sb.appendHtmlConstant(openTag.toString());
      sb.append(content);
      sb.appendHtmlConstant("</button>");
    }
    
    public void setFocus(Element parent, boolean focused)
    {
      Element focusable = (Element)parent.getFirstChildElement().cast();
      if (focused) {
        focusable.focus();
      } else {
        focusable.blur();
      }
    }
    
    static abstract interface Template
      extends SafeHtmlTemplates
    {
      @SafeHtmlTemplates.Template("<div class=\"{0}\" style=\"{1}position:relative;zoom:0;\">{2}{3}</div>")
      public abstract SafeHtml iconContentLayout(String paramString, SafeStyles paramSafeStyles, SafeHtml paramSafeHtml1, SafeHtml paramSafeHtml2);
      
      @SafeHtmlTemplates.Template("<div style=\"{0}position:absolute;top:50%;line-height:0px;\">{1}</div>")
      public abstract SafeHtml iconWrapper(SafeStyles paramSafeStyles, SafeHtml paramSafeHtml);
    }
    
    @CssResource.ImportedWithPrefix("gwt-ButtonCellBase")
    public static abstract interface Style
      extends CssResource
    {
      public static final String DEFAULT_CSS = "com/google/gwt/cell/client/ButtonCellBase.css";
      
      public abstract String buttonCellBase();
      
      public abstract String buttonCellBaseCollapseLeft();
      
      public abstract String buttonCellBaseCollapseRight();
      
      public abstract String buttonCellBaseDefault();
      
      public abstract String buttonCellBaseNegative();
      
      public abstract String buttonCellBasePrimary();
      
      public abstract String buttonCellBasePushing();
    }
    
    public static abstract interface Resources
      extends ClientBundle
    {
      @ImageResource.ImageOptions(repeatStyle=ImageResource.RepeatStyle.Horizontal, flipRtl=true)
      public abstract ImageResource buttonCellBaseBackground();
      
      @ClientBundle.Source({"com/google/gwt/cell/client/ButtonCellBase.css"})
      public abstract ButtonCellBase.DefaultAppearance.Style buttonCellBaseStyle();
    }
  }
  
  private class UnpushHandler
    implements Event.NativePreviewHandler
  {
    private final Element parent;
    private final HandlerRegistration reg;
    
    public UnpushHandler(Element parent)
    {
      this.parent = parent;
      this.reg = Event.addNativePreviewHandler(this);
    }
    
    public void onPreviewNativeEvent(Event.NativePreviewEvent event)
    {
      if ("mouseup".equals(event.getNativeEvent().getType()))
      {
        this.reg.removeHandler();
        
        ButtonCellBase.this.appearance.onUnpush(this.parent);
      }
    }
  }
  
  private Decoration decoration = Decoration.DEFAULT;
  private ImageResource icon;
  private boolean isCollapsedLeft;
  private boolean isCollapsedRight;
  private boolean isEnabled = true;
  private int tabIndex = -1;
  
  public ButtonCellBase(Appearance<C> appearance)
  {
    super(new String[] { "click", "keydown", "mousedown" });
    this.appearance = appearance;
  }
  
  public char getAccessKey()
  {
    return this.accessKey;
  }
  
  public Decoration getDecoration()
  {
    return this.decoration;
  }
  
  public ImageResource getIcon()
  {
    return this.icon;
  }
  
  public int getTabIndex()
  {
    return this.tabIndex;
  }
  
  public boolean isCollapseLeft()
  {
    return this.isCollapsedLeft;
  }
  
  public boolean isCollapseRight()
  {
    return this.isCollapsedRight;
  }
  
  public boolean isEnabled()
  {
    return this.isEnabled;
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    if (!isEnabled()) {
      return;
    }
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    
    Element target = (Element)event.getEventTarget().cast();
    if (!parent.getFirstChildElement().isOrHasChild(target)) {
      return;
    }
    String eventType = event.getType();
    if ("click".equals(eventType))
    {
      onEnterKeyDown(context, parent, value, event, valueUpdater);
    }
    else if ("mousedown".equals(eventType))
    {
      this.appearance.onPush(parent);
      
      new UnpushHandler(parent);
      
      event.preventDefault();
    }
  }
  
  public void render(Cell.Context context, C value, SafeHtmlBuilder sb)
  {
    this.appearance.render(this, context, value, sb);
  }
  
  public void setAccessKey(char key)
  {
    this.accessKey = key;
  }
  
  public void setCollapseLeft(boolean isCollapsed)
  {
    this.isCollapsedLeft = isCollapsed;
  }
  
  public void setCollapseRight(boolean isCollapsed)
  {
    this.isCollapsedRight = isCollapsed;
  }
  
  public void setDecoration(Decoration decoration)
  {
    this.decoration = decoration;
  }
  
  public void setEnabled(boolean isEnabled)
  {
    this.isEnabled = isEnabled;
  }
  
  public void setFocus(Element parent, boolean focused)
  {
    this.appearance.setFocus(parent, focused);
  }
  
  public void setIcon(ImageResource icon)
  {
    this.icon = icon;
  }
  
  public void setTabIndex(int tabIndex)
  {
    this.tabIndex = tabIndex;
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    if (valueUpdater != null) {
      valueUpdater.update(value);
    }
  }
}
