package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.OptGroupBuilder;
import com.google.gwt.dom.client.OptGroupElement;

public class DomOptGroupBuilder
  extends DomElementBuilderBase<OptGroupBuilder, OptGroupElement>
  implements OptGroupBuilder
{
  DomOptGroupBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public OptGroupBuilder disabled()
  {
    ((OptGroupElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public OptGroupBuilder label(String label)
  {
    ((OptGroupElement)assertCanAddAttribute()).setLabel(label);
    return this;
  }
}
