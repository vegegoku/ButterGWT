package org.aopalliance.intercept;

public abstract interface Invocation
  extends Joinpoint
{
  public abstract Object[] getArguments();
}
