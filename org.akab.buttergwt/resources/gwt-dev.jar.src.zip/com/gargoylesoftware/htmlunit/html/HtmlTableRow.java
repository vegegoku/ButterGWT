package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

public class HtmlTableRow
  extends HtmlElement
{
  public static final String TAG_NAME = "tr";
  
  HtmlTableRow(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public CellIterator getCellIterator()
  {
    return new CellIterator();
  }
  
  public List<HtmlTableCell> getCells()
  {
    List<HtmlTableCell> result = new ArrayList();
    for (HtmlTableCell cell : getCellIterator()) {
      result.add(cell);
    }
    return Collections.unmodifiableList(result);
  }
  
  public HtmlTableCell getCell(int index)
    throws IndexOutOfBoundsException
  {
    int count = 0;
    for (HtmlTableCell cell : getCellIterator())
    {
      if (count == index) {
        return cell;
      }
      count++;
    }
    throw new IndexOutOfBoundsException();
  }
  
  public final String getAlignAttribute()
  {
    return getAttribute("align");
  }
  
  public final String getCharAttribute()
  {
    return getAttribute("char");
  }
  
  public final String getCharoffAttribute()
  {
    return getAttribute("charoff");
  }
  
  public final String getValignAttribute()
  {
    return getAttribute("valign");
  }
  
  public HtmlTable getEnclosingTable()
  {
    return (HtmlTable)getEnclosingElement("table");
  }
  
  public final String getBgcolorAttribute()
  {
    return getAttribute("bgcolor");
  }
  
  public class CellIterator
    implements Iterator<HtmlTableCell>, Iterable<HtmlTableCell>
  {
    private HtmlTableCell nextCell_;
    private HtmlForm currentForm_;
    
    public CellIterator()
    {
      setNextCell(HtmlTableRow.this.getFirstChild());
    }
    
    public boolean hasNext()
    {
      return this.nextCell_ != null;
    }
    
    public HtmlTableCell next()
      throws NoSuchElementException
    {
      return nextCell();
    }
    
    public void remove()
      throws IllegalStateException
    {
      if (this.nextCell_ == null) {
        throw new IllegalStateException();
      }
      DomNode sibling = this.nextCell_.getPreviousSibling();
      if (sibling != null) {
        sibling.remove();
      }
    }
    
    public HtmlTableCell nextCell()
      throws NoSuchElementException
    {
      if (this.nextCell_ != null)
      {
        HtmlTableCell result = this.nextCell_;
        setNextCell(this.nextCell_.getNextSibling());
        return result;
      }
      throw new NoSuchElementException();
    }
    
    private void setNextCell(DomNode node)
    {
      this.nextCell_ = null;
      for (DomNode next = node; next != null; next = next.getNextSibling())
      {
        if ((next instanceof HtmlTableCell))
        {
          this.nextCell_ = ((HtmlTableCell)next);
          return;
        }
        if ((this.currentForm_ == null) && ((next instanceof HtmlForm)))
        {
          this.currentForm_ = ((HtmlForm)next);
          setNextCell(next.getFirstChild());
          return;
        }
      }
      if (this.currentForm_ != null)
      {
        DomNode form = this.currentForm_;
        this.currentForm_ = null;
        setNextCell(form.getNextSibling());
      }
    }
    
    public Iterator<HtmlTableCell> iterator()
    {
      return this;
    }
  }
}
