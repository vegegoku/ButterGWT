package com.google.gwt.core.client.impl;

public class StringBufferImplArray
  extends StringBufferImplArrayBase
{}
