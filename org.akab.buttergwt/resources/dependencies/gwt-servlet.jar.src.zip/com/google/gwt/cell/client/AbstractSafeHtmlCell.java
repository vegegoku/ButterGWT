package com.google.gwt.cell.client;

import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;
import java.util.Set;

public abstract class AbstractSafeHtmlCell<C>
  extends AbstractCell<C>
{
  private final SafeHtmlRenderer<C> renderer;
  
  public AbstractSafeHtmlCell(SafeHtmlRenderer<C> renderer, String... consumedEvents)
  {
    super(consumedEvents);
    if (renderer == null) {
      throw new IllegalArgumentException("renderer == null");
    }
    this.renderer = renderer;
  }
  
  public AbstractSafeHtmlCell(SafeHtmlRenderer<C> renderer, Set<String> consumedEvents)
  {
    super(consumedEvents);
    if (renderer == null) {
      throw new IllegalArgumentException("renderer == null");
    }
    this.renderer = renderer;
  }
  
  public SafeHtmlRenderer<C> getRenderer()
  {
    return this.renderer;
  }
  
  public void render(Cell.Context context, C data, SafeHtmlBuilder sb)
  {
    if (data == null) {
      render(context, (SafeHtml)null, sb);
    } else {
      render(context, this.renderer.render(data), sb);
    }
  }
  
  protected abstract void render(Cell.Context paramContext, SafeHtml paramSafeHtml, SafeHtmlBuilder paramSafeHtmlBuilder);
}
