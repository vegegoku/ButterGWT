package com.google.gwt.activity.shared;

import com.google.gwt.util.PreventSpuriousRebuilds;

@PreventSpuriousRebuilds
abstract interface package-info {}
