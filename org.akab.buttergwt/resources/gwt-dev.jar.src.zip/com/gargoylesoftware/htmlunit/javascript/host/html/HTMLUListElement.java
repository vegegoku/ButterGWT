package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlUnorderedList;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={HtmlUnorderedList.class})
public class HTMLUListElement
  extends HTMLListElement
{}
