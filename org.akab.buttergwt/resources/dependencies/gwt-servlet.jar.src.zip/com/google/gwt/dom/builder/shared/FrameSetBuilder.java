package com.google.gwt.dom.builder.shared;

public abstract interface FrameSetBuilder
  extends ElementBuilderBase<FrameSetBuilder>
{
  public abstract FrameSetBuilder cols(String paramString);
  
  public abstract FrameSetBuilder rows(String paramString);
}
