package com.google.gwt.canvas.dom.client;

public class CssColor
  extends FillStrokeStyle
{
  public static final CssColor make(int r, int g, int b)
  {
    return make("rgb(" + r + "," + g + "," + b + ")");
  }
  
  public static final native CssColor make(String paramString);
  
  public final native String value();
}
