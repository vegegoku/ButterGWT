package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomDocumentFragment;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HTMLParser;
import com.gargoylesoftware.htmlunit.html.impl.SimpleRange;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstant;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import java.util.ArrayList;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import org.apache.commons.collections.ListUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

@JsxClass
public class Range
  extends SimpleScriptable
{
  private Node startContainer_;
  private Node endContainer_;
  private int startOffset_;
  private int endOffset_;
  @JsxConstant
  public static final short START_TO_START = 0;
  @JsxConstant
  public static final short START_TO_END = 1;
  @JsxConstant
  public static final short END_TO_END = 2;
  @JsxConstant
  public static final short END_TO_START = 3;
  
  public Range() {}
  
  public Range(HTMLDocument document)
  {
    this.startContainer_ = document;
    this.endContainer_ = document;
  }
  
  Range(org.w3c.dom.ranges.Range w3cRange)
  {
    DomNode domNodeStartContainer = (DomNode)w3cRange.getStartContainer();
    this.startContainer_ = ((Node)domNodeStartContainer.getScriptObject());
    this.startOffset_ = w3cRange.getStartOffset();
    
    DomNode domNodeEndContainer = (DomNode)w3cRange.getEndContainer();
    this.endContainer_ = ((Node)domNodeEndContainer.getScriptObject());
    this.endOffset_ = w3cRange.getEndOffset();
  }
  
  public Object getDefaultValue(Class<?> hint)
  {
    return toW3C().toString();
  }
  
  @JsxGetter
  public Object getStartContainer()
  {
    if (this.startContainer_ == null) {
      return Context.getUndefinedValue();
    }
    return this.startContainer_;
  }
  
  @JsxGetter
  public Object getEndContainer()
  {
    if (this.endContainer_ == null) {
      return Context.getUndefinedValue();
    }
    return this.endContainer_;
  }
  
  @JsxGetter
  public int getStartOffset()
  {
    return this.startOffset_;
  }
  
  @JsxGetter
  public int getEndOffset()
  {
    return this.endOffset_;
  }
  
  @JsxFunction
  public void setStart(Node refNode, int offset)
  {
    if (refNode == null) {
      throw Context.reportRuntimeError("It is illegal to call Range.setStart() with a null node.");
    }
    this.startContainer_ = refNode;
    this.startOffset_ = offset;
  }
  
  @JsxFunction
  public void setStartAfter(Node refNode)
  {
    if (refNode == null) {
      throw Context.reportRuntimeError("It is illegal to call Range.setStartAfter() with a null node.");
    }
    this.startContainer_ = refNode.getParent();
    this.startOffset_ = (getPositionInContainer(refNode) + 1);
  }
  
  @JsxFunction
  public void setStartBefore(Node refNode)
  {
    if (refNode == null) {
      throw Context.reportRuntimeError("It is illegal to call Range.setStartBefore() with a null node.");
    }
    this.startContainer_ = refNode.getParent();
    this.startOffset_ = getPositionInContainer(refNode);
  }
  
  private int getPositionInContainer(Node refNode)
  {
    int i = 0;
    Node node = refNode;
    while (node.getPreviousSibling() != null)
    {
      node = node.getPreviousSibling();
      i++;
    }
    return i;
  }
  
  @JsxGetter
  public boolean getCollapsed()
  {
    return (this.startContainer_ == this.endContainer_) && (this.startOffset_ == this.endOffset_);
  }
  
  @JsxFunction
  public void setEnd(Node refNode, int offset)
  {
    if (refNode == null) {
      throw Context.reportRuntimeError("It is illegal to call Range.setEnd() with a null node.");
    }
    this.endContainer_ = refNode;
    this.endOffset_ = offset;
  }
  
  @JsxFunction
  public void setEndAfter(Node refNode)
  {
    if (refNode == null) {
      throw Context.reportRuntimeError("It is illegal to call Range.setEndAfter() with a null node.");
    }
    this.endContainer_ = refNode.getParent();
    this.endOffset_ = (getPositionInContainer(refNode) + 1);
  }
  
  @JsxFunction
  public void setEndBefore(Node refNode)
  {
    if (refNode == null) {
      throw Context.reportRuntimeError("It is illegal to call Range.setEndBefore() with a null node.");
    }
    this.startContainer_ = refNode.getParent();
    this.startOffset_ = getPositionInContainer(refNode);
  }
  
  @JsxFunction
  public void selectNodeContents(Node refNode)
  {
    this.startContainer_ = refNode;
    this.startOffset_ = 0;
    this.endContainer_ = refNode;
    this.endOffset_ = refNode.getChildNodes().getLength();
  }
  
  @JsxFunction
  public void selectNode(Node refNode)
  {
    setStartBefore(refNode);
    setEndAfter(refNode);
  }
  
  @JsxFunction
  public void collapse(boolean toStart)
  {
    if (toStart)
    {
      this.endContainer_ = this.startContainer_;
      this.endOffset_ = this.startOffset_;
    }
    else
    {
      this.startContainer_ = this.endContainer_;
      this.startOffset_ = this.endOffset_;
    }
  }
  
  @JsxGetter
  public Object getCommonAncestorContainer()
  {
    Node ancestor = getCommonAncestor();
    if (ancestor == null) {
      return Context.getUndefinedValue();
    }
    return ancestor;
  }
  
  private Node getCommonAncestor()
  {
    List<Node> startAncestors = getAncestorsAndSelf(this.startContainer_);
    List<Node> endAncestors = getAncestorsAndSelf(this.endContainer_);
    List<Node> commonAncestors = ListUtils.intersection(startAncestors, endAncestors);
    if (commonAncestors.isEmpty()) {
      return null;
    }
    return (Node)commonAncestors.get(0);
  }
  
  private List<Node> getAncestorsAndSelf(Node node)
  {
    List<Node> ancestors = new ArrayList();
    Node ancestor = node;
    while (ancestor != null)
    {
      ancestors.add(ancestor);
      ancestor = ancestor.getParent();
    }
    return ancestors;
  }
  
  @JsxFunction
  public Object createContextualFragment(String valueAsString)
  {
    SgmlPage page = this.startContainer_.getDomNodeOrDie().getPage();
    DomDocumentFragment fragment = new DomDocumentFragment(page);
    try
    {
      HTMLParser.parseFragment(fragment, this.startContainer_.getDomNodeOrDie(), valueAsString);
    }
    catch (Exception e)
    {
      LogFactory.getLog(Range.class).error("Unexpected exception occurred in createContextualFragment", e);
      throw Context.reportRuntimeError("Unexpected exception occurred in createContextualFragment: " + e.getMessage());
    }
    return fragment.getScriptObject();
  }
  
  @JsxFunction
  public Object extractContents()
  {
    return toW3C().extractContents().getScriptObject();
  }
  
  public SimpleRange toW3C()
  {
    return new SimpleRange(this.startContainer_.getDomNodeOrNull(), this.startOffset_, this.endContainer_.getDomNodeOrDie(), this.endOffset_);
  }
  
  @JsxFunction
  public Object compareBoundaryPoints(int how, Range sourceRange)
  {
    int containingMoficator;
    Node nodeForThis;
    int offsetForThis;
    int containingMoficator;
    if ((0 == how) || (3 == how))
    {
      Node nodeForThis = this.startContainer_;
      int offsetForThis = this.startOffset_;
      containingMoficator = 1;
    }
    else
    {
      nodeForThis = this.endContainer_;
      offsetForThis = this.endOffset_;
      containingMoficator = -1;
    }
    int offsetForOther;
    Node nodeForOther;
    int offsetForOther;
    if ((1 == how) || (0 == how))
    {
      Node nodeForOther = sourceRange.startContainer_;
      offsetForOther = sourceRange.startOffset_;
    }
    else
    {
      nodeForOther = sourceRange.endContainer_;
      offsetForOther = sourceRange.endOffset_;
    }
    if (nodeForThis == nodeForOther)
    {
      if (offsetForThis < offsetForOther) {
        return Integer.valueOf(-1);
      }
      if (offsetForThis < offsetForOther) {
        return Integer.valueOf(1);
      }
      return Integer.valueOf(0);
    }
    byte nodeComparision = (byte)nodeForThis.compareDocumentPosition(nodeForOther);
    if ((nodeComparision & 0x10) != 0) {
      return Integer.valueOf(-1 * containingMoficator);
    }
    if ((nodeComparision & 0x2) != 0) {
      return Integer.valueOf(-1);
    }
    return Integer.valueOf(1);
  }
  
  @JsxFunction
  public Object cloneContents()
  {
    return toW3C().cloneContents().getScriptObject();
  }
  
  @JsxFunction
  public void deleteContents()
  {
    toW3C().deleteContents();
  }
  
  @JsxFunction
  public void insertNode(Node newNode)
  {
    toW3C().insertNode(newNode.getDomNodeOrDie());
  }
  
  @JsxFunction
  public void surroundContents(Node newNode)
  {
    toW3C().surroundContents(newNode.getDomNodeOrDie());
  }
  
  @JsxFunction
  public Object cloneRange()
  {
    return new Range(toW3C().cloneRange());
  }
  
  @JsxFunction
  public void detach() {}
  
  @JsxFunction
  public String toString()
  {
    return toW3C().toString();
  }
  
  protected Object equivalentValues(Object value)
  {
    if (!(value instanceof Range)) {
      return Boolean.valueOf(false);
    }
    Range other = (Range)value;
    return Boolean.valueOf((this.startContainer_ == other.startContainer_) && (this.endContainer_ == other.endContainer_) && (this.startOffset_ == other.startOffset_) && (this.endOffset_ == other.endOffset_));
  }
}
