package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.lang3.StringUtils;

class HtmlSerializer
{
  private final StringBuilder buffer_ = new StringBuilder();
  protected static final String AS_TEXT_BLOCK_SEPARATOR = "§bs§";
  protected static final String AS_TEXT_NEW_LINE = "§nl§";
  protected static final String AS_TEXT_BLANK = "§blank§";
  protected static final String AS_TEXT_TAB = "§tab§";
  private static final Pattern CLEAN_UP_PATTERN = Pattern.compile("(?:§bs§)+");
  private static final Pattern REDUCE_WHITESPACE_PATTERN = Pattern.compile("\\s*§bs§\\s*");
  private static final Pattern TEXT_AREA_PATTERN = Pattern.compile("\r?\n");
  private boolean appletEnabled_;
  private boolean ignoreMaskedElements_ = true;
  
  public String asText(DomNode node)
  {
    this.appletEnabled_ = node.getPage().getWebClient().getOptions().isAppletEnabled();
    this.buffer_.setLength(0);
    appendNode(node);
    String response = this.buffer_.toString();
    this.buffer_.setLength(0);
    return cleanUp(response);
  }
  
  private String cleanUp(String text)
  {
    text = StringUtils.replace(text, "§nl§§bs§", "§bs§");
    text = reduceWhitespace(text);
    text = StringUtils.replace(text, "§blank§", " ");
    String ls = System.getProperty("line.separator");
    text = StringUtils.replace(text, "§nl§", ls);
    text = CLEAN_UP_PATTERN.matcher(text).replaceAll(ls);
    text = StringUtils.replace(text, "§tab§", "\t");
    
    return text;
  }
  
  protected String reduceWhitespace(String text)
  {
    text = text.trim();
    
    text = REDUCE_WHITESPACE_PATTERN.matcher(text).replaceAll("§bs§");
    while (text.startsWith("§bs§")) {
      text = text.substring("§bs§".length());
    }
    while (text.endsWith("§bs§")) {
      text = text.substring(0, text.length() - "§bs§".length());
    }
    text = text.trim();
    
    StringBuilder buffer = new StringBuilder(text.length());
    
    boolean whitespace = false;
    for (char ch : text.toCharArray()) {
      if (ch == ' ')
      {
        buffer.append(' ');
        whitespace = false;
      }
      else if (whitespace)
      {
        if (!Character.isWhitespace(ch))
        {
          buffer.append(ch);
          whitespace = false;
        }
      }
      else if (Character.isWhitespace(ch))
      {
        whitespace = true;
        buffer.append(' ');
      }
      else
      {
        buffer.append(ch);
      }
    }
    return buffer.toString();
  }
  
  protected void appendNode(DomNode node)
  {
    if ((node instanceof DomText)) {
      appendText((DomText)node);
    } else if (!(node instanceof DomComment)) {
      if ((!(node instanceof HtmlApplet)) || (!this.appletEnabled_)) {
        if ((node instanceof HtmlBreak)) {
          doAppendNewLine();
        } else if ((!(node instanceof HtmlHiddenInput)) && (!(node instanceof HtmlScript)) && (!(node instanceof HtmlStyle)) && (!(node instanceof HtmlNoFrames))) {
          if ((node instanceof HtmlTextArea))
          {
            appendHtmlTextArea((HtmlTextArea)node);
          }
          else if ((node instanceof HtmlTitle))
          {
            appendHtmlTitle((HtmlTitle)node);
          }
          else if ((node instanceof HtmlTableRow))
          {
            appendHtmlTableRow((HtmlTableRow)node);
          }
          else if ((node instanceof HtmlSelect))
          {
            appendHtmlSelect((HtmlSelect)node);
          }
          else if ((node instanceof HtmlSubmitInput))
          {
            appendHtmlSubmitInput((HtmlSubmitInput)node);
          }
          else if ((node instanceof HtmlCheckBoxInput))
          {
            String str;
            String str;
            if (((HtmlCheckBoxInput)node).isChecked()) {
              str = "checked";
            } else {
              str = "unchecked";
            }
            doAppend(str);
          }
          else if ((node instanceof HtmlRadioButtonInput))
          {
            String str;
            String str;
            if (((HtmlRadioButtonInput)node).isChecked()) {
              str = "checked";
            } else {
              str = "unchecked";
            }
            doAppend(str);
          }
          else if ((node instanceof HtmlInput))
          {
            doAppend(((HtmlInput)node).getValueAttribute());
          }
          else if ((node instanceof HtmlTable))
          {
            appendHtmlTable((HtmlTable)node);
          }
          else if ((node instanceof HtmlOrderedList))
          {
            appendHtmlOrderedList((HtmlOrderedList)node);
          }
          else if ((node instanceof HtmlUnorderedList))
          {
            appendHtmlUnorderedList((HtmlUnorderedList)node);
          }
          else
          {
            if (((node instanceof HtmlNoScript)) && (node.getPage().getWebClient().getOptions().isJavaScriptEnabled())) {
              return;
            }
            boolean block = node.isBlock();
            if (block) {
              doAppendBlockSeparator();
            }
            appendChildren(node);
            if (block) {
              doAppendBlockSeparator();
            }
          }
        }
      }
    }
  }
  
  private void doAppendBlockSeparator()
  {
    this.buffer_.append("§bs§");
  }
  
  private void doAppend(String str)
  {
    this.buffer_.append(str);
  }
  
  private void doAppendNewLine()
  {
    this.buffer_.append("§nl§");
  }
  
  private void doAppendTab()
  {
    this.buffer_.append("§tab§");
  }
  
  private void appendHtmlUnorderedList(HtmlUnorderedList htmlUnorderedList)
  {
    doAppendBlockSeparator();
    boolean first = true;
    for (DomNode item : htmlUnorderedList.getChildren())
    {
      if (!first) {
        doAppendBlockSeparator();
      }
      first = false;
      appendNode(item);
    }
    doAppendBlockSeparator();
  }
  
  private void appendHtmlTitle(HtmlTitle htmlTitle)
  {
    DomNode child = htmlTitle.getFirstChild();
    if ((child instanceof DomText))
    {
      doAppend(((DomText)child).getData());
      doAppendBlockSeparator();
      return;
    }
  }
  
  private void appendChildren(DomNode node)
  {
    for (DomNode child : node.getChildren()) {
      appendNode(child);
    }
  }
  
  private void appendHtmlTableRow(HtmlTableRow htmlTableRow)
  {
    boolean first = true;
    for (HtmlTableCell cell : htmlTableRow.getCells())
    {
      if (!first) {
        doAppendTab();
      } else {
        first = false;
      }
      appendChildren(cell);
    }
  }
  
  private void appendHtmlTextArea(HtmlTextArea htmlTextArea)
  {
    if (isVisible(htmlTextArea))
    {
      String text = htmlTextArea.getText();
      text = StringUtils.replace(text, " ", "§blank§");
      text = TEXT_AREA_PATTERN.matcher(text).replaceAll("§nl§");
      text = StringUtils.replace(text, "\r", "§nl§");
      doAppend(text);
    }
  }
  
  private void appendHtmlTable(HtmlTable htmlTable)
  {
    doAppendBlockSeparator();
    String caption = htmlTable.getCaptionText();
    if (caption != null)
    {
      doAppend(caption);
      doAppendBlockSeparator();
    }
    boolean first = true;
    
    HtmlTableHeader tableHeader = htmlTable.getHeader();
    if (tableHeader != null) {
      first = appendHtmlTableRows(tableHeader.getRows(), true, null, null);
    }
    HtmlTableFooter tableFooter = htmlTable.getFooter();
    
    first = appendHtmlTableRows(htmlTable.getRows(), first, tableHeader, tableFooter);
    if (tableFooter != null) {
      first = appendHtmlTableRows(tableFooter.getRows(), first, null, null);
    }
    doAppendBlockSeparator();
  }
  
  private boolean appendHtmlTableRows(List<HtmlTableRow> rows, boolean first, TableRowGroup skipParent1, TableRowGroup skipParent2)
  {
    for (HtmlTableRow row : rows) {
      if ((row.getParentNode() != skipParent1) && (row.getParentNode() != skipParent2))
      {
        if (!first) {
          doAppendBlockSeparator();
        }
        first = false;
        appendHtmlTableRow(row);
      }
    }
    return first;
  }
  
  private void appendHtmlSubmitInput(HtmlSubmitInput htmlSubmitInput)
  {
    String value = htmlSubmitInput.getValueAttribute();
    if (value == DomElement.ATTRIBUTE_NOT_DEFINED) {
      value = "Submit Query";
    }
    doAppend(value);
  }
  
  private void appendHtmlSelect(HtmlSelect htmlSelect)
  {
    List<HtmlOption> options;
    List<HtmlOption> options;
    if (htmlSelect.isMultipleSelectEnabled()) {
      options = htmlSelect.getOptions();
    } else {
      options = htmlSelect.getSelectedOptions();
    }
    for (Iterator<HtmlOption> i = options.iterator(); i.hasNext();)
    {
      HtmlOption currentOption = (HtmlOption)i.next();
      appendNode(currentOption);
      if (i.hasNext()) {
        doAppendBlockSeparator();
      }
    }
  }
  
  private void appendHtmlOrderedList(HtmlOrderedList htmlOrderedList)
  {
    doAppendBlockSeparator();
    boolean first = true;
    int i = 1;
    for (DomNode item : htmlOrderedList.getChildren()) {
      if ((item instanceof HtmlListItem))
      {
        if (!first) {
          doAppendBlockSeparator();
        }
        first = false;
        doAppend(Integer.toString(i++));
        doAppend(". ");
        appendChildren(item);
      }
    }
    doAppendBlockSeparator();
  }
  
  private void appendText(DomText domText)
  {
    if (isVisible(domText.getParentNode())) {
      append(domText.getData());
    }
  }
  
  private boolean isVisible(DomNode node)
  {
    return (!this.ignoreMaskedElements_) || (node.isDisplayed());
  }
  
  public void setIgnoreMaskedElements(boolean ignore)
  {
    this.ignoreMaskedElements_ = ignore;
  }
  
  private void append(String text)
  {
    doAppend(text);
  }
}
