package com.google.gwt.core.client.impl;

public class StringBufferImplPush
  extends StringBufferImplArrayBase
{
  public native void append(Object paramObject, boolean paramBoolean);
  
  public native void append(Object paramObject, double paramDouble);
  
  public native void append(Object paramObject, float paramFloat);
  
  public native void append(Object paramObject, int paramInt);
  
  public native void appendNonNull(Object paramObject, String paramString);
}
