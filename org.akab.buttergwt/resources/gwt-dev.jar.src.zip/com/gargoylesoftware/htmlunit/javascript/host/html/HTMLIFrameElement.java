package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.BaseFrameElement;
import com.gargoylesoftware.htmlunit.html.FrameWindow;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlInlineFrame;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Window;

@JsxClass(domClasses={HtmlInlineFrame.class})
public class HTMLIFrameElement
  extends HTMLElement
{
  @JsxGetter
  public String getSrc()
  {
    return getFrame().getSrcAttribute();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public DocumentProxy getContentDocument()
  {
    return getContentWindow().getDocument_js();
  }
  
  @JsxGetter
  public Window getContentWindow()
  {
    return (Window)getFrame().getEnclosedWindow().getScriptObject();
  }
  
  @JsxSetter
  public void setSrc(String src)
  {
    getFrame().setSrcAttribute(src);
  }
  
  @JsxGetter
  public String getName()
  {
    return getFrame().getNameAttribute();
  }
  
  @JsxSetter
  public void setName(String name)
  {
    getFrame().setNameAttribute(name);
  }
  
  private BaseFrameElement getFrame()
  {
    return (BaseFrameElement)getDomNodeOrDie();
  }
  
  @JsxSetter
  public void setOnload(Object eventHandler)
  {
    setEventHandlerProp("onload", eventHandler);
  }
  
  @JsxGetter
  public Object getOnload()
  {
    return getEventHandlerProp("onload");
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBorder()
  {
    String border = getDomNodeOrDie().getAttribute("border");
    return border;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setBorder(String border)
  {
    getDomNodeOrDie().setAttribute("border", border);
  }
  
  @JsxGetter
  public String getAlign()
  {
    return getAlign(true);
  }
  
  @JsxSetter
  public void setAlign(String align)
  {
    setAlign(align, false);
  }
  
  @JsxGetter(propertyName="width")
  public String getWidth_js()
  {
    boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_IFRAME_GET_WIDTH_NEGATIVE_VALUES);
    Boolean returnNegativeValues = ie ? Boolean.TRUE : null;
    return getWidthOrHeight("width", returnNegativeValues);
  }
  
  @JsxSetter
  public void setWidth(String width)
  {
    setWidthOrHeight("width", width, true);
  }
  
  @JsxGetter(propertyName="height")
  public String getHeight_js()
  {
    boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_IFRAME_GET_HEIGHT_NEGATIVE_VALUES);
    Boolean returnNegativeValues = ie ? Boolean.TRUE : null;
    return getWidthOrHeight("height", returnNegativeValues);
  }
  
  @JsxSetter
  public void setHeight(String height)
  {
    setWidthOrHeight("height", height, true);
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
