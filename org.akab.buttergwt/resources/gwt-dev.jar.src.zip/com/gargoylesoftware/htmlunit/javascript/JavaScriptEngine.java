package com.gargoylesoftware.htmlunit.javascript;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.ScriptException;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlDivision;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.background.BackgroundJavaScriptFactory;
import com.gargoylesoftware.htmlunit.javascript.background.JavaScriptExecutor;
import com.gargoylesoftware.htmlunit.javascript.configuration.ClassConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.ClassConfiguration.PropertyInfo;
import com.gargoylesoftware.htmlunit.javascript.configuration.JavaScriptConfiguration;
import com.gargoylesoftware.htmlunit.javascript.host.DateCustom;
import com.gargoylesoftware.htmlunit.javascript.host.Element;
import com.gargoylesoftware.htmlunit.javascript.host.StringCustom;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Stack;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.ContextAction;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.FunctionObject;
import net.sourceforge.htmlunit.corejs.javascript.Script;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class JavaScriptEngine
{
  private static final Log LOG = LogFactory.getLog(JavaScriptEngine.class);
  private final WebClient webClient_;
  private final HtmlUnitContextFactory contextFactory_;
  private final JavaScriptConfiguration jsConfig_;
  private transient ThreadLocal<Boolean> javaScriptRunning_;
  private transient ThreadLocal<List<PostponedAction>> postponedActions_;
  private transient boolean holdPostponedActions_;
  private transient JavaScriptExecutor javaScriptExecutor_;
  public static final String KEY_STARTING_SCOPE = "startingScope";
  public static final String KEY_STARTING_PAGE = "startingPage";
  
  public JavaScriptEngine(WebClient webClient)
  {
    this.webClient_ = webClient;
    this.contextFactory_ = new HtmlUnitContextFactory(webClient);
    initTransientFields();
    this.jsConfig_ = JavaScriptConfiguration.getInstance(webClient.getBrowserVersion());
  }
  
  public final WebClient getWebClient()
  {
    return this.webClient_;
  }
  
  public HtmlUnitContextFactory getContextFactory()
  {
    return this.contextFactory_;
  }
  
  public void initialize(final WebWindow webWindow)
  {
    WebAssert.notNull("webWindow", webWindow);
    
    ContextAction action = new ContextAction()
    {
      public Object run(Context cx)
      {
        try
        {
          JavaScriptEngine.this.init(webWindow, cx);
        }
        catch (Exception e)
        {
          JavaScriptEngine.LOG.error("Exception while initializing JavaScript for the page", e);
          throw new ScriptException(null, e);
        }
        return null;
      }
    };
    getContextFactory().call(action);
  }
  
  public JavaScriptExecutor getJavaScriptExecutor()
  {
    return this.javaScriptExecutor_;
  }
  
  private void init(WebWindow webWindow, Context context)
    throws Exception
  {
    WebClient webClient = webWindow.getWebClient();
    BrowserVersion browserVersion = webClient.getBrowserVersion();
    Map<Class<? extends SimpleScriptable>, Scriptable> prototypes = new HashMap();
    
    Map<String, ScriptableObject> prototypesPerJSName = new HashMap();
    Window window = new Window();
    context.initStandardObjects(window);
    if (browserVersion.hasFeature(BrowserVersionFeatures.JS_CONSTRUCTOR)) {
      defineConstructor(window, window, new Window());
    } else {
      deleteProperties(window, new String[] { "constructor" });
    }
    deleteProperties(window, new String[] { "java", "javax", "org", "com", "edu", "net", "JavaAdapter", "JavaImporter", "Continuation", "Packages", "getClass" });
    if (!browserVersion.hasFeature(BrowserVersionFeatures.JS_XML)) {
      deleteProperties(window, new String[] { "XML", "XMLList", "Namespace", "QName" });
    }
    Scriptable fallbackCaller = new FallbackCaller(null);
    ScriptableObject.getObjectPrototype(window).setPrototype(fallbackCaller);
    
    boolean putPrototypeInWindowScope = browserVersion.hasFeature(BrowserVersionFeatures.JS_HAS_OBJECT_WITH_PROTOTYPE_PROPERTY_IN_WINDOW_SCOPE);
    for (ClassConfiguration config : this.jsConfig_.getAll())
    {
      boolean isWindow = Window.class.getName().equals(config.getHostClass().getName());
      if (isWindow)
      {
        configureConstantsPropertiesAndFunctions(config, window);
      }
      else
      {
        ScriptableObject prototype = configureClass(config, window);
        if (config.isJsObject())
        {
          if (putPrototypeInWindowScope)
          {
            SimpleScriptable obj = (SimpleScriptable)config.getHostClass().newInstance();
            prototype.defineProperty("__proto__", prototype, 2);
            obj.defineProperty("prototype", prototype, 2);
            obj.setParentScope(window);
            ScriptableObject.defineProperty(window, obj.getClassName(), obj, 2);
            
            configureConstants(config, obj);
            if (obj.getClass() == Element.class)
            {
              Page page = webWindow.getEnclosedPage();
              if ((page != null) && (page.isHtmlPage()))
              {
                DomNode domNode = new HtmlDivision(null, "", (HtmlPage)page, null);
                obj.setDomNode(domNode);
              }
            }
          }
          prototypes.put(config.getHostClass(), prototype);
        }
        prototypesPerJSName.put(config.getHostClass().getSimpleName(), prototype);
      }
    }
    Scriptable objectPrototype = ScriptableObject.getObjectPrototype(window);
    for (Map.Entry<String, ScriptableObject> entry : prototypesPerJSName.entrySet())
    {
      String name = (String)entry.getKey();
      ClassConfiguration config = this.jsConfig_.getClassConfiguration(name);
      Scriptable prototype = (Scriptable)entry.getValue();
      if (prototype.getPrototype() != null) {
        prototype = prototype.getPrototype();
      }
      if (!StringUtils.isEmpty(config.getExtendedClassName()))
      {
        Scriptable parentPrototype = (Scriptable)prototypesPerJSName.get(config.getExtendedClassName());
        prototype.setPrototype(parentPrototype);
      }
      else
      {
        prototype.setPrototype(objectPrototype);
      }
    }
    for (ClassConfiguration config : this.jsConfig_.getAll())
    {
      Method jsConstructor = config.getJsConstructor();
      String jsClassName = config.getHostClass().getSimpleName();
      ScriptableObject prototype = (ScriptableObject)prototypesPerJSName.get(jsClassName);
      if (prototype != null) {
        if (jsConstructor != null)
        {
          FunctionObject functionObject = new FunctionObject(jsClassName, jsConstructor, window);
          functionObject.addAsConstructor(window, prototype);
          configureConstants(config, functionObject);
        }
        else if (browserVersion.hasFeature(BrowserVersionFeatures.JS_CONSTRUCTOR))
        {
          Class<?> jsHostClass = config.getHostClass();
          ScriptableObject constructor = (ScriptableObject)jsHostClass.newInstance();
          defineConstructor(window, prototype, constructor);
          configureConstants(config, constructor);
        }
        else
        {
          deleteProperties(prototype, new String[] { "constructor" });
        }
      }
    }
    removePrototypeProperties(window, "String", new String[] { "equals", "equalsIgnoreCase" });
    if (!browserVersion.hasFeature(BrowserVersionFeatures.STRING_TRIM)) {
      removePrototypeProperties(window, "String", new String[] { "trim" });
    }
    if (browserVersion.hasFeature(BrowserVersionFeatures.STRING_TRIM_LEFT_RIGHT))
    {
      ScriptableObject stringPrototype = (ScriptableObject)ScriptableObject.getClassPrototype(window, "String");
      
      stringPrototype.defineFunctionProperties(new String[] { "trimLeft", "trimRight" }, StringCustom.class, 0);
    }
    if (!browserVersion.hasFeature(BrowserVersionFeatures.JS_FUNCTION_BIND)) {
      removePrototypeProperties(window, "Function", new String[] { "bind" });
    }
    if (!browserVersion.hasFeature(BrowserVersionFeatures.JS_ECMA5_FUNCTIONS)) {
      removePrototypeProperties(window, "Date", new String[] { "toISOString", "toJSON" });
    }
    if (!browserVersion.hasFeature(BrowserVersionFeatures.JS_DEFINE_GETTER)) {
      removePrototypeProperties(window, "Object", new String[] { "__defineGetter__", "__defineSetter__", "__lookupGetter__", "__lookupSetter__" });
    }
    if (!browserVersion.hasFeature(BrowserVersionFeatures.JS_FUNCTION_TOSOURCE))
    {
      deleteProperties(window, new String[] { "uneval" });
      removePrototypeProperties(window, "Object", new String[] { "toSource" });
      removePrototypeProperties(window, "Array", new String[] { "toSource" });
      removePrototypeProperties(window, "Date", new String[] { "toSource" });
      removePrototypeProperties(window, "Function", new String[] { "toSource" });
      removePrototypeProperties(window, "Number", new String[] { "toSource" });
      removePrototypeProperties(window, "String", new String[] { "toSource" });
    }
    if (!browserVersion.hasFeature(BrowserVersionFeatures.JS_FUNCTION_ISXMLNAME)) {
      deleteProperties(window, new String[] { "isXMLName" });
    }
    NativeFunctionToStringFunction.installFix(window, webClient.getBrowserVersion());
    if (browserVersion.hasFeature(BrowserVersionFeatures.JS_ALLOW_CONST_ASSIGNMENT)) {
      makeConstWritable(window, new String[] { "undefined", "NaN", "Infinity" });
    }
    ScriptableObject datePrototype = (ScriptableObject)ScriptableObject.getClassPrototype(window, "Date");
    datePrototype.defineFunctionProperties(new String[] { "toLocaleDateString", "toLocaleTimeString" }, DateCustom.class, 2);
    if (browserVersion.hasFeature(BrowserVersionFeatures.JS_DATE_USE_UTC)) {
      datePrototype.defineFunctionProperties(new String[] { "toUTCString" }, DateCustom.class, 2);
    }
    window.setPrototypes(prototypes);
    window.initialize(webWindow);
  }
  
  private void defineConstructor(Window window, Scriptable prototype, ScriptableObject constructor)
  {
    constructor.setParentScope(window);
    ScriptableObject.defineProperty(prototype, "constructor", constructor, 7);
    
    ScriptableObject.defineProperty(constructor, "prototype", prototype, 7);
    
    window.defineProperty(constructor.getClassName(), constructor, 2);
  }
  
  private void makeConstWritable(ScriptableObject scope, String... constNames)
  {
    for (String name : constNames)
    {
      Object value = ScriptableObject.getProperty(scope, name);
      ScriptableObject.defineProperty(scope, name, value, 6);
    }
  }
  
  private void deleteProperties(ScriptableObject scope, String... propertiesToDelete)
  {
    for (String property : propertiesToDelete) {
      scope.delete(property);
    }
  }
  
  private void removePrototypeProperties(Scriptable scope, String className, String... properties)
  {
    ScriptableObject prototype = (ScriptableObject)ScriptableObject.getClassPrototype(scope, className);
    for (String property : properties) {
      prototype.delete(property);
    }
  }
  
  private ScriptableObject configureClass(ClassConfiguration config, Scriptable window)
    throws InstantiationException, IllegalAccessException
  {
    Class<?> jsHostClass = config.getHostClass();
    ScriptableObject prototype = (ScriptableObject)jsHostClass.newInstance();
    prototype.setParentScope(window);
    
    configureConstantsPropertiesAndFunctions(config, prototype);
    
    return prototype;
  }
  
  private void configureConstantsPropertiesAndFunctions(ClassConfiguration config, ScriptableObject scriptable)
  {
    configureConstants(config, scriptable);
    for (Map.Entry<String, ClassConfiguration.PropertyInfo> propertyEntry : config.propertyEntries())
    {
      String propertyName = (String)propertyEntry.getKey();
      Method readMethod = ((ClassConfiguration.PropertyInfo)propertyEntry.getValue()).getReadMethod();
      Method writeMethod = ((ClassConfiguration.PropertyInfo)propertyEntry.getValue()).getWriteMethod();
      scriptable.defineProperty(propertyName, null, readMethod, writeMethod, 0);
    }
    int attributes;
    int attributes;
    if (this.webClient_.getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DONT_ENUM_FUNCTIONS)) {
      attributes = 2;
    } else {
      attributes = 0;
    }
    for (Map.Entry<String, Method> functionInfo : config.functionEntries())
    {
      String functionName = (String)functionInfo.getKey();
      Method method = (Method)functionInfo.getValue();
      FunctionObject functionObject = new FunctionObject(functionName, method, scriptable);
      scriptable.defineProperty(functionName, functionObject, attributes);
    }
  }
  
  private void configureConstants(ClassConfiguration config, ScriptableObject scriptable)
  {
    Class<?> linkedClass = config.getHostClass();
    for (String constant : config.constants()) {
      try
      {
        Object value = linkedClass.getField(constant).get(null);
        scriptable.defineProperty(constant, value, 0);
      }
      catch (Exception e)
      {
        throw Context.reportRuntimeError("Cannot get field '" + constant + "' for type: " + config.getHostClass().getName());
      }
    }
  }
  
  public void registerWindowAndMaybeStartEventLoop(WebWindow webWindow)
  {
    if (this.javaScriptExecutor_ == null) {
      this.javaScriptExecutor_ = BackgroundJavaScriptFactory.theFactory().createJavaScriptExecutor(this.webClient_);
    }
    this.javaScriptExecutor_.addWindow(webWindow);
  }
  
  public int pumpEventLoop(long timeoutMillis)
  {
    if (this.javaScriptExecutor_ == null) {
      return 0;
    }
    return this.javaScriptExecutor_.pumpEventLoop(timeoutMillis);
  }
  
  public void shutdownJavaScriptExecutor()
  {
    if (this.javaScriptExecutor_ != null)
    {
      this.javaScriptExecutor_.shutdown();
      this.javaScriptExecutor_ = null;
    }
  }
  
  public Script compile(HtmlPage htmlPage, String sourceCode, final String sourceName, final int startLine)
  {
    WebAssert.notNull("sourceCode", sourceCode);
    if (LOG.isTraceEnabled())
    {
      String newline = System.getProperty("line.separator");
      LOG.trace("Javascript compile " + sourceName + newline + sourceCode + newline);
    }
    Scriptable scope = getScope(htmlPage, null);
    final String source = sourceCode;
    ContextAction action = new HtmlUnitContextAction(scope, htmlPage, source)
    {
      public Object doRun(Context cx)
      {
        return cx.compileString(source, sourceName, startLine, null);
      }
      
      protected String getSourceCode(Context cx)
      {
        return source;
      }
    };
    return (Script)getContextFactory().call(action);
  }
  
  public Object execute(HtmlPage htmlPage, String sourceCode, String sourceName, int startLine)
  {
    Script script = compile(htmlPage, sourceCode, sourceName, startLine);
    if (script == null) {
      return null;
    }
    return execute(htmlPage, script);
  }
  
  public Object execute(HtmlPage htmlPage, final Script script)
  {
    final Scriptable scope = getScope(htmlPage, null);
    
    ContextAction action = new HtmlUnitContextAction(scope, htmlPage, script)
    {
      public Object doRun(Context cx)
      {
        return script.exec(cx, scope);
      }
      
      protected String getSourceCode(Context cx)
      {
        return null;
      }
    };
    return getContextFactory().call(action);
  }
  
  public Object callFunction(HtmlPage htmlPage, Function javaScriptFunction, Scriptable thisObject, Object[] args, DomNode htmlElement)
  {
    Scriptable scope = getScope(htmlPage, htmlElement);
    
    return callFunction(htmlPage, javaScriptFunction, scope, thisObject, args);
  }
  
  public Object callFunction(HtmlPage htmlPage, final Function function, final Scriptable scope, final Scriptable thisObject, final Object[] args)
  {
    ContextAction action = new HtmlUnitContextAction(scope, htmlPage, function)
    {
      public Object doRun(Context cx)
      {
        return function.call(cx, scope, thisObject, args);
      }
      
      protected String getSourceCode(Context cx)
      {
        return cx.decompileFunction(function, 2);
      }
    };
    return getContextFactory().call(action);
  }
  
  private Scriptable getScope(HtmlPage htmlPage, DomNode htmlElement)
  {
    if (htmlElement != null) {
      return htmlElement.getScriptObject();
    }
    return (Window)htmlPage.getEnclosingWindow().getScriptObject();
  }
  
  public boolean isScriptRunning()
  {
    return Boolean.TRUE.equals(this.javaScriptRunning_.get());
  }
  
  private abstract class HtmlUnitContextAction
    implements ContextAction
  {
    private final Scriptable scope_;
    private final HtmlPage htmlPage_;
    
    public HtmlUnitContextAction(Scriptable scope, HtmlPage htmlPage)
    {
      this.scope_ = scope;
      this.htmlPage_ = htmlPage;
    }
    
    public final Object run(Context cx)
    {
      Boolean javaScriptAlreadyRunning = (Boolean)JavaScriptEngine.this.javaScriptRunning_.get();
      JavaScriptEngine.this.javaScriptRunning_.set(Boolean.TRUE);
      try
      {
        Stack<Scriptable> stack = (Stack)cx.getThreadLocal("startingScope");
        if (null == stack)
        {
          stack = new Stack();
          cx.putThreadLocal("startingScope", stack);
        }
        stack.push(this.scope_);
        try
        {
          cx.putThreadLocal("startingPage", this.htmlPage_);
          synchronized (this.htmlPage_)
          {
            if (this.htmlPage_ != this.htmlPage_.getEnclosingWindow().getEnclosedPage())
            {
              Object localObject1 = null;
              
              stack.pop();
              
              return localObject1;
            }
            response = doRun(cx);
          }
        }
        finally
        {
          stack.pop();
        }
        if (!JavaScriptEngine.this.holdPostponedActions_) {
          JavaScriptEngine.this.doProcessPostponedActions();
        }
        return response;
      }
      catch (Exception e)
      {
        Object response;
        JavaScriptEngine.this.handleJavaScriptException(new ScriptException(this.htmlPage_, e, getSourceCode(cx)), true);
        return null;
      }
      catch (TimeoutError e)
      {
        JavaScriptErrorListener javaScriptErrorListener = JavaScriptEngine.this.getWebClient().getJavaScriptErrorListener();
        if (javaScriptErrorListener != null) {
          javaScriptErrorListener.timeoutError(this.htmlPage_, e.getAllowedTime(), e.getExecutionTime());
        }
        if (JavaScriptEngine.this.getWebClient().getOptions().isThrowExceptionOnScriptError()) {
          throw new RuntimeException(e);
        }
        JavaScriptEngine.LOG.info("Caught script timeout error", e);
        return null;
      }
      finally
      {
        JavaScriptEngine.this.javaScriptRunning_.set(javaScriptAlreadyRunning);
      }
    }
    
    protected abstract Object doRun(Context paramContext);
    
    protected abstract String getSourceCode(Context paramContext);
  }
  
  private void doProcessPostponedActions()
  {
    this.holdPostponedActions_ = false;
    try
    {
      getWebClient().loadDownloadedResponses();
    }
    catch (RuntimeException e)
    {
      throw e;
    }
    catch (Exception e)
    {
      throw new RuntimeException(e);
    }
    List<PostponedAction> actions = (List)this.postponedActions_.get();
    if (actions != null)
    {
      this.postponedActions_.set(null);
      try
      {
        for (PostponedAction action : actions)
        {
          Page owningPage = action.getOwningPage();
          if ((owningPage != null) && (owningPage == owningPage.getEnclosingWindow().getEnclosedPage())) {
            action.execute();
          }
        }
      }
      catch (Exception e)
      {
        Context.throwAsScriptRuntimeEx(e);
      }
    }
  }
  
  public void addPostponedAction(PostponedAction action)
  {
    List<PostponedAction> actions = (List)this.postponedActions_.get();
    if (actions == null)
    {
      actions = new ArrayList();
      this.postponedActions_.set(actions);
    }
    actions.add(action);
  }
  
  protected void handleJavaScriptException(ScriptException scriptException, boolean triggerOnError)
  {
    HtmlPage page = scriptException.getPage();
    if ((triggerOnError) && (page != null))
    {
      WebWindow window = page.getEnclosingWindow();
      if (window != null)
      {
        Window w = (Window)window.getScriptObject();
        if (w != null) {
          try
          {
            w.triggerOnError(scriptException);
          }
          catch (Exception e)
          {
            handleJavaScriptException(new ScriptException(page, e, null), false);
          }
        }
      }
    }
    JavaScriptErrorListener javaScriptErrorListener = getWebClient().getJavaScriptErrorListener();
    if (javaScriptErrorListener != null) {
      javaScriptErrorListener.scriptException(page, scriptException);
    }
    if (getWebClient().getOptions().isThrowExceptionOnScriptError()) {
      throw scriptException;
    }
    LOG.info("Caught script exception", scriptException);
  }
  
  public void holdPosponedActions()
  {
    this.holdPostponedActions_ = true;
  }
  
  public void processPostponedActions()
  {
    doProcessPostponedActions();
  }
  
  private void readObject(ObjectInputStream in)
    throws IOException, ClassNotFoundException
  {
    in.defaultReadObject();
    initTransientFields();
  }
  
  private void initTransientFields()
  {
    this.javaScriptRunning_ = new ThreadLocal();
    this.postponedActions_ = new ThreadLocal();
    this.holdPostponedActions_ = false;
  }
  
  private static class FallbackCaller
    extends ScriptableObject
  {
    private static final long serialVersionUID = 5142592186670858001L;
    
    public Object get(String name, Scriptable start)
    {
      if ((start instanceof ScriptableWithFallbackGetter)) {
        return ((ScriptableWithFallbackGetter)start).getWithFallback(name);
      }
      return NOT_FOUND;
    }
    
    public String getClassName()
    {
      return "htmlUnitHelper-fallbackCaller";
    }
  }
  
  public Class<? extends SimpleScriptable> getJavaScriptClass(Class<?> c)
  {
    return (Class)this.jsConfig_.getDomJavaScriptMapping().get(c);
  }
  
  public JavaScriptConfiguration getJavaScriptConfiguration()
  {
    return this.jsConfig_;
  }
}
