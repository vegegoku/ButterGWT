package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeUri;

public class SafeImageCell
  extends AbstractCell<SafeUri>
{
  private static Template template;
  
  public SafeImageCell()
  {
    super(new String[0]);
    if (template == null) {
      template = (Template)GWT.create(Template.class);
    }
  }
  
  public void render(Cell.Context context, SafeUri value, SafeHtmlBuilder sb)
  {
    if (value != null) {
      sb.append(template.img(value));
    }
  }
  
  static abstract interface Template
    extends SafeHtmlTemplates
  {
    @SafeHtmlTemplates.Template("<img src=\"{0}\"/>")
    public abstract SafeHtml img(SafeUri paramSafeUri);
  }
}
