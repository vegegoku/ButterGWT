package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ParagraphBuilder;
import com.google.gwt.dom.client.ParagraphElement;

public class DomParagraphBuilder
  extends DomElementBuilderBase<ParagraphBuilder, ParagraphElement>
  implements ParagraphBuilder
{
  DomParagraphBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
