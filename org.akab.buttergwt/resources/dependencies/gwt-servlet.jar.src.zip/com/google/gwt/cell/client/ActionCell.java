package com.google.gwt.cell.client;

import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.safehtml.shared.SafeHtmlUtils;

public class ActionCell<C>
  extends AbstractCell<C>
{
  private final SafeHtml html;
  private final Delegate<C> delegate;
  
  public ActionCell(SafeHtml message, Delegate<C> delegate)
  {
    super(new String[] { "click", "keydown" });
    this.delegate = delegate;
    this.html = new SafeHtmlBuilder().appendHtmlConstant("<button type=\"button\" tabindex=\"-1\">").append(message).appendHtmlConstant("</button>").toSafeHtml();
  }
  
  public ActionCell(String text, Delegate<C> delegate)
  {
    this(SafeHtmlUtils.fromString(text), delegate);
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    if ("click".equals(event.getType()))
    {
      EventTarget eventTarget = event.getEventTarget();
      if (!Element.is(eventTarget)) {
        return;
      }
      if (parent.getFirstChildElement().isOrHasChild(Element.as(eventTarget))) {
        onEnterKeyDown(context, parent, value, event, valueUpdater);
      }
    }
  }
  
  public void render(Cell.Context context, C value, SafeHtmlBuilder sb)
  {
    sb.append(this.html);
  }
  
  protected void onEnterKeyDown(Cell.Context context, Element parent, C value, NativeEvent event, ValueUpdater<C> valueUpdater)
  {
    this.delegate.execute(value);
  }
  
  public static abstract interface Delegate<T>
  {
    public abstract void execute(T paramT);
  }
}
