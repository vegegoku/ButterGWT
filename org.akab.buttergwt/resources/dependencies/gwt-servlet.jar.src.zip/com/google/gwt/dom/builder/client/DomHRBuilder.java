package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.HRBuilder;
import com.google.gwt.dom.client.HRElement;

public class DomHRBuilder
  extends DomElementBuilderBase<HRBuilder, HRElement>
  implements HRBuilder
{
  DomHRBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
}
