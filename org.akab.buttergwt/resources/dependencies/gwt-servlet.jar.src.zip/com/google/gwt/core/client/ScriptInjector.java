package com.google.gwt.core.client;

public class ScriptInjector
{
  public static class FromString
  {
    private boolean removeTag = true;
    private final String scriptBody;
    private JavaScriptObject window;
    
    public FromString(String scriptBody)
    {
      this.scriptBody = scriptBody;
    }
    
    public JavaScriptObject inject()
    {
      JavaScriptObject wnd = this.window == null ? ScriptInjector.access$000() : this.window;
      assert (wnd != null);
      JavaScriptObject doc = ScriptInjector.nativeGetDocument(wnd);
      assert (doc != null);
      JavaScriptObject scriptElement = ScriptInjector.nativeMakeScriptElement(doc);
      assert (scriptElement != null);
      ScriptInjector.nativeSetText(scriptElement, this.scriptBody);
      ScriptInjector.nativeAttachToHead(doc, scriptElement);
      if (this.removeTag) {
        ScriptInjector.nativeRemove(scriptElement);
      }
      return scriptElement;
    }
    
    public FromString setRemoveTag(boolean removeTag)
    {
      this.removeTag = removeTag;
      return this;
    }
    
    public FromString setWindow(JavaScriptObject window)
    {
      this.window = window;
      return this;
    }
  }
  
  public static class FromUrl
  {
    private Callback<Void, Exception> callback;
    private boolean removeTag = false;
    private final String scriptUrl;
    private JavaScriptObject window;
    
    private FromUrl(String scriptUrl)
    {
      this.scriptUrl = scriptUrl;
    }
    
    public JavaScriptObject inject()
    {
      JavaScriptObject wnd = this.window == null ? ScriptInjector.access$000() : this.window;
      assert (wnd != null);
      JavaScriptObject doc = ScriptInjector.nativeGetDocument(wnd);
      assert (doc != null);
      JavaScriptObject scriptElement = ScriptInjector.nativeMakeScriptElement(doc);
      assert (scriptElement != null);
      if ((this.callback != null) || (this.removeTag)) {
        ScriptInjector.attachListeners(scriptElement, this.callback, this.removeTag);
      }
      ScriptInjector.nativeSetSrc(scriptElement, this.scriptUrl);
      ScriptInjector.nativeAttachToHead(doc, scriptElement);
      return scriptElement;
    }
    
    public FromUrl setCallback(Callback<Void, Exception> callback)
    {
      this.callback = callback;
      return this;
    }
    
    public FromUrl setRemoveTag(boolean removeTag)
    {
      this.removeTag = removeTag;
      return this;
    }
    
    public FromUrl setWindow(JavaScriptObject window)
    {
      this.window = window;
      return this;
    }
  }
  
  public static final JavaScriptObject TOP_WINDOW = ;
  
  public static FromString fromString(String scriptBody)
  {
    return new FromString(scriptBody);
  }
  
  public static FromUrl fromUrl(String scriptUrl)
  {
    return new FromUrl(scriptUrl, null);
  }
  
  private static native void attachListeners(JavaScriptObject paramJavaScriptObject, Callback<Void, Exception> paramCallback, boolean paramBoolean);
  
  private static native void nativeAttachToHead(JavaScriptObject paramJavaScriptObject1, JavaScriptObject paramJavaScriptObject2);
  
  private static native JavaScriptObject nativeDefaultWindow();
  
  private static native JavaScriptObject nativeGetDocument(JavaScriptObject paramJavaScriptObject);
  
  private static native JavaScriptObject nativeMakeScriptElement(JavaScriptObject paramJavaScriptObject);
  
  private static native void nativeRemove(JavaScriptObject paramJavaScriptObject);
  
  private static native void nativeSetSrc(JavaScriptObject paramJavaScriptObject, String paramString);
  
  private static native void nativeSetText(JavaScriptObject paramJavaScriptObject, String paramString);
  
  private static native JavaScriptObject nativeTopWindow();
}
