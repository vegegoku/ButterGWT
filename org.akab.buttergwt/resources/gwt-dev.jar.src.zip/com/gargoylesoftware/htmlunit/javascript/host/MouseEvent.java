package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;
import java.util.LinkedList;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass
public class MouseEvent
  extends UIEvent
{
  public static final String TYPE_CLICK = "click";
  public static final String TYPE_DBL_CLICK = "dblclick";
  public static final String TYPE_MOUSE_OVER = "mouseover";
  public static final String TYPE_MOUSE_MOVE = "mousemove";
  public static final String TYPE_MOUSE_OUT = "mouseout";
  public static final String TYPE_MOUSE_DOWN = "mousedown";
  public static final String TYPE_MOUSE_UP = "mouseup";
  public static final String TYPE_CONTEXT_MENU = "contextmenu";
  public static final int BUTTON_LEFT = 0;
  public static final int BUTTON_MIDDLE = 1;
  public static final int BUTTON_RIGHT = 2;
  private static final int[] buttonCodeToIE = { 1, 4, 2 };
  private Integer screenX_;
  private Integer screenY_;
  private Integer clientX_;
  private Integer clientY_;
  private int button_;
  
  public MouseEvent()
  {
    this.screenX_ = Integer.valueOf(0);
    this.screenY_ = Integer.valueOf(0);
    setDetail(1L);
  }
  
  public MouseEvent(DomNode domNode, String type, boolean shiftKey, boolean ctrlKey, boolean altKey, int button)
  {
    super(domNode, type);
    setShiftKey(shiftKey);
    setCtrlKey(ctrlKey);
    setAltKey(altKey);
    setMetaKey(false);
    if ((button != 0) && (button != 1) && (button != 2)) {
      throw new IllegalArgumentException("Invalid button code: " + button);
    }
    this.button_ = button;
    if ("dblclick".equals(type)) {
      setDetail(2L);
    } else {
      setDetail(1L);
    }
  }
  
  @JsxGetter
  public int getClientX()
  {
    if (this.clientX_ == null) {
      this.clientX_ = Integer.valueOf(getScreenX());
    }
    return this.clientX_.intValue();
  }
  
  @JsxSetter
  public void setClientX(int value)
  {
    this.clientX_ = Integer.valueOf(value);
  }
  
  @JsxGetter
  public int getScreenX()
  {
    if (this.screenX_ == null)
    {
      HTMLElement target = (HTMLElement)getTarget();
      this.screenX_ = Integer.valueOf(target.getPosX() + 10);
    }
    return this.screenX_.intValue();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getPageX()
  {
    return getScreenX();
  }
  
  @JsxGetter
  public int getClientY()
  {
    if (this.clientY_ == null) {
      this.clientY_ = Integer.valueOf(getScreenY());
    }
    return this.clientY_.intValue();
  }
  
  @JsxSetter
  public void setClientY(int value)
  {
    this.clientY_ = Integer.valueOf(value);
  }
  
  @JsxGetter
  public int getScreenY()
  {
    if (this.screenY_ == null)
    {
      HTMLElement target = (HTMLElement)getTarget();
      this.screenY_ = Integer.valueOf(target.getPosY() + 10);
    }
    return this.screenY_.intValue();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getPageY()
  {
    return getScreenY();
  }
  
  @JsxGetter
  public int getButton()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_116))
    {
      if (getType().equals("contextmenu")) {
        return 0;
      }
      if (getType().equals("click")) {
        return this.button_;
      }
      return buttonCodeToIE[this.button_];
    }
    return this.button_;
  }
  
  @JsxSetter
  public void setButton(int value)
  {
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_116)) && (!"click".equals(getType()))) {
      switch (value)
      {
      case 1: 
        value = 0;
        break;
      case 4: 
        value = 1;
        break;
      case 2: 
        value = 2;
        break;
      }
    }
    this.button_ = value;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getWhich()
  {
    return this.button_ + 1;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void initMouseEvent(String type, boolean bubbles, boolean cancelable, Object view, int detail, int screenX, int screenY, int clientX, int clientY, boolean ctrlKey, boolean altKey, boolean shiftKey, boolean metaKey, int button, Object relatedTarget)
  {
    initUIEvent(type, bubbles, cancelable, view, detail);
    this.screenX_ = Integer.valueOf(screenX);
    this.screenY_ = Integer.valueOf(screenY);
    this.clientX_ = Integer.valueOf(clientX);
    this.clientY_ = Integer.valueOf(clientY);
    setCtrlKey(ctrlKey);
    setAltKey(altKey);
    setShiftKey(shiftKey);
    setMetaKey(metaKey);
    this.button_ = button;
  }
  
  public static MouseEvent getCurrentMouseEvent()
  {
    LinkedList<Event> events = (LinkedList)Context.getCurrentContext().getThreadLocal("Event#current");
    if ((events != null) && (!events.isEmpty()) && ((events.getLast() instanceof MouseEvent))) {
      return (MouseEvent)events.getLast();
    }
    return null;
  }
  
  static boolean isMouseEvent(String type)
  {
    return ("click".equals(type)) || ("mouseover".equals(type)) || ("mousemove".equals(type)) || ("mouseout".equals(type)) || ("mousedown".equals(type)) || ("mouseup".equals(type)) || ("contextmenu".equals(type));
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getAltKey()
  {
    return super.getAltKey();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getCtrlKey()
  {
    return super.getCtrlKey();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getShiftKey()
  {
    return super.getShiftKey();
  }
}
