package com.gargoylesoftware.htmlunit.javascript.host.arrays;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstant;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class Uint8ClampedArray
  extends ArrayBufferViewBase
{
  @JsxConstant
  public static final int BYTES_PER_ELEMENT = 1;
  
  @JsxConstructor
  public void constructor(Object object, Object byteOffset, Object length)
  {
    super.constructor(object, byteOffset, length);
  }
  
  protected byte[] toArray(Number number)
  {
    if (number.intValue() < 0) {
      number = Integer.valueOf(0);
    } else if (number.intValue() > 255) {
      number = Integer.valueOf(255);
    }
    return new byte[] { number.byteValue() };
  }
  
  protected Integer fromArray(byte[] array, int offset)
  {
    return Integer.valueOf(array[offset] & 0xFF);
  }
  
  protected int getBytesPerElement()
  {
    return 1;
  }
}
