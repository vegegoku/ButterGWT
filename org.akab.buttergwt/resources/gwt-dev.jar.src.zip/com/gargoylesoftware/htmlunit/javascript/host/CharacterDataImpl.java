package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.html.DomCharacterData;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={DomCharacterData.class})
public class CharacterDataImpl
  extends Node
{
  @JsxGetter
  public Object getData()
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    return domCharacterData.getData();
  }
  
  @JsxSetter
  public void setData(String newValue)
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    domCharacterData.setData(newValue);
  }
  
  @JsxGetter
  public int getLength()
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    return domCharacterData.getLength();
  }
  
  @JsxFunction
  public void appendData(String arg)
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    domCharacterData.appendData(arg);
  }
  
  @JsxFunction
  public void deleteData(int offset, int count)
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    domCharacterData.deleteData(offset, count);
  }
  
  @JsxFunction
  public void insertData(int offset, String arg)
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    domCharacterData.insertData(offset, arg);
  }
  
  @JsxFunction
  public void replaceData(int offset, int count, String arg)
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    domCharacterData.replaceData(offset, count, arg);
  }
  
  @JsxFunction
  public String substringData(int offset, int count)
  {
    DomCharacterData domCharacterData = (DomCharacterData)getDomNodeOrDie();
    return domCharacterData.substringData(offset, count);
  }
}
