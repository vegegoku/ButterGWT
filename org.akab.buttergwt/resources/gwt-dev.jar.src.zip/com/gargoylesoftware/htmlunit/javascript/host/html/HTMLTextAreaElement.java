package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlTextArea;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.FormField;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sourceforge.htmlunit.corejs.javascript.Context;

@JsxClass(domClasses={HtmlTextArea.class})
public class HTMLTextAreaElement
  extends FormField
{
  private static final Pattern NORMALIZE_VALUE_PATTERN = Pattern.compile("([^\\r])\\n");
  
  public String getType()
  {
    return "textarea";
  }
  
  public String getValue()
  {
    String value = ((HtmlTextArea)getDomNodeOrDie()).getText();
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.TEXTAREA_CRNL)) {
      value = NORMALIZE_VALUE_PATTERN.matcher(value).replaceAll("$1\r\n");
    }
    return value;
  }
  
  public void setValue(String value)
  {
    ((HtmlTextArea)getDomNodeOrDie()).setText(value);
  }
  
  @JsxGetter
  public int getCols()
  {
    String s = getDomNodeOrDie().getAttribute("cols");
    try
    {
      return Integer.parseInt(s);
    }
    catch (NumberFormatException e)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_COLS_RETURNS_MINUS1)) {
        return -1;
      }
    }
    return 20;
  }
  
  @JsxSetter
  public void setCols(String cols)
  {
    int i;
    try
    {
      i = Float.valueOf(cols).intValue();
      if (i < 0)
      {
        if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_SET_COLS_NEGATIVE_THROWS_EXCEPTION)) || (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_COLS_RETURNS_MINUS1))) {
          throw new NumberFormatException("New value for cols '" + cols + "' is smaller than zero.");
        }
        getDomNodeOrDie().setAttribute("cols", null);
        return;
      }
    }
    catch (NumberFormatException e)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_SET_COLS_THROWS_EXCEPTION)) {
        throw Context.throwAsScriptRuntimeEx(e);
      }
      if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_COLS_RETURNS_MINUS1)) {
        return;
      }
      i = 0;
    }
    getDomNodeOrDie().setAttribute("cols", Integer.toString(i));
  }
  
  @JsxGetter
  public int getRows()
  {
    String s = getDomNodeOrDie().getAttribute("rows");
    try
    {
      return Integer.parseInt(s);
    }
    catch (NumberFormatException e)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_ROWS_RETURNS_MINUS1)) {
        return -1;
      }
    }
    return 2;
  }
  
  @JsxSetter
  public void setRows(String rows)
  {
    int i;
    try
    {
      i = new Float(rows).intValue();
      if (i < 0)
      {
        if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_SET_ROWS_NEGATIVE_THROWS_EXCEPTION)) || (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_COLS_RETURNS_MINUS1))) {
          throw new NumberFormatException("New value for rows '" + rows + "' is smaller than zero.");
        }
        getDomNodeOrDie().setAttribute("rows", null);
        return;
      }
    }
    catch (NumberFormatException e)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_SET_ROWS_THROWS_EXCEPTION)) {
        throw Context.throwAsScriptRuntimeEx(e);
      }
      if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TEXT_AREA_COLS_RETURNS_MINUS1)) {
        return;
      }
      i = 0;
    }
    getDomNodeOrDie().setAttribute("rows", Integer.toString(i));
  }
  
  @JsxGetter
  public String getDefaultValue()
  {
    String value = ((HtmlTextArea)getDomNodeOrDie()).getDefaultValue();
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.TEXTAREA_CRNL)) {
      value = NORMALIZE_VALUE_PATTERN.matcher(value).replaceAll("$1\r\n");
    }
    return value;
  }
  
  @JsxSetter
  public void setDefaultValue(String defaultValue)
  {
    ((HtmlTextArea)getDomNodeOrDie()).setDefaultValue(defaultValue);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getTextLength()
  {
    return getValue().length();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getSelectionStart()
  {
    return ((HtmlTextArea)getDomNodeOrDie()).getSelectionStart();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSelectionStart(int start)
  {
    ((HtmlTextArea)getDomNodeOrDie()).setSelectionStart(start);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getSelectionEnd()
  {
    return ((HtmlTextArea)getDomNodeOrDie()).getSelectionEnd();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSelectionEnd(int end)
  {
    ((HtmlTextArea)getDomNodeOrDie()).setSelectionEnd(end);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSelectionRange(int start, int end)
  {
    setSelectionStart(start);
    setSelectionEnd(end);
  }
  
  @JsxFunction
  public void select()
  {
    ((HtmlTextArea)getDomNodeOrDie()).select();
  }
  
  @JsxGetter
  public boolean getReadOnly()
  {
    return ((HtmlTextArea)getDomNodeOrDie()).isReadOnly();
  }
  
  @JsxSetter
  public void setReadOnly(boolean readOnly)
  {
    ((HtmlTextArea)getDomNodeOrDie()).setReadOnly(readOnly);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getAccessKey()
  {
    return super.getAccessKey();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setAccessKey(String accessKey)
  {
    super.setAccessKey(accessKey);
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "inline";
    }
    return "inline-block";
  }
}
