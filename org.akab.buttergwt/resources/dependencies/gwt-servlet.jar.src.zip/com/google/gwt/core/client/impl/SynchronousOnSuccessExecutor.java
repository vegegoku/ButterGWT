package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.RunAsyncCallback;

class SynchronousOnSuccessExecutor
  extends OnSuccessExecutor
{
  void execute(AsyncFragmentLoader fragmentLoader, RunAsyncCallback callback)
  {
    fragmentLoader.executeOnSuccess0(callback);
  }
}
