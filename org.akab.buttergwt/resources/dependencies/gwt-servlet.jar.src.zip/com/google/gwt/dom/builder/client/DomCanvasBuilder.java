package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.CanvasBuilder;
import com.google.gwt.dom.client.CanvasElement;

public class DomCanvasBuilder
  extends DomElementBuilderBase<CanvasBuilder, CanvasElement>
  implements CanvasBuilder
{
  DomCanvasBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
  
  public CanvasBuilder height(int height)
  {
    ((CanvasElement)assertCanAddAttribute()).setHeight(height);
    return this;
  }
  
  public CanvasBuilder width(int width)
  {
    ((CanvasElement)assertCanAddAttribute()).setWidth(width);
    return this;
  }
}
