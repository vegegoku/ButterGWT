package com.google.gwt.codegen.server;

import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class LoggingCodeGenContext
  implements CodeGenContext
{
  private final Logger logger;
  
  protected LoggingCodeGenContext()
  {
    this(Logger.getAnonymousLogger());
  }
  
  protected LoggingCodeGenContext(String loggerName)
  {
    this(Logger.getLogger(loggerName));
  }
  
  protected LoggingCodeGenContext(Logger logger)
  {
    this.logger = logger;
  }
  
  public JavaSourceWriterBuilder addClass(String pkgName, String className)
  {
    return addClass(null, pkgName, className);
  }
  
  public abstract JavaSourceWriterBuilder addClass(String paramString1, String paramString2, String paramString3);
  
  public void error(String msg)
  {
    this.logger.log(Level.SEVERE, msg);
  }
  
  public void error(String msg, Throwable cause)
  {
    this.logger.log(Level.SEVERE, msg, cause);
  }
  
  public void error(Throwable cause)
  {
    this.logger.log(Level.SEVERE, cause.getMessage(), cause);
  }
  
  public void warn(String msg)
  {
    this.logger.log(Level.WARNING, msg);
  }
  
  public void warn(String msg, Throwable cause)
  {
    this.logger.log(Level.WARNING, msg);
  }
  
  public void warn(Throwable cause)
  {
    this.logger.log(Level.WARNING, cause.getMessage(), cause);
  }
}
