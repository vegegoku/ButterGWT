package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;

@JsxClass
public class BoxObject
  extends SimpleScriptable
{
  private final HTMLElement element_;
  
  public BoxObject()
  {
    this(null);
  }
  
  public BoxObject(HTMLElement element)
  {
    this.element_ = element;
  }
  
  @JsxGetter
  public HTMLElement getElement()
  {
    return this.element_;
  }
  
  @JsxGetter
  public Object getFirstChild()
  {
    return this.element_.getFirstChild();
  }
  
  @JsxGetter
  public Object getLastChild()
  {
    return this.element_.getLastChild();
  }
  
  @JsxGetter
  public Object getNextSibling()
  {
    return this.element_.getNextSibling();
  }
  
  @JsxGetter
  public Object getPreviousSibling()
  {
    return this.element_.getPreviousSibling();
  }
  
  @JsxGetter
  public int getX()
  {
    return this.element_.getPosX();
  }
  
  @JsxGetter
  public int getY()
  {
    return this.element_.getPosY();
  }
  
  @JsxGetter
  public int getScreenX()
  {
    return getX();
  }
  
  @JsxGetter
  public int getScreenY()
  {
    return getY() + 121;
  }
  
  @JsxGetter
  public int getWidth()
  {
    return this.element_.getClientWidth();
  }
  
  @JsxGetter
  public int getHeight()
  {
    return this.element_.getClientHeight();
  }
}
