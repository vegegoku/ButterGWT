package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import net.sourceforge.htmlunit.corejs.javascript.BaseFunction;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.JavaScriptException;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

public class EventHandler
  extends BaseFunction
{
  private final DomNode node_;
  private final String eventName_;
  private final String jsSnippet_;
  private Function realFunction_;
  
  public EventHandler(DomNode node, String eventName, String jsSnippet)
  {
    this.node_ = node;
    this.eventName_ = eventName;
    String functionSignature;
    String functionSignature;
    if (node.getPage().getEnclosingWindow().getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_EVENT_NO_PARAMETER)) {
      functionSignature = "function " + eventName + "()";
    } else {
      functionSignature = "function " + eventName + "(event)";
    }
    this.jsSnippet_ = (functionSignature + " {" + jsSnippet + "\n}");
    
    Window w = (Window)node.getPage().getEnclosingWindow().getScriptObject();
    Scriptable function = (Scriptable)w.get("Function", w);
    setPrototype(function.getPrototype());
  }
  
  public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
    throws JavaScriptException
  {
    SimpleScriptable jsObj = (SimpleScriptable)this.node_.getScriptObject();
    if (this.realFunction_ == null)
    {
      this.realFunction_ = cx.compileFunction(jsObj, this.jsSnippet_, this.eventName_ + " event for " + this.node_ + " in " + this.node_.getPage().getUrl(), 0, null);
      
      this.realFunction_.setParentScope(jsObj);
    }
    Object result = this.realFunction_.call(cx, scope, thisObj, args);
    return result;
  }
  
  public Object getDefaultValue(Class<?> typeHint)
  {
    return this.jsSnippet_;
  }
  
  public Object get(String name, Scriptable start)
  {
    if ("toString".equals(name)) {
      new BaseFunction()
      {
        public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
        {
          return EventHandler.this.jsSnippet_;
        }
      };
    }
    return super.get(name, start);
  }
}
