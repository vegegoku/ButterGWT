package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface OptionRole
  extends InputRole
{
  public abstract String getAriaCheckedState(Element paramElement);
  
  public abstract String getAriaPosinsetProperty(Element paramElement);
  
  public abstract String getAriaSelectedState(Element paramElement);
  
  public abstract String getAriaSetsizeProperty(Element paramElement);
  
  public abstract void removeAriaCheckedState(Element paramElement);
  
  public abstract void removeAriaPosinsetProperty(Element paramElement);
  
  public abstract void removeAriaSelectedState(Element paramElement);
  
  public abstract void removeAriaSetsizeProperty(Element paramElement);
  
  public abstract void setAriaCheckedState(Element paramElement, CheckedValue paramCheckedValue);
  
  public abstract void setAriaPosinsetProperty(Element paramElement, int paramInt);
  
  public abstract void setAriaSelectedState(Element paramElement, SelectedValue paramSelectedValue);
  
  public abstract void setAriaSetsizeProperty(Element paramElement, int paramInt);
}
