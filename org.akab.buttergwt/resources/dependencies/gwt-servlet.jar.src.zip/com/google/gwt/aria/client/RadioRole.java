package com.google.gwt.aria.client;

public abstract interface RadioRole
  extends CheckboxRole, OptionRole
{}
