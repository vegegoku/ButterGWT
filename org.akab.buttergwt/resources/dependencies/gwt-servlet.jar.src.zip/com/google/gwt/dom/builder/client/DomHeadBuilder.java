package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.HeadBuilder;
import com.google.gwt.dom.client.HeadElement;
import com.google.gwt.safehtml.shared.SafeHtml;

public class DomHeadBuilder
  extends DomElementBuilderBase<HeadBuilder, HeadElement>
  implements HeadBuilder
{
  DomHeadBuilder(DomBuilderImpl delegate)
  {
    super(delegate, false);
  }
  
  public HeadBuilder html(SafeHtml html)
  {
    throw new UnsupportedOperationException();
  }
  
  public HeadBuilder text(String text)
  {
    throw new UnsupportedOperationException();
  }
}
