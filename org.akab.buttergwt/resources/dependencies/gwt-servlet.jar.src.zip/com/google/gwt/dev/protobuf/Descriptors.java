package com.google.gwt.dev.protobuf;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class Descriptors
{
  public static final class FileDescriptor
  {
    private DescriptorProtos.FileDescriptorProto proto;
    private final Descriptors.Descriptor[] messageTypes;
    private final Descriptors.EnumDescriptor[] enumTypes;
    private final Descriptors.ServiceDescriptor[] services;
    private final Descriptors.FieldDescriptor[] extensions;
    private final FileDescriptor[] dependencies;
    private final FileDescriptor[] publicDependencies;
    private final Descriptors.DescriptorPool pool;
    
    public DescriptorProtos.FileDescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public String getPackage()
    {
      return this.proto.getPackage();
    }
    
    public DescriptorProtos.FileOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    public List<Descriptors.Descriptor> getMessageTypes()
    {
      return Collections.unmodifiableList(Arrays.asList(this.messageTypes));
    }
    
    public List<Descriptors.EnumDescriptor> getEnumTypes()
    {
      return Collections.unmodifiableList(Arrays.asList(this.enumTypes));
    }
    
    public List<Descriptors.ServiceDescriptor> getServices()
    {
      return Collections.unmodifiableList(Arrays.asList(this.services));
    }
    
    public List<Descriptors.FieldDescriptor> getExtensions()
    {
      return Collections.unmodifiableList(Arrays.asList(this.extensions));
    }
    
    public List<FileDescriptor> getDependencies()
    {
      return Collections.unmodifiableList(Arrays.asList(this.dependencies));
    }
    
    public List<FileDescriptor> getPublicDependencies()
    {
      return Collections.unmodifiableList(Arrays.asList(this.publicDependencies));
    }
    
    public Descriptors.Descriptor findMessageTypeByName(String name)
    {
      if (name.indexOf('.') != -1) {
        return null;
      }
      if (getPackage().length() > 0) {
        name = getPackage() + '.' + name;
      }
      Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
      if ((result != null) && ((result instanceof Descriptors.Descriptor)) && (result.getFile() == this)) {
        return (Descriptors.Descriptor)result;
      }
      return null;
    }
    
    public Descriptors.EnumDescriptor findEnumTypeByName(String name)
    {
      if (name.indexOf('.') != -1) {
        return null;
      }
      if (getPackage().length() > 0) {
        name = getPackage() + '.' + name;
      }
      Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
      if ((result != null) && ((result instanceof Descriptors.EnumDescriptor)) && (result.getFile() == this)) {
        return (Descriptors.EnumDescriptor)result;
      }
      return null;
    }
    
    public Descriptors.ServiceDescriptor findServiceByName(String name)
    {
      if (name.indexOf('.') != -1) {
        return null;
      }
      if (getPackage().length() > 0) {
        name = getPackage() + '.' + name;
      }
      Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
      if ((result != null) && ((result instanceof Descriptors.ServiceDescriptor)) && (result.getFile() == this)) {
        return (Descriptors.ServiceDescriptor)result;
      }
      return null;
    }
    
    public Descriptors.FieldDescriptor findExtensionByName(String name)
    {
      if (name.indexOf('.') != -1) {
        return null;
      }
      if (getPackage().length() > 0) {
        name = getPackage() + '.' + name;
      }
      Descriptors.GenericDescriptor result = this.pool.findSymbol(name);
      if ((result != null) && ((result instanceof Descriptors.FieldDescriptor)) && (result.getFile() == this)) {
        return (Descriptors.FieldDescriptor)result;
      }
      return null;
    }
    
    public static FileDescriptor buildFrom(DescriptorProtos.FileDescriptorProto proto, FileDescriptor[] dependencies)
      throws Descriptors.DescriptorValidationException
    {
      Descriptors.DescriptorPool pool = new Descriptors.DescriptorPool(dependencies);
      FileDescriptor result = new FileDescriptor(proto, dependencies, pool);
      if (dependencies.length != proto.getDependencyCount()) {
        throw new Descriptors.DescriptorValidationException(result, "Dependencies passed to FileDescriptor.buildFrom() don't match those listed in the FileDescriptorProto.", null);
      }
      for (int i = 0; i < proto.getDependencyCount(); i++) {
        if (!dependencies[i].getName().equals(proto.getDependency(i))) {
          throw new Descriptors.DescriptorValidationException(result, "Dependencies passed to FileDescriptor.buildFrom() don't match those listed in the FileDescriptorProto.", null);
        }
      }
      result.crossLink();
      return result;
    }
    
    public static void internalBuildGeneratedFileFrom(String[] descriptorDataParts, FileDescriptor[] dependencies, InternalDescriptorAssigner descriptorAssigner)
    {
      StringBuilder descriptorData = new StringBuilder();
      for (String part : descriptorDataParts) {
        descriptorData.append(part);
      }
      byte[] descriptorBytes;
      try
      {
        descriptorBytes = descriptorData.toString().getBytes("ISO-8859-1");
      }
      catch (UnsupportedEncodingException e)
      {
        throw new RuntimeException("Standard encoding ISO-8859-1 not supported by JVM.", e);
      }
      DescriptorProtos.FileDescriptorProto proto;
      try
      {
        proto = DescriptorProtos.FileDescriptorProto.parseFrom(descriptorBytes);
      }
      catch (InvalidProtocolBufferException e)
      {
        throw new IllegalArgumentException("Failed to parse protocol buffer descriptor for generated code.", e);
      }
      FileDescriptor result;
      try
      {
        result = buildFrom(proto, dependencies);
      }
      catch (Descriptors.DescriptorValidationException e)
      {
        throw new IllegalArgumentException("Invalid embedded descriptor for \"" + proto.getName() + "\".", e);
      }
      ExtensionRegistry registry = descriptorAssigner.assignDescriptors(result);
      if (registry != null)
      {
        try
        {
          proto = DescriptorProtos.FileDescriptorProto.parseFrom(descriptorBytes, registry);
        }
        catch (InvalidProtocolBufferException e)
        {
          throw new IllegalArgumentException("Failed to parse protocol buffer descriptor for generated code.", e);
        }
        result.setProto(proto);
      }
    }
    
    private FileDescriptor(DescriptorProtos.FileDescriptorProto proto, FileDescriptor[] dependencies, Descriptors.DescriptorPool pool)
      throws Descriptors.DescriptorValidationException
    {
      this.pool = pool;
      this.proto = proto;
      this.dependencies = ((FileDescriptor[])dependencies.clone());
      this.publicDependencies = new FileDescriptor[proto.getPublicDependencyCount()];
      for (int i = 0; i < proto.getPublicDependencyCount(); i++)
      {
        int index = proto.getPublicDependency(i);
        if ((index < 0) || (index >= this.dependencies.length)) {
          throw new Descriptors.DescriptorValidationException(this, "Invalid public dependency index.", null);
        }
        this.publicDependencies[i] = this.dependencies[proto.getPublicDependency(i)];
      }
      pool.addPackage(getPackage(), this);
      
      this.messageTypes = new Descriptors.Descriptor[proto.getMessageTypeCount()];
      for (int i = 0; i < proto.getMessageTypeCount(); i++) {
        this.messageTypes[i] = new Descriptors.Descriptor(proto.getMessageType(i), this, null, i, null);
      }
      this.enumTypes = new Descriptors.EnumDescriptor[proto.getEnumTypeCount()];
      for (int i = 0; i < proto.getEnumTypeCount(); i++) {
        this.enumTypes[i] = new Descriptors.EnumDescriptor(proto.getEnumType(i), this, null, i, null);
      }
      this.services = new Descriptors.ServiceDescriptor[proto.getServiceCount()];
      for (int i = 0; i < proto.getServiceCount(); i++) {
        this.services[i] = new Descriptors.ServiceDescriptor(proto.getService(i), this, i, null);
      }
      this.extensions = new Descriptors.FieldDescriptor[proto.getExtensionCount()];
      for (int i = 0; i < proto.getExtensionCount(); i++) {
        this.extensions[i] = new Descriptors.FieldDescriptor(proto.getExtension(i), this, null, i, true, null);
      }
    }
    
    private void crossLink()
      throws Descriptors.DescriptorValidationException
    {
      for (Descriptors.Descriptor messageType : this.messageTypes) {
        messageType.crossLink();
      }
      for (Descriptors.ServiceDescriptor service : this.services) {
        service.crossLink();
      }
      for (Descriptors.FieldDescriptor extension : this.extensions) {
        extension.crossLink();
      }
    }
    
    private void setProto(DescriptorProtos.FileDescriptorProto proto)
    {
      this.proto = proto;
      for (int i = 0; i < this.messageTypes.length; i++) {
        this.messageTypes[i].setProto(proto.getMessageType(i));
      }
      for (int i = 0; i < this.enumTypes.length; i++) {
        this.enumTypes[i].setProto(proto.getEnumType(i));
      }
      for (int i = 0; i < this.services.length; i++) {
        this.services[i].setProto(proto.getService(i));
      }
      for (int i = 0; i < this.extensions.length; i++) {
        this.extensions[i].setProto(proto.getExtension(i));
      }
    }
    
    public static abstract interface InternalDescriptorAssigner
    {
      public abstract ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor paramFileDescriptor);
    }
  }
  
  public static final class Descriptor
    implements Descriptors.GenericDescriptor
  {
    private final int index;
    private DescriptorProtos.DescriptorProto proto;
    private final String fullName;
    private final Descriptors.FileDescriptor file;
    private final Descriptor containingType;
    private final Descriptor[] nestedTypes;
    private final Descriptors.EnumDescriptor[] enumTypes;
    private final Descriptors.FieldDescriptor[] fields;
    private final Descriptors.FieldDescriptor[] extensions;
    
    public int getIndex()
    {
      return this.index;
    }
    
    public DescriptorProtos.DescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public String getFullName()
    {
      return this.fullName;
    }
    
    public Descriptors.FileDescriptor getFile()
    {
      return this.file;
    }
    
    public Descriptor getContainingType()
    {
      return this.containingType;
    }
    
    public DescriptorProtos.MessageOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    public List<Descriptors.FieldDescriptor> getFields()
    {
      return Collections.unmodifiableList(Arrays.asList(this.fields));
    }
    
    public List<Descriptors.FieldDescriptor> getExtensions()
    {
      return Collections.unmodifiableList(Arrays.asList(this.extensions));
    }
    
    public List<Descriptor> getNestedTypes()
    {
      return Collections.unmodifiableList(Arrays.asList(this.nestedTypes));
    }
    
    public List<Descriptors.EnumDescriptor> getEnumTypes()
    {
      return Collections.unmodifiableList(Arrays.asList(this.enumTypes));
    }
    
    public boolean isExtensionNumber(int number)
    {
      for (DescriptorProtos.DescriptorProto.ExtensionRange range : this.proto.getExtensionRangeList()) {
        if ((range.getStart() <= number) && (number < range.getEnd())) {
          return true;
        }
      }
      return false;
    }
    
    public Descriptors.FieldDescriptor findFieldByName(String name)
    {
      Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
      if ((result != null) && ((result instanceof Descriptors.FieldDescriptor))) {
        return (Descriptors.FieldDescriptor)result;
      }
      return null;
    }
    
    public Descriptors.FieldDescriptor findFieldByNumber(int number)
    {
      return (Descriptors.FieldDescriptor)Descriptors.FileDescriptor.access$1200(this.file).fieldsByNumber.get(new Descriptors.DescriptorPool.DescriptorIntPair(this, number));
    }
    
    public Descriptor findNestedTypeByName(String name)
    {
      Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
      if ((result != null) && ((result instanceof Descriptor))) {
        return (Descriptor)result;
      }
      return null;
    }
    
    public Descriptors.EnumDescriptor findEnumTypeByName(String name)
    {
      Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
      if ((result != null) && ((result instanceof Descriptors.EnumDescriptor))) {
        return (Descriptors.EnumDescriptor)result;
      }
      return null;
    }
    
    private Descriptor(DescriptorProtos.DescriptorProto proto, Descriptors.FileDescriptor file, Descriptor parent, int index)
      throws Descriptors.DescriptorValidationException
    {
      this.index = index;
      this.proto = proto;
      this.fullName = Descriptors.computeFullName(file, parent, proto.getName());
      this.file = file;
      this.containingType = parent;
      
      this.nestedTypes = new Descriptor[proto.getNestedTypeCount()];
      for (int i = 0; i < proto.getNestedTypeCount(); i++) {
        this.nestedTypes[i] = new Descriptor(proto.getNestedType(i), file, this, i);
      }
      this.enumTypes = new Descriptors.EnumDescriptor[proto.getEnumTypeCount()];
      for (int i = 0; i < proto.getEnumTypeCount(); i++) {
        this.enumTypes[i] = new Descriptors.EnumDescriptor(proto.getEnumType(i), file, this, i, null);
      }
      this.fields = new Descriptors.FieldDescriptor[proto.getFieldCount()];
      for (int i = 0; i < proto.getFieldCount(); i++) {
        this.fields[i] = new Descriptors.FieldDescriptor(proto.getField(i), file, this, i, false, null);
      }
      this.extensions = new Descriptors.FieldDescriptor[proto.getExtensionCount()];
      for (int i = 0; i < proto.getExtensionCount(); i++) {
        this.extensions[i] = new Descriptors.FieldDescriptor(proto.getExtension(i), file, this, i, true, null);
      }
      Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
    }
    
    private void crossLink()
      throws Descriptors.DescriptorValidationException
    {
      for (Descriptor nestedType : this.nestedTypes) {
        nestedType.crossLink();
      }
      for (Descriptors.FieldDescriptor field : this.fields) {
        field.crossLink();
      }
      for (Descriptors.FieldDescriptor extension : this.extensions) {
        extension.crossLink();
      }
    }
    
    private void setProto(DescriptorProtos.DescriptorProto proto)
    {
      this.proto = proto;
      for (int i = 0; i < this.nestedTypes.length; i++) {
        this.nestedTypes[i].setProto(proto.getNestedType(i));
      }
      for (int i = 0; i < this.enumTypes.length; i++) {
        this.enumTypes[i].setProto(proto.getEnumType(i));
      }
      for (int i = 0; i < this.fields.length; i++) {
        this.fields[i].setProto(proto.getField(i));
      }
      for (int i = 0; i < this.extensions.length; i++) {
        this.extensions[i].setProto(proto.getExtension(i));
      }
    }
  }
  
  public static final class FieldDescriptor
    implements Descriptors.GenericDescriptor, Comparable<FieldDescriptor>, FieldSet.FieldDescriptorLite<FieldDescriptor>
  {
    public int getIndex()
    {
      return this.index;
    }
    
    public DescriptorProtos.FieldDescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public int getNumber()
    {
      return this.proto.getNumber();
    }
    
    public String getFullName()
    {
      return this.fullName;
    }
    
    public JavaType getJavaType()
    {
      return this.type.getJavaType();
    }
    
    public WireFormat.JavaType getLiteJavaType()
    {
      return getLiteType().getJavaType();
    }
    
    public Descriptors.FileDescriptor getFile()
    {
      return this.file;
    }
    
    public Type getType()
    {
      return this.type;
    }
    
    public WireFormat.FieldType getLiteType()
    {
      return table[this.type.ordinal()];
    }
    
    private static final WireFormat.FieldType[] table = ;
    private final int index;
    private DescriptorProtos.FieldDescriptorProto proto;
    private final String fullName;
    private final Descriptors.FileDescriptor file;
    private final Descriptors.Descriptor extensionScope;
    private Type type;
    private Descriptors.Descriptor containingType;
    private Descriptors.Descriptor messageType;
    private Descriptors.EnumDescriptor enumType;
    private Object defaultValue;
    
    public boolean isRequired()
    {
      return this.proto.getLabel() == DescriptorProtos.FieldDescriptorProto.Label.LABEL_REQUIRED;
    }
    
    public boolean isOptional()
    {
      return this.proto.getLabel() == DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
    }
    
    public boolean isRepeated()
    {
      return this.proto.getLabel() == DescriptorProtos.FieldDescriptorProto.Label.LABEL_REPEATED;
    }
    
    public boolean isPacked()
    {
      return getOptions().getPacked();
    }
    
    public boolean isPackable()
    {
      return (isRepeated()) && (getLiteType().isPackable());
    }
    
    public boolean hasDefaultValue()
    {
      return this.proto.hasDefaultValue();
    }
    
    public Object getDefaultValue()
    {
      if (getJavaType() == JavaType.MESSAGE) {
        throw new UnsupportedOperationException("FieldDescriptor.getDefaultValue() called on an embedded message field.");
      }
      return this.defaultValue;
    }
    
    public DescriptorProtos.FieldOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    public boolean isExtension()
    {
      return this.proto.hasExtendee();
    }
    
    public Descriptors.Descriptor getContainingType()
    {
      return this.containingType;
    }
    
    public Descriptors.Descriptor getExtensionScope()
    {
      if (!isExtension()) {
        throw new UnsupportedOperationException("This field is not an extension.");
      }
      return this.extensionScope;
    }
    
    public Descriptors.Descriptor getMessageType()
    {
      if (getJavaType() != JavaType.MESSAGE) {
        throw new UnsupportedOperationException("This field is not of message type.");
      }
      return this.messageType;
    }
    
    public Descriptors.EnumDescriptor getEnumType()
    {
      if (getJavaType() != JavaType.ENUM) {
        throw new UnsupportedOperationException("This field is not of enum type.");
      }
      return this.enumType;
    }
    
    public int compareTo(FieldDescriptor other)
    {
      if (other.containingType != this.containingType) {
        throw new IllegalArgumentException("FieldDescriptors can only be compared to other FieldDescriptors for fields of the same message type.");
      }
      return getNumber() - other.getNumber();
    }
    
    public static enum Type
    {
      DOUBLE(Descriptors.FieldDescriptor.JavaType.DOUBLE),  FLOAT(Descriptors.FieldDescriptor.JavaType.FLOAT),  INT64(Descriptors.FieldDescriptor.JavaType.LONG),  UINT64(Descriptors.FieldDescriptor.JavaType.LONG),  INT32(Descriptors.FieldDescriptor.JavaType.INT),  FIXED64(Descriptors.FieldDescriptor.JavaType.LONG),  FIXED32(Descriptors.FieldDescriptor.JavaType.INT),  BOOL(Descriptors.FieldDescriptor.JavaType.BOOLEAN),  STRING(Descriptors.FieldDescriptor.JavaType.STRING),  GROUP(Descriptors.FieldDescriptor.JavaType.MESSAGE),  MESSAGE(Descriptors.FieldDescriptor.JavaType.MESSAGE),  BYTES(Descriptors.FieldDescriptor.JavaType.BYTE_STRING),  UINT32(Descriptors.FieldDescriptor.JavaType.INT),  ENUM(Descriptors.FieldDescriptor.JavaType.ENUM),  SFIXED32(Descriptors.FieldDescriptor.JavaType.INT),  SFIXED64(Descriptors.FieldDescriptor.JavaType.LONG),  SINT32(Descriptors.FieldDescriptor.JavaType.INT),  SINT64(Descriptors.FieldDescriptor.JavaType.LONG);
      
      private Descriptors.FieldDescriptor.JavaType javaType;
      
      private Type(Descriptors.FieldDescriptor.JavaType javaType)
      {
        this.javaType = javaType;
      }
      
      public DescriptorProtos.FieldDescriptorProto.Type toProto()
      {
        return DescriptorProtos.FieldDescriptorProto.Type.valueOf(ordinal() + 1);
      }
      
      public Descriptors.FieldDescriptor.JavaType getJavaType()
      {
        return this.javaType;
      }
      
      public static Type valueOf(DescriptorProtos.FieldDescriptorProto.Type type)
      {
        return values()[(type.getNumber() - 1)];
      }
    }
    
    static
    {
      if (Type.values().length != DescriptorProtos.FieldDescriptorProto.Type.values().length) {
        throw new RuntimeException("descriptor.proto has a new declared type but Desrciptors.java wasn't updated.");
      }
    }
    
    public static enum JavaType
    {
      INT(Integer.valueOf(0)),  LONG(Long.valueOf(0L)),  FLOAT(Float.valueOf(0.0F)),  DOUBLE(Double.valueOf(0.0D)),  BOOLEAN(Boolean.valueOf(false)),  STRING(""),  BYTE_STRING(ByteString.EMPTY),  ENUM(null),  MESSAGE(null);
      
      private final Object defaultDefault;
      
      private JavaType(Object defaultDefault)
      {
        this.defaultDefault = defaultDefault;
      }
    }
    
    private FieldDescriptor(DescriptorProtos.FieldDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.Descriptor parent, int index, boolean isExtension)
      throws Descriptors.DescriptorValidationException
    {
      this.index = index;
      this.proto = proto;
      this.fullName = Descriptors.computeFullName(file, parent, proto.getName());
      this.file = file;
      if (proto.hasType()) {
        this.type = Type.valueOf(proto.getType());
      }
      if (getNumber() <= 0) {
        throw new Descriptors.DescriptorValidationException(this, "Field numbers must be positive integers.", null);
      }
      if ((proto.getOptions().getPacked()) && (!isPackable())) {
        throw new Descriptors.DescriptorValidationException(this, "[packed = true] can only be specified for repeated primitive fields.", null);
      }
      if (isExtension)
      {
        if (!proto.hasExtendee()) {
          throw new Descriptors.DescriptorValidationException(this, "FieldDescriptorProto.extendee not set for extension field.", null);
        }
        this.containingType = null;
        if (parent != null) {
          this.extensionScope = parent;
        } else {
          this.extensionScope = null;
        }
      }
      else
      {
        if (proto.hasExtendee()) {
          throw new Descriptors.DescriptorValidationException(this, "FieldDescriptorProto.extendee set for non-extension field.", null);
        }
        this.containingType = parent;
        this.extensionScope = null;
      }
      Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
    }
    
    private void crossLink()
      throws Descriptors.DescriptorValidationException
    {
      if (this.proto.hasExtendee())
      {
        Descriptors.GenericDescriptor extendee = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getExtendee(), this, Descriptors.DescriptorPool.SearchFilter.TYPES_ONLY);
        if (!(extendee instanceof Descriptors.Descriptor)) {
          throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getExtendee() + "\" is not a message type.", null);
        }
        this.containingType = ((Descriptors.Descriptor)extendee);
        if (!getContainingType().isExtensionNumber(getNumber())) {
          throw new Descriptors.DescriptorValidationException(this, '"' + getContainingType().getFullName() + "\" does not declare " + getNumber() + " as an extension number.", null);
        }
      }
      if (this.proto.hasTypeName())
      {
        Descriptors.GenericDescriptor typeDescriptor = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getTypeName(), this, Descriptors.DescriptorPool.SearchFilter.TYPES_ONLY);
        if (!this.proto.hasType()) {
          if ((typeDescriptor instanceof Descriptors.Descriptor)) {
            this.type = Type.MESSAGE;
          } else if ((typeDescriptor instanceof Descriptors.EnumDescriptor)) {
            this.type = Type.ENUM;
          } else {
            throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getTypeName() + "\" is not a type.", null);
          }
        }
        if (getJavaType() == JavaType.MESSAGE)
        {
          if (!(typeDescriptor instanceof Descriptors.Descriptor)) {
            throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getTypeName() + "\" is not a message type.", null);
          }
          this.messageType = ((Descriptors.Descriptor)typeDescriptor);
          if (this.proto.hasDefaultValue()) {
            throw new Descriptors.DescriptorValidationException(this, "Messages can't have default values.", null);
          }
        }
        else if (getJavaType() == JavaType.ENUM)
        {
          if (!(typeDescriptor instanceof Descriptors.EnumDescriptor)) {
            throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getTypeName() + "\" is not an enum type.", null);
          }
          this.enumType = ((Descriptors.EnumDescriptor)typeDescriptor);
        }
        else
        {
          throw new Descriptors.DescriptorValidationException(this, "Field with primitive type has type_name.", null);
        }
      }
      else if ((getJavaType() == JavaType.MESSAGE) || (getJavaType() == JavaType.ENUM))
      {
        throw new Descriptors.DescriptorValidationException(this, "Field with message or enum type missing type_name.", null);
      }
      if (this.proto.hasDefaultValue())
      {
        if (isRepeated()) {
          throw new Descriptors.DescriptorValidationException(this, "Repeated fields cannot have default values.", null);
        }
        try
        {
          switch (Descriptors.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$Type[getType().ordinal()])
          {
          case 1: 
          case 2: 
          case 3: 
            this.defaultValue = Integer.valueOf(TextFormat.parseInt32(this.proto.getDefaultValue()));
            break;
          case 4: 
          case 5: 
            this.defaultValue = Integer.valueOf(TextFormat.parseUInt32(this.proto.getDefaultValue()));
            break;
          case 6: 
          case 7: 
          case 8: 
            this.defaultValue = Long.valueOf(TextFormat.parseInt64(this.proto.getDefaultValue()));
            break;
          case 9: 
          case 10: 
            this.defaultValue = Long.valueOf(TextFormat.parseUInt64(this.proto.getDefaultValue()));
            break;
          case 11: 
            if (this.proto.getDefaultValue().equals("inf")) {
              this.defaultValue = Float.valueOf(Float.POSITIVE_INFINITY);
            } else if (this.proto.getDefaultValue().equals("-inf")) {
              this.defaultValue = Float.valueOf(Float.NEGATIVE_INFINITY);
            } else if (this.proto.getDefaultValue().equals("nan")) {
              this.defaultValue = Float.valueOf(NaN.0F);
            } else {
              this.defaultValue = Float.valueOf(this.proto.getDefaultValue());
            }
            break;
          case 12: 
            if (this.proto.getDefaultValue().equals("inf")) {
              this.defaultValue = Double.valueOf(Double.POSITIVE_INFINITY);
            } else if (this.proto.getDefaultValue().equals("-inf")) {
              this.defaultValue = Double.valueOf(Double.NEGATIVE_INFINITY);
            } else if (this.proto.getDefaultValue().equals("nan")) {
              this.defaultValue = Double.valueOf(NaN.0D);
            } else {
              this.defaultValue = Double.valueOf(this.proto.getDefaultValue());
            }
            break;
          case 13: 
            this.defaultValue = Boolean.valueOf(this.proto.getDefaultValue());
            break;
          case 14: 
            this.defaultValue = this.proto.getDefaultValue();
            break;
          case 15: 
            try
            {
              this.defaultValue = TextFormat.unescapeBytes(this.proto.getDefaultValue());
            }
            catch (TextFormat.InvalidEscapeSequenceException e)
            {
              throw new Descriptors.DescriptorValidationException(this, "Couldn't parse default value: " + e.getMessage(), e, null);
            }
          case 16: 
            this.defaultValue = this.enumType.findValueByName(this.proto.getDefaultValue());
            if (this.defaultValue == null) {
              throw new Descriptors.DescriptorValidationException(this, "Unknown enum default value: \"" + this.proto.getDefaultValue() + '"', null);
            }
            break;
          case 17: 
          case 18: 
            throw new Descriptors.DescriptorValidationException(this, "Message type had default value.", null);
          }
        }
        catch (NumberFormatException e)
        {
          throw new Descriptors.DescriptorValidationException(this, "Could not parse default value: \"" + this.proto.getDefaultValue() + '"', e, null);
        }
      }
      else if (isRepeated())
      {
        this.defaultValue = Collections.emptyList();
      }
      else
      {
        switch (Descriptors.1.$SwitchMap$com$google$protobuf$Descriptors$FieldDescriptor$JavaType[getJavaType().ordinal()])
        {
        case 1: 
          this.defaultValue = this.enumType.getValues().get(0);
          break;
        case 2: 
          this.defaultValue = null;
          break;
        default: 
          this.defaultValue = getJavaType().defaultDefault;
        }
      }
      if (!isExtension()) {
        Descriptors.FileDescriptor.access$1200(this.file).addFieldByNumber(this);
      }
      if ((this.containingType != null) && (this.containingType.getOptions().getMessageSetWireFormat())) {
        if (isExtension())
        {
          if ((!isOptional()) || (getType() != Type.MESSAGE)) {
            throw new Descriptors.DescriptorValidationException(this, "Extensions of MessageSets must be optional messages.", null);
          }
        }
        else {
          throw new Descriptors.DescriptorValidationException(this, "MessageSets cannot have fields, only extensions.", null);
        }
      }
    }
    
    private void setProto(DescriptorProtos.FieldDescriptorProto proto)
    {
      this.proto = proto;
    }
    
    public MessageLite.Builder internalMergeFrom(MessageLite.Builder to, MessageLite from)
    {
      return ((Message.Builder)to).mergeFrom((Message)from);
    }
  }
  
  public static final class EnumDescriptor
    implements Descriptors.GenericDescriptor, Internal.EnumLiteMap<Descriptors.EnumValueDescriptor>
  {
    private final int index;
    private DescriptorProtos.EnumDescriptorProto proto;
    private final String fullName;
    private final Descriptors.FileDescriptor file;
    private final Descriptors.Descriptor containingType;
    private Descriptors.EnumValueDescriptor[] values;
    
    public int getIndex()
    {
      return this.index;
    }
    
    public DescriptorProtos.EnumDescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public String getFullName()
    {
      return this.fullName;
    }
    
    public Descriptors.FileDescriptor getFile()
    {
      return this.file;
    }
    
    public Descriptors.Descriptor getContainingType()
    {
      return this.containingType;
    }
    
    public DescriptorProtos.EnumOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    public List<Descriptors.EnumValueDescriptor> getValues()
    {
      return Collections.unmodifiableList(Arrays.asList(this.values));
    }
    
    public Descriptors.EnumValueDescriptor findValueByName(String name)
    {
      Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
      if ((result != null) && ((result instanceof Descriptors.EnumValueDescriptor))) {
        return (Descriptors.EnumValueDescriptor)result;
      }
      return null;
    }
    
    public Descriptors.EnumValueDescriptor findValueByNumber(int number)
    {
      return (Descriptors.EnumValueDescriptor)Descriptors.FileDescriptor.access$1200(this.file).enumValuesByNumber.get(new Descriptors.DescriptorPool.DescriptorIntPair(this, number));
    }
    
    private EnumDescriptor(DescriptorProtos.EnumDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.Descriptor parent, int index)
      throws Descriptors.DescriptorValidationException
    {
      this.index = index;
      this.proto = proto;
      this.fullName = Descriptors.computeFullName(file, parent, proto.getName());
      this.file = file;
      this.containingType = parent;
      if (proto.getValueCount() == 0) {
        throw new Descriptors.DescriptorValidationException(this, "Enums must contain at least one value.", null);
      }
      this.values = new Descriptors.EnumValueDescriptor[proto.getValueCount()];
      for (int i = 0; i < proto.getValueCount(); i++) {
        this.values[i] = new Descriptors.EnumValueDescriptor(proto.getValue(i), file, this, i, null);
      }
      Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
    }
    
    private void setProto(DescriptorProtos.EnumDescriptorProto proto)
    {
      this.proto = proto;
      for (int i = 0; i < this.values.length; i++) {
        this.values[i].setProto(proto.getValue(i));
      }
    }
  }
  
  public static final class EnumValueDescriptor
    implements Descriptors.GenericDescriptor, Internal.EnumLite
  {
    private final int index;
    private DescriptorProtos.EnumValueDescriptorProto proto;
    private final String fullName;
    private final Descriptors.FileDescriptor file;
    private final Descriptors.EnumDescriptor type;
    
    public int getIndex()
    {
      return this.index;
    }
    
    public DescriptorProtos.EnumValueDescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public int getNumber()
    {
      return this.proto.getNumber();
    }
    
    public String getFullName()
    {
      return this.fullName;
    }
    
    public Descriptors.FileDescriptor getFile()
    {
      return this.file;
    }
    
    public Descriptors.EnumDescriptor getType()
    {
      return this.type;
    }
    
    public DescriptorProtos.EnumValueOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    private EnumValueDescriptor(DescriptorProtos.EnumValueDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.EnumDescriptor parent, int index)
      throws Descriptors.DescriptorValidationException
    {
      this.index = index;
      this.proto = proto;
      this.file = file;
      this.type = parent;
      
      this.fullName = (parent.getFullName() + '.' + proto.getName());
      
      Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
      Descriptors.FileDescriptor.access$1200(file).addEnumValueByNumber(this);
    }
    
    private void setProto(DescriptorProtos.EnumValueDescriptorProto proto)
    {
      this.proto = proto;
    }
  }
  
  public static final class ServiceDescriptor
    implements Descriptors.GenericDescriptor
  {
    private final int index;
    private DescriptorProtos.ServiceDescriptorProto proto;
    private final String fullName;
    private final Descriptors.FileDescriptor file;
    private Descriptors.MethodDescriptor[] methods;
    
    public int getIndex()
    {
      return this.index;
    }
    
    public DescriptorProtos.ServiceDescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public String getFullName()
    {
      return this.fullName;
    }
    
    public Descriptors.FileDescriptor getFile()
    {
      return this.file;
    }
    
    public DescriptorProtos.ServiceOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    public List<Descriptors.MethodDescriptor> getMethods()
    {
      return Collections.unmodifiableList(Arrays.asList(this.methods));
    }
    
    public Descriptors.MethodDescriptor findMethodByName(String name)
    {
      Descriptors.GenericDescriptor result = Descriptors.FileDescriptor.access$1200(this.file).findSymbol(this.fullName + '.' + name);
      if ((result != null) && ((result instanceof Descriptors.MethodDescriptor))) {
        return (Descriptors.MethodDescriptor)result;
      }
      return null;
    }
    
    private ServiceDescriptor(DescriptorProtos.ServiceDescriptorProto proto, Descriptors.FileDescriptor file, int index)
      throws Descriptors.DescriptorValidationException
    {
      this.index = index;
      this.proto = proto;
      this.fullName = Descriptors.computeFullName(file, null, proto.getName());
      this.file = file;
      
      this.methods = new Descriptors.MethodDescriptor[proto.getMethodCount()];
      for (int i = 0; i < proto.getMethodCount(); i++) {
        this.methods[i] = new Descriptors.MethodDescriptor(proto.getMethod(i), file, this, i, null);
      }
      Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
    }
    
    private void crossLink()
      throws Descriptors.DescriptorValidationException
    {
      for (Descriptors.MethodDescriptor method : this.methods) {
        method.crossLink();
      }
    }
    
    private void setProto(DescriptorProtos.ServiceDescriptorProto proto)
    {
      this.proto = proto;
      for (int i = 0; i < this.methods.length; i++) {
        this.methods[i].setProto(proto.getMethod(i));
      }
    }
  }
  
  public static final class MethodDescriptor
    implements Descriptors.GenericDescriptor
  {
    private final int index;
    private DescriptorProtos.MethodDescriptorProto proto;
    private final String fullName;
    private final Descriptors.FileDescriptor file;
    private final Descriptors.ServiceDescriptor service;
    private Descriptors.Descriptor inputType;
    private Descriptors.Descriptor outputType;
    
    public int getIndex()
    {
      return this.index;
    }
    
    public DescriptorProtos.MethodDescriptorProto toProto()
    {
      return this.proto;
    }
    
    public String getName()
    {
      return this.proto.getName();
    }
    
    public String getFullName()
    {
      return this.fullName;
    }
    
    public Descriptors.FileDescriptor getFile()
    {
      return this.file;
    }
    
    public Descriptors.ServiceDescriptor getService()
    {
      return this.service;
    }
    
    public Descriptors.Descriptor getInputType()
    {
      return this.inputType;
    }
    
    public Descriptors.Descriptor getOutputType()
    {
      return this.outputType;
    }
    
    public DescriptorProtos.MethodOptions getOptions()
    {
      return this.proto.getOptions();
    }
    
    private MethodDescriptor(DescriptorProtos.MethodDescriptorProto proto, Descriptors.FileDescriptor file, Descriptors.ServiceDescriptor parent, int index)
      throws Descriptors.DescriptorValidationException
    {
      this.index = index;
      this.proto = proto;
      this.file = file;
      this.service = parent;
      
      this.fullName = (parent.getFullName() + '.' + proto.getName());
      
      Descriptors.FileDescriptor.access$1200(file).addSymbol(this);
    }
    
    private void crossLink()
      throws Descriptors.DescriptorValidationException
    {
      Descriptors.GenericDescriptor input = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getInputType(), this, Descriptors.DescriptorPool.SearchFilter.TYPES_ONLY);
      if (!(input instanceof Descriptors.Descriptor)) {
        throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getInputType() + "\" is not a message type.", null);
      }
      this.inputType = ((Descriptors.Descriptor)input);
      
      Descriptors.GenericDescriptor output = Descriptors.FileDescriptor.access$1200(this.file).lookupSymbol(this.proto.getOutputType(), this, Descriptors.DescriptorPool.SearchFilter.TYPES_ONLY);
      if (!(output instanceof Descriptors.Descriptor)) {
        throw new Descriptors.DescriptorValidationException(this, '"' + this.proto.getOutputType() + "\" is not a message type.", null);
      }
      this.outputType = ((Descriptors.Descriptor)output);
    }
    
    private void setProto(DescriptorProtos.MethodDescriptorProto proto)
    {
      this.proto = proto;
    }
  }
  
  private static String computeFullName(FileDescriptor file, Descriptor parent, String name)
  {
    if (parent != null) {
      return parent.getFullName() + '.' + name;
    }
    if (file.getPackage().length() > 0) {
      return file.getPackage() + '.' + name;
    }
    return name;
  }
  
  private static abstract interface GenericDescriptor
  {
    public abstract Message toProto();
    
    public abstract String getName();
    
    public abstract String getFullName();
    
    public abstract Descriptors.FileDescriptor getFile();
  }
  
  public static class DescriptorValidationException
    extends Exception
  {
    private static final long serialVersionUID = 5750205775490483148L;
    private final String name;
    private final Message proto;
    private final String description;
    
    public String getProblemSymbolName()
    {
      return this.name;
    }
    
    public Message getProblemProto()
    {
      return this.proto;
    }
    
    public String getDescription()
    {
      return this.description;
    }
    
    private DescriptorValidationException(Descriptors.GenericDescriptor problemDescriptor, String description)
    {
      super();
      
      this.name = problemDescriptor.getFullName();
      this.proto = problemDescriptor.toProto();
      this.description = description;
    }
    
    private DescriptorValidationException(Descriptors.GenericDescriptor problemDescriptor, String description, Throwable cause)
    {
      this(problemDescriptor, description);
      initCause(cause);
    }
    
    private DescriptorValidationException(Descriptors.FileDescriptor problemDescriptor, String description)
    {
      super();
      
      this.name = problemDescriptor.getName();
      this.proto = problemDescriptor.toProto();
      this.description = description;
    }
  }
  
  private static final class DescriptorPool
  {
    private final Set<Descriptors.FileDescriptor> dependencies;
    
    static enum SearchFilter
    {
      TYPES_ONLY,  AGGREGATES_ONLY,  ALL_SYMBOLS;
      
      private SearchFilter() {}
    }
    
    DescriptorPool(Descriptors.FileDescriptor[] dependencies)
    {
      this.dependencies = new HashSet();
      for (int i = 0; i < dependencies.length; i++)
      {
        this.dependencies.add(dependencies[i]);
        importPublicDependencies(dependencies[i]);
      }
      for (Descriptors.FileDescriptor dependency : this.dependencies) {
        try
        {
          addPackage(dependency.getPackage(), dependency);
        }
        catch (Descriptors.DescriptorValidationException e)
        {
          if (!$assertionsDisabled) {
            throw new AssertionError();
          }
        }
      }
    }
    
    private void importPublicDependencies(Descriptors.FileDescriptor file)
    {
      for (Descriptors.FileDescriptor dependency : file.getPublicDependencies()) {
        if (this.dependencies.add(dependency)) {
          importPublicDependencies(dependency);
        }
      }
    }
    
    private final Map<String, Descriptors.GenericDescriptor> descriptorsByName = new HashMap();
    private final Map<DescriptorIntPair, Descriptors.FieldDescriptor> fieldsByNumber = new HashMap();
    private final Map<DescriptorIntPair, Descriptors.EnumValueDescriptor> enumValuesByNumber = new HashMap();
    
    Descriptors.GenericDescriptor findSymbol(String fullName)
    {
      return findSymbol(fullName, SearchFilter.ALL_SYMBOLS);
    }
    
    Descriptors.GenericDescriptor findSymbol(String fullName, SearchFilter filter)
    {
      Descriptors.GenericDescriptor result = (Descriptors.GenericDescriptor)this.descriptorsByName.get(fullName);
      if ((result != null) && (
        (filter == SearchFilter.ALL_SYMBOLS) || ((filter == SearchFilter.TYPES_ONLY) && (isType(result))) || ((filter == SearchFilter.AGGREGATES_ONLY) && (isAggregate(result))))) {
        return result;
      }
      for (Descriptors.FileDescriptor dependency : this.dependencies)
      {
        result = (Descriptors.GenericDescriptor)Descriptors.FileDescriptor.access$1200(dependency).descriptorsByName.get(fullName);
        if ((result != null) && (
          (filter == SearchFilter.ALL_SYMBOLS) || ((filter == SearchFilter.TYPES_ONLY) && (isType(result))) || ((filter == SearchFilter.AGGREGATES_ONLY) && (isAggregate(result))))) {
          return result;
        }
      }
      return null;
    }
    
    boolean isType(Descriptors.GenericDescriptor descriptor)
    {
      return ((descriptor instanceof Descriptors.Descriptor)) || ((descriptor instanceof Descriptors.EnumDescriptor));
    }
    
    boolean isAggregate(Descriptors.GenericDescriptor descriptor)
    {
      return ((descriptor instanceof Descriptors.Descriptor)) || ((descriptor instanceof Descriptors.EnumDescriptor)) || ((descriptor instanceof PackageDescriptor)) || ((descriptor instanceof Descriptors.ServiceDescriptor));
    }
    
    Descriptors.GenericDescriptor lookupSymbol(String name, Descriptors.GenericDescriptor relativeTo, SearchFilter filter)
      throws Descriptors.DescriptorValidationException
    {
      Descriptors.GenericDescriptor result;
      Descriptors.GenericDescriptor result;
      if (name.startsWith("."))
      {
        result = findSymbol(name.substring(1), filter);
      }
      else
      {
        int firstPartLength = name.indexOf('.');
        String firstPart;
        String firstPart;
        if (firstPartLength == -1) {
          firstPart = name;
        } else {
          firstPart = name.substring(0, firstPartLength);
        }
        StringBuilder scopeToTry = new StringBuilder(relativeTo.getFullName());
        for (;;)
        {
          int dotpos = scopeToTry.lastIndexOf(".");
          if (dotpos == -1)
          {
            Descriptors.GenericDescriptor result = findSymbol(name, filter);
            break;
          }
          scopeToTry.setLength(dotpos + 1);
          
          scopeToTry.append(firstPart);
          result = findSymbol(scopeToTry.toString(), SearchFilter.AGGREGATES_ONLY);
          if (result != null)
          {
            if (firstPartLength == -1) {
              break;
            }
            scopeToTry.setLength(dotpos + 1);
            scopeToTry.append(name);
            result = findSymbol(scopeToTry.toString(), filter); break;
          }
          scopeToTry.setLength(dotpos);
        }
      }
      if (result == null) {
        throw new Descriptors.DescriptorValidationException(relativeTo, '"' + name + "\" is not defined.", null);
      }
      return result;
    }
    
    void addSymbol(Descriptors.GenericDescriptor descriptor)
      throws Descriptors.DescriptorValidationException
    {
      validateSymbolName(descriptor);
      
      String fullName = descriptor.getFullName();
      int dotpos = fullName.lastIndexOf('.');
      
      Descriptors.GenericDescriptor old = (Descriptors.GenericDescriptor)this.descriptorsByName.put(fullName, descriptor);
      if (old != null)
      {
        this.descriptorsByName.put(fullName, old);
        if (descriptor.getFile() == old.getFile())
        {
          if (dotpos == -1) {
            throw new Descriptors.DescriptorValidationException(descriptor, '"' + fullName + "\" is already defined.", null);
          }
          throw new Descriptors.DescriptorValidationException(descriptor, '"' + fullName.substring(dotpos + 1) + "\" is already defined in \"" + fullName.substring(0, dotpos) + "\".", null);
        }
        throw new Descriptors.DescriptorValidationException(descriptor, '"' + fullName + "\" is already defined in file \"" + old.getFile().getName() + "\".", null);
      }
    }
    
    private static final class PackageDescriptor
      implements Descriptors.GenericDescriptor
    {
      private final String name;
      private final String fullName;
      private final Descriptors.FileDescriptor file;
      
      public Message toProto()
      {
        return this.file.toProto();
      }
      
      public String getName()
      {
        return this.name;
      }
      
      public String getFullName()
      {
        return this.fullName;
      }
      
      public Descriptors.FileDescriptor getFile()
      {
        return this.file;
      }
      
      PackageDescriptor(String name, String fullName, Descriptors.FileDescriptor file)
      {
        this.file = file;
        this.fullName = fullName;
        this.name = name;
      }
    }
    
    void addPackage(String fullName, Descriptors.FileDescriptor file)
      throws Descriptors.DescriptorValidationException
    {
      int dotpos = fullName.lastIndexOf('.');
      String name;
      String name;
      if (dotpos == -1)
      {
        name = fullName;
      }
      else
      {
        addPackage(fullName.substring(0, dotpos), file);
        name = fullName.substring(dotpos + 1);
      }
      Descriptors.GenericDescriptor old = (Descriptors.GenericDescriptor)this.descriptorsByName.put(fullName, new PackageDescriptor(name, fullName, file));
      if (old != null)
      {
        this.descriptorsByName.put(fullName, old);
        if (!(old instanceof PackageDescriptor)) {
          throw new Descriptors.DescriptorValidationException(file, '"' + name + "\" is already defined (as something other than a " + "package) in file \"" + old.getFile().getName() + "\".", null);
        }
      }
    }
    
    private static final class DescriptorIntPair
    {
      private final Descriptors.GenericDescriptor descriptor;
      private final int number;
      
      DescriptorIntPair(Descriptors.GenericDescriptor descriptor, int number)
      {
        this.descriptor = descriptor;
        this.number = number;
      }
      
      public int hashCode()
      {
        return this.descriptor.hashCode() * 65535 + this.number;
      }
      
      public boolean equals(Object obj)
      {
        if (!(obj instanceof DescriptorIntPair)) {
          return false;
        }
        DescriptorIntPair other = (DescriptorIntPair)obj;
        return (this.descriptor == other.descriptor) && (this.number == other.number);
      }
    }
    
    void addFieldByNumber(Descriptors.FieldDescriptor field)
      throws Descriptors.DescriptorValidationException
    {
      DescriptorIntPair key = new DescriptorIntPair(field.getContainingType(), field.getNumber());
      
      Descriptors.FieldDescriptor old = (Descriptors.FieldDescriptor)this.fieldsByNumber.put(key, field);
      if (old != null)
      {
        this.fieldsByNumber.put(key, old);
        throw new Descriptors.DescriptorValidationException(field, "Field number " + field.getNumber() + "has already been used in \"" + field.getContainingType().getFullName() + "\" by field \"" + old.getName() + "\".", null);
      }
    }
    
    void addEnumValueByNumber(Descriptors.EnumValueDescriptor value)
    {
      DescriptorIntPair key = new DescriptorIntPair(value.getType(), value.getNumber());
      
      Descriptors.EnumValueDescriptor old = (Descriptors.EnumValueDescriptor)this.enumValuesByNumber.put(key, value);
      if (old != null) {
        this.enumValuesByNumber.put(key, old);
      }
    }
    
    static void validateSymbolName(Descriptors.GenericDescriptor descriptor)
      throws Descriptors.DescriptorValidationException
    {
      String name = descriptor.getName();
      if (name.length() == 0) {
        throw new Descriptors.DescriptorValidationException(descriptor, "Missing name.", null);
      }
      boolean valid = true;
      for (int i = 0; i < name.length(); i++)
      {
        char c = name.charAt(i);
        if (c >= '') {
          valid = false;
        }
        if ((!Character.isLetter(c)) && (c != '_') && ((!Character.isDigit(c)) || (i <= 0))) {
          valid = false;
        }
      }
      if (!valid) {
        throw new Descriptors.DescriptorValidationException(descriptor, '"' + name + "\" is not a valid identifier.", null);
      }
    }
  }
}
