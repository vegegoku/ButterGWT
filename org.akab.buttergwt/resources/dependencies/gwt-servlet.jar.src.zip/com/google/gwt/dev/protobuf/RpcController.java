package com.google.gwt.dev.protobuf;

public abstract interface RpcController
{
  public abstract void reset();
  
  public abstract boolean failed();
  
  public abstract String errorText();
  
  public abstract void startCancel();
  
  public abstract void setFailed(String paramString);
  
  public abstract boolean isCanceled();
  
  public abstract void notifyOnCancel(RpcCallback<Object> paramRpcCallback);
}
