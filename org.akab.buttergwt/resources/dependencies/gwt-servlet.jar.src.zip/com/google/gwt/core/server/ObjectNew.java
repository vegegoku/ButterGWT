package com.google.gwt.core.server;

final class ObjectNew
  extends ServerGwtBridge.ClassInstantiatorBase
{
  public <T> T create(Class<?> clazz, ServerGwtBridge.Properties properties)
  {
    return (T)tryCreate(clazz);
  }
}
