package com.google.gwt.aria.client;

public enum RelevantValue
  implements AriaAttributeType
{
  ADDITIONS,  REMOVALS,  TEXT,  ALL;
  
  private RelevantValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case ADDITIONS: 
      return "additions";
    case REMOVALS: 
      return "removals";
    case TEXT: 
      return "text";
    case ALL: 
      return "all";
    }
    return null;
  }
}
