package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlUnknownElement
  extends HtmlElement
{
  HtmlUnknownElement(SgmlPage page, String tagName, Map<String, DomAttr> attributes)
  {
    this(page, null, tagName, attributes);
  }
  
  HtmlUnknownElement(SgmlPage page, String namespaceURI, String qualifiedName, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  protected boolean isTrimmedText()
  {
    return false;
  }
}
