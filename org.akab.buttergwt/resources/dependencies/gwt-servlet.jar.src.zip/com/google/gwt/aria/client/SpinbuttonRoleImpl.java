package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class SpinbuttonRoleImpl
  extends RoleImpl
  implements SpinbuttonRole
{
  SpinbuttonRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaRequiredProperty(Element element)
  {
    return Property.REQUIRED.get(element);
  }
  
  public String getAriaValuemaxProperty(Element element)
  {
    return Property.VALUEMAX.get(element);
  }
  
  public String getAriaValueminProperty(Element element)
  {
    return Property.VALUEMIN.get(element);
  }
  
  public String getAriaValuenowProperty(Element element)
  {
    return Property.VALUENOW.get(element);
  }
  
  public String getAriaValuetextProperty(Element element)
  {
    return Property.VALUETEXT.get(element);
  }
  
  public void removeAriaRequiredProperty(Element element)
  {
    Property.REQUIRED.remove(element);
  }
  
  public void removeAriaValuemaxProperty(Element element)
  {
    Property.VALUEMAX.remove(element);
  }
  
  public void removeAriaValueminProperty(Element element)
  {
    Property.VALUEMIN.remove(element);
  }
  
  public void removeAriaValuenowProperty(Element element)
  {
    Property.VALUENOW.remove(element);
  }
  
  public void removeAriaValuetextProperty(Element element)
  {
    Property.VALUETEXT.remove(element);
  }
  
  public void setAriaRequiredProperty(Element element, boolean value)
  {
    Property.REQUIRED.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaValuemaxProperty(Element element, Number value)
  {
    Property.VALUEMAX.set(element, new Number[] { value });
  }
  
  public void setAriaValueminProperty(Element element, Number value)
  {
    Property.VALUEMIN.set(element, new Number[] { value });
  }
  
  public void setAriaValuenowProperty(Element element, Number value)
  {
    Property.VALUENOW.set(element, new Number[] { value });
  }
  
  public void setAriaValuetextProperty(Element element, String value)
  {
    Property.VALUETEXT.set(element, new String[] { value });
  }
}
