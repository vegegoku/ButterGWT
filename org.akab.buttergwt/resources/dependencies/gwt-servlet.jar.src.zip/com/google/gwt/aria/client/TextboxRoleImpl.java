package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class TextboxRoleImpl
  extends RoleImpl
  implements TextboxRole
{
  TextboxRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaActivedescendantProperty(Element element)
  {
    return Property.ACTIVEDESCENDANT.get(element);
  }
  
  public String getAriaAutocompleteProperty(Element element)
  {
    return Property.AUTOCOMPLETE.get(element);
  }
  
  public String getAriaMultilineProperty(Element element)
  {
    return Property.MULTILINE.get(element);
  }
  
  public String getAriaReadonlyProperty(Element element)
  {
    return Property.READONLY.get(element);
  }
  
  public String getAriaRequiredProperty(Element element)
  {
    return Property.REQUIRED.get(element);
  }
  
  public void removeAriaActivedescendantProperty(Element element)
  {
    Property.ACTIVEDESCENDANT.remove(element);
  }
  
  public void removeAriaAutocompleteProperty(Element element)
  {
    Property.AUTOCOMPLETE.remove(element);
  }
  
  public void removeAriaMultilineProperty(Element element)
  {
    Property.MULTILINE.remove(element);
  }
  
  public void removeAriaReadonlyProperty(Element element)
  {
    Property.READONLY.remove(element);
  }
  
  public void removeAriaRequiredProperty(Element element)
  {
    Property.REQUIRED.remove(element);
  }
  
  public void setAriaActivedescendantProperty(Element element, Id value)
  {
    Property.ACTIVEDESCENDANT.set(element, new Id[] { value });
  }
  
  public void setAriaAutocompleteProperty(Element element, AutocompleteValue value)
  {
    Property.AUTOCOMPLETE.set(element, new AutocompleteValue[] { value });
  }
  
  public void setAriaMultilineProperty(Element element, boolean value)
  {
    Property.MULTILINE.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaReadonlyProperty(Element element, boolean value)
  {
    Property.READONLY.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaRequiredProperty(Element element, boolean value)
  {
    Property.REQUIRED.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
}
