package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebWindow;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Ellipse2D.Double;
import java.awt.geom.GeneralPath;
import java.awt.geom.Rectangle2D;
import java.awt.geom.Rectangle2D.Double;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class HtmlArea
  extends HtmlElement
{
  public static final String TAG_NAME = "area";
  
  HtmlArea(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  protected boolean doClickStateUpdate()
    throws IOException
  {
    HtmlPage enclosingPage = (HtmlPage)getPage();
    WebClient webClient = enclosingPage.getWebClient();
    
    String href = getHrefAttribute().trim();
    if (href.length() > 0)
    {
      HtmlPage page = (HtmlPage)getPage();
      if (StringUtils.startsWithIgnoreCase(href, "javascript:"))
      {
        page.executeJavaScriptIfPossible(href, "javascript url", getStartLineNumber());
        
        return false;
      }
      URL url;
      try
      {
        url = enclosingPage.getFullyQualifiedUrl(getHrefAttribute());
      }
      catch (MalformedURLException e)
      {
        throw new IllegalStateException("Not a valid url: " + getHrefAttribute());
      }
      WebRequest request = new WebRequest(url);
      request.setAdditionalHeader("Referer", page.getUrl().toExternalForm());
      WebWindow webWindow = enclosingPage.getEnclosingWindow();
      webClient.getPage(webWindow, enclosingPage.getResolvedTarget(getTargetAttribute()), request);
    }
    return false;
  }
  
  public final String getShapeAttribute()
  {
    return getAttribute("shape");
  }
  
  public final String getCoordsAttribute()
  {
    return getAttribute("coords");
  }
  
  public final String getHrefAttribute()
  {
    return getAttribute("href");
  }
  
  public final String getNoHrefAttribute()
  {
    return getAttribute("nohref");
  }
  
  public final String getAltAttribute()
  {
    return getAttribute("alt");
  }
  
  public final String getTabIndexAttribute()
  {
    return getAttribute("tabindex");
  }
  
  public final String getAccessKeyAttribute()
  {
    return getAttribute("accesskey");
  }
  
  public final String getOnFocusAttribute()
  {
    return getAttribute("onfocus");
  }
  
  public final String getOnBlurAttribute()
  {
    return getAttribute("onblur");
  }
  
  public final String getTargetAttribute()
  {
    return getAttribute("target");
  }
  
  boolean containsPoint(int x, int y)
  {
    String shape = ((String)StringUtils.defaultIfEmpty(getShapeAttribute(), "rect")).toLowerCase(Locale.ENGLISH);
    if (("default".equals(shape)) && (getCoordsAttribute() != null)) {
      return true;
    }
    if (("rect".equals(shape)) && (getCoordsAttribute() != null))
    {
      String[] coords = StringUtils.split(getCoordsAttribute(), ',');
      double leftX = Double.parseDouble(coords[0].trim());
      double topY = Double.parseDouble(coords[1].trim());
      double rightX = Double.parseDouble(coords[2].trim());
      double bottomY = Double.parseDouble(coords[3].trim());
      Rectangle2D rectangle = new Rectangle2D.Double(leftX, topY, rightX - leftX + 1.0D, bottomY - topY + 1.0D);
      if (rectangle.contains(x, y)) {
        return true;
      }
    }
    else if (("circle".equals(shape)) && (getCoordsAttribute() != null))
    {
      String[] coords = StringUtils.split(getCoordsAttribute(), ',');
      double centerX = Double.parseDouble(coords[0].trim());
      double centerY = Double.parseDouble(coords[1].trim());
      String radiusString = coords[2].trim();
      int radius;
      try
      {
        radius = Integer.parseInt(radiusString);
      }
      catch (NumberFormatException nfe)
      {
        throw new NumberFormatException("Circle radius of " + radiusString + " is not yet implemented.");
      }
      Ellipse2D ellipse = new Ellipse2D.Double(centerX - radius / 2.0D, centerY - radius / 2.0D, radius, radius);
      if (ellipse.contains(x, y)) {
        return true;
      }
    }
    else if (("poly".equals(shape)) && (getCoordsAttribute() != null))
    {
      String[] coords = StringUtils.split(getCoordsAttribute(), ',');
      GeneralPath path = new GeneralPath();
      for (int i = 0; i + 1 < coords.length; i += 2) {
        if (i == 0) {
          path.moveTo(Float.parseFloat(coords[i]), Float.parseFloat(coords[(i + 1)]));
        } else {
          path.lineTo(Float.parseFloat(coords[i]), Float.parseFloat(coords[(i + 1)]));
        }
      }
      path.closePath();
      if (path.contains(x, y)) {
        return true;
      }
    }
    return false;
  }
}
