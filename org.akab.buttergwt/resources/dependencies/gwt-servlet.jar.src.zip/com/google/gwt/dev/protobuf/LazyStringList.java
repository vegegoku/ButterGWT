package com.google.gwt.dev.protobuf;

import java.util.List;

public abstract interface LazyStringList
  extends List<String>
{
  public abstract ByteString getByteString(int paramInt);
  
  public abstract void add(ByteString paramByteString);
  
  public abstract List<?> getUnderlyingElements();
}
