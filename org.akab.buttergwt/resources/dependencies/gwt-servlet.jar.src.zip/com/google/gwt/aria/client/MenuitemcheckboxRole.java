package com.google.gwt.aria.client;

public abstract interface MenuitemcheckboxRole
  extends CheckboxRole, MenuitemRole
{}
