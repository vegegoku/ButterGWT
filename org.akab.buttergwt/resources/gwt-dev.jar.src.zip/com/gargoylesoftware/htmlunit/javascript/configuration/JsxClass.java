package com.gargoylesoftware.htmlunit.javascript.configuration;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target({java.lang.annotation.ElementType.TYPE})
public @interface JsxClass
{
  Class<?>[] domClasses() default {};
  
  boolean isJSObject() default true;
  
  WebBrowser[] browsers() default {@WebBrowser(BrowserName.IE), @WebBrowser(BrowserName.FF), @WebBrowser(BrowserName.CHROME)};
}
