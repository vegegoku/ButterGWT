package com.google.gwt.dom.builder.shared;

import com.google.gwt.dom.client.Element;
import com.google.gwt.safehtml.shared.SafeHtml;

public abstract interface ElementBuilderBase<T extends ElementBuilderBase<?>>
{
  public abstract T attribute(String paramString, int paramInt);
  
  public abstract T attribute(String paramString1, String paramString2);
  
  public abstract T className(String paramString);
  
  public abstract T dir(String paramString);
  
  public abstract T draggable(String paramString);
  
  public abstract void end();
  
  public abstract void end(String paramString);
  
  public abstract void endAnchor();
  
  public abstract void endArea();
  
  public abstract void endAudio();
  
  public abstract void endBase();
  
  public abstract void endBlockQuote();
  
  public abstract void endBody();
  
  public abstract void endBR();
  
  public abstract void endButton();
  
  public abstract void endCanvas();
  
  public abstract void endCol();
  
  public abstract void endColGroup();
  
  public abstract void endDiv();
  
  public abstract void endDList();
  
  public abstract void endFieldSet();
  
  public abstract void endForm();
  
  public abstract void endFrame();
  
  public abstract void endFrameSet();
  
  public abstract void endH1();
  
  public abstract void endH2();
  
  public abstract void endH3();
  
  public abstract void endH4();
  
  public abstract void endH5();
  
  public abstract void endH6();
  
  public abstract void endHead();
  
  public abstract void endHR();
  
  public abstract void endIFrame();
  
  public abstract void endImage();
  
  public abstract void endInput();
  
  public abstract void endLabel();
  
  public abstract void endLegend();
  
  public abstract void endLI();
  
  public abstract void endLink();
  
  public abstract void endMap();
  
  public abstract void endMeta();
  
  public abstract void endOList();
  
  public abstract void endOptGroup();
  
  public abstract void endOption();
  
  public abstract void endParagraph();
  
  public abstract void endParam();
  
  public abstract void endPre();
  
  public abstract void endQuote();
  
  public abstract void endScript();
  
  public abstract void endSelect();
  
  public abstract void endSource();
  
  public abstract void endSpan();
  
  public abstract void endStyle();
  
  public abstract void endTable();
  
  public abstract void endTableCaption();
  
  public abstract void endTBody();
  
  public abstract void endTD();
  
  public abstract void endTextArea();
  
  public abstract void endTFoot();
  
  public abstract void endTH();
  
  public abstract void endTHead();
  
  public abstract void endTR();
  
  public abstract void endUList();
  
  public abstract void endVideo();
  
  public abstract Element finish();
  
  public abstract int getDepth();
  
  public abstract T html(SafeHtml paramSafeHtml);
  
  public abstract T id(String paramString);
  
  public abstract boolean isChildElementSupported();
  
  public abstract boolean isEndTagForbidden();
  
  public abstract T lang(String paramString);
  
  public abstract AnchorBuilder startAnchor();
  
  public abstract AreaBuilder startArea();
  
  public abstract AudioBuilder startAudio();
  
  public abstract BaseBuilder startBase();
  
  public abstract QuoteBuilder startBlockQuote();
  
  public abstract BodyBuilder startBody();
  
  public abstract BRBuilder startBR();
  
  public abstract InputBuilder startButtonInput();
  
  public abstract CanvasBuilder startCanvas();
  
  public abstract InputBuilder startCheckboxInput();
  
  public abstract TableColBuilder startCol();
  
  public abstract TableColBuilder startColGroup();
  
  public abstract DivBuilder startDiv();
  
  public abstract DListBuilder startDList();
  
  public abstract FieldSetBuilder startFieldSet();
  
  public abstract InputBuilder startFileInput();
  
  public abstract FormBuilder startForm();
  
  public abstract FrameBuilder startFrame();
  
  public abstract FrameSetBuilder startFrameSet();
  
  public abstract HeadingBuilder startH1();
  
  public abstract HeadingBuilder startH2();
  
  public abstract HeadingBuilder startH3();
  
  public abstract HeadingBuilder startH4();
  
  public abstract HeadingBuilder startH5();
  
  public abstract HeadingBuilder startH6();
  
  public abstract HeadBuilder startHead();
  
  public abstract InputBuilder startHiddenInput();
  
  public abstract HRBuilder startHR();
  
  public abstract IFrameBuilder startIFrame();
  
  public abstract ImageBuilder startImage();
  
  public abstract InputBuilder startImageInput();
  
  public abstract LabelBuilder startLabel();
  
  public abstract LegendBuilder startLegend();
  
  public abstract LIBuilder startLI();
  
  public abstract LinkBuilder startLink();
  
  public abstract MapBuilder startMap();
  
  public abstract MetaBuilder startMeta();
  
  public abstract OListBuilder startOList();
  
  public abstract OptGroupBuilder startOptGroup();
  
  public abstract OptionBuilder startOption();
  
  public abstract ParagraphBuilder startParagraph();
  
  public abstract ParamBuilder startParam();
  
  public abstract InputBuilder startPasswordInput();
  
  public abstract PreBuilder startPre();
  
  public abstract ButtonBuilder startPushButton();
  
  public abstract QuoteBuilder startQuote();
  
  public abstract InputBuilder startRadioInput(String paramString);
  
  public abstract ButtonBuilder startResetButton();
  
  public abstract InputBuilder startResetInput();
  
  public abstract ScriptBuilder startScript();
  
  public abstract SelectBuilder startSelect();
  
  public abstract SourceBuilder startSource();
  
  public abstract SpanBuilder startSpan();
  
  public abstract StyleBuilder startStyle();
  
  public abstract ButtonBuilder startSubmitButton();
  
  public abstract InputBuilder startSubmitInput();
  
  public abstract TableBuilder startTable();
  
  public abstract TableCaptionBuilder startTableCaption();
  
  public abstract TableSectionBuilder startTBody();
  
  public abstract TableCellBuilder startTD();
  
  public abstract TextAreaBuilder startTextArea();
  
  public abstract InputBuilder startTextInput();
  
  public abstract TableSectionBuilder startTFoot();
  
  public abstract TableCellBuilder startTH();
  
  public abstract TableSectionBuilder startTHead();
  
  public abstract TableRowBuilder startTR();
  
  public abstract UListBuilder startUList();
  
  public abstract VideoBuilder startVideo();
  
  public abstract StylesBuilder style();
  
  public abstract T tabIndex(int paramInt);
  
  public abstract T text(String paramString);
  
  public abstract T title(String paramString);
  
  public abstract ElementBuilder trustedStart(String paramString);
}
