package com.google.gwt.core.shared.impl;

public class JsLogger
{
  public void log(String message, Throwable e) {}
}
