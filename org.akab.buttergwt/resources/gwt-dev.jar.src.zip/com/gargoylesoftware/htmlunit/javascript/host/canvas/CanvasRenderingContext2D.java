package com.gargoylesoftware.htmlunit.javascript.host.canvas;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass
public class CanvasRenderingContext2D
  extends SimpleScriptable
{
  @JsxGetter
  public Object getFillStyle()
  {
    return null;
  }
  
  @JsxFunction
  public void translate(Object x, Object y) {}
  
  @JsxFunction
  public void scale(Object x, Object y) {}
  
  @JsxSetter
  public void setFillStyle(Object fillStyle) {}
  
  @JsxGetter
  public Object getStrokeStyle()
  {
    return null;
  }
  
  @JsxSetter
  public void setStrokeStyle(Object strokeStyle) {}
  
  @JsxGetter
  public double getLineWidth()
  {
    return 0.0D;
  }
  
  @JsxSetter
  public void setLineWidth(Object lineWidth) {}
  
  @JsxGetter
  public double getGlobalAlpha()
  {
    return 0.0D;
  }
  
  @JsxSetter
  public void setGlobalAlpha(Object globalAlpha) {}
  
  @JsxFunction
  public void clearRect(double x, double y, double w, double h) {}
  
  @JsxFunction
  public void fillRect(double x, double y, double w, double h) {}
  
  @JsxFunction
  public void strokeRect(double x, double y, double w, double h) {}
  
  @JsxFunction
  public void beginPath() {}
  
  @JsxFunction
  public void closePath() {}
  
  @JsxFunction
  public void moveTo(double x, double y) {}
  
  @JsxFunction
  public void lineTo(double x, double y) {}
  
  @JsxFunction
  public void save() {}
  
  @JsxFunction
  public void restore() {}
  
  @JsxFunction
  public void createLinearGradient(double x0, double y0, double r0, double x1, Object y1, Object r1) {}
  
  @JsxFunction
  public void arc(double x, double y, double radius, double startAngle, double endAngle, boolean anticlockwise) {}
  
  @JsxFunction
  public void arcTo(double x1, double y1, double x2, double y2, double radius) {}
  
  @JsxFunction
  public void bezierCurveTo(double cp1x, double cp1y, double cp2x, double cp2y, double x, double y) {}
  
  @JsxFunction
  public void quadraticCurveTo(double controlPointX, double controlPointY, double endPointX, double endPointY) {}
  
  @JsxFunction
  public void fill() {}
  
  @JsxFunction
  public void stroke() {}
  
  @JsxFunction
  public void clip() {}
  
  @JsxFunction
  public static void drawImage(Context context, Scriptable thisObj, Object[] args, Function function) {}
  
  @JsxFunction
  public void createImageData() {}
  
  @JsxFunction
  public void createPattern() {}
  
  @JsxFunction
  public void createRadialGradient() {}
  
  @JsxFunction
  public void fillText() {}
  
  @JsxFunction
  public void getImageData() {}
  
  @JsxFunction
  public void getLineData() {}
  
  @JsxFunction
  public void isPointInPath() {}
  
  @JsxFunction
  public void measureText() {}
  
  @JsxFunction
  public void putImageData() {}
  
  @JsxFunction
  public void rect() {}
  
  @JsxFunction
  public void rotate() {}
  
  @JsxFunction
  public void setTransform() {}
  
  @JsxFunction
  public void strokeText() {}
  
  @JsxFunction
  public void transform() {}
}
