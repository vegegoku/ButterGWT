package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import org.apache.commons.lang3.StringUtils;

final class IEConditionalCommentExpressionEvaluator
{
  public static boolean evaluate(String condition, BrowserVersion browserVersion)
  {
    condition = condition.trim();
    if ("IE".equals(condition)) {
      return true;
    }
    if ("true".equals(condition)) {
      return true;
    }
    if ("false".equals(condition)) {
      return false;
    }
    if (condition.contains("&")) {
      return (evaluate(StringUtils.substringBefore(condition, "&"), browserVersion)) && (evaluate(StringUtils.substringAfter(condition, "&"), browserVersion));
    }
    if (condition.contains("|")) {
      return (evaluate(StringUtils.substringBefore(condition, "|"), browserVersion)) || (evaluate(StringUtils.substringAfter(condition, "|"), browserVersion));
    }
    if (condition.startsWith("!")) {
      return !evaluate(condition.substring(1), browserVersion);
    }
    if (condition.startsWith("IE"))
    {
      String currentVersion = Float.toString(browserVersion.getBrowserVersionNumeric());
      return currentVersion.startsWith(condition.substring(2).trim());
    }
    if (condition.startsWith("lte IE")) {
      return browserVersion.getBrowserVersionNumeric() <= parseVersion(condition.substring(6));
    }
    if (condition.startsWith("lt IE")) {
      return browserVersion.getBrowserVersionNumeric() < parseVersion(condition.substring(5));
    }
    if (condition.startsWith("gt IE")) {
      return browserVersion.getBrowserVersionNumeric() > parseVersion(condition.substring(5));
    }
    if (condition.startsWith("gte IE")) {
      return browserVersion.getBrowserVersionNumeric() >= parseVersion(condition.substring(6));
    }
    if (condition.startsWith("lt")) {
      return true;
    }
    if (condition.startsWith("gt")) {
      return false;
    }
    if (condition.startsWith("(")) {
      return evaluate(StringUtils.substringBetween(condition, "(", ")"), browserVersion);
    }
    return false;
  }
  
  private static float parseVersion(String s)
  {
    return Float.parseFloat(s);
  }
}
