package com.google.gwt.dom.builder.shared;

public abstract interface DivBuilder
  extends ElementBuilderBase<DivBuilder>
{}
