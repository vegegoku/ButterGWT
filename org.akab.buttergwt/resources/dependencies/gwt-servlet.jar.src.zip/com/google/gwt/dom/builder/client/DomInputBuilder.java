package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.InputBuilder;
import com.google.gwt.dom.client.InputElement;

public class DomInputBuilder
  extends DomElementBuilderBase<InputBuilder, InputElement>
  implements InputBuilder
{
  DomInputBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public InputBuilder accept(String accept)
  {
    ((InputElement)assertCanAddAttribute()).setAccept(accept);
    return this;
  }
  
  public InputBuilder accessKey(String accessKey)
  {
    ((InputElement)assertCanAddAttribute()).setAccessKey(accessKey);
    return this;
  }
  
  public InputBuilder alt(String alt)
  {
    ((InputElement)assertCanAddAttribute()).setAlt(alt);
    return this;
  }
  
  public InputBuilder checked()
  {
    ((InputElement)assertCanAddAttribute()).setChecked(true);
    return this;
  }
  
  public InputBuilder defaultChecked()
  {
    ((InputElement)assertCanAddAttribute()).setDefaultChecked(true);
    return this;
  }
  
  public InputBuilder defaultValue(String defaultValue)
  {
    ((InputElement)assertCanAddAttribute()).setDefaultValue(defaultValue);
    return this;
  }
  
  public InputBuilder disabled()
  {
    ((InputElement)assertCanAddAttribute()).setDisabled(true);
    return this;
  }
  
  public InputBuilder maxLength(int maxLength)
  {
    ((InputElement)assertCanAddAttribute()).setMaxLength(maxLength);
    return this;
  }
  
  public InputBuilder name(String name)
  {
    ((InputElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public InputBuilder readOnly()
  {
    ((InputElement)assertCanAddAttribute()).setReadOnly(true);
    return this;
  }
  
  public InputBuilder size(int size)
  {
    ((InputElement)assertCanAddAttribute()).setSize(size);
    return this;
  }
  
  public InputBuilder src(String src)
  {
    ((InputElement)assertCanAddAttribute()).setSrc(src);
    return this;
  }
  
  public InputBuilder value(String value)
  {
    ((InputElement)assertCanAddAttribute()).setValue(value);
    return this;
  }
}
