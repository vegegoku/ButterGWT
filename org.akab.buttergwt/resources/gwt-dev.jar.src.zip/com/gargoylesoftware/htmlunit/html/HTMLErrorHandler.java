package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.WebAssert;
import java.net.URL;
import org.apache.xerces.util.DefaultErrorHandler;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLParseException;

class HTMLErrorHandler
  extends DefaultErrorHandler
{
  private final HTMLParserListener listener_;
  private final URL url_;
  private String html_;
  
  HTMLErrorHandler(HTMLParserListener listener, URL url, String htmlContent)
  {
    WebAssert.notNull("listener", listener);
    WebAssert.notNull("url", url);
    this.listener_ = listener;
    this.url_ = url;
    this.html_ = htmlContent;
  }
  
  public void error(String domain, String key, XMLParseException exception)
    throws XNIException
  {
    this.listener_.error(exception.getMessage(), this.url_, this.html_, exception.getLineNumber(), exception.getColumnNumber(), key);
  }
  
  public void warning(String domain, String key, XMLParseException exception)
    throws XNIException
  {
    this.listener_.warning(exception.getMessage(), this.url_, this.html_, exception.getLineNumber(), exception.getColumnNumber(), key);
  }
}
