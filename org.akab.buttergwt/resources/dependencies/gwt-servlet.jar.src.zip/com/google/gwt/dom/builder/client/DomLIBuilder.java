package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.LIBuilder;
import com.google.gwt.dom.client.LIElement;

public class DomLIBuilder
  extends DomElementBuilderBase<LIBuilder, LIElement>
  implements LIBuilder
{
  DomLIBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
