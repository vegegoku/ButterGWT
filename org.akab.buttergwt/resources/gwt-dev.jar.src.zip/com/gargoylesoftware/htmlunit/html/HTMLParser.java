package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ObjectInstantiationException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebRequest;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLBodyElement;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLDocument;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement.ProxyDomNode;
import com.gargoylesoftware.htmlunit.svg.SvgElementFactory;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Stack;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.apache.commons.lang3.StringUtils;
import org.apache.xerces.parsers.AbstractSAXParser;
import org.apache.xerces.xni.Augmentations;
import org.apache.xerces.xni.QName;
import org.apache.xerces.xni.XMLAttributes;
import org.apache.xerces.xni.XNIException;
import org.apache.xerces.xni.parser.XMLInputSource;
import org.apache.xerces.xni.parser.XMLParserConfiguration;
import org.cyberneko.html.HTMLConfiguration;
import org.cyberneko.html.HTMLEventInfo;
import org.cyberneko.html.HTMLScanner;
import org.cyberneko.html.HTMLTagBalancingListener;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.ext.LexicalHandler;

public final class HTMLParser
{
  public static final String XHTML_NAMESPACE = "http://www.w3.org/1999/xhtml";
  public static final String SVG_NAMESPACE = "http://www.w3.org/2000/svg";
  private static final Map<String, ElementFactory> ELEMENT_FACTORIES = new HashMap();
  private static final ElementFactory SVG_FACTORY = new SvgElementFactory();
  
  static
  {
    ELEMENT_FACTORIES.put("input", InputElementFactory.instance);
    
    DefaultElementFactory defaultElementFactory = new DefaultElementFactory();
    for (String tagName : DefaultElementFactory.SUPPORTED_TAGS_) {
      ELEMENT_FACTORIES.put(tagName, defaultElementFactory);
    }
  }
  
  public static void parseFragment(DomNode parent, String source)
    throws SAXException, IOException
  {
    parseFragment(parent, parent, source);
  }
  
  public static void parseFragment(DomNode parent, DomNode context, String source)
    throws SAXException, IOException
  {
    HtmlPage page = (HtmlPage)parent.getPage();
    URL url = page.getUrl();
    
    HtmlUnitDOMBuilder domBuilder = new HtmlUnitDOMBuilder(parent, url, source, null);
    domBuilder.setFeature("http://cyberneko.org/html/features/balance-tags/document-fragment", true);
    
    DomNode node = context;
    List<QName> ancestors = new ArrayList();
    while ((node != null) && (node.getNodeType() != 9))
    {
      ancestors.add(0, new QName(null, node.getNodeName(), null, null));
      node = node.getParentNode();
    }
    if ((ancestors.isEmpty()) || (!"html".equals(((QName)ancestors.get(0)).localpart))) {
      ancestors.add(0, new QName(null, "html", null, null));
    }
    if ((ancestors.size() == 1) || (!"body".equals(((QName)ancestors.get(1)).localpart))) {
      ancestors.add(1, new QName(null, "body", null, null));
    }
    domBuilder.setFeature("http://cyberneko.org/html/features/scanner/allow-selfclosing-tags", true);
    domBuilder.setProperty("http://cyberneko.org/html/properties/balance-tags/fragment-context-stack", ancestors.toArray(new QName[0]));
    
    XMLInputSource in = new XMLInputSource(null, url.toString(), null, new StringReader(source), null);
    
    page.registerParsingStart();
    page.registerSnippetParsingStart();
    try
    {
      domBuilder.parse(in);
    }
    finally
    {
      page.registerParsingEnd();
      page.registerSnippetParsingEnd();
    }
  }
  
  public static HtmlPage parseHtml(WebResponse webResponse, WebWindow webWindow)
    throws IOException
  {
    HtmlPage page = new HtmlPage(webResponse.getWebRequest().getUrl(), webResponse, webWindow);
    parse(webResponse, webWindow, page, false);
    return page;
  }
  
  public static XHtmlPage parseXHtml(WebResponse webResponse, WebWindow webWindow)
    throws IOException
  {
    XHtmlPage page = new XHtmlPage(webResponse.getWebRequest().getUrl(), webResponse, webWindow);
    parse(webResponse, webWindow, page, true);
    return page;
  }
  
  private static void parse(WebResponse webResponse, WebWindow webWindow, HtmlPage page, boolean xhtml)
    throws IOException
  {
    webWindow.setEnclosedPage(page);
    
    URL url = webResponse.getWebRequest().getUrl();
    HtmlUnitDOMBuilder domBuilder = new HtmlUnitDOMBuilder(page, url, null, null);
    
    String charset = webResponse.getContentCharsetOrNull();
    try
    {
      if (charset != null)
      {
        domBuilder.setFeature("http://cyberneko.org/html/features/scanner/ignore-specified-charset", true);
      }
      else
      {
        String specifiedCharset = webResponse.getWebRequest().getCharset();
        if (specifiedCharset != null) {
          charset = specifiedCharset;
        }
      }
      if (xhtml) {
        domBuilder.setFeature("http://cyberneko.org/html/features/scanner/allow-selfclosing-tags", true);
      }
    }
    catch (Exception e)
    {
      throw new ObjectInstantiationException("Error setting HTML parser feature", e);
    }
    InputStream content = webResponse.getContentAsStream();
    XMLInputSource in = new XMLInputSource(null, url.toString(), null, content, charset);
    
    page.registerParsingStart();
    try
    {
      domBuilder.parse(in);
    }
    catch (XNIException e)
    {
      Throwable origin = extractNestedException(e);
      throw new RuntimeException("Failed parsing content from " + url, origin);
    }
    finally
    {
      page.registerParsingEnd();
    }
    addBodyToPageIfNecessary(page, true, domBuilder.body_ != null);
  }
  
  private static void addBodyToPageIfNecessary(HtmlPage page, boolean originalCall, boolean checkInsideFrameOnly)
  {
    boolean waitToLoad = page.hasFeature(BrowserVersionFeatures.PAGE_WAIT_LOAD_BEFORE_BODY);
    if (((page.getEnclosingWindow() instanceof FrameWindow)) && (originalCall) && (waitToLoad)) {
      return;
    }
    Element doc = page.getDocumentElement();
    boolean hasBody = false;
    for (Node child = doc.getFirstChild(); child != null; child = child.getNextSibling()) {
      if (((child instanceof HtmlBody)) || ((child instanceof HtmlFrameSet)))
      {
        hasBody = true;
        break;
      }
    }
    if ((!hasBody) && (!checkInsideFrameOnly))
    {
      HtmlBody body = new HtmlBody(null, "body", page, null, false);
      doc.appendChild(body);
    }
    if (waitToLoad) {
      for (FrameWindow frame : page.getFrames())
      {
        Page containedPage = frame.getEnclosedPage();
        if ((containedPage != null) && (containedPage.isHtmlPage())) {
          addBodyToPageIfNecessary((HtmlPage)containedPage, false, false);
        }
      }
    }
  }
  
  static Throwable extractNestedException(Throwable e)
  {
    Throwable originalException = e;
    Throwable cause = ((XNIException)e).getException();
    while (cause != null)
    {
      originalException = cause;
      if ((cause instanceof XNIException)) {
        cause = ((XNIException)cause).getException();
      } else if ((cause instanceof InvocationTargetException)) {
        cause = cause.getCause();
      } else {
        cause = null;
      }
    }
    return originalException;
  }
  
  public static ElementFactory getFactory(String tagName)
  {
    ElementFactory result = (ElementFactory)ELEMENT_FACTORIES.get(tagName);
    if (result != null) {
      return result;
    }
    return UnknownElementFactory.instance;
  }
  
  static ElementFactory getElementFactory(HtmlPage page, String namespaceURI, String qualifiedName)
  {
    if ((namespaceURI == null) || (namespaceURI.isEmpty()) || (!qualifiedName.contains(":")) || (namespaceURI.equals("http://www.w3.org/1999/xhtml")))
    {
      if (("http://www.w3.org/2000/svg".equals(namespaceURI)) && (page.hasFeature(BrowserVersionFeatures.SVG))) {
        return SVG_FACTORY;
      }
      String tagName = qualifiedName;
      int index = tagName.indexOf(':');
      if (index != -1) {
        tagName = tagName.substring(index + 1);
      } else {
        tagName = tagName.toLowerCase(Locale.ENGLISH);
      }
      ElementFactory factory = (ElementFactory)ELEMENT_FACTORIES.get(tagName);
      if (factory != null) {
        return factory;
      }
    }
    return UnknownElementFactory.instance;
  }
  
  static final class HtmlUnitDOMBuilder
    extends AbstractSAXParser
    implements ContentHandler, LexicalHandler, HTMLTagBalancingListener
  {
    private final HtmlPage page_;
    private Locator locator_;
    private final Stack<DomNode> stack_ = new Stack();
    private DomNode currentNode_;
    private StringBuilder characters_;
    private boolean headParsed_ = false;
    private boolean parsingInnerHead_ = false;
    private HtmlElement head_;
    private HtmlElement body_;
    private Augmentations augmentations_;
    private HtmlForm formWaitingForLostChildren_;
    private static final String FEATURE_AUGMENTATIONS = "http://cyberneko.org/html/features/augmentations";
    private static final String FEATURE_PARSE_NOSCRIPT = "http://cyberneko.org/html/features/parse-noscript-content";
    
    public void pushInputString(String html)
    {
      this.page_.registerParsingStart();
      this.page_.registerInlineSnippetParsingStart();
      try
      {
        WebResponse webResponse = this.page_.getWebResponse();
        String charset = webResponse.getContentCharset();
        String url = webResponse.getWebRequest().getUrl().toString();
        XMLInputSource in = new XMLInputSource(null, url, null, new StringReader(html), charset);
        ((HTMLConfiguration)this.fConfiguration).evaluateInputSource(in);
      }
      finally
      {
        this.page_.registerParsingEnd();
        this.page_.registerInlineSnippetParsingEnd();
      }
    }
    
    private HtmlUnitDOMBuilder(DomNode node, URL url, String htmlContent)
    {
      super();
      this.page_ = ((HtmlPage)node.getPage());
      
      this.currentNode_ = node;
      for (Node ancestor : this.currentNode_.getAncestors(true)) {
        this.stack_.push((DomNode)ancestor);
      }
      WebClient webClient = this.page_.getWebClient();
      HTMLParserListener listener = webClient.getHTMLParserListener();
      boolean reportErrors;
      if (listener != null)
      {
        boolean reportErrors = true;
        this.fConfiguration.setErrorHandler(new HTMLErrorHandler(listener, url, htmlContent));
      }
      else
      {
        reportErrors = false;
      }
      try
      {
        setFeature("http://cyberneko.org/html/features/augmentations", true);
        setProperty("http://cyberneko.org/html/properties/names/elems", "default");
        setFeature("http://cyberneko.org/html/features/report-errors", reportErrors);
        setFeature("http://cyberneko.org/html/features/parse-noscript-content", !webClient.getOptions().isJavaScriptEnabled());
        setFeature("http://cyberneko.org/html/features/scanner/allow-selfclosing-iframe", !webClient.getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLIFRAME_IGNORE_SELFCLOSING));
        
        setContentHandler(this);
        setLexicalHandler(this);
      }
      catch (SAXException e)
      {
        throw new ObjectInstantiationException("unable to create HTML parser", e);
      }
    }
    
    private static XMLParserConfiguration createConfiguration(WebClient webClient)
    {
      BrowserVersion browserVersion = webClient.getBrowserVersion();
      if (browserVersion.hasFeature(BrowserVersionFeatures.HTMLCONDITIONAL_COMMENTS)) {
        new HTMLConfiguration()
        {
          protected HTMLScanner createDocumentScanner()
          {
            return new HTMLScannerForIE(this.val$browserVersion);
          }
        };
      }
      return new HTMLConfiguration();
    }
    
    public Locator getLocator()
    {
      return this.locator_;
    }
    
    public void setDocumentLocator(Locator locator)
    {
      this.locator_ = locator;
    }
    
    public void startDocument()
      throws SAXException
    {}
    
    public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
      throws SAXException
    {
      handleCharacters();
      
      String tagLower = localName.toLowerCase(Locale.ENGLISH);
      if ((this.page_.isParsingHtmlSnippet()) && (("html".equals(tagLower)) || ("body".equals(tagLower)))) {
        return;
      }
      if ((this.parsingInnerHead_) && (this.page_.hasFeature(BrowserVersionFeatures.IGNORE_CONTENTS_OF_INNER_HEAD))) {
        return;
      }
      if (namespaceURI != null) {
        namespaceURI = namespaceURI.trim();
      }
      if ("head".equals(tagLower))
      {
        if ((this.headParsed_) || (this.page_.isParsingHtmlSnippet()))
        {
          this.parsingInnerHead_ = true;
          return;
        }
        this.headParsed_ = true;
      }
      else if ((!this.headParsed_) && (("body".equals(tagLower)) || ("frameset".equals(tagLower))))
      {
        ElementFactory factory = HTMLParser.getElementFactory(this.page_, namespaceURI, "head");
        DomElement newElement = factory.createElement(this.page_, "head", null);
        this.currentNode_.appendChild(newElement);
        this.headParsed_ = true;
      }
      HtmlBody oldBody = null;
      if (("body".equals(qName)) && ((this.page_.getBody() instanceof HtmlBody))) {
        oldBody = (HtmlBody)this.page_.getBody();
      }
      if ((!(this.page_ instanceof XHtmlPage)) && ("http://www.w3.org/1999/xhtml".equals(namespaceURI))) {
        namespaceURI = null;
      }
      ElementFactory factory = HTMLParser.getElementFactory(this.page_, namespaceURI, qName);
      DomElement newElement = factory.createElementNS(this.page_, namespaceURI, qName, atts, true);
      newElement.setStartLocation(this.locator_.getLineNumber(), this.locator_.getColumnNumber());
      
      addNodeToRightParent(this.currentNode_, newElement);
      if (oldBody != null) {
        oldBody.quietlyRemoveAndMoveChildrenTo(newElement);
      }
      if ("body".equals(tagLower)) {
        this.body_ = ((HtmlElement)newElement);
      } else if ("head".equals(tagLower)) {
        this.head_ = ((HtmlElement)newElement);
      } else if ("html".equals(tagLower))
      {
        if ((!this.page_.hasFeature(BrowserVersionFeatures.JS_DEFINE_GETTER)) && (this.page_.isQuirksMode())) {
          removePrototypeProperties((Scriptable)this.page_.getEnclosingWindow().getScriptObject(), "Array", new String[] { "every", "filter", "forEach", "indexOf", "lastIndexOf", "map", "reduce", "reduceRight", "some" });
        }
      }
      else if ("meta".equals(tagLower)) {
        if (this.page_.hasFeature(BrowserVersionFeatures.META_X_UA_COMPATIBLE))
        {
          HtmlMeta meta = (HtmlMeta)newElement;
          if ("X-UA-Compatible".equals(meta.getHttpEquivAttribute()))
          {
            String content = meta.getContentAttribute();
            if (content.startsWith("IE="))
            {
              String mode = content.substring(3).trim();
              int version = (int)this.page_.getWebClient().getBrowserVersion().getBrowserVersionNumeric();
              if ("edge".equals(mode)) {
                ((HTMLDocument)this.page_.getScriptObject()).forceDocumentMode(version);
              } else {
                try
                {
                  int value = Integer.parseInt(mode);
                  if (value > version) {
                    value = version;
                  }
                  ((HTMLDocument)this.page_.getScriptObject()).forceDocumentMode(value);
                }
                catch (Exception e) {}
              }
            }
          }
        }
      }
      this.currentNode_ = newElement;
      this.stack_.push(this.currentNode_);
    }
    
    private void removePrototypeProperties(Scriptable scope, String className, String... properties)
    {
      ScriptableObject prototype = (ScriptableObject)ScriptableObject.getClassPrototype(scope, className);
      for (String property : properties) {
        prototype.delete(property);
      }
    }
    
    private void addNodeToRightParent(DomNode currentNode, DomElement newElement)
    {
      String currentNodeName = currentNode.getNodeName();
      String newNodeName = newElement.getNodeName();
      if (("table".equals(currentNodeName)) && ("div".equals(newNodeName))) {
        currentNode.insertBefore(newElement);
      } else if ((this.head_ != null) && ("title".equals(newNodeName))) {
        this.head_.appendChild(newElement);
      } else {
        currentNode.appendChild(newElement);
      }
    }
    
    public void endElement(QName element, Augmentations augs)
      throws XNIException
    {
      this.augmentations_ = augs;
      super.endElement(element, augs);
    }
    
    public void endElement(String namespaceURI, String localName, String qName)
      throws SAXException
    {
      handleCharacters();
      
      String tagLower = localName.toLowerCase(Locale.ENGLISH);
      if ((this.page_.isParsingHtmlSnippet()) && (("html".equals(tagLower)) || ("body".equals(tagLower)))) {
        return;
      }
      if (this.parsingInnerHead_)
      {
        if ("head".equals(tagLower)) {
          this.parsingInnerHead_ = false;
        }
        if (("head".equals(tagLower)) || (this.page_.hasFeature(BrowserVersionFeatures.IGNORE_CONTENTS_OF_INNER_HEAD))) {
          return;
        }
      }
      DomNode previousNode = (DomNode)this.stack_.pop();
      previousNode.setEndLocation(this.locator_.getLineNumber(), this.locator_.getColumnNumber());
      if (((previousNode instanceof HtmlForm)) && (((HTMLEventInfo)this.augmentations_.getItem("http://cyberneko.org/html/features/augmentations")).isSynthesized())) {
        this.formWaitingForLostChildren_ = ((HtmlForm)previousNode);
      } else if ((this.formWaitingForLostChildren_ != null) && ((previousNode instanceof SubmittableElement))) {
        this.formWaitingForLostChildren_.addLostChild((HtmlElement)previousNode);
      }
      if (!this.stack_.isEmpty()) {
        this.currentNode_ = ((DomNode)this.stack_.peek());
      }
      boolean postponed = this.page_.isParsingInlineHtmlSnippet();
      previousNode.onAllChildrenAddedToPage(postponed);
    }
    
    public void characters(char[] ch, int start, int length)
      throws SAXException
    {
      if (((this.characters_ == null) || (this.characters_.length() == 0)) && (this.page_.hasFeature(BrowserVersionFeatures.HTMLPARSER_REMOVE_EMPTY_CONTENT)) && (StringUtils.isBlank(new String(ch, start, length))))
      {
        DomNode node = this.currentNode_.getLastChild();
        if ((this.currentNode_ instanceof HTMLElement.ProxyDomNode))
        {
          HTMLElement.ProxyDomNode proxyNode = (HTMLElement.ProxyDomNode)this.currentNode_;
          node = proxyNode.getDomNode();
          if (!proxyNode.isAppend())
          {
            node = node.getPreviousSibling();
            if (node == null) {
              node = proxyNode.getDomNode().getParentNode();
            }
          }
        }
        if (removeEmptyCharacters(node)) {
          return;
        }
      }
      if (this.characters_ == null) {
        this.characters_ = new StringBuilder();
      }
      this.characters_.append(ch, start, length);
    }
    
    private boolean removeEmptyCharacters(DomNode node)
    {
      if (node != null)
      {
        if ((node instanceof HtmlInput)) {
          return false;
        }
        if ((node.getFirstChild() != null) && (((node instanceof HtmlAnchor)) || ((node instanceof HtmlSpan)) || ((node instanceof HtmlFont)) || ((node instanceof HtmlStrong)) || ((node instanceof HtmlBold)) || ((node instanceof HtmlItalic)) || ((node instanceof HtmlUnderlined)) || ((node instanceof HtmlEmphasis)) || ((node instanceof HtmlAbbreviated)) || ((node instanceof HtmlAcronym)) || ((node instanceof HtmlBaseFont)) || ((node instanceof HtmlBidirectionalOverride)) || ((node instanceof HtmlBig)) || ((node instanceof HtmlBlink)) || ((node instanceof HtmlCitation)) || ((node instanceof HtmlCode)) || ((node instanceof HtmlDeletedText)) || ((node instanceof HtmlDefinition)) || ((node instanceof HtmlInsertedText)) || ((node instanceof HtmlKeyboard)) || ((node instanceof HtmlLabel)) || ((node instanceof HtmlMap)) || ((node instanceof HtmlNoBreak)) || ((node instanceof HtmlInlineQuotation)) || ((node instanceof HtmlS)) || ((node instanceof HtmlSample)) || ((node instanceof HtmlSmall)) || ((node instanceof HtmlStrike)) || ((node instanceof HtmlSubscript)) || ((node instanceof HtmlSuperscript)) || ((node instanceof HtmlTeletype)) || ((node instanceof HtmlVariable)))) {
          return false;
        }
      }
      else if ((this.currentNode_ instanceof HtmlFont))
      {
        return false;
      }
      return true;
    }
    
    public void ignorableWhitespace(char[] ch, int start, int length)
      throws SAXException
    {
      if (this.characters_ == null) {
        this.characters_ = new StringBuilder();
      }
      this.characters_.append(ch, start, length);
    }
    
    private void handleCharacters()
    {
      if ((this.characters_ != null) && (this.characters_.length() > 0)) {
        if ((this.currentNode_ instanceof HtmlHtml))
        {
          this.characters_.setLength(0);
        }
        else
        {
          String textValue = this.characters_.toString();
          DomText text = new DomText(this.page_, textValue);
          this.characters_.setLength(0);
          if (((this.currentNode_ instanceof HtmlTableRow)) && (StringUtils.isNotBlank(textValue)))
          {
            HtmlTableRow row = (HtmlTableRow)this.currentNode_;
            HtmlTable enclosingTable = row.getEnclosingTable();
            if (enclosingTable != null) {
              enclosingTable.insertBefore(text);
            }
          }
          else
          {
            this.currentNode_.appendChild(text);
          }
        }
      }
    }
    
    public void endDocument()
      throws SAXException
    {
      handleCharacters();
      DomNode currentPage = this.page_;
      currentPage.setEndLocation(this.locator_.getLineNumber(), this.locator_.getColumnNumber());
    }
    
    public void startPrefixMapping(String prefix, String uri)
      throws SAXException
    {}
    
    public void endPrefixMapping(String prefix)
      throws SAXException
    {}
    
    public void processingInstruction(String target, String data)
      throws SAXException
    {}
    
    public void skippedEntity(String name)
      throws SAXException
    {}
    
    public void comment(char[] ch, int start, int length)
    {
      handleCharacters();
      String data = new String(ch, start, length);
      if ((!data.startsWith("[CDATA")) || (!this.page_.hasFeature(BrowserVersionFeatures.GENERATED_3)))
      {
        DomComment comment = new DomComment(this.page_, data);
        this.currentNode_.appendChild(comment);
      }
    }
    
    public void endCDATA() {}
    
    public void endDTD() {}
    
    public void endEntity(String name) {}
    
    public void startCDATA() {}
    
    public void startDTD(String name, String publicId, String systemId)
    {
      DomDocumentType type = new DomDocumentType(this.page_, name, publicId, systemId);
      this.page_.setDocumentType(type);
      Node child;
      Node child;
      if (this.page_.hasFeature(BrowserVersionFeatures.DOCTYPE_IS_COMMENT)) {
        child = new DomComment(this.page_, "DOCTYPE " + name + " PUBLIC \"" + publicId + "\"      \"" + systemId + '"');
      } else {
        child = type;
      }
      this.page_.appendChild(child);
    }
    
    public void startEntity(String name) {}
    
    public void ignoredEndElement(QName element, Augmentations augs)
    {
      if ((this.formWaitingForLostChildren_ != null) && ("form".equals(element.localpart))) {
        this.formWaitingForLostChildren_ = null;
      }
    }
    
    public void ignoredStartElement(QName elem, XMLAttributes attrs, Augmentations augs)
    {
      if ((this.body_ != null) && ("body".equalsIgnoreCase(elem.localpart)) && (attrs != null))
      {
        int length = attrs.getLength();
        for (int i = 0; i < length; i++)
        {
          String attrName = attrs.getLocalName(i).toLowerCase(Locale.ENGLISH);
          if (this.body_.getAttributes().getNamedItem(attrName) == null)
          {
            this.body_.setAttribute(attrName, attrs.getValue(i));
            if ((attrName.startsWith("on")) && (this.body_.getScriptObject() != null))
            {
              HTMLBodyElement jsBody = (HTMLBodyElement)this.body_.getScriptObject();
              jsBody.createEventHandlerFromAttribute(attrName, attrs.getValue(i));
            }
          }
        }
      }
    }
    
    public void parse(XMLInputSource inputSource)
      throws XNIException, IOException
    {
      HtmlUnitDOMBuilder oldBuilder = this.page_.getBuilder();
      this.page_.setBuilder(this);
      try
      {
        super.parse(inputSource);
      }
      finally
      {
        this.page_.setBuilder(oldBuilder);
      }
    }
  }
}
