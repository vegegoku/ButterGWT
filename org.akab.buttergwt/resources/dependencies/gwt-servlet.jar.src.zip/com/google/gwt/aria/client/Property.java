package com.google.gwt.aria.client;

public final class Property
{
  public static final Attribute<Id> ACTIVEDESCENDANT = new AriaValueAttribute("aria-activedescendant", "");
  public static final Attribute<Boolean> ATOMIC = new PrimitiveValueAttribute("aria-atomic", "false");
  public static final Attribute<AutocompleteValue> AUTOCOMPLETE = new AriaValueAttribute("aria-autocomplete", "none");
  public static final Attribute<Id> CONTROLS = new AriaValueAttribute("aria-controls", "");
  public static final Attribute<Id> DESCRIBEDBY = new AriaValueAttribute("aria-describedby", "");
  public static final Attribute<DropeffectValue> DROPEFFECT = new AriaValueAttribute("aria-dropeffect", "none");
  public static final Attribute<Id> FLOWTO = new AriaValueAttribute("aria-flowto", "");
  public static final Attribute<Boolean> HASPOPUP = new PrimitiveValueAttribute("aria-haspopup", "false");
  public static final Attribute<String> LABEL = new PrimitiveValueAttribute("aria-label", "");
  public static final Attribute<Id> LABELLEDBY = new AriaValueAttribute("aria-labelledby", "");
  public static final Attribute<Integer> LEVEL = new PrimitiveValueAttribute("aria-level", "");
  public static final Attribute<LiveValue> LIVE = new AriaValueAttribute("aria-live", "off");
  public static final Attribute<Boolean> MULTILINE = new PrimitiveValueAttribute("aria-multiline", "false");
  public static final Attribute<Boolean> MULTISELECTABLE = new PrimitiveValueAttribute("aria-multiselectable", "false");
  public static final Attribute<OrientationValue> ORIENTATION = new AriaValueAttribute("aria-orientation", "vertical");
  public static final Attribute<Id> OWNS = new AriaValueAttribute("aria-owns", "");
  public static final Attribute<Integer> POSINSET = new PrimitiveValueAttribute("aria-posinset", "");
  public static final Attribute<Boolean> READONLY = new PrimitiveValueAttribute("aria-readonly", "false");
  public static final Attribute<RelevantValue> RELEVANT = new AriaValueAttribute("aria-relevant", "additions text");
  public static final Attribute<Boolean> REQUIRED = new PrimitiveValueAttribute("aria-required", "false");
  public static final Attribute<Integer> SETSIZE = new PrimitiveValueAttribute("aria-setsize", "");
  public static final Attribute<SortValue> SORT = new AriaValueAttribute("aria-sort", "none");
  public static final Attribute<Number> VALUEMAX = new PrimitiveValueAttribute("aria-valuemax", "");
  public static final Attribute<Number> VALUEMIN = new PrimitiveValueAttribute("aria-valuemin", "");
  public static final Attribute<Number> VALUENOW = new PrimitiveValueAttribute("aria-valuenow", "");
  public static final Attribute<String> VALUETEXT = new PrimitiveValueAttribute("aria-valuetext", "");
}
