package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlListItem;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={HtmlListItem.class})
public class HTMLLIElement
  extends HTMLElement
{
  public String getDefaultStyleDisplay()
  {
    return "list-item";
  }
}
