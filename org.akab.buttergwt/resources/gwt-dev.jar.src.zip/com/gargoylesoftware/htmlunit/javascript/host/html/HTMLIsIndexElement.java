package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlIsIndex;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass(domClasses={HtmlIsIndex.class})
public class HTMLIsIndexElement
  extends HTMLElement
{
  protected boolean isEndTagForbidden()
  {
    return true;
  }
}
