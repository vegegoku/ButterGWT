package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import org.w3c.dom.DocumentType;
import org.w3c.dom.NamedNodeMap;

public class DomDocumentType
  extends DomNode
  implements DocumentType
{
  private final String name_;
  private final String publicId_;
  private final String systemId_;
  
  public DomDocumentType(SgmlPage page, String name, String publicId, String systemId)
  {
    super(page);
    this.name_ = name;
    this.publicId_ = publicId;
    this.systemId_ = systemId;
  }
  
  public String getNodeName()
  {
    return this.name_;
  }
  
  public short getNodeType()
  {
    return 10;
  }
  
  public NamedNodeMap getEntities()
  {
    return null;
  }
  
  public String getInternalSubset()
  {
    return "";
  }
  
  public String getName()
  {
    return this.name_;
  }
  
  public NamedNodeMap getNotations()
  {
    return null;
  }
  
  public String getPublicId()
  {
    return this.publicId_;
  }
  
  public String getSystemId()
  {
    return this.systemId_;
  }
}
