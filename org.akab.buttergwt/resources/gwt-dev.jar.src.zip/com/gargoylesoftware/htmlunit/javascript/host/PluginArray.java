package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;

@JsxClass
public class PluginArray
  extends SimpleArray
{
  @JsxFunction
  public void refresh(boolean reloadDocuments) {}
  
  protected String getItemName(Object element)
  {
    return ((Plugin)element).getName();
  }
}
