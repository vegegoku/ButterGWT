package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass
public class Screen
  extends SimpleScriptable
{
  private int left_;
  private int top_;
  private int width_;
  private int height_;
  private int colorDepth_;
  private int bufferDepth_;
  private int dpi_;
  private boolean fontSmoothingEnabled_;
  private int updateInterval_;
  
  public Screen()
  {
    this.left_ = 0;
    this.top_ = 0;
    this.width_ = 1024;
    this.height_ = 768;
    this.colorDepth_ = 24;
    this.bufferDepth_ = 24;
    this.dpi_ = 96;
    this.fontSmoothingEnabled_ = true;
    this.updateInterval_ = 0;
  }
  
  @JsxGetter
  public int getAvailHeight()
  {
    return this.height_;
  }
  
  @JsxGetter
  public int getAvailLeft()
  {
    return this.left_;
  }
  
  @JsxGetter
  public int getAvailTop()
  {
    return this.top_;
  }
  
  @JsxGetter
  public int getAvailWidth()
  {
    return this.width_;
  }
  
  @JsxGetter
  public int getBufferDepth()
  {
    return this.bufferDepth_;
  }
  
  @JsxSetter
  public void setBufferDepth(int bufferDepth)
  {
    this.bufferDepth_ = bufferDepth;
  }
  
  @JsxGetter
  public int getColorDepth()
  {
    return this.colorDepth_;
  }
  
  @JsxGetter
  public int getDeviceXDPI()
  {
    return this.dpi_;
  }
  
  @JsxGetter
  public int getDeviceYDPI()
  {
    return this.dpi_;
  }
  
  @JsxGetter
  public boolean getFontSmoothingEnabled()
  {
    return this.fontSmoothingEnabled_;
  }
  
  @JsxGetter
  public int getHeight()
  {
    return this.height_;
  }
  
  @JsxGetter
  public int getLeft()
  {
    return this.left_;
  }
  
  @JsxSetter
  public void setLeft(int left)
  {
    this.left_ = left;
  }
  
  @JsxGetter
  public int getLogicalXDPI()
  {
    return this.dpi_;
  }
  
  @JsxGetter
  public int getLogicalYDPI()
  {
    return this.dpi_;
  }
  
  @JsxGetter
  public int getPixelDepth()
  {
    return this.colorDepth_;
  }
  
  @JsxGetter
  public int getTop()
  {
    return this.top_;
  }
  
  @JsxSetter
  public void setTop(int top)
  {
    this.top_ = top;
  }
  
  @JsxGetter
  public int getUpdateInterval()
  {
    return this.updateInterval_;
  }
  
  @JsxSetter
  public void setUpdateInterval(int updateInterval)
  {
    this.updateInterval_ = updateInterval;
  }
  
  @JsxGetter
  public int getWidth()
  {
    return this.width_;
  }
}
