package com.google.gwt.core.server;

import com.google.gwt.core.shared.GWT;
import com.google.gwt.core.shared.GWTBridge;
import com.google.gwt.i18n.server.GwtLocaleFactoryImpl;
import com.google.gwt.i18n.shared.GwtLocale;
import com.google.gwt.i18n.shared.GwtLocaleFactory;
import com.google.gwt.i18n.shared.Localizable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ServerGwtBridge
  extends GWTBridge
{
  public static abstract interface ClassInstantiator
  {
    public abstract <T> T create(Class<?> paramClass, ServerGwtBridge.Properties paramProperties);
  }
  
  public static abstract class ClassInstantiatorBase
    implements ServerGwtBridge.ClassInstantiator
  {
    protected <T> T tryCreate(Class<T> clazz)
    {
      try
      {
        return (T)clazz.newInstance();
      }
      catch (InstantiationException e) {}catch (IllegalAccessException e) {}
      return null;
    }
    
    protected <T> T tryCreate(String className)
    {
      try
      {
        Class<?> clazz = Class.forName(className);
        
        return (T)tryCreate(clazz);
      }
      catch (ClassNotFoundException e) {}
      return null;
    }
  }
  
  public static abstract interface Properties
  {
    public abstract String getProperty(String paramString);
  }
  
  private static class Node
  {
    public final Class<?> type;
    public final ArrayList<Node> children;
    public final ArrayList<ServerGwtBridge.ClassInstantiator> instantiators;
    
    public Node(Class<?> type)
    {
      this.type = type;
      this.children = new ArrayList();
      this.instantiators = new ArrayList();
    }
  }
  
  private static class PropertiesImpl
    implements ServerGwtBridge.Properties
  {
    private final Object lock = new Object[0];
    private final Map<String, String> map = new HashMap();
    
    /* Error */
    public String getProperty(String name)
    {
      // Byte code:
      //   0: aload_0
      //   1: getfield 4	com/google/gwt/core/server/ServerGwtBridge$PropertiesImpl:lock	Ljava/lang/Object;
      //   4: dup
      //   5: astore_2
      //   6: monitorenter
      //   7: aload_0
      //   8: getfield 7	com/google/gwt/core/server/ServerGwtBridge$PropertiesImpl:map	Ljava/util/Map;
      //   11: aload_1
      //   12: invokeinterface 8 2 0
      //   17: checkcast 9	java/lang/String
      //   20: aload_2
      //   21: monitorexit
      //   22: areturn
      //   23: astore_3
      //   24: aload_2
      //   25: monitorexit
      //   26: aload_3
      //   27: athrow
      // Line number table:
      //   Java source line #130	-> byte code offset #0
      //   Java source line #131	-> byte code offset #7
      //   Java source line #132	-> byte code offset #23
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	28	0	this	PropertiesImpl
      //   0	28	1	name	String
      //   5	20	2	Ljava/lang/Object;	Object
      //   23	4	3	localObject1	Object
      // Exception table:
      //   from	to	target	type
      //   7	22	23	finally
      //   23	26	23	finally
    }
    
    public void setProperty(String name, String value)
    {
      synchronized (this.lock)
      {
        this.map.put(name, value);
      }
    }
  }
  
  private class PropertyLookup
    implements ServerGwtBridge.Properties
  {
    private PropertyLookup() {}
    
    public String getProperty(String name)
    {
      String val = ((ServerGwtBridge.PropertiesImpl)ServerGwtBridge.this.threadProperties.get()).getProperty(name);
      if (val == null) {
        val = ServerGwtBridge.this.globalProperties.getProperty(name);
      }
      return val;
    }
  }
  
  private static Object instanceLock = new Object[0];
  private static ServerGwtBridge instance = null;
  private static final GwtLocaleFactory factory = new GwtLocaleFactoryImpl();
  private static final Logger LOGGER = Logger.getLogger(ServerGwtBridge.class.getName());
  
  public static ServerGwtBridge getInstance()
  {
    synchronized (instanceLock)
    {
      if (instance == null)
      {
        instance = new ServerGwtBridge();
        GWT.setBridge(instance);
      }
      return instance;
    }
  }
  
  public static GwtLocale getLocale(Properties properties)
  {
    String propVal = properties.getProperty("locale");
    if (propVal == null) {
      propVal = "default";
    }
    return factory.fromString(propVal);
  }
  
  private final Node root = new Node(Object.class);
  private final Object instantiatorsLock = new Object[0];
  private final ThreadLocal<PropertiesImpl> threadProperties;
  private final PropertiesImpl globalProperties = new PropertiesImpl(null);
  private Properties properties = new PropertyLookup(null);
  
  ServerGwtBridge()
  {
    this.threadProperties = new ThreadLocal()
    {
      protected ServerGwtBridge.PropertiesImpl initialValue()
      {
        return new ServerGwtBridge.PropertiesImpl(null);
      }
    };
    register(Object.class, new ObjectNew());
    register(Localizable.class, new LocalizableInstantiator());
  }
  
  public <T> T create(Class<?> classLiteral)
  {
    synchronized (this.instantiatorsLock)
    {
      Stack<Node> stack = new Stack();
      stack.push(this.root);
      boolean found;
      do
      {
        found = false;
        Node node = (Node)stack.peek();
        for (Node child : node.children) {
          if (child.type.isAssignableFrom(classLiteral))
          {
            found = true;
            stack.push(child);
            break;
          }
        }
      } while (found);
      while (!stack.isEmpty())
      {
        Node node = (Node)stack.pop();
        for (ClassInstantiator inst : node.instantiators)
        {
          T obj = inst.create(classLiteral, this.properties);
          if (obj != null) {
            return obj;
          }
        }
      }
      throw new RuntimeException("No instantiator created " + classLiteral.getCanonicalName());
    }
  }
  
  public String getProperty(String property)
  {
    return this.properties.getProperty(property);
  }
  
  public String getVersion()
  {
    return "unknown";
  }
  
  public boolean isClient()
  {
    return false;
  }
  
  public void log(String message, Throwable e)
  {
    LOGGER.log(Level.INFO, message, e);
  }
  
  public void register(Class<?> baseClass, ClassInstantiator instantiator)
  {
    synchronized (this.instantiatorsLock)
    {
      Node node = this.root;
      boolean found;
      do
      {
        found = false;
        for (Node child : node.children) {
          if (child.type.isAssignableFrom(baseClass))
          {
            found = true;
            node = child;
          }
        }
      } while (found);
      Node nodeToAdd = node;
      if (node.type != baseClass)
      {
        nodeToAdd = new Node(baseClass);
        
        boolean needsAdd = true;
        for (Node child : node.children) {
          if (baseClass.isAssignableFrom(child.type))
          {
            nodeToAdd.children.add(child);
            int childPosition = node.children.indexOf(child);
            node.children.set(childPosition, nodeToAdd);
            needsAdd = false;
            break;
          }
        }
        if (needsAdd) {
          node.children.add(nodeToAdd);
        }
      }
      nodeToAdd.instantiators.add(0, instantiator);
    }
  }
  
  public void setGlobalProperty(String property, String value)
  {
    this.globalProperties.setProperty(property, value);
  }
  
  public void setThreadProperty(String property, String value)
  {
    ((PropertiesImpl)this.threadProperties.get()).setProperty(property, value);
  }
}
