package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.AbstractElementBuilderBase;
import com.google.gwt.dom.builder.shared.AnchorBuilder;
import com.google.gwt.dom.builder.shared.AreaBuilder;
import com.google.gwt.dom.builder.shared.AudioBuilder;
import com.google.gwt.dom.builder.shared.BRBuilder;
import com.google.gwt.dom.builder.shared.BaseBuilder;
import com.google.gwt.dom.builder.shared.BodyBuilder;
import com.google.gwt.dom.builder.shared.ButtonBuilder;
import com.google.gwt.dom.builder.shared.CanvasBuilder;
import com.google.gwt.dom.builder.shared.DListBuilder;
import com.google.gwt.dom.builder.shared.DivBuilder;
import com.google.gwt.dom.builder.shared.ElementBuilder;
import com.google.gwt.dom.builder.shared.ElementBuilderBase;
import com.google.gwt.dom.builder.shared.FieldSetBuilder;
import com.google.gwt.dom.builder.shared.FormBuilder;
import com.google.gwt.dom.builder.shared.FrameBuilder;
import com.google.gwt.dom.builder.shared.FrameSetBuilder;
import com.google.gwt.dom.builder.shared.HRBuilder;
import com.google.gwt.dom.builder.shared.HeadBuilder;
import com.google.gwt.dom.builder.shared.HeadingBuilder;
import com.google.gwt.dom.builder.shared.IFrameBuilder;
import com.google.gwt.dom.builder.shared.ImageBuilder;
import com.google.gwt.dom.builder.shared.InputBuilder;
import com.google.gwt.dom.builder.shared.LIBuilder;
import com.google.gwt.dom.builder.shared.LabelBuilder;
import com.google.gwt.dom.builder.shared.LegendBuilder;
import com.google.gwt.dom.builder.shared.LinkBuilder;
import com.google.gwt.dom.builder.shared.MapBuilder;
import com.google.gwt.dom.builder.shared.MetaBuilder;
import com.google.gwt.dom.builder.shared.OListBuilder;
import com.google.gwt.dom.builder.shared.OptGroupBuilder;
import com.google.gwt.dom.builder.shared.OptionBuilder;
import com.google.gwt.dom.builder.shared.ParagraphBuilder;
import com.google.gwt.dom.builder.shared.ParamBuilder;
import com.google.gwt.dom.builder.shared.PreBuilder;
import com.google.gwt.dom.builder.shared.QuoteBuilder;
import com.google.gwt.dom.builder.shared.ScriptBuilder;
import com.google.gwt.dom.builder.shared.SelectBuilder;
import com.google.gwt.dom.builder.shared.SourceBuilder;
import com.google.gwt.dom.builder.shared.SpanBuilder;
import com.google.gwt.dom.builder.shared.StyleBuilder;
import com.google.gwt.dom.builder.shared.TableBuilder;
import com.google.gwt.dom.builder.shared.TableCaptionBuilder;
import com.google.gwt.dom.builder.shared.TableCellBuilder;
import com.google.gwt.dom.builder.shared.TableColBuilder;
import com.google.gwt.dom.builder.shared.TableRowBuilder;
import com.google.gwt.dom.builder.shared.TableSectionBuilder;
import com.google.gwt.dom.builder.shared.TextAreaBuilder;
import com.google.gwt.dom.builder.shared.UListBuilder;
import com.google.gwt.dom.builder.shared.VideoBuilder;
import com.google.gwt.dom.client.Element;

public class DomElementBuilderBase<R extends ElementBuilderBase<?>, E extends Element>
  extends AbstractElementBuilderBase<R>
{
  private final DomBuilderImpl delegate;
  
  DomElementBuilderBase(DomBuilderImpl delegate)
  {
    this(delegate, false);
  }
  
  DomElementBuilderBase(DomBuilderImpl delegate, boolean isEndTagForbidden)
  {
    super(delegate, isEndTagForbidden);
    this.delegate = delegate;
  }
  
  public R attribute(String name, int value)
  {
    assertCanAddAttribute().setAttribute(name, String.valueOf(value));
    return getReturnBuilder();
  }
  
  public R attribute(String name, String value)
  {
    assertCanAddAttribute().setAttribute(name, value);
    return getReturnBuilder();
  }
  
  public R className(String className)
  {
    assertCanAddAttribute().setClassName(className);
    return getReturnBuilder();
  }
  
  public R dir(String dir)
  {
    assertCanAddAttribute().setDir(dir);
    return getReturnBuilder();
  }
  
  public R draggable(String draggable)
  {
    assertCanAddAttribute().setDraggable(draggable);
    return getReturnBuilder();
  }
  
  public R id(String id)
  {
    assertCanAddAttribute().setId(id);
    return getReturnBuilder();
  }
  
  public R lang(String lang)
  {
    assertCanAddAttribute().setLang(lang);
    return getReturnBuilder();
  }
  
  public AnchorBuilder startAnchor()
  {
    return this.delegate.startAnchor();
  }
  
  public AreaBuilder startArea()
  {
    return this.delegate.startArea();
  }
  
  public AudioBuilder startAudio()
  {
    return this.delegate.startAudio();
  }
  
  public BaseBuilder startBase()
  {
    return this.delegate.startBase();
  }
  
  public QuoteBuilder startBlockQuote()
  {
    return this.delegate.startBlockQuote();
  }
  
  public BodyBuilder startBody()
  {
    return this.delegate.startBody();
  }
  
  public BRBuilder startBR()
  {
    return this.delegate.startBR();
  }
  
  public InputBuilder startButtonInput()
  {
    return this.delegate.startButtonInput();
  }
  
  public CanvasBuilder startCanvas()
  {
    return this.delegate.startCanvas();
  }
  
  public InputBuilder startCheckboxInput()
  {
    return this.delegate.startCheckboxInput();
  }
  
  public TableColBuilder startCol()
  {
    return this.delegate.startCol();
  }
  
  public TableColBuilder startColGroup()
  {
    return this.delegate.startColGroup();
  }
  
  public DivBuilder startDiv()
  {
    return this.delegate.startDiv();
  }
  
  public DListBuilder startDList()
  {
    return this.delegate.startDList();
  }
  
  public FieldSetBuilder startFieldSet()
  {
    return this.delegate.startFieldSet();
  }
  
  public InputBuilder startFileInput()
  {
    return this.delegate.startFileInput();
  }
  
  public FormBuilder startForm()
  {
    return this.delegate.startForm();
  }
  
  public FrameBuilder startFrame()
  {
    return this.delegate.startFrame();
  }
  
  public FrameSetBuilder startFrameSet()
  {
    return this.delegate.startFrameSet();
  }
  
  public HeadingBuilder startH1()
  {
    return this.delegate.startH1();
  }
  
  public HeadingBuilder startH2()
  {
    return this.delegate.startH2();
  }
  
  public HeadingBuilder startH3()
  {
    return this.delegate.startH3();
  }
  
  public HeadingBuilder startH4()
  {
    return this.delegate.startH4();
  }
  
  public HeadingBuilder startH5()
  {
    return this.delegate.startH5();
  }
  
  public HeadingBuilder startH6()
  {
    return this.delegate.startH6();
  }
  
  public HeadBuilder startHead()
  {
    return this.delegate.startHead();
  }
  
  public InputBuilder startHiddenInput()
  {
    return this.delegate.startHiddenInput();
  }
  
  public HRBuilder startHR()
  {
    return this.delegate.startHR();
  }
  
  public IFrameBuilder startIFrame()
  {
    return this.delegate.startIFrame();
  }
  
  public ImageBuilder startImage()
  {
    return this.delegate.startImage();
  }
  
  public InputBuilder startImageInput()
  {
    return this.delegate.startImageInput();
  }
  
  public LabelBuilder startLabel()
  {
    return this.delegate.startLabel();
  }
  
  public LegendBuilder startLegend()
  {
    return this.delegate.startLegend();
  }
  
  public LIBuilder startLI()
  {
    return this.delegate.startLI();
  }
  
  public LinkBuilder startLink()
  {
    return this.delegate.startLink();
  }
  
  public MapBuilder startMap()
  {
    return this.delegate.startMap();
  }
  
  public MetaBuilder startMeta()
  {
    return this.delegate.startMeta();
  }
  
  public OListBuilder startOList()
  {
    return this.delegate.startOList();
  }
  
  public OptGroupBuilder startOptGroup()
  {
    return this.delegate.startOptGroup();
  }
  
  public OptionBuilder startOption()
  {
    return this.delegate.startOption();
  }
  
  public ParagraphBuilder startParagraph()
  {
    return this.delegate.startParagraph();
  }
  
  public ParamBuilder startParam()
  {
    return this.delegate.startParam();
  }
  
  public InputBuilder startPasswordInput()
  {
    return this.delegate.startPasswordInput();
  }
  
  public PreBuilder startPre()
  {
    return this.delegate.startPre();
  }
  
  public ButtonBuilder startPushButton()
  {
    return this.delegate.startPushButton();
  }
  
  public QuoteBuilder startQuote()
  {
    return this.delegate.startQuote();
  }
  
  public InputBuilder startRadioInput(String name)
  {
    return this.delegate.startRadioInput(name);
  }
  
  public ButtonBuilder startResetButton()
  {
    return this.delegate.startResetButton();
  }
  
  public InputBuilder startResetInput()
  {
    return this.delegate.startResetInput();
  }
  
  public ScriptBuilder startScript()
  {
    return this.delegate.startScript();
  }
  
  public SelectBuilder startSelect()
  {
    return this.delegate.startSelect();
  }
  
  public SourceBuilder startSource()
  {
    return this.delegate.startSource();
  }
  
  public SpanBuilder startSpan()
  {
    return this.delegate.startSpan();
  }
  
  public StyleBuilder startStyle()
  {
    return this.delegate.startStyle();
  }
  
  public ButtonBuilder startSubmitButton()
  {
    return this.delegate.startSubmitButton();
  }
  
  public InputBuilder startSubmitInput()
  {
    return this.delegate.startSubmitInput();
  }
  
  public TableBuilder startTable()
  {
    return this.delegate.startTable();
  }
  
  public TableCaptionBuilder startTableCaption()
  {
    return this.delegate.startTableCaption();
  }
  
  public TableSectionBuilder startTBody()
  {
    return this.delegate.startTBody();
  }
  
  public TableCellBuilder startTD()
  {
    return this.delegate.startTD();
  }
  
  public TextAreaBuilder startTextArea()
  {
    return this.delegate.startTextArea();
  }
  
  public InputBuilder startTextInput()
  {
    return this.delegate.startTextInput();
  }
  
  public TableSectionBuilder startTFoot()
  {
    return this.delegate.startTFoot();
  }
  
  public TableCellBuilder startTH()
  {
    return this.delegate.startTH();
  }
  
  public TableSectionBuilder startTHead()
  {
    return this.delegate.startTHead();
  }
  
  public TableRowBuilder startTR()
  {
    return this.delegate.startTR();
  }
  
  public UListBuilder startUList()
  {
    return this.delegate.startUList();
  }
  
  public VideoBuilder startVideo()
  {
    return this.delegate.startVideo();
  }
  
  public R tabIndex(int tabIndex)
  {
    assertCanAddAttribute().setTabIndex(tabIndex);
    return getReturnBuilder();
  }
  
  public R title(String title)
  {
    assertCanAddAttribute().setTitle(title);
    return getReturnBuilder();
  }
  
  public ElementBuilder trustedStart(String tagName)
  {
    return this.delegate.trustedStart(tagName);
  }
  
  protected E assertCanAddAttribute()
  {
    return (Element)this.delegate.assertCanAddAttribute().cast();
  }
  
  DomBuilderImpl getDelegate()
  {
    return this.delegate;
  }
}
