package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.javascript.NamedNodeMap;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleDeclaration;
import com.gargoylesoftware.htmlunit.javascript.host.css.ComputedCSSStyleDeclaration;
import com.gargoylesoftware.htmlunit.javascript.host.dom.DOMTokenList;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLCollection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass(domClasses={DomElement.class})
public class Element
  extends EventNode
{
  private NamedNodeMap attributes_;
  private Map<String, HTMLCollection> elementsByTagName_;
  private CSSStyleDeclaration style_;
  
  public void setDomNode(DomNode domNode)
  {
    super.setDomNode(domNode);
    
    this.style_ = new CSSStyleDeclaration(this);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public HTMLCollection selectNodes(final String expression)
  {
    final DomElement domNode = getDomNodeOrDie();
    boolean attributeChangeSensitive = expression.contains("@");
    String description = "Element.selectNodes('" + expression + "')";
    HTMLCollection collection = new HTMLCollection(domNode, attributeChangeSensitive, description)
    {
      protected List<Object> computeElements()
      {
        return new ArrayList(domNode.getByXPath(expression));
      }
    };
    return collection;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object selectSingleNode(String expression)
  {
    HTMLCollection collection = selectNodes(expression);
    if (collection.getLength() > 0) {
      return collection.get(0, collection);
    }
    return null;
  }
  
  @JsxGetter
  public String getTagName()
  {
    return getNodeName();
  }
  
  @JsxGetter
  public Object getAttributes()
  {
    if (this.attributes_ == null) {
      this.attributes_ = createAttributesObject();
    }
    return this.attributes_;
  }
  
  @JsxGetter
  public String getBaseURI()
  {
    return getDomNodeOrDie().getPage().getUrl().toExternalForm();
  }
  
  protected NamedNodeMap createAttributesObject()
  {
    return new NamedNodeMap(getDomNodeOrDie());
  }
  
  @JsxFunction
  public Object getAttribute(String attributeName, Integer flags)
  {
    attributeName = fixAttributeName(attributeName);
    HtmlPage htmlPage = getDomNodeOrDie().getHtmlPageOrNull();
    boolean supportsFlags = (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_GET_ATTRIBUTE_SUPPORTS_FLAGS_IN_QUIRKS_MODE)) && (htmlPage != null) && (htmlPage.isQuirksMode());
    Object value;
    Object value;
    if ((supportsFlags) && (flags != null) && (flags.intValue() == 2) && ("style".equalsIgnoreCase(attributeName))) {
      value = "";
    } else {
      value = getDomNodeOrDie().getAttribute(attributeName);
    }
    if (value == DomElement.ATTRIBUTE_NOT_DEFINED)
    {
      value = null;
      if (supportsFlags) {
        for (Scriptable object = this; object != null; object = object.getPrototype())
        {
          Object property = object.get(attributeName, this);
          if (property != NOT_FOUND)
          {
            value = property;
            break;
          }
        }
      }
    }
    return value;
  }
  
  protected String fixAttributeName(String attributeName)
  {
    return attributeName;
  }
  
  @JsxFunction
  public void setAttribute(String name, String value)
  {
    getDomNodeOrDie().setAttribute(name, value);
  }
  
  @JsxFunction
  public HTMLCollection getElementsByTagName(String tagName)
  {
    final String tagNameLC = tagName.toLowerCase(Locale.ENGLISH);
    if (this.elementsByTagName_ == null) {
      this.elementsByTagName_ = new HashMap();
    }
    HTMLCollection collection = (HTMLCollection)this.elementsByTagName_.get(tagNameLC);
    if (collection != null) {
      return collection;
    }
    DomNode node = getDomNodeOrDie();
    String description = "Element.getElementsByTagName('" + tagNameLC + "')";
    if ("*".equals(tagName)) {
      collection = new HTMLCollection(node, false, description)
      {
        protected boolean isMatching(DomNode node)
        {
          return true;
        }
      };
    } else {
      collection = new HTMLCollection(node, false, description)
      {
        protected boolean isMatching(DomNode node)
        {
          return tagNameLC.equalsIgnoreCase(node.getNodeName());
        }
      };
    }
    this.elementsByTagName_.put(tagName, collection);
    
    return collection;
  }
  
  @JsxFunction
  public Object getAttributeNode(String name)
  {
    Map<String, DomAttr> attributes = getDomNodeOrDie().getAttributesMap();
    for (DomAttr attr : attributes.values()) {
      if (attr.getName().equals(name)) {
        return attr.getScriptObject();
      }
    }
    return null;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getText()
  {
    StringBuilder buffer = new StringBuilder();
    toText(getDomNodeOrDie(), buffer);
    return buffer.toString();
  }
  
  private void toText(DomNode node, StringBuilder buffer)
  {
    switch (node.getNodeType())
    {
    case 10: 
    case 12: 
      return;
    case 3: 
    case 4: 
    case 7: 
    case 8: 
      buffer.append(node.getNodeValue());
      break;
    }
    for (DomNode child : node.getChildren()) {
      switch (child.getNodeType())
      {
      case 1: 
        toText(child, buffer);
        break;
      case 3: 
      case 4: 
        buffer.append(child.getNodeValue());
      }
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getElementsByTagNameNS(Object namespaceURI, final String localName)
  {
    String description = "Element.getElementsByTagNameNS('" + namespaceURI + "', '" + localName + "')";
    
    HTMLCollection collection = new HTMLCollection(getDomNodeOrDie(), false, description)
    {
      protected boolean isMatching(DomNode node)
      {
        return localName.equals(node.getLocalName());
      }
    };
    return collection;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean hasAttribute(String name)
  {
    return getDomNodeOrDie().hasAttribute(name);
  }
  
  public DomElement getDomNodeOrDie()
  {
    return (DomElement)super.getDomNodeOrDie();
  }
  
  @JsxFunction
  public void removeAttribute(String name)
  {
    getDomNodeOrDie().removeAttribute(name);
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_37)) {
      delete(name);
    }
  }
  
  @JsxFunction
  public ClientRect getBoundingClientRect()
  {
    return null;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getChildElementCount()
  {
    return getDomNodeOrDie().getChildElementCount();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Element getFirstElementChild()
  {
    DomElement child = getDomNodeOrDie().getFirstElementChild();
    if (child != null) {
      return (Element)child.getScriptObject();
    }
    return null;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Element getLastElementChild()
  {
    DomElement child = getDomNodeOrDie().getLastElementChild();
    if (child != null) {
      return (Element)child.getScriptObject();
    }
    return null;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Element getNextElementSibling()
  {
    DomElement child = getDomNodeOrDie().getNextElementSibling();
    if (child != null) {
      return (Element)child.getScriptObject();
    }
    return null;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Element getPreviousElementSibling()
  {
    DomElement child = getDomNodeOrDie().getPreviousElementSibling();
    if (child != null) {
      return (Element)child.getScriptObject();
    }
    return null;
  }
  
  public Element getParentElement()
  {
    Node parent = getParent();
    while ((parent != null) && (!(parent instanceof Element))) {
      parent = parent.getParent();
    }
    return (Element)parent;
  }
  
  public void setDefaults(ComputedCSSStyleDeclaration style) {}
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public HTMLCollection getChildren()
  {
    final DomElement node = getDomNodeOrDie();
    HTMLCollection collection = new HTMLCollection(node, false, "Element.children")
    {
      protected List<Object> computeElements()
      {
        return new ArrayList(node.getChildNodes());
      }
    };
    return collection;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public DOMTokenList getClassList()
  {
    return null;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getAttributeNS(String namespaceURI, String localName)
  {
    return getDomNodeOrDie().getAttributeNS(namespaceURI, localName);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public boolean hasAttributeNS(String namespaceURI, String localName)
  {
    return getDomNodeOrDie().hasAttributeNS(namespaceURI, localName);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void setAttributeNS(String namespaceURI, String qualifiedName, String value)
  {
    getDomNodeOrDie().setAttributeNS(namespaceURI, qualifiedName, value);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public void removeAttributeNS(String namespaceURI, String localName)
  {
    getDomNodeOrDie().removeAttributeNS(namespaceURI, localName);
  }
  
  @JsxGetter
  public CSSStyleDeclaration getStyle()
  {
    return this.style_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public CSSStyleDeclaration getRuntimeStyle()
  {
    return this.style_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public ComputedCSSStyleDeclaration getCurrentStyle()
  {
    return getWindow().getComputedStyle(this, null);
  }
  
  public String getDefaultStyleDisplay()
  {
    return "block";
  }
}
