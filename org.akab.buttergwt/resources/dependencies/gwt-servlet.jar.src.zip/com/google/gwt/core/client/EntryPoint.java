package com.google.gwt.core.client;

public abstract interface EntryPoint
{
  public abstract void onModuleLoad();
}
