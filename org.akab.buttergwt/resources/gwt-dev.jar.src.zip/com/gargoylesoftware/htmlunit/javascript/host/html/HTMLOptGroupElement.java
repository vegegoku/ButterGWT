package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlOptionGroup;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlOptionGroup.class})
public class HTMLOptGroupElement
  extends HTMLElement
{
  @JsxGetter
  public boolean getDisabled()
  {
    return super.getDisabled();
  }
  
  @JsxSetter
  public void setDisabled(boolean disabled)
  {
    super.setDisabled(disabled);
  }
  
  @JsxGetter
  public String getLabel()
  {
    String label = getDomNodeOrDie().getAttribute("label");
    if (DomElement.ATTRIBUTE_NOT_DEFINED == label) {
      return "";
    }
    return label;
  }
  
  @JsxSetter
  public void setLabel(String newLabel)
  {
    getDomNodeOrDie().setAttribute("label", newLabel);
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "block";
    }
    return "inline";
  }
}
