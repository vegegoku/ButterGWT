package com.google.gwt.aria.client;

public enum SortValue
  implements AriaAttributeType
{
  ASCENDING,  DESCENDING,  NONE,  OTHER;
  
  private SortValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case ASCENDING: 
      return "ascending";
    case DESCENDING: 
      return "descending";
    case NONE: 
      return "none";
    case OTHER: 
      return "other";
    }
    return null;
  }
}
