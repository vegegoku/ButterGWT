package com.google.gwt.aria.client;

public enum LiveValue
  implements AriaAttributeType
{
  OFF,  POLITE,  ASSERTIVE;
  
  private LiveValue() {}
  
  public String getAriaValue()
  {
    switch (this)
    {
    case OFF: 
      return "off";
    case POLITE: 
      return "polite";
    case ASSERTIVE: 
      return "assertive";
    }
    return null;
  }
}
