package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet;

@JsxClass
public class MediaList
  extends SimpleScriptable
{
  private final org.w3c.dom.stylesheets.MediaList wrappedList_;
  
  @Deprecated
  public MediaList()
  {
    this.wrappedList_ = null;
  }
  
  public MediaList(CSSStyleSheet parent, org.w3c.dom.stylesheets.MediaList wrappedList)
  {
    this.wrappedList_ = wrappedList;
    setParentScope(parent);
    setPrototype(getPrototype(getClass()));
  }
  
  @JsxFunction
  public String item(int index)
  {
    if ((index < 0) || (index >= getLength())) {
      return null;
    }
    return this.wrappedList_.item(index);
  }
  
  @JsxGetter
  public int getLength()
  {
    return this.wrappedList_.getLength();
  }
  
  @JsxGetter
  public String getMediaText()
  {
    return this.wrappedList_.getMediaText();
  }
}
