package com.gargoylesoftware.htmlunit.javascript.background;

import net.sourceforge.htmlunit.corejs.javascript.ContextAction;
import net.sourceforge.htmlunit.corejs.javascript.ContextFactory;

final class JavascriptXMLHttpRequestJob
  extends BasicJavaScriptJob
{
  private final ContextFactory contextFactory_;
  private final ContextAction action_;
  
  public JavascriptXMLHttpRequestJob(ContextFactory contextFactory, ContextAction action)
  {
    this.contextFactory_ = contextFactory;
    this.action_ = action;
  }
  
  public void run()
  {
    this.contextFactory_.call(this.action_);
  }
  
  public String toString()
  {
    return "XMLHttpRequest Job " + getId();
  }
}
