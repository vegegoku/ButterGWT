package org.aopalliance.intercept;

import org.aopalliance.aop.Advice;

public abstract interface Interceptor
  extends Advice
{}
