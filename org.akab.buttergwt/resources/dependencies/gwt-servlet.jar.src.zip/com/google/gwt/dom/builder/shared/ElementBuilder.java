package com.google.gwt.dom.builder.shared;

public abstract interface ElementBuilder
  extends ElementBuilderBase<ElementBuilder>
{}
