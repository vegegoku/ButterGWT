package com.google.gwt.cell.client;

import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;

public class SafeHtmlCell
  extends AbstractCell<SafeHtml>
{
  public SafeHtmlCell()
  {
    super(new String[0]);
  }
  
  public void render(Cell.Context context, SafeHtml value, SafeHtmlBuilder sb)
  {
    if (value != null) {
      sb.append(value);
    }
  }
}
