package com.google.gwt.dev.asm.tree;

import com.google.gwt.dev.asm.MethodVisitor;
import java.util.Map;

public class InsnNode
  extends AbstractInsnNode
{
  public InsnNode(int opcode)
  {
    super(opcode);
  }
  
  public int getType()
  {
    return 0;
  }
  
  public void accept(MethodVisitor mv)
  {
    mv.visitInsn(this.opcode);
  }
  
  public AbstractInsnNode clone(Map<LabelNode, LabelNode> labels)
  {
    return new InsnNode(this.opcode);
  }
}
