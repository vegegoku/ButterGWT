package com.google.gwt.core.client.prefetch;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.impl.AsyncFragmentLoader;

public class RunAsyncCode
  implements PrefetchableResource
{
  private final int splitPoint;
  
  public static RunAsyncCode runAsyncCode(Class<?> splitPoint)
  {
    return forSplitPointNumber(-1);
  }
  
  static RunAsyncCode forSplitPointNumber(int splitPoint)
  {
    return new RunAsyncCode(splitPoint);
  }
  
  private RunAsyncCode(int splitPoint)
  {
    this.splitPoint = splitPoint;
  }
  
  public int getSplitPoint()
  {
    return this.splitPoint;
  }
  
  public boolean isLoaded()
  {
    if (!GWT.isScript()) {
      return true;
    }
    return AsyncFragmentLoader.BROWSER_LOADER.isAlreadyLoaded(this.splitPoint);
  }
}
