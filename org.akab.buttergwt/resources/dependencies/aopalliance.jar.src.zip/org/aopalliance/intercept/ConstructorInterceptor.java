package org.aopalliance.intercept;

public abstract interface ConstructorInterceptor
  extends Interceptor
{
  public abstract Object construct(ConstructorInvocation paramConstructorInvocation)
    throws Throwable;
}
