package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass
public class ClientRect
  extends SimpleScriptable
{
  private int bottom_;
  private int left_;
  private int right_;
  private int top_;
  
  public ClientRect() {}
  
  public ClientRect(int bottom, int left, int right, int top)
  {
    this.bottom_ = bottom;
    this.left_ = left;
    this.right_ = right;
    this.top_ = top;
  }
  
  @JsxSetter
  public void setBottom(int bottom)
  {
    this.bottom_ = bottom;
  }
  
  @JsxGetter
  public int getBottom()
  {
    return this.bottom_;
  }
  
  @JsxSetter
  public void setLeft(int left)
  {
    this.left_ = left;
  }
  
  @JsxGetter
  public int getLeft()
  {
    return this.left_;
  }
  
  @JsxSetter
  public void setRight(int right)
  {
    this.right_ = right;
  }
  
  @JsxGetter
  public int getRight()
  {
    return this.right_;
  }
  
  @JsxSetter
  public void setTop(int top)
  {
    this.top_ = top;
  }
  
  @JsxGetter
  public int getTop()
  {
    return this.top_;
  }
}
