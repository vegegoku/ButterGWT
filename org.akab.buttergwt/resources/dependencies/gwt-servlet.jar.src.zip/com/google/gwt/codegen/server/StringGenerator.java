package com.google.gwt.codegen.server;

public abstract class StringGenerator
{
  protected final StringBuilder buf;
  protected boolean inString;
  
  protected static enum Type
  {
    LITERAL,  PRIMITIVE,  SAFE,  OTHER;
    
    private Type() {}
  }
  
  public static StringGenerator create(StringBuilder buf, boolean returnsSafeHtml)
  {
    if (returnsSafeHtml) {
      return new SafeHtmlStringGenerator(buf);
    }
    return new PlainStringGenerator(buf);
  }
  
  protected StringGenerator(StringBuilder buf)
  {
    this.buf = buf;
    this.inString = false;
  }
  
  public void appendExpression(String expression, boolean isSafeHtmlTyped, boolean isPrimitiveTyped, boolean needsConversionToString)
  {
    if (this.inString)
    {
      this.buf.append('"');
      afterExpression(Type.LITERAL);
      this.inString = false;
    }
    Type type;
    Type type;
    if (isPrimitiveTyped)
    {
      type = Type.PRIMITIVE;
    }
    else
    {
      Type type;
      if (isSafeHtmlTyped) {
        type = Type.SAFE;
      } else {
        type = Type.OTHER;
      }
    }
    beforeExpression(type);
    if ((type == Type.OTHER) && (needsConversionToString)) {
      forceStringPrefix();
    }
    this.buf.append(expression);
    if ((type == Type.OTHER) && (needsConversionToString)) {
      forceStringSuffix();
    }
    afterExpression(type);
  }
  
  public void appendStringLiteral(String str)
  {
    if (!this.inString)
    {
      beforeExpression(Type.LITERAL);
      this.buf.append('"');
      this.inString = true;
    }
    this.buf.append(str);
  }
  
  public void appendStringValuedExpression(String expression)
  {
    appendExpression(expression, false, false, false);
  }
  
  public void completeString()
  {
    if (this.inString)
    {
      this.buf.append('"');
      afterExpression(Type.LITERAL);
    }
    finishOutput();
  }
  
  protected abstract void afterExpression(Type paramType);
  
  protected abstract void beforeExpression(Type paramType);
  
  protected abstract void finishOutput();
  
  protected abstract void forceStringPrefix();
  
  protected abstract void forceStringSuffix();
}
