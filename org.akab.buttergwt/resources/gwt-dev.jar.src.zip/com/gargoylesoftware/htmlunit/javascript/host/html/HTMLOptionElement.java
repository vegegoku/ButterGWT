package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.html.ElementFactory;
import com.gargoylesoftware.htmlunit.html.HTMLParser;
import com.gargoylesoftware.htmlunit.html.HtmlOption;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlSelect;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxConstructor;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.FormChild;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import org.xml.sax.helpers.AttributesImpl;

@JsxClass(domClasses={HtmlOption.class})
public class HTMLOptionElement
  extends FormChild
{
  @JsxConstructor
  public void jsConstructor(String newText, String newValue, boolean defaultSelected, boolean selected)
  {
    HtmlPage page = (HtmlPage)getWindow().getWebWindow().getEnclosedPage();
    AttributesImpl attributes = null;
    if (defaultSelected)
    {
      attributes = new AttributesImpl();
      attributes.addAttribute(null, "selected", "selected", null, "selected");
    }
    HtmlOption htmlOption = (HtmlOption)HTMLParser.getFactory("option").createElement(page, "option", attributes);
    
    htmlOption.setSelected(selected);
    setDomNode(htmlOption);
    if (!"undefined".equals(newText)) {
      htmlOption.appendChild(new DomText(page, newText));
    }
    if (!"undefined".equals(newValue)) {
      htmlOption.setValueAttribute(newValue);
    }
  }
  
  @JsxGetter
  public String getValue()
  {
    String value = getDomNodeOrNull().getAttribute("value");
    if ((value == DomElement.ATTRIBUTE_NOT_DEFINED) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_170))) {
      value = getDomNodeOrNull().getText();
    }
    return value;
  }
  
  @JsxSetter
  public void setValue(String newValue)
  {
    getDomNodeOrNull().setValueAttribute(newValue);
  }
  
  @JsxGetter
  public String getText()
  {
    return getDomNodeOrNull().getText();
  }
  
  public HtmlOption getDomNodeOrNull()
  {
    return (HtmlOption)super.getDomNodeOrNull();
  }
  
  @JsxSetter
  public void setText(String newText)
  {
    getDomNodeOrNull().setText(newText);
  }
  
  @JsxGetter
  public boolean getSelected()
  {
    return getDomNodeOrNull().isSelected();
  }
  
  @JsxSetter
  public void setSelected(boolean selected)
  {
    HtmlOption optionNode = getDomNodeOrNull();
    HtmlSelect enclosingSelect = optionNode.getEnclosingSelect();
    if ((!selected) && (optionNode.isSelected()) && (enclosingSelect != null) && (!enclosingSelect.isMultipleSelectEnabled()))
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLOPTION_UNSELECT_SELECTS_FIRST)) {
        enclosingSelect.getOption(0).setSelected(true, false);
      }
    }
    else {
      optionNode.setSelected(selected, false);
    }
  }
  
  @JsxGetter
  public boolean getDefaultSelected()
  {
    return getDomNodeOrNull().isDefaultSelected();
  }
  
  @JsxGetter
  public String getLabel()
  {
    return getDomNodeOrNull().getLabelAttribute();
  }
  
  @JsxSetter
  public void setLabel(String label)
  {
    getDomNodeOrNull().setLabelAttribute(label);
  }
  
  @JsxGetter
  public boolean getDisabled()
  {
    return super.getDisabled();
  }
  
  @JsxSetter
  public void setDisabled(boolean disabled)
  {
    super.setDisabled(disabled);
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "block";
    }
    return "inline";
  }
}
