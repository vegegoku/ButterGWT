package com.google.gwt.cell.client;

import com.google.gwt.core.client.GWT;
import com.google.gwt.dom.client.Element;
import com.google.gwt.dom.client.EventTarget;
import com.google.gwt.dom.client.InputElement;
import com.google.gwt.dom.client.NativeEvent;
import com.google.gwt.safehtml.client.SafeHtmlTemplates;
import com.google.gwt.safehtml.client.SafeHtmlTemplates.Template;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.text.shared.SafeHtmlRenderer;

public class TextInputCell
  extends AbstractInputCell<String, ViewData>
{
  private static Template template;
  
  public static class ViewData
  {
    private String lastValue;
    private String curValue;
    
    public ViewData(String value)
    {
      this.lastValue = value;
      this.curValue = value;
    }
    
    public boolean equals(Object other)
    {
      if (!(other instanceof ViewData)) {
        return false;
      }
      ViewData vd = (ViewData)other;
      return (equalsOrNull(this.lastValue, vd.lastValue)) && (equalsOrNull(this.curValue, vd.curValue));
    }
    
    public String getCurrentValue()
    {
      return this.curValue;
    }
    
    public String getLastValue()
    {
      return this.lastValue;
    }
    
    public int hashCode()
    {
      return (this.lastValue + "_*!@HASH_SEPARATOR@!*_" + this.curValue).hashCode();
    }
    
    protected void setCurrentValue(String curValue)
    {
      this.curValue = curValue;
    }
    
    protected void setLastValue(String lastValue)
    {
      this.lastValue = lastValue;
    }
    
    private boolean equalsOrNull(Object a, Object b)
    {
      return b == null ? true : a != null ? a.equals(b) : false;
    }
  }
  
  public TextInputCell()
  {
    super(new String[] { "change", "keyup" });
    if (template == null) {
      template = (Template)GWT.create(Template.class);
    }
  }
  
  @Deprecated
  public TextInputCell(SafeHtmlRenderer<String> renderer)
  {
    this();
  }
  
  public void onBrowserEvent(Cell.Context context, Element parent, String value, NativeEvent event, ValueUpdater<String> valueUpdater)
  {
    super.onBrowserEvent(context, parent, value, event, valueUpdater);
    
    InputElement input = getInputElement(parent);
    Element target = (Element)event.getEventTarget().cast();
    if (!input.isOrHasChild(target)) {
      return;
    }
    String eventType = event.getType();
    Object key = context.getKey();
    if ("change".equals(eventType))
    {
      finishEditing(parent, value, key, valueUpdater);
    }
    else if ("keyup".equals(eventType))
    {
      ViewData vd = (ViewData)getViewData(key);
      if (vd == null)
      {
        vd = new ViewData(value);
        setViewData(key, vd);
      }
      vd.setCurrentValue(input.getValue());
    }
  }
  
  public void render(Cell.Context context, String value, SafeHtmlBuilder sb)
  {
    Object key = context.getKey();
    ViewData viewData = (ViewData)getViewData(key);
    if ((viewData != null) && (viewData.getCurrentValue().equals(value)))
    {
      clearViewData(key);
      viewData = null;
    }
    String s = viewData != null ? viewData.getCurrentValue() : value;
    if (s != null) {
      sb.append(template.input(s));
    } else {
      sb.appendHtmlConstant("<input type=\"text\" tabindex=\"-1\"></input>");
    }
  }
  
  protected void finishEditing(Element parent, String value, Object key, ValueUpdater<String> valueUpdater)
  {
    String newValue = getInputElement(parent).getValue();
    
    ViewData vd = (ViewData)getViewData(key);
    if (vd == null)
    {
      vd = new ViewData(value);
      setViewData(key, vd);
    }
    vd.setCurrentValue(newValue);
    if ((valueUpdater != null) && (!vd.getCurrentValue().equals(vd.getLastValue())))
    {
      vd.setLastValue(newValue);
      valueUpdater.update(newValue);
    }
    super.finishEditing(parent, newValue, key, valueUpdater);
  }
  
  protected InputElement getInputElement(Element parent)
  {
    return (InputElement)super.getInputElement(parent).cast();
  }
  
  static abstract interface Template
    extends SafeHtmlTemplates
  {
    @SafeHtmlTemplates.Template("<input type=\"text\" value=\"{0}\" tabindex=\"-1\"></input>")
    public abstract SafeHtml input(String paramString);
  }
}
