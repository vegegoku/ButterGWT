package com.google.gwt.dev.protobuf;

public abstract interface RpcCallback<ParameterType>
{
  public abstract void run(ParameterType paramParameterType);
}
