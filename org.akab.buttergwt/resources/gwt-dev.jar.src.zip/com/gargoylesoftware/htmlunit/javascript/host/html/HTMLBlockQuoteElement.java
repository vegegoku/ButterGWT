package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlBlockQuote;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlBlockQuote.class})
public class HTMLBlockQuoteElement
  extends HTMLElement
{
  public String getClassName()
  {
    return "HTMLQuoteElement";
  }
  
  @JsxGetter
  public String getCite()
  {
    String cite = getDomNodeOrDie().getAttribute("cite");
    return cite;
  }
  
  @JsxSetter
  public void setCite(String cite)
  {
    getDomNodeOrDie().setAttribute("cite", cite);
  }
}
