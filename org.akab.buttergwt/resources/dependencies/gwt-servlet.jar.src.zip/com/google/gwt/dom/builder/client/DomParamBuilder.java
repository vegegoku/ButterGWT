package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.ParamBuilder;
import com.google.gwt.dom.client.ParamElement;

public class DomParamBuilder
  extends DomElementBuilderBase<ParamBuilder, ParamElement>
  implements ParamBuilder
{
  DomParamBuilder(DomBuilderImpl delegate)
  {
    super(delegate, true);
  }
  
  public ParamBuilder name(String name)
  {
    ((ParamElement)assertCanAddAttribute()).setName(name);
    return this;
  }
  
  public ParamBuilder value(String value)
  {
    ((ParamElement)assertCanAddAttribute()).setValue(value);
    return this;
  }
}
