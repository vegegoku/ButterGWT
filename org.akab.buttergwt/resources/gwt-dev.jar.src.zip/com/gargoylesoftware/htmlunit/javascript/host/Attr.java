package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomText;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import java.net.URL;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;

@JsxClass(domClasses={DomAttr.class})
public class Attr
  extends Node
{
  public void detachFromParent()
  {
    DomAttr domNode = getDomNodeOrDie();
    DomElement parent = (DomElement)domNode.getParentNode();
    if (parent != null) {
      domNode.setValue(parent.getAttribute(getName()));
    }
    domNode.remove();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public boolean getIsId()
  {
    return getDomNodeOrDie().isId();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public boolean getExpando()
  {
    Object owner = getOwnerElement();
    if (null == owner) {
      return false;
    }
    return !ScriptableObject.hasProperty((Scriptable)owner, getName());
  }
  
  @JsxGetter
  public String getName()
  {
    return getDomNodeOrDie().getName();
  }
  
  public String getNodeValue()
  {
    return getValue();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getOwnerElement()
  {
    DomElement parent = getDomNodeOrDie().getOwnerElement();
    if (parent != null) {
      return parent.getScriptObject();
    }
    return null;
  }
  
  public Node getParentNode()
  {
    return null;
  }
  
  @JsxGetter
  public boolean getSpecified()
  {
    return getDomNodeOrDie().getSpecified();
  }
  
  @JsxGetter
  public String getValue()
  {
    return getDomNodeOrDie().getValue();
  }
  
  @JsxSetter
  public void setValue(String value)
  {
    getDomNodeOrDie().setValue(value);
  }
  
  public Node getFirstChild()
  {
    return getLastChild();
  }
  
  public Node getLastChild()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_ATTR_FIRST_LAST_CHILD_RETURNS_NULL)) {
      return null;
    }
    DomText text = new DomText(getDomNodeOrDie().getPage(), getNodeValue());
    return (Node)text.getScriptObject();
  }
  
  public DomAttr getDomNodeOrDie()
    throws IllegalStateException
  {
    return (DomAttr)super.getDomNodeOrDie();
  }
  
  public Object getBaseName()
  {
    return Undefined.instance;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getBaseURI()
  {
    return getDomNodeOrDie().getPage().getUrl().toExternalForm();
  }
}
