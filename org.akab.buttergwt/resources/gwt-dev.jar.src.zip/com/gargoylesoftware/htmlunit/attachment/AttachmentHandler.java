package com.gargoylesoftware.htmlunit.attachment;

import com.gargoylesoftware.htmlunit.Page;

public abstract interface AttachmentHandler
{
  public abstract void handleAttachment(Page paramPage);
}
