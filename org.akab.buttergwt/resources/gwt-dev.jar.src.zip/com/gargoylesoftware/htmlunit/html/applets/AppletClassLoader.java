package com.gargoylesoftware.htmlunit.html.applets;

import com.gargoylesoftware.htmlunit.WebResponse;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import org.apache.commons.io.IOUtils;

public class AppletClassLoader
  extends URLClassLoader
{
  public AppletClassLoader()
  {
    super(new URL[0]);
  }
  
  public void addArchiveToClassPath(URL jarUrl)
  {
    addURL(jarUrl);
  }
  
  public void addClassToClassPath(String className, WebResponse webResponse)
    throws IOException
  {
    byte[] bytes = IOUtils.toByteArray(webResponse.getContentAsStream());
    defineClass(className, bytes, 0, bytes.length);
  }
}
