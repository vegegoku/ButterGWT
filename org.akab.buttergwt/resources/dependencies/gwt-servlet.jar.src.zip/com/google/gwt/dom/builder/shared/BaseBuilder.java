package com.google.gwt.dom.builder.shared;

public abstract interface BaseBuilder
  extends ElementBuilderBase<BaseBuilder>
{
  public abstract BaseBuilder href(String paramString);
  
  public abstract BaseBuilder target(String paramString);
}
