package com.google.gwt.core.client;

public class JsArrayMixed
  extends JavaScriptObject
{
  public final native boolean getBoolean(int paramInt);
  
  public final native double getNumber(int paramInt);
  
  public final native <T extends JavaScriptObject> T getObject(int paramInt);
  
  public final native String getString(int paramInt);
  
  public final String join()
  {
    return join(",");
  }
  
  public final native String join(String paramString);
  
  public final native int length();
  
  public final native void push(boolean paramBoolean);
  
  public final native void push(double paramDouble);
  
  public final native void push(JavaScriptObject paramJavaScriptObject);
  
  public final native void push(String paramString);
  
  public final native void set(int paramInt, boolean paramBoolean);
  
  public final native void set(int paramInt, double paramDouble);
  
  public final native void set(int paramInt, JavaScriptObject paramJavaScriptObject);
  
  public final native void set(int paramInt, String paramString);
  
  public final native void setLength(int paramInt);
  
  public final native boolean shiftBoolean();
  
  public final native double shiftNumber();
  
  public final native <T extends JavaScriptObject> T shiftObject();
  
  public final native String shiftString();
  
  public final native void unshift(boolean paramBoolean);
  
  public final native void unshift(double paramDouble);
  
  public final native void unshift(JavaScriptObject paramJavaScriptObject);
  
  public final native void unshift(String paramString);
}
