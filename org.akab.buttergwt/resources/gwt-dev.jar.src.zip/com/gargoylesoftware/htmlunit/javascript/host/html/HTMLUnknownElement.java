package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlUnknownElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.xml.XmlPage;
import java.util.Map;

@JsxClass(domClasses={HtmlUnknownElement.class})
public class HTMLUnknownElement
  extends HTMLElement
{
  public String getNodeName()
  {
    Page page = getDomNodeOrDie().getPage();
    if (((page instanceof XmlPage)) || ((getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_112)) && (((HtmlPage)page).getNamespaces().containsKey(getDomNodeOrDie().getPrefix())))) {
      return getDomNodeOrDie().getLocalName();
    }
    return super.getNodeName();
  }
  
  public String getClassName()
  {
    if ((getWindow().getWebWindow() != null) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTML_GENERIC_ELEMENT))) {
      return "HTMLGenericElement";
    }
    return super.getClassName();
  }
  
  protected boolean isLowerCaseInOuterHtml()
  {
    return true;
  }
  
  public String getDefaultStyleDisplay()
  {
    String tagName = getTagName();
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT))
    {
      if (("ARTICLE".equals(tagName)) || ("ASIDE".equals(tagName)) || ("FIGCAPTION".equals(tagName)) || ("FIGURE".equals(tagName)) || ("FOOTER".equals(tagName)) || ("HEADER".equals(tagName)) || ("NAV".equals(tagName)) || ("SECTION".equals(tagName))) {
        return "block";
      }
      if ("METER".equals(tagName)) {
        return "inline-block";
      }
      if ("PROGRESS".equals(tagName)) {
        return "inline-block";
      }
    }
    if ("RUBY".equals(tagName))
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
        return "inline";
      }
      return "ruby";
    }
    if ("RT".equals(tagName))
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
        return "inline";
      }
      return "ruby-text";
    }
    return "inline";
  }
}
