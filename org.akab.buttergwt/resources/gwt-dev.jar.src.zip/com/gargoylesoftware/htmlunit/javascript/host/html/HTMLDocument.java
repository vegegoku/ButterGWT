package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.CookieManager;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.ScriptResult;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.StringWebResponse;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebResponse;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.BaseFrameElement;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.FrameWindow;
import com.gargoylesoftware.htmlunit.html.HtmlAnchor;
import com.gargoylesoftware.htmlunit.html.HtmlApplet;
import com.gargoylesoftware.htmlunit.html.HtmlArea;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeEvent;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlForm;
import com.gargoylesoftware.htmlunit.html.HtmlHead;
import com.gargoylesoftware.htmlunit.html.HtmlImage;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlScript;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.PostponedAction;
import com.gargoylesoftware.htmlunit.javascript.ScriptableWithFallbackGetter;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.CanSetReadOnly;
import com.gargoylesoftware.htmlunit.javascript.configuration.CanSetReadOnlyStatus;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Document;
import com.gargoylesoftware.htmlunit.javascript.host.Event;
import com.gargoylesoftware.htmlunit.javascript.host.KeyboardEvent;
import com.gargoylesoftware.htmlunit.javascript.host.MouseEvent;
import com.gargoylesoftware.htmlunit.javascript.host.MutationEvent;
import com.gargoylesoftware.htmlunit.javascript.host.NamespaceCollection;
import com.gargoylesoftware.htmlunit.javascript.host.Node;
import com.gargoylesoftware.htmlunit.javascript.host.NodeFilter;
import com.gargoylesoftware.htmlunit.javascript.host.NodeList.EffectOnCache;
import com.gargoylesoftware.htmlunit.javascript.host.Range;
import com.gargoylesoftware.htmlunit.javascript.host.Selection;
import com.gargoylesoftware.htmlunit.javascript.host.StaticNodeList;
import com.gargoylesoftware.htmlunit.javascript.host.TreeWalker;
import com.gargoylesoftware.htmlunit.javascript.host.UIEvent;
import com.gargoylesoftware.htmlunit.javascript.host.Window;
import com.gargoylesoftware.htmlunit.javascript.host.css.CSSStyleSheet;
import com.gargoylesoftware.htmlunit.javascript.host.css.StyleSheetList;
import com.gargoylesoftware.htmlunit.util.Cookie;
import com.gargoylesoftware.htmlunit.util.UrlUtils;
import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.sourceforge.htmlunit.corejs.javascript.Callable;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.FunctionObject;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import net.sourceforge.htmlunit.corejs.javascript.Undefined;
import net.sourceforge.htmlunit.corejs.javascript.UniqueTag;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.css.sac.CSSException;
import org.w3c.css.sac.InputSource;
import org.w3c.dom.DOMException;
import org.w3c.dom.DocumentType;

@JsxClass
public class HTMLDocument
  extends Document
  implements ScriptableWithFallbackGetter
{
  private static final Log LOG = LogFactory.getLog(HTMLDocument.class);
  public static final String EMPTY_COOKIE_NAME = "HTMLUNIT_EMPTY_COOKIE";
  private static final String LAST_MODIFIED_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
  private static final Pattern FIRST_TAG_PATTERN = Pattern.compile("<(\\w+)(\\s+[^>]*)?>");
  private static final Pattern ATTRIBUTES_PATTERN = Pattern.compile("(\\w+)\\s*=\\s*['\"]([^'\"]*)['\"]");
  private static final Map<String, Class<? extends Event>> SUPPORTED_EVENT_TYPE_MAP;
  private static final Set<String> EXECUTE_CMDS_IE = new HashSet();
  private static final Set<String> EXECUTE_CMDS_FF = new HashSet();
  private static final Set<String> EXECUTE_CMDS_FF17 = new HashSet();
  private static int UniqueID_Counter_ = 1;
  private HTMLCollection all_;
  private HTMLCollection forms_;
  private HTMLCollection links_;
  private HTMLCollection images_;
  private HTMLCollection scripts_;
  private HTMLCollection anchors_;
  private HTMLCollection applets_;
  private StyleSheetList styleSheets_;
  private NamespaceCollection namespaces_;
  private HTMLElement activeElement_;
  private final StringBuilder writeBuffer_;
  private boolean writeInCurrentDocument_;
  private String domain_;
  private String uniqueID_;
  private String lastModified_;
  private int documentMode_;
  private boolean closePostponedAction_;
  private boolean executionExternalPostponed_;
  
  static
  {
    Map<String, Class<? extends Event>> eventMap = new HashMap();
    eventMap.put("Event", Event.class);
    eventMap.put("Events", Event.class);
    eventMap.put("KeyboardEvent", KeyboardEvent.class);
    eventMap.put("KeyEvents", KeyboardEvent.class);
    eventMap.put("HTMLEvents", Event.class);
    eventMap.put("MouseEvent", MouseEvent.class);
    eventMap.put("MouseEvents", MouseEvent.class);
    eventMap.put("MutationEvent", MutationEvent.class);
    eventMap.put("MutationEvents", MutationEvent.class);
    eventMap.put("UIEvent", UIEvent.class);
    eventMap.put("UIEvents", UIEvent.class);
    SUPPORTED_EVENT_TYPE_MAP = Collections.unmodifiableMap(eventMap);
    
    List<String> cmds = Arrays.asList(new String[] { "2D-Position", "AbsolutePosition", "BackColor", "BackgroundImageCache", "BlockDirLTR", "BlockDirRTL", "Bold", "BrowseMode", "ClearAuthenticationCache", "Copy", "CreateBookmark", "CreateLink", "Cut", "Delete", "DirLTR", "DirRTL", "EditMode", "FontName", "FontSize", "ForeColor", "FormatBlock", "Indent", "InlineDirLTR", "InlineDirRTL", "InsertButton", "InsertFieldset", "InsertHorizontalRule", "InsertIFrame", "InsertImage", "InsertInputButton", "InsertInputCheckbox", "InsertInputFileUpload", "InsertInputHidden", "InsertInputImage", "InsertInputPassword", "InsertInputRadio", "InsertInputReset", "InsertInputSubmit", "InsertInputText", "InsertMarquee", "InsertOrderedList", "InsertParagraph", "InsertSelectDropdown", "InsertSelectListbox", "InsertTextArea", "InsertUnorderedList", "Italic", "JustifyCenter", "JustifyFull", "JustifyLeft", "JustifyNone", "JustifyRight", "LiveResize", "MultipleSelection", "Open", "Outdent", "OverWrite", "Paste", "PlayImage", "Print", "Redo", "Refresh", "RemoveFormat", "RemoveParaFormat", "SaveAs", "SelectAll", "SizeToControl", "SizeToControlHeight", "SizeToControlWidth", "Stop", "StopImage", "StrikeThrough", "Subscript", "Superscript", "UnBookmark", "Underline", "Undo", "Unlink", "Unselect" });
    for (String cmd : cmds) {
      EXECUTE_CMDS_IE.add(cmd.toLowerCase(Locale.ENGLISH));
    }
    cmds = Arrays.asList(new String[] { "backColor", "bold", "contentReadOnly", "copy", "createLink", "cut", "decreaseFontSize", "delete", "fontName", "fontSize", "foreColor", "formatBlock", "heading", "hiliteColor", "increaseFontSize", "indent", "insertHorizontalRule", "insertHTML", "insertImage", "insertOrderedList", "insertUnorderedList", "insertParagraph", "italic", "justifyCenter", "justifyLeft", "justifyRight", "outdent", "paste", "redo", "removeFormat", "selectAll", "strikeThrough", "subscript", "superscript", "underline", "undo", "unlink", "useCSS", "styleWithCSS" });
    for (String cmd : cmds)
    {
      EXECUTE_CMDS_FF.add(cmd.toLowerCase(Locale.ENGLISH));
      EXECUTE_CMDS_FF17.add(cmd.toLowerCase(Locale.ENGLISH));
    }
    EXECUTE_CMDS_FF17.add("JustifyFull".toLowerCase(Locale.ENGLISH));
  }
  
  public <N extends DomNode> N getDomNodeOrDie()
    throws IllegalStateException
  {
    try
    {
      return super.getDomNodeOrDie();
    }
    catch (IllegalStateException e)
    {
      DomNode node = getDomNodeOrNullFromRealDocument();
      if (node != null) {
        return node;
      }
      throw Context.reportRuntimeError("No node attached to this object");
    }
  }
  
  public <N extends DomNode> N getDomNodeOrNull()
  {
    N node = super.getDomNodeOrNull();
    if (node == null) {
      node = getDomNodeOrNullFromRealDocument();
    }
    return node;
  }
  
  private <N extends DomNode> N getDomNodeOrNullFromRealDocument()
  {
    N node = null;
    
    boolean ie = getWindow().getWebWindow().getWebClient().getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_51);
    if (ie)
    {
      Scriptable scope = getParentScope();
      if ((scope instanceof Window))
      {
        Window w = (Window)scope;
        Document realDocument = w.getDocument();
        if (realDocument != this) {
          node = realDocument.getDomNodeOrDie();
        }
      }
    }
    return node;
  }
  
  public HtmlPage getHtmlPage()
  {
    return (HtmlPage)getDomNodeOrDie();
  }
  
  public HtmlPage getHtmlPageOrNull()
  {
    return (HtmlPage)getDomNodeOrNull();
  }
  
  @JsxGetter
  public Object getForms()
  {
    if (this.forms_ == null)
    {
      final boolean allowFunctionCall = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCUMENT_FORMS_FUNCTION_SUPPORTED);
      
      this.forms_ = new HTMLCollection(getDomNodeOrDie(), false, "HTMLDocument.forms")
      {
        protected boolean isMatching(DomNode node)
        {
          return node instanceof HtmlForm;
        }
        
        public final Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
        {
          if (allowFunctionCall) {
            return super.call(cx, scope, thisObj, args);
          }
          throw Context.reportRuntimeError("TypeError: document.forms is not a function");
        }
      };
    }
    return this.forms_;
  }
  
  @JsxGetter
  public Object getLinks()
  {
    if (this.links_ == null) {
      this.links_ = new HTMLCollection(getDomNodeOrDie(), true, "HTMLDocument.links")
      {
        protected boolean isMatching(DomNode node)
        {
          return (((node instanceof HtmlAnchor)) || ((node instanceof HtmlArea))) && (((HtmlElement)node).hasAttribute("href"));
        }
        
        protected NodeList.EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
        {
          HtmlElement node = event.getHtmlElement();
          if ((((node instanceof HtmlAnchor)) || ((node instanceof HtmlArea))) && ("href".equals(event.getName()))) {
            return NodeList.EffectOnCache.RESET;
          }
          return NodeList.EffectOnCache.NONE;
        }
      };
    }
    return this.links_;
  }
  
  @JsxGetter
  public String getLastModified()
  {
    if (this.lastModified_ == null)
    {
      WebResponse webResponse = getPage().getWebResponse();
      String stringDate = webResponse.getResponseHeaderValue("Last-Modified");
      if (stringDate == null) {
        stringDate = webResponse.getResponseHeaderValue("Date");
      }
      Date lastModified = parseDateOrNow(stringDate);
      this.lastModified_ = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss").format(lastModified);
    }
    return this.lastModified_;
  }
  
  private static Date parseDateOrNow(String stringDate)
  {
    Date date = com.gargoylesoftware.htmlunit.util.StringUtils.parseHttpDate(stringDate);
    if (date == null) {
      return new Date();
    }
    return date;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getNamespaces()
  {
    if (this.namespaces_ == null) {
      this.namespaces_ = new NamespaceCollection(this);
    }
    return this.namespaces_;
  }
  
  @JsxGetter
  public Object getAnchors()
  {
    if (this.anchors_ == null)
    {
      final boolean checkId = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_ANCHORS_REQUIRES_NAME_OR_ID);
      
      this.anchors_ = new HTMLCollection(getDomNodeOrDie(), true, "HTMLDocument.anchors")
      {
        protected boolean isMatching(DomNode node)
        {
          if (!(node instanceof HtmlAnchor)) {
            return false;
          }
          HtmlAnchor anchor = (HtmlAnchor)node;
          if (checkId) {
            return (anchor.hasAttribute("name")) || (anchor.hasAttribute("id"));
          }
          return anchor.hasAttribute("name");
        }
        
        protected NodeList.EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
        {
          HtmlElement node = event.getHtmlElement();
          if (!(node instanceof HtmlAnchor)) {
            return NodeList.EffectOnCache.NONE;
          }
          if (("name".equals(event.getName())) || ("id".equals(event.getName()))) {
            return NodeList.EffectOnCache.RESET;
          }
          return NodeList.EffectOnCache.NONE;
        }
      };
    }
    return this.anchors_;
  }
  
  @JsxGetter
  public Object getApplets()
  {
    if (this.applets_ == null) {
      this.applets_ = new HTMLCollection(getDomNodeOrDie(), false, "HTMLDocument.applets")
      {
        protected boolean isMatching(DomNode node)
        {
          return node instanceof HtmlApplet;
        }
      };
    }
    return this.applets_;
  }
  
  @JsxFunction
  public static void write(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    HTMLDocument thisAsDocument = getDocument(thisObj);
    thisAsDocument.write(concatArgsAsString(args));
  }
  
  private static String concatArgsAsString(Object[] args)
  {
    StringBuilder buffer = new StringBuilder();
    for (Object arg : args) {
      buffer.append(Context.toString(arg));
    }
    return buffer.toString();
  }
  
  @JsxFunction
  public static void writeln(Context context, Scriptable thisObj, Object[] args, Function function)
  {
    HTMLDocument thisAsDocument = getDocument(thisObj);
    thisAsDocument.write(concatArgsAsString(args) + "\n");
  }
  
  private static HTMLDocument getDocument(Scriptable thisObj)
  {
    if (((thisObj instanceof HTMLDocument)) && ((thisObj.getPrototype() instanceof HTMLDocument))) {
      return (HTMLDocument)thisObj;
    }
    if (((thisObj instanceof DocumentProxy)) && ((thisObj.getPrototype() instanceof HTMLDocument))) {
      return (HTMLDocument)((DocumentProxy)thisObj).getDelegee();
    }
    Window window = getWindow(thisObj);
    BrowserVersion browser = window.getWebWindow().getWebClient().getBrowserVersion();
    if (browser.hasFeature(BrowserVersionFeatures.GENERATED_53)) {
      return (HTMLDocument)window.getDocument();
    }
    throw Context.reportRuntimeError("Function can't be used detached from document");
  }
  
  public HTMLDocument()
  {
    this.writeBuffer_ = new StringBuilder();
    this.writeInCurrentDocument_ = true;
    
    this.documentMode_ = -1;
    
    this.executionExternalPostponed_ = false;
  }
  
  public void setExecutingDynamicExternalPosponed(boolean executing)
  {
    this.executionExternalPostponed_ = executing;
  }
  
  protected void write(String content)
  {
    if (this.executionExternalPostponed_)
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("skipping write for external posponed: " + content);
      }
      return;
    }
    if (LOG.isDebugEnabled()) {
      LOG.debug("write: " + content);
    }
    HtmlPage page = (HtmlPage)getDomNodeOrDie();
    if (!page.isBeingParsed()) {
      this.writeInCurrentDocument_ = false;
    }
    this.writeBuffer_.append(content);
    if (!this.writeInCurrentDocument_)
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("wrote content to buffer");
      }
      scheduleImplicitClose();
      return;
    }
    String bufferedContent = this.writeBuffer_.toString();
    if (!canAlreadyBeParsed(bufferedContent))
    {
      if (LOG.isDebugEnabled()) {
        LOG.debug("write: not enough content to parse it now");
      }
      return;
    }
    this.writeBuffer_.setLength(0);
    page.writeInParsedStream(bufferedContent);
  }
  
  private void scheduleImplicitClose()
  {
    if (!this.closePostponedAction_)
    {
      this.closePostponedAction_ = true;
      HtmlPage page = (HtmlPage)getDomNodeOrDie();
      page.getWebClient().getJavaScriptEngine().addPostponedAction(new PostponedAction(page)
      {
        public void execute()
          throws Exception
        {
          if (HTMLDocument.this.writeBuffer_.length() > 0) {
            HTMLDocument.this.close();
          }
          HTMLDocument.this.closePostponedAction_ = false;
        }
      });
    }
  }
  
  private static enum PARSING_STATUS
  {
    OUTSIDE,  START,  IN_NAME,  INSIDE,  IN_STRING;
    
    private PARSING_STATUS() {}
  }
  
  static boolean canAlreadyBeParsed(String content)
  {
    PARSING_STATUS tagState = PARSING_STATUS.OUTSIDE;
    int tagNameBeginIndex = 0;
    int scriptTagCount = 0;
    boolean tagIsOpen = true;
    char stringBoundary = '\000';
    boolean stringSkipNextChar = false;
    int index = 0;
    char openingQuote = '\000';
    for (char currentChar : content.toCharArray())
    {
      switch (tagState)
      {
      case OUTSIDE: 
        if (currentChar == '<')
        {
          tagState = PARSING_STATUS.START;
          tagIsOpen = true;
        }
        else if ((scriptTagCount > 0) && ((currentChar == '\'') || (currentChar == '"')))
        {
          tagState = PARSING_STATUS.IN_STRING;
          stringBoundary = currentChar;
          stringSkipNextChar = false;
        }
        break;
      case START: 
        if (currentChar == '/')
        {
          tagIsOpen = false;
          tagNameBeginIndex = index + 1;
        }
        else
        {
          tagNameBeginIndex = index;
        }
        tagState = PARSING_STATUS.IN_NAME;
        break;
      case IN_NAME: 
        if ((Character.isWhitespace(currentChar)) || (currentChar == '>'))
        {
          String tagName = content.substring(tagNameBeginIndex, index);
          if ("script".equalsIgnoreCase(tagName)) {
            if (tagIsOpen) {
              scriptTagCount++;
            } else if (scriptTagCount > 0) {
              scriptTagCount--;
            }
          }
          if (currentChar == '>') {
            tagState = PARSING_STATUS.OUTSIDE;
          } else {
            tagState = PARSING_STATUS.INSIDE;
          }
        }
        else if (!Character.isLetter(currentChar))
        {
          tagState = PARSING_STATUS.OUTSIDE;
        }
        break;
      case INSIDE: 
        if (currentChar == openingQuote) {
          openingQuote = '\000';
        } else if (openingQuote == 0) {
          if ((currentChar == '\'') || (currentChar == '"')) {
            openingQuote = currentChar;
          } else if ((currentChar == '>') && (openingQuote == 0)) {
            tagState = PARSING_STATUS.OUTSIDE;
          }
        }
        break;
      case IN_STRING: 
        if (stringSkipNextChar) {
          stringSkipNextChar = false;
        } else if (currentChar == stringBoundary) {
          tagState = PARSING_STATUS.OUTSIDE;
        } else if (currentChar == '\\') {
          stringSkipNextChar = true;
        }
        break;
      }
      index++;
    }
    if ((scriptTagCount > 0) || (tagState != PARSING_STATUS.OUTSIDE))
    {
      if (LOG.isDebugEnabled())
      {
        StringBuffer message = new StringBuffer();
        message.append("canAlreadyBeParsed() retruns false for content: '");
        message.append(org.apache.commons.lang3.StringUtils.abbreviateMiddle(content, ".", 100));
        message.append("' (scriptTagCount: " + scriptTagCount);
        message.append(" tagState: " + tagState);
        message.append(")");
        LOG.debug(message.toString());
      }
      return false;
    }
    return true;
  }
  
  HtmlElement getLastHtmlElement(HtmlElement node)
  {
    DomNode lastChild = node.getLastChild();
    if ((lastChild == null) || (!(lastChild instanceof HtmlElement)) || ((lastChild instanceof HtmlScript))) {
      return node;
    }
    return getLastHtmlElement((HtmlElement)lastChild);
  }
  
  @JsxGetter
  public String getCookie()
  {
    HtmlPage page = getHtmlPage();
    
    URL url = page.getUrl();
    url = replaceForCookieIfNecessary(url);
    
    StringBuilder buffer = new StringBuilder();
    Set<Cookie> cookies = page.getWebClient().getCookieManager().getCookies(url);
    for (Cookie cookie : cookies) {
      if (!cookie.isHttpOnly())
      {
        if (buffer.length() != 0) {
          buffer.append("; ");
        }
        if (!"HTMLUNIT_EMPTY_COOKIE".equals(cookie.getName()))
        {
          buffer.append(cookie.getName());
          buffer.append("=");
        }
        buffer.append(cookie.getValue());
      }
    }
    return buffer.toString();
  }
  
  @JsxGetter
  public String getCompatMode()
  {
    if (getDocumentMode() == 5) {
      return "BackCompat";
    }
    return "CSS1Compat";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F)})
  public int getDocumentMode()
  {
    if (this.documentMode_ != -1) {
      return this.documentMode_;
    }
    BrowserVersion browserVersion = getBrowserVersion();
    if (isQuirksDocType(browserVersion))
    {
      this.documentMode_ = 5;
      return this.documentMode_;
    }
    float version = browserVersion.getBrowserVersionNumeric();
    if (version == 8.0F)
    {
      this.documentMode_ = 8;
      return this.documentMode_;
    }
    this.documentMode_ = 9;
    return this.documentMode_;
  }
  
  public void forceDocumentMode(int documentMode)
  {
    this.documentMode_ = documentMode;
  }
  
  private boolean isQuirksDocType(BrowserVersion browserVersion)
  {
    DocumentType docType = getHtmlPage().getDoctype();
    if (docType != null)
    {
      String systemId = docType.getSystemId();
      if (systemId != null)
      {
        if ("http://www.w3.org/TR/html4/strict.dtd".equals(systemId)) {
          return false;
        }
        if ("http://www.w3.org/TR/html4/loose.dtd".equals(systemId))
        {
          String publicId = docType.getPublicId();
          if (("-//W3C//DTD HTML 4.01 Transitional//EN".equals(publicId)) || (("-//W3C//DTD HTML 4.0 Transitional//EN".equals(publicId)) && (browserVersion.hasFeature(BrowserVersionFeatures.DOCTYPE_4_0_TRANSITIONAL_STANDARDS)))) {
            return false;
          }
        }
        if (("http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd".equals(systemId)) || ("http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd".equals(systemId))) {
          return false;
        }
      }
      else if (docType.getPublicId() == null)
      {
        return false;
      }
    }
    return true;
  }
  
  @JsxSetter
  public void setCookie(String newCookie)
  {
    CookieManager cookieManager = getHtmlPage().getWebClient().getCookieManager();
    if (cookieManager.isCookiesEnabled())
    {
      URL url = getHtmlPage().getUrl();
      url = replaceForCookieIfNecessary(url);
      Cookie cookie = buildCookie(newCookie, url);
      cookieManager.addCookie(cookie);
      if (LOG.isDebugEnabled()) {
        LOG.debug("Added cookie: " + cookie);
      }
    }
    else if (LOG.isDebugEnabled())
    {
      LOG.debug("Skipped adding cookie: " + newCookie);
    }
  }
  
  private static URL replaceForCookieIfNecessary(URL url)
  {
    String protocol = url.getProtocol();
    boolean file = "file".equals(protocol);
    if (file) {
      try
      {
        url = UrlUtils.getUrlWithNewHostAndPort(url, "LOCAL_FILESYSTEM", 0);
      }
      catch (MalformedURLException e)
      {
        throw new RuntimeException(e);
      }
    }
    return url;
  }
  
  public static Cookie buildCookie(String newCookie, URL currentURL)
  {
    StringTokenizer st = new StringTokenizer(newCookie, ";");
    String value;
    String name;
    String value;
    if (newCookie.contains("="))
    {
      String nameAndValue = st.nextToken();
      String name = org.apache.commons.lang3.StringUtils.substringBefore(nameAndValue, "=").trim();
      value = org.apache.commons.lang3.StringUtils.substringAfter(nameAndValue, "=").trim();
    }
    else
    {
      name = "HTMLUNIT_EMPTY_COOKIE";
      value = newCookie;
    }
    Map<String, Object> atts = new HashMap();
    atts.put("domain", currentURL.getHost());
    atts.put("path", getDefaultCookiePath(currentURL));
    while (st.hasMoreTokens())
    {
      String token = st.nextToken();
      int indexEqual = token.indexOf('=');
      if (indexEqual > -1) {
        atts.put(token.substring(0, indexEqual).trim().toLowerCase(Locale.ENGLISH), token.substring(indexEqual + 1).trim());
      } else {
        atts.put(token.trim().toLowerCase(Locale.ENGLISH), Boolean.TRUE);
      }
    }
    String date = (String)atts.get("expires");
    Date expires = com.gargoylesoftware.htmlunit.util.StringUtils.parseHttpDate(date);
    
    String domain = (String)atts.get("domain");
    String path = (String)atts.get("path");
    boolean secure = atts.get("secure") != null;
    Cookie cookie = new Cookie(domain, name, value, path, expires, secure);
    
    return cookie;
  }
  
  private static String getDefaultCookiePath(URL url)
  {
    String path = url.getPath();
    int lastSlashIndex = path.lastIndexOf('/');
    if (lastSlashIndex >= 0) {
      if (lastSlashIndex == 0) {
        path = "/";
      } else {
        path = path.substring(0, lastSlashIndex);
      }
    }
    return path;
  }
  
  @JsxGetter
  public Object getImages()
  {
    if (this.images_ == null) {
      this.images_ = new HTMLCollection(getDomNodeOrDie(), false, "HTMLDocument.images")
      {
        protected boolean isMatching(DomNode node)
        {
          return node instanceof HtmlImage;
        }
      };
    }
    return this.images_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getInputEncoding()
  {
    return getHtmlPage().getPageEncoding();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getCharacterSet()
  {
    return getHtmlPage().getPageEncoding();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getCharset()
  {
    String charset = getHtmlPage().getPageEncoding();
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_CHARSET_LOWERCASE)) {
      charset = charset.toLowerCase(Locale.ENGLISH);
    }
    return charset;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getDefaultCharset()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_CHARSET_LOWERCASE)) {
      return "windows-1252";
    }
    return "ISO-8859-1";
  }
  
  @JsxGetter(propertyName="URL")
  public String getURL()
  {
    return getHtmlPage().getUrl().toExternalForm();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getUniqueID()
  {
    if (this.uniqueID_ == null) {
      this.uniqueID_ = ("ms__id" + UniqueID_Counter_++);
    }
    return this.uniqueID_;
  }
  
  @JsxGetter
  public HTMLCollection getAll()
  {
    if (this.all_ == null)
    {
      this.all_ = new HTMLCollectionTags(getDomNodeOrDie(), "HTMLDocument.all")
      {
        protected boolean isMatching(DomNode node)
        {
          return true;
        }
      };
      this.all_.setAvoidObjectDetection(!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_OBJECT_DETECTION));
    }
    return this.all_;
  }
  
  @JsxFunction
  public Object open(String url, Object name, Object features, Object replace)
  {
    HtmlPage page = getHtmlPage();
    if (page.isBeingParsed())
    {
      LOG.warn("Ignoring call to open() during the parsing stage.");
      return null;
    }
    if (!this.writeInCurrentDocument_) {
      LOG.warn("Function open() called when document is already open.");
    }
    this.writeInCurrentDocument_ = false;
    return null;
  }
  
  @JsxFunction
  public void close()
    throws IOException
  {
    if (this.writeInCurrentDocument_)
    {
      LOG.warn("close() called when document is not open.");
    }
    else
    {
      HtmlPage page = getHtmlPage();
      URL url = page.getUrl();
      StringWebResponse webResponse = new StringWebResponse(this.writeBuffer_.toString(), url);
      webResponse.setFromJavascript(true);
      this.writeInCurrentDocument_ = true;
      this.writeBuffer_.setLength(0);
      
      WebClient webClient = page.getWebClient();
      WebWindow window = page.getEnclosingWindow();
      webClient.loadWebResponseInto(webResponse, window);
    }
  }
  
  private void implicitCloseIfNecessary()
  {
    boolean ie = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_55);
    if ((!this.writeInCurrentDocument_) && (ie)) {
      try
      {
        close();
      }
      catch (IOException e)
      {
        throw Context.throwAsScriptRuntimeEx(e);
      }
    }
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getParentWindow()
  {
    return getWindow();
  }
  
  public Object appendChild(Object childObject)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCUMENT_APPEND_CHILD_SUPPORTED)) {
      return super.appendChild(childObject);
    }
    throw Context.reportRuntimeError("Node cannot be inserted at the specified point in the hierarchy.");
  }
  
  public Object createElement(String tagName)
  {
    Object result = NOT_FOUND;
    if ((tagName.startsWith("<")) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_57)))
    {
      Matcher m = FIRST_TAG_PATTERN.matcher(tagName);
      if (m.find())
      {
        tagName = m.group(1);
        result = super.createElement(tagName);
        if ((result == NOT_FOUND) || (m.group(2) == null)) {
          return result;
        }
        HTMLElement elt = (HTMLElement)result;
        
        String attributes = m.group(2);
        Matcher mAttribute = ATTRIBUTES_PATTERN.matcher(attributes);
        while (mAttribute.find())
        {
          String attrName = mAttribute.group(1);
          String attrValue = mAttribute.group(2);
          elt.setAttribute(attrName, attrValue);
        }
      }
    }
    else
    {
      return super.createElement(tagName);
    }
    return result;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public CSSStyleSheet createStyleSheet(String url, Object index)
  {
    HTMLLinkElement link = (HTMLLinkElement)createElement("link");
    link.setHref(url);
    link.setRel("stylesheet");
    
    int insertPos = Integer.MAX_VALUE;
    if (Undefined.instance != index) {
      try
      {
        insertPos = ((Double)index).intValue();
      }
      catch (NumberFormatException e) {}
    }
    InputSource source = new InputSource(new StringReader(""));
    CSSStyleSheet stylesheet = new CSSStyleSheet(link, source, url);
    stylesheet.setPrototype(getPrototype(CSSStyleSheet.class));
    stylesheet.setParentScope(getWindow());
    
    HTMLCollection heads = getElementsByTagName("head");
    if (heads.getLength() > 0)
    {
      HtmlHead head = (HtmlHead)heads.item(0);
      
      int stylesheetPos = -1;
      for (DomNode domNode : head.getChildNodes()) {
        if (StyleSheetList.isStyleSheetLink(domNode))
        {
          stylesheetPos++;
          if (insertPos <= stylesheetPos)
          {
            domNode.insertBefore(link.getDomNodeOrDie());
            return stylesheet;
          }
        }
      }
      head.appendChild(link.getDomNodeOrDie());
    }
    return stylesheet;
  }
  
  @JsxFunction
  public Object getElementById(String id)
  {
    implicitCloseIfNecessary();
    Object result = null;
    try
    {
      boolean caseSensitive = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_GET_ELEMENT_BY_ID_CASE_SENSITIVE);
      DomElement htmlElement = getHtmlPage().getElementById(id, caseSensitive);
      Object jsElement = getScriptableFor(htmlElement);
      if (jsElement == NOT_FOUND)
      {
        if (LOG.isDebugEnabled()) {
          LOG.debug("getElementById(" + id + ") cannot return a result as there isn't a JavaScript object for the HTML element " + htmlElement.getClass().getName());
        }
      }
      else {
        result = jsElement;
      }
    }
    catch (ElementNotFoundException e)
    {
      BrowserVersion browser = getBrowserVersion();
      if ((browser.hasFeature(BrowserVersionFeatures.JS_GET_ELEMENT_BY_ID_ALSO_BY_NAME_IN_QUICKS_MODE)) && (getHtmlPage().isQuirksMode()))
      {
        HTMLCollection elements = getElementsByName(id);
        result = elements.get(0, elements);
        if ((result instanceof UniqueTag)) {
          return null;
        }
        LOG.warn("getElementById(" + id + ") did a getElementByName for Internet Explorer");
        return result;
      }
      if (LOG.isDebugEnabled()) {
        LOG.debug("getElementById(" + id + "): no DOM node found with this id");
      }
    }
    return result;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public HTMLCollection getElementsByClassName(String className)
  {
    return ((HTMLElement)getDocumentElement()).getElementsByClassName(className);
  }
  
  @JsxFunction
  public HTMLCollection getElementsByName(String elementName)
  {
    implicitCloseIfNecessary();
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_59)) && ((org.apache.commons.lang3.StringUtils.isEmpty(elementName)) || ("null".equals(elementName)))) {
      return HTMLCollection.emptyCollection(getWindow());
    }
    final String expElementName = "null".equals(elementName) ? "" : elementName;
    
    final HtmlPage page = (HtmlPage)getPage();
    String description = "HTMLDocument.getElementsByName('" + elementName + "')";
    HTMLCollection collection = new HTMLCollection(page, true, description)
    {
      protected List<Object> computeElements()
      {
        return new ArrayList(page.getElementsByName(expElementName));
      }
      
      protected NodeList.EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
      {
        if ("name".equals(event.getName())) {
          return NodeList.EffectOnCache.RESET;
        }
        return NodeList.EffectOnCache.NONE;
      }
    };
    return collection;
  }
  
  protected Object getWithPreemption(String name)
  {
    HtmlPage page = (HtmlPage)getDomNodeOrNull();
    if ((page == null) || (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_160))) {
      return NOT_FOUND;
    }
    return getIt(name);
  }
  
  private Object getIt(final String name)
  {
    final HtmlPage page = (HtmlPage)getDomNodeOrNull();
    
    final boolean isIE = getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_60);
    HTMLCollection collection = new HTMLCollection(page, true, "HTMLDocument." + name)
    {
      protected List<Object> computeElements()
      {
        List<DomElement> elements;
        List<DomElement> elements;
        if (isIE) {
          elements = page.getElementsByIdAndOrName(name);
        } else {
          elements = page.getElementsByName(name);
        }
        List<Object> matchingElements = new ArrayList();
        for (DomElement elt : elements) {
          if (((elt instanceof HtmlForm)) || ((elt instanceof HtmlImage)) || ((elt instanceof HtmlApplet)) || ((isIE) && ((elt instanceof BaseFrameElement)))) {
            matchingElements.add(elt);
          }
        }
        return matchingElements;
      }
      
      protected NodeList.EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
      {
        String attributeName = event.getName();
        if ("name".equals(attributeName)) {
          return NodeList.EffectOnCache.RESET;
        }
        if ((isIE) && ("id".equals(attributeName))) {
          return NodeList.EffectOnCache.RESET;
        }
        return NodeList.EffectOnCache.NONE;
      }
      
      protected SimpleScriptable getScriptableFor(Object object)
      {
        if ((isIE) && ((object instanceof BaseFrameElement))) {
          return (SimpleScriptable)((BaseFrameElement)object).getEnclosedWindow().getScriptObject();
        }
        return super.getScriptableFor(object);
      }
    };
    int length = collection.getLength();
    if (length == 0) {
      return NOT_FOUND;
    }
    if (length == 1) {
      return collection.item(Integer.valueOf(0));
    }
    return collection;
  }
  
  public Object getWithFallback(String name)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_161)) {
      return getIt(name);
    }
    return NOT_FOUND;
  }
  
  @JsxGetter
  @CanSetReadOnly(CanSetReadOnlyStatus.EXCEPTION)
  public HTMLElement getBody()
  {
    HtmlPage page = getHtmlPage();
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_61)) && ((page.getEnclosingWindow() instanceof FrameWindow)))
    {
      HtmlPage enclosingPage = (HtmlPage)page.getEnclosingWindow().getParentWindow().getEnclosedPage();
      if ((WebClient.URL_ABOUT_BLANK.equals(page.getUrl())) && (enclosingPage.getReadyState() != "complete")) {
        return null;
      }
    }
    HtmlElement body = page.getBody();
    if (body != null) {
      return (HTMLElement)body.getScriptObject();
    }
    return null;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F)})
  public HTMLElement getHead()
  {
    HtmlElement head = getHtmlPage().getHead();
    if (head != null) {
      return (HTMLElement)head.getScriptObject();
    }
    return null;
  }
  
  @JsxGetter
  public String getTitle()
  {
    return getHtmlPage().getTitleText();
  }
  
  @JsxSetter
  public void setTitle(String title)
  {
    getHtmlPage().setTitleText(title);
  }
  
  @JsxGetter
  public String getBgColor()
  {
    String color = getHtmlPage().getBody().getAttribute("bgColor");
    if ((color == DomElement.ATTRIBUTE_NOT_DEFINED) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_COLOR))) {
      color = "#ffffff";
    }
    return color;
  }
  
  @JsxSetter
  public void setBgColor(String color)
  {
    HTMLBodyElement body = (HTMLBodyElement)getHtmlPage().getBody().getScriptObject();
    body.setBgColor(color);
  }
  
  @JsxGetter
  public String getAlinkColor()
  {
    String color = getHtmlPage().getBody().getAttribute("aLink");
    if ((color == DomElement.ATTRIBUTE_NOT_DEFINED) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_COLOR))) {
      color = "#0000ff";
    }
    return color;
  }
  
  @JsxSetter
  public void setAlinkColor(String color)
  {
    HTMLBodyElement body = (HTMLBodyElement)getHtmlPage().getBody().getScriptObject();
    body.setALink(color);
  }
  
  @JsxGetter
  public String getLinkColor()
  {
    String color = getHtmlPage().getBody().getAttribute("link");
    if ((color == DomElement.ATTRIBUTE_NOT_DEFINED) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_COLOR))) {
      color = "#0000ff";
    }
    return color;
  }
  
  @JsxSetter
  public void setLinkColor(String color)
  {
    HTMLBodyElement body = (HTMLBodyElement)getHtmlPage().getBody().getScriptObject();
    body.setLink(color);
  }
  
  @JsxGetter
  public String getVlinkColor()
  {
    String color = getHtmlPage().getBody().getAttribute("vLink");
    if ((color == DomElement.ATTRIBUTE_NOT_DEFINED) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_COLOR))) {
      color = "#800080";
    }
    return color;
  }
  
  @JsxSetter
  public void setVlinkColor(String color)
  {
    HTMLBodyElement body = (HTMLBodyElement)getHtmlPage().getBody().getScriptObject();
    body.setVLink(color);
  }
  
  @JsxGetter
  public String getFgColor()
  {
    String color = getHtmlPage().getBody().getAttribute("text");
    if ((color == DomElement.ATTRIBUTE_NOT_DEFINED) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLDOCUMENT_COLOR))) {
      color = "#000000";
    }
    return color;
  }
  
  @JsxSetter
  public void setFgColor(String color)
  {
    HTMLBodyElement body = (HTMLBodyElement)getHtmlPage().getBody().getScriptObject();
    body.setText(color);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getReadyState()
  {
    DomNode node = getDomNodeOrDie();
    return node.getReadyState();
  }
  
  @JsxGetter
  public String getDomain()
  {
    if (this.domain_ == null)
    {
      URL url = getHtmlPage().getUrl();
      if (url == WebClient.URL_ABOUT_BLANK)
      {
        WebWindow w = getWindow().getWebWindow();
        if ((w instanceof FrameWindow)) {
          url = ((FrameWindow)w).getEnclosingPage().getUrl();
        } else {
          return null;
        }
      }
      this.domain_ = url.getHost();
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCUMENT_DOMAIN_IS_LOWERCASE)) {
        this.domain_ = this.domain_.toLowerCase(Locale.ENGLISH);
      }
    }
    return this.domain_;
  }
  
  @JsxSetter
  public void setDomain(String newDomain)
  {
    BrowserVersion browserVersion = getBrowserVersion();
    if ((WebClient.URL_ABOUT_BLANK == getPage().getUrl()) && (browserVersion.hasFeature(BrowserVersionFeatures.JS_DOCUMENT_SETTING_DOMAIN_THROWS_FOR_ABOUT_BLANK))) {
      throw Context.reportRuntimeError("Illegal domain value, cannot set domain from \"" + WebClient.URL_ABOUT_BLANK + "\" to: \"" + newDomain + "\".");
    }
    String currentDomain = getDomain();
    if (currentDomain.equalsIgnoreCase(newDomain)) {
      return;
    }
    if (newDomain.indexOf('.') == -1) {
      throw Context.reportRuntimeError("Illegal domain value, cannot set domain from: \"" + currentDomain + "\" to: \"" + newDomain + "\" (new domain has to contain a dot).");
    }
    if ((currentDomain.indexOf('.') > -1) && (!currentDomain.toLowerCase(Locale.ENGLISH).endsWith("." + newDomain.toLowerCase(Locale.ENGLISH)))) {
      throw Context.reportRuntimeError("Illegal domain value, cannot set domain from: \"" + currentDomain + "\" to: \"" + newDomain + "\"");
    }
    if (browserVersion.hasFeature(BrowserVersionFeatures.JS_DOCUMENT_DOMAIN_IS_LOWERCASE)) {
      this.domain_ = newDomain.toLowerCase(Locale.ENGLISH);
    } else {
      this.domain_ = newDomain;
    }
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F)})
  public Object getScripts()
  {
    if (this.scripts_ == null) {
      this.scripts_ = new HTMLCollection(getDomNodeOrDie(), false, "HTMLDocument.scripts")
      {
        protected boolean isMatching(DomNode node)
        {
          return node instanceof HtmlScript;
        }
      };
    }
    return this.scripts_;
  }
  
  @JsxGetter(value={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)}, propertyName="selection")
  public Selection getSelection_js()
  {
    return getWindow().getSelectionImpl();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Object getFrames()
  {
    return getWindow().getFrames_js();
  }
  
  @JsxGetter
  public StyleSheetList getStyleSheets()
  {
    if (this.styleSheets_ == null) {
      this.styleSheets_ = new StyleSheetList(this);
    }
    return this.styleSheets_;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Event createEvent(String eventType)
    throws DOMException
  {
    Class<? extends Event> clazz = (Class)SUPPORTED_EVENT_TYPE_MAP.get(eventType);
    if (clazz == null)
    {
      Context.throwAsScriptRuntimeEx(new DOMException((short)9, "Event Type is not supported: " + eventType));
      
      return null;
    }
    try
    {
      Event event = (Event)clazz.newInstance();
      event.setEventType(eventType);
      event.setParentScope(getWindow());
      event.setPrototype(getPrototype(clazz));
      return event;
    }
    catch (InstantiationException e)
    {
      throw Context.reportRuntimeError("Failed to instantiate event: class ='" + clazz.getName() + "' for event type of '" + eventType + "': " + e.getMessage());
    }
    catch (IllegalAccessException e)
    {
      throw Context.reportRuntimeError("Failed to instantiate event: class ='" + clazz.getName() + "' for event type of '" + eventType + "': " + e.getMessage());
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public Event createEventObject()
  {
    Event event = new MouseEvent();
    event.setParentScope(getWindow());
    event.setPrototype(getPrototype(event.getClass()));
    return event;
  }
  
  @JsxFunction
  public Object elementFromPoint(int x, int y)
  {
    if ((getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_164)) && ((x <= 0) || (y <= 0))) {
      return null;
    }
    return getBody();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Range createRange()
  {
    Range r = new Range(this);
    r.setParentScope(getWindow());
    r.setPrototype(getPrototype(Range.class));
    return r;
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Object createTreeWalker(Node root, double whatToShow, final Scriptable filter, boolean expandEntityReferences)
    throws DOMException
  {
    long whatToShowL = Double.valueOf(whatToShow).longValue();
    NodeFilter filterWrapper = null;
    if (filter != null) {
      filterWrapper = new NodeFilter()
      {
        public short acceptNode(Node n)
        {
          Object[] args = { n };
          Object response;
          Object response;
          if ((filter instanceof Callable)) {
            response = ((Callable)filter).call(Context.getCurrentContext(), filter, filter, args);
          } else {
            response = ScriptableObject.callMethod(filter, "acceptNode", args);
          }
          return (short)(int)Context.toNumber(response);
        }
      };
    }
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_TREEWALKER_EXPAND_ENTITY_REFERENCES_FALSE)) {
      expandEntityReferences = false;
    }
    TreeWalker t = new TreeWalker(root, whatToShowL, filterWrapper, expandEntityReferences);
    t.setParentScope(getWindow(this));
    t.setPrototype(staticGetPrototype(getWindow(this), TreeWalker.class));
    return t;
  }
  
  private static Scriptable staticGetPrototype(Window window, Class<? extends SimpleScriptable> javaScriptClass)
  {
    Scriptable prototype = window.getPrototype(javaScriptClass);
    if ((prototype == null) && (javaScriptClass != SimpleScriptable.class)) {
      return staticGetPrototype(window, javaScriptClass.getSuperclass());
    }
    return prototype;
  }
  
  @JsxFunction
  public boolean queryCommandSupported(String cmd)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_QUERYCOMMAND_SUPPORTED_ONLY_DESIGNMODE))
    {
      String mode = getDesignMode();
      if (!"on".equals(mode))
      {
        String msg = "queryCommandSupported() called while document.designMode='" + mode + "'.";
        throw Context.reportRuntimeError(msg);
      }
    }
    return hasCommand(cmd);
  }
  
  private boolean hasCommand(String cmd)
  {
    if (null == cmd) {
      return false;
    }
    String cmdLC = cmd.toLowerCase(Locale.ENGLISH);
    if (getBrowserVersion().isIE()) {
      return EXECUTE_CMDS_IE.contains(cmdLC);
    }
    if ("FF3.6".equals(getBrowserVersion().getNickname())) {
      return EXECUTE_CMDS_FF.contains(cmdLC);
    }
    return EXECUTE_CMDS_FF17.contains(cmdLC);
  }
  
  @JsxFunction
  public boolean queryCommandEnabled(String cmd)
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_QUERYCOMMAND_SUPPORTED_ONLY_DESIGNMODE))
    {
      String mode = getDesignMode();
      if (!"on".equals(mode))
      {
        String msg = "queryCommandEnabled() called while document.designMode='" + mode + "'.";
        throw Context.reportRuntimeError(msg);
      }
    }
    return hasCommand(cmd);
  }
  
  @JsxFunction
  public boolean execCommand(String cmd, boolean userInterface, Object value)
  {
    if (!hasCommand(cmd))
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.EXECCOMMAND_THROWS_ON_WRONG_COMMAND)) {
        throw Context.reportRuntimeError("document.execCommand(): invalid command '" + cmd + "'");
      }
      return false;
    }
    LOG.warn("Nothing done for execCommand(" + cmd + ", ...) (feature not implemented)");
    return true;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Object getActiveElement()
  {
    if (this.activeElement_ == null)
    {
      HtmlElement body = getHtmlPage().getBody();
      if (body != null) {
        this.activeElement_ = ((HTMLElement)getScriptableFor(body));
      }
    }
    return this.activeElement_;
  }
  
  public void setActiveElement(HTMLElement element)
  {
    this.activeElement_ = element;
  }
  
  public SimpleScriptable getDoctype()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_DOCUMENT_DOCTYPE_NULL)) {
      return null;
    }
    return super.getDoctype();
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public boolean dispatchEvent(Event event)
  {
    event.setTarget(this);
    ScriptResult result = fireEvent(event);
    return !event.isAborted(result);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public StaticNodeList querySelectorAll(String selectors)
  {
    try
    {
      List<Node> nodes = new ArrayList();
      for (DomNode domNode : getDomNodeOrDie().querySelectorAll(selectors)) {
        nodes.add((Node)domNode.getScriptObject());
      }
      return new StaticNodeList(nodes, this);
    }
    catch (CSSException e)
    {
      throw Context.reportRuntimeError("An invalid or illegal selector was specified (selector: '" + selectors + "' error: " + e.getMessage() + ").");
    }
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=8.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public Node querySelector(String selectors)
  {
    try
    {
      DomNode node = getDomNodeOrDie().querySelector(selectors);
      if (node != null) {
        return (Node)node.getScriptObject();
      }
      return null;
    }
    catch (CSSException e)
    {
      throw Context.reportRuntimeError("An invalid or illegal selector was specified (selector: '" + selectors + "' error: " + e.getMessage() + ").");
    }
  }
  
  public Object get(String name, Scriptable start)
  {
    Object response = super.get(name, start);
    if (((response instanceof FunctionObject)) && (("querySelectorAll".equals(name)) || ("querySelector".equals(name))) && (getBrowserVersion().hasFeature(BrowserVersionFeatures.QUERYSELECTORALL_NOT_IN_QUIRKS)))
    {
      ScriptableObject sobj = getPage().getScriptObject();
      if (((sobj instanceof HTMLDocument)) && (((HTMLDocument)sobj).getDocumentMode() < 8)) {
        return NOT_FOUND;
      }
    }
    return response;
  }
  
  public SimpleScriptable makeScriptableFor(DomNode domNode)
  {
    return super.makeScriptableFor(domNode);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Selection getSelection()
  {
    return getWindow().getSelectionImpl();
  }
  
  @JsxFunction
  public void clear() {}
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F)})
  public void setHead(ScriptableObject head) {}
}
