package com.google.gwt.aria.client;

public abstract interface ContentinfoRole
  extends LandmarkRole
{}
