package com.google.gwt.core.server;

import com.google.gwt.i18n.shared.GwtLocale;

class LocalizableInstantiator
  extends ServerGwtBridge.ClassInstantiatorBase
  implements ServerGwtBridge.ClassInstantiator
{
  public <T> T create(Class<?> clazz, ServerGwtBridge.Properties properties)
  {
    String pkgName = clazz.getPackage().getName();
    Class<?> enclosingClass = clazz.getEnclosingClass();
    String className = clazz.getSimpleName();
    GwtLocale locale = ServerGwtBridge.getLocale(properties);
    for (GwtLocale search : locale.getCompleteSearchList())
    {
      String suffix = "_" + search.getAsString();
      T obj = tryCreate(pkgName + "." + className + suffix);
      if (obj != null) {
        return obj;
      }
      obj = tryCreate(pkgName + ".impl." + className + suffix);
      if (obj != null) {
        return obj;
      }
      obj = tryCreate(pkgName + "." + className + "Impl" + suffix);
      if (obj != null) {
        return obj;
      }
      if (enclosingClass != null)
      {
        obj = tryCreate(enclosingClass.getCanonicalName() + "$" + className + suffix);
        if (obj != null) {
          return obj;
        }
      }
    }
    return null;
  }
}
