package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.HtmlBackgroundSound;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.host.Window;

@JsxClass(domClasses={HtmlBackgroundSound.class})
public class HTMLBGSoundElement
  extends HTMLElement
{
  public String getClassName()
  {
    if ((getWindow().getWebWindow() != null) && (!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLBGSOUND))) {
      return "HTMLSpanElement";
    }
    return super.getClassName();
  }
  
  protected boolean isEndTagForbidden()
  {
    return true;
  }
}
