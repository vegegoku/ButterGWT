package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.html.DomChangeEvent;
import com.gargoylesoftware.htmlunit.html.DomChangeListener;
import com.gargoylesoftware.htmlunit.html.DomComment;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeEvent;
import com.gargoylesoftware.htmlunit.html.HtmlAttributeChangeListener;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.ClassConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.JavaScriptConfiguration;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Function;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.ScriptableObject;
import org.w3c.dom.Node;

@JsxClass
public class NodeList
  extends SimpleScriptable
  implements Function, org.w3c.dom.NodeList
{
  public NodeList() {}
  
  protected static enum EffectOnCache
  {
    NONE,  RESET;
    
    private EffectOnCache() {}
  }
  
  private boolean avoidObjectDetection_ = false;
  private String description_;
  private boolean attributeChangeSensitive_ = true;
  private List<Object> cachedElements_;
  private boolean listenerRegistered_;
  
  private NodeList(ScriptableObject parentScope)
  {
    setParentScope(parentScope);
    setPrototype(getPrototype(getClass()));
  }
  
  public NodeList(DomNode parentScope, boolean attributeChangeSensitive, String description)
  {
    this(parentScope.getScriptObject());
    setDomNode(parentScope, false);
    this.description_ = description;
    this.attributeChangeSensitive_ = attributeChangeSensitive;
  }
  
  protected NodeList(DomNode parentScope, List<?> initialElements)
  {
    this(parentScope.getScriptObject());
    this.cachedElements_ = new ArrayList(initialElements);
  }
  
  public static NodeList emptyCollection(Window window)
  {
    final List<Object> list = Collections.emptyList();
    new NodeList(window, list)
    {
      public List<Object> getElements()
      {
        return list;
      }
    };
  }
  
  public boolean avoidObjectDetection()
  {
    return this.avoidObjectDetection_;
  }
  
  public void setAvoidObjectDetection(boolean newValue)
  {
    this.avoidObjectDetection_ = newValue;
  }
  
  public Object call(Context cx, Scriptable scope, Scriptable thisObj, Object[] args)
  {
    if (args.length == 0) {
      throw Context.reportRuntimeError("Zero arguments; need an index or a key.");
    }
    return nullIfNotFound(getIt(args[0]));
  }
  
  public final Scriptable construct(Context cx, Scriptable scope, Object[] args)
  {
    return null;
  }
  
  private Object getIt(Object o)
  {
    if ((o instanceof Number))
    {
      Number n = (Number)o;
      int i = n.intValue();
      return get(i, this);
    }
    String key = String.valueOf(o);
    return get(key, this);
  }
  
  public final Object get(int index, Scriptable start)
  {
    NodeList array = (NodeList)start;
    List<Object> elements = array.getElements();
    if ((index >= 0) && (index < elements.size())) {
      return getScriptableForElement(elements.get(index));
    }
    return NOT_FOUND;
  }
  
  public List<Object> getElements()
  {
    List<Object> cachedElements = this.cachedElements_;
    if (cachedElements == null)
    {
      cachedElements = computeElements();
      this.cachedElements_ = cachedElements;
      if (!this.listenerRegistered_)
      {
        DomHtmlAttributeChangeListenerImpl listener = new DomHtmlAttributeChangeListenerImpl(null);
        DomNode domNode = getDomNodeOrNull();
        if (domNode != null)
        {
          domNode.addDomChangeListener(listener);
          if ((this.attributeChangeSensitive_) && ((domNode instanceof HtmlElement))) {
            ((HtmlElement)domNode).addHtmlAttributeChangeListener(listener);
          }
        }
        this.listenerRegistered_ = true;
      }
    }
    return cachedElements;
  }
  
  protected List<Object> computeElements()
  {
    List<Object> response = new ArrayList();
    DomNode domNode = getDomNodeOrNull();
    if (domNode == null) {
      return response;
    }
    for (DomNode node : getCandidates())
    {
      boolean commentIncluded = (getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_COMMENT_IS_ELEMENT)) && ((node instanceof DomComment));
      if ((((node instanceof DomElement)) || (commentIncluded)) && (isMatching(node))) {
        response.add(node);
      }
    }
    return response;
  }
  
  protected Iterable<DomNode> getCandidates()
  {
    DomNode domNode = getDomNodeOrNull();
    return domNode.getDescendants();
  }
  
  protected boolean isMatching(DomNode node)
  {
    return false;
  }
  
  protected Object getWithPreemption(String name)
  {
    if ("length".equals(name)) {
      return NOT_FOUND;
    }
    List<Object> elements = getElements();
    
    List<Object> matchingElements = new ArrayList();
    for (Object next : elements) {
      if ((next instanceof DomElement))
      {
        String id = ((DomElement)next).getAttribute("id");
        if (name.equals(id))
        {
          if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_IDENTICAL_IDS)) {
            return getScriptableForElement(next);
          }
          matchingElements.add(next);
        }
      }
    }
    if (matchingElements.size() == 1) {
      return getScriptableForElement(matchingElements.get(0));
    }
    if (!matchingElements.isEmpty())
    {
      NodeList collection = new NodeList(getDomNodeOrDie(), matchingElements);
      collection.setAvoidObjectDetection(!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_OBJECT_DETECTION));
      return collection;
    }
    for (Object next : elements) {
      if ((next instanceof DomElement))
      {
        String nodeName = ((DomElement)next).getAttribute("name");
        if (name.equals(nodeName))
        {
          if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_IDENTICAL_IDS)) {
            return getScriptableForElement(next);
          }
          matchingElements.add(next);
        }
      }
    }
    if (matchingElements.isEmpty()) {
      return NOT_FOUND;
    }
    if (matchingElements.size() == 1) {
      return getScriptableForElement(matchingElements.get(0));
    }
    DomNode domNode = getDomNodeOrNull();
    NodeList collection = new NodeList(domNode, matchingElements);
    collection.setAvoidObjectDetection(!getBrowserVersion().hasFeature(BrowserVersionFeatures.HTMLCOLLECTION_OBJECT_DETECTION));
    
    return collection;
  }
  
  @JsxGetter
  public final int getLength()
  {
    return getElements().size();
  }
  
  @JsxFunction
  public final Object item(Object index)
  {
    return nullIfNotFound(getIt(index));
  }
  
  private Object nullIfNotFound(Object object)
  {
    if (object == NOT_FOUND)
    {
      if (getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_48)) {
        return null;
      }
      return Context.getUndefinedValue();
    }
    return object;
  }
  
  public String toString()
  {
    return this.description_;
  }
  
  protected Object equivalentValues(Object other)
  {
    if (other == this) {
      return Boolean.TRUE;
    }
    if ((other instanceof NodeList))
    {
      NodeList otherArray = (NodeList)other;
      DomNode domNode = getDomNodeOrNull();
      DomNode domNodeOther = otherArray.getDomNodeOrNull();
      if ((getClass() == other.getClass()) && (domNode == domNodeOther) && (getElements().equals(otherArray.getElements()))) {
        return Boolean.TRUE;
      }
      return NOT_FOUND;
    }
    return super.equivalentValues(other);
  }
  
  public boolean has(int index, Scriptable start)
  {
    return (index >= 0) && (index < getElements().size());
  }
  
  public boolean has(String name, Scriptable start)
  {
    if (isPrototype()) {
      return super.has(name, start);
    }
    try
    {
      return has(Integer.parseInt(name), start);
    }
    catch (NumberFormatException e)
    {
      if ("length".equals(name)) {
        return true;
      }
      if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_49))
      {
        JavaScriptConfiguration jsConfig = getWindow().getWebWindow().getWebClient().getJavaScriptEngine().getJavaScriptConfiguration();
        for (String functionName : jsConfig.getClassConfiguration(getClassName()).functionKeys()) {
          if (name.equals(functionName)) {
            return true;
          }
        }
        return false;
      }
      if (getWithPreemption(name) != NOT_FOUND) {
        tmpTernaryOp = true;
      }
    }
    return false;
  }
  
  public Object[] getIds()
  {
    if (isPrototype()) {
      return super.getIds();
    }
    List<String> idList = new ArrayList();
    
    List<Object> elements = getElements();
    if (!getBrowserVersion().hasFeature(BrowserVersionFeatures.GENERATED_50))
    {
      int length = elements.size();
      for (int i = 0; i < length; i++) {
        idList.add(Integer.toString(i));
      }
      idList.add("length");
      JavaScriptConfiguration jsConfig = getWindow().getWebWindow().getWebClient().getJavaScriptEngine().getJavaScriptConfiguration();
      for (String name : jsConfig.getClassConfiguration(getClassName()).functionKeys()) {
        idList.add(name);
      }
    }
    else
    {
      idList.add("length");
      
      addElementIds(idList, elements);
    }
    return idList.toArray();
  }
  
  private boolean isPrototype()
  {
    return !(getPrototype() instanceof NodeList);
  }
  
  protected void addElementIds(List<String> idList, List<Object> elements)
  {
    int index = 0;
    for (Object next : elements)
    {
      HtmlElement element = (HtmlElement)next;
      String name = element.getAttribute("name");
      if (name != DomElement.ATTRIBUTE_NOT_DEFINED)
      {
        idList.add(name);
      }
      else
      {
        String id = element.getId();
        if (id != DomElement.ATTRIBUTE_NOT_DEFINED) {
          idList.add(id);
        } else {
          idList.add(Integer.toString(index));
        }
      }
      index++;
    }
  }
  
  private class DomHtmlAttributeChangeListenerImpl
    implements DomChangeListener, HtmlAttributeChangeListener
  {
    private DomHtmlAttributeChangeListenerImpl() {}
    
    public void nodeAdded(DomChangeEvent event)
    {
      NodeList.this.cachedElements_ = null;
    }
    
    public void nodeDeleted(DomChangeEvent event)
    {
      NodeList.this.cachedElements_ = null;
    }
    
    public void attributeAdded(HtmlAttributeChangeEvent event)
    {
      handleChangeOnCache(NodeList.this.getEffectOnCache(event));
    }
    
    public void attributeRemoved(HtmlAttributeChangeEvent event)
    {
      handleChangeOnCache(NodeList.this.getEffectOnCache(event));
    }
    
    public void attributeReplaced(HtmlAttributeChangeEvent event)
    {
      if (NodeList.this.attributeChangeSensitive_) {
        handleChangeOnCache(NodeList.this.getEffectOnCache(event));
      }
    }
    
    private void handleChangeOnCache(NodeList.EffectOnCache effectOnCache)
    {
      if (NodeList.EffectOnCache.NONE == effectOnCache) {
        return;
      }
      if (NodeList.EffectOnCache.RESET == effectOnCache) {
        NodeList.this.cachedElements_ = null;
      }
    }
  }
  
  protected EffectOnCache getEffectOnCache(HtmlAttributeChangeEvent event)
  {
    return EffectOnCache.RESET;
  }
  
  public Node item(int index)
  {
    return (DomNode)getElements().get(index);
  }
  
  protected Scriptable getScriptableForElement(Object object)
  {
    if ((object instanceof Scriptable)) {
      return (Scriptable)object;
    }
    return getScriptableFor(object);
  }
  
  public String getClassName()
  {
    return "NodeList";
  }
}
