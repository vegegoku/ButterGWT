package com.google.gwt.aria.client;

public abstract interface TreeitemRole
  extends ListitemRole, OptionRole
{}
