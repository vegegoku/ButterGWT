package com.gargoylesoftware.htmlunit.javascript.host.svg;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Window;

@JsxClass(browsers={@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE, minVersion=9.0F), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
public class SVGMatrix
  extends SimpleScriptable
{
  private double fieldA_ = 1.0D;
  private double fieldB_ = 0.0D;
  private double fieldC_ = 0.0D;
  private double fieldD_ = 1.0D;
  private double fieldE_ = 0.0D;
  private double fieldF_ = 0.0D;
  
  public SVGMatrix() {}
  
  public SVGMatrix(Window scope)
  {
    setParentScope(scope);
    setPrototype(getPrototype(getClass()));
  }
  
  @JsxGetter
  public double getA()
  {
    return this.fieldA_;
  }
  
  @JsxGetter
  public double getB()
  {
    return this.fieldB_;
  }
  
  @JsxGetter
  public double getC()
  {
    return this.fieldC_;
  }
  
  @JsxGetter
  public double getD()
  {
    return this.fieldD_;
  }
  
  @JsxGetter
  public double getE()
  {
    return this.fieldE_;
  }
  
  @JsxGetter
  public double getF()
  {
    return this.fieldF_;
  }
  
  @JsxSetter
  public void setA(double newValue)
  {
    this.fieldA_ = newValue;
  }
  
  @JsxSetter
  public void setB(double newValue)
  {
    this.fieldB_ = newValue;
  }
  
  @JsxSetter
  public void setC(double newValue)
  {
    this.fieldC_ = newValue;
  }
  
  @JsxSetter
  public void setD(double newValue)
  {
    this.fieldD_ = newValue;
  }
  
  @JsxSetter
  public void setE(double newValue)
  {
    this.fieldE_ = newValue;
  }
  
  @JsxSetter
  public void setF(double newValue)
  {
    this.fieldF_ = newValue;
  }
  
  @JsxFunction
  public SVGMatrix flipX()
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix flipY()
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix inverse()
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix multiply(SVGMatrix by)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix rotate(double angle)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix rotateFromVector(double x, double y)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix scale(double factor)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix scaleNonUniform(double factorX, double factorY)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix skewX(double angle)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix skewY(double angle)
  {
    return new SVGMatrix(getWindow());
  }
  
  @JsxFunction
  public SVGMatrix translate(double x, double y)
  {
    return new SVGMatrix(getWindow());
  }
}
