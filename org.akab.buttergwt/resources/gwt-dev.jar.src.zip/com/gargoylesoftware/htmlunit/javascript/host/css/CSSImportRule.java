package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.html.HTMLElement;

@JsxClass
public class CSSImportRule
  extends CSSRule
{
  private com.gargoylesoftware.htmlunit.javascript.host.MediaList media_;
  private CSSStyleSheet importedStylesheet_;
  
  @Deprecated
  public CSSImportRule() {}
  
  protected CSSImportRule(CSSStyleSheet stylesheet, org.w3c.dom.css.CSSImportRule rule)
  {
    super(stylesheet, rule);
  }
  
  @JsxGetter
  public String getHref()
  {
    return getImportRule().getHref();
  }
  
  @JsxGetter
  public com.gargoylesoftware.htmlunit.javascript.host.MediaList getMedia()
  {
    if (this.media_ == null)
    {
      CSSStyleSheet parent = getParentStyleSheet();
      org.w3c.dom.stylesheets.MediaList ml = getImportRule().getMedia();
      this.media_ = new com.gargoylesoftware.htmlunit.javascript.host.MediaList(parent, ml);
    }
    return this.media_;
  }
  
  @JsxGetter
  public CSSStyleSheet getStyleSheet()
  {
    if (this.importedStylesheet_ == null)
    {
      CSSStyleSheet owningSheet = getParentStyleSheet();
      HTMLElement ownerNode = owningSheet.getOwnerNode();
      org.w3c.dom.css.CSSStyleSheet importedStylesheet = getImportRule().getStyleSheet();
      this.importedStylesheet_ = new CSSStyleSheet(ownerNode, importedStylesheet, owningSheet.getUri());
    }
    return this.importedStylesheet_;
  }
  
  private org.w3c.dom.css.CSSImportRule getImportRule()
  {
    return (org.w3c.dom.css.CSSImportRule)getRule();
  }
}
