package com.google.gwt.core.shared;

public abstract class GWTBridge
{
  public abstract <T> T create(Class<?> paramClass);
  
  public String getThreadUniqueID()
  {
    return "";
  }
  
  public abstract String getVersion();
  
  public abstract boolean isClient();
  
  public abstract void log(String paramString, Throwable paramThrowable);
}
