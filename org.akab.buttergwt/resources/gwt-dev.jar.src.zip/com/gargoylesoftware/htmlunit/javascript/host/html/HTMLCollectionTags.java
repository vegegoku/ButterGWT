package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;

@JsxClass
public class HTMLCollectionTags
  extends HTMLCollection
{
  @Deprecated
  public HTMLCollectionTags() {}
  
  public HTMLCollectionTags(DomNode parentScope, String description)
  {
    super(parentScope, false, description);
  }
  
  protected Object equivalentValues(Object other)
  {
    if (!(other instanceof HTMLCollectionTags)) {
      return Boolean.FALSE;
    }
    return super.equivalentValues(other);
  }
}
