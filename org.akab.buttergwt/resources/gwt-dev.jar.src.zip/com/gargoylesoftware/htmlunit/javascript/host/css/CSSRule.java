package com.gargoylesoftware.htmlunit.javascript.host.css;

import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(isJSObject=false)
public class CSSRule
  extends SimpleScriptable
{
  public static final short UNKNOWN_RULE = 0;
  public static final short STYLE_RULE = 1;
  public static final short CHARSET_RULE = 2;
  public static final short IMPORT_RULE = 3;
  public static final short MEDIA_RULE = 4;
  public static final short FONT_FACE_RULE = 5;
  public static final short PAGE_RULE = 6;
  private final CSSStyleSheet stylesheet_;
  private final org.w3c.dom.css.CSSRule rule_;
  
  @Deprecated
  public CSSRule()
  {
    this.stylesheet_ = null;
    this.rule_ = null;
  }
  
  public static CSSRule create(CSSStyleSheet stylesheet, org.w3c.dom.css.CSSRule rule)
  {
    switch (rule.getType())
    {
    case 1: 
      return new CSSStyleRule(stylesheet, (org.w3c.dom.css.CSSStyleRule)rule);
    case 3: 
      return new CSSImportRule(stylesheet, (org.w3c.dom.css.CSSImportRule)rule);
    case 2: 
      return new CSSCharsetRule(stylesheet, (org.w3c.dom.css.CSSCharsetRule)rule);
    case 4: 
      return new CSSMediaRule(stylesheet, (org.w3c.dom.css.CSSMediaRule)rule);
    case 5: 
      return new CSSFontFaceRule(stylesheet, (org.w3c.dom.css.CSSFontFaceRule)rule);
    }
    throw new UnsupportedOperationException("CSSRule " + rule.getClass().getName() + " is not yet supported:" + rule.getCssText());
  }
  
  protected CSSRule(CSSStyleSheet stylesheet, org.w3c.dom.css.CSSRule rule)
  {
    this.stylesheet_ = stylesheet;
    this.rule_ = rule;
    setParentScope(stylesheet);
    setPrototype(getPrototype(getClass()));
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public short getType()
  {
    return this.rule_.getType();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getCssText()
  {
    return this.rule_.getCssText();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setCssText(String cssText)
  {
    this.rule_.setCssText(cssText);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public CSSStyleSheet getParentStyleSheet()
  {
    return this.stylesheet_;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public CSSRule getParentRule()
  {
    org.w3c.dom.css.CSSRule parentRule = this.rule_.getParentRule();
    if (parentRule != null) {
      return create(this.stylesheet_, parentRule);
    }
    return null;
  }
  
  protected org.w3c.dom.css.CSSRule getRule()
  {
    return this.rule_;
  }
}
