package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class ScrollbarRoleImpl
  extends RoleImpl
  implements ScrollbarRole
{
  ScrollbarRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaControlsProperty(Element element)
  {
    return Property.CONTROLS.get(element);
  }
  
  public String getAriaOrientationProperty(Element element)
  {
    return Property.ORIENTATION.get(element);
  }
  
  public String getAriaValuemaxProperty(Element element)
  {
    return Property.VALUEMAX.get(element);
  }
  
  public String getAriaValueminProperty(Element element)
  {
    return Property.VALUEMIN.get(element);
  }
  
  public String getAriaValuenowProperty(Element element)
  {
    return Property.VALUENOW.get(element);
  }
  
  public String getAriaValuetextProperty(Element element)
  {
    return Property.VALUETEXT.get(element);
  }
  
  public void removeAriaControlsProperty(Element element)
  {
    Property.CONTROLS.remove(element);
  }
  
  public void removeAriaOrientationProperty(Element element)
  {
    Property.ORIENTATION.remove(element);
  }
  
  public void removeAriaValuemaxProperty(Element element)
  {
    Property.VALUEMAX.remove(element);
  }
  
  public void removeAriaValueminProperty(Element element)
  {
    Property.VALUEMIN.remove(element);
  }
  
  public void removeAriaValuenowProperty(Element element)
  {
    Property.VALUENOW.remove(element);
  }
  
  public void removeAriaValuetextProperty(Element element)
  {
    Property.VALUETEXT.remove(element);
  }
  
  public void setAriaControlsProperty(Element element, Id... value)
  {
    Property.CONTROLS.set(element, value);
  }
  
  public void setAriaOrientationProperty(Element element, OrientationValue value)
  {
    Property.ORIENTATION.set(element, new OrientationValue[] { value });
  }
  
  public void setAriaValuemaxProperty(Element element, Number value)
  {
    Property.VALUEMAX.set(element, new Number[] { value });
  }
  
  public void setAriaValueminProperty(Element element, Number value)
  {
    Property.VALUEMIN.set(element, new Number[] { value });
  }
  
  public void setAriaValuenowProperty(Element element, Number value)
  {
    Property.VALUENOW.set(element, new Number[] { value });
  }
  
  public void setAriaValuetextProperty(Element element, String value)
  {
    Property.VALUETEXT.set(element, new String[] { value });
  }
}
