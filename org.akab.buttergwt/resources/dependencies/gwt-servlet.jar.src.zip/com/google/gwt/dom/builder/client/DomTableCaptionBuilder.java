package com.google.gwt.dom.builder.client;

import com.google.gwt.dom.builder.shared.TableCaptionBuilder;
import com.google.gwt.dom.client.TableCaptionElement;

public class DomTableCaptionBuilder
  extends DomElementBuilderBase<TableCaptionBuilder, TableCaptionElement>
  implements TableCaptionBuilder
{
  DomTableCaptionBuilder(DomBuilderImpl delegate)
  {
    super(delegate);
  }
}
