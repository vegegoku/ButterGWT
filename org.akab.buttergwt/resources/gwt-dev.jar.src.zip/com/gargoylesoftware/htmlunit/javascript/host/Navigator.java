package com.gargoylesoftware.htmlunit.javascript.host;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.CookieManager;
import com.gargoylesoftware.htmlunit.PluginConfiguration;
import com.gargoylesoftware.htmlunit.PluginConfiguration.MimeType;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebClientOptions;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.SimpleScriptable;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.geo.Geolocation;

@JsxClass
public final class Navigator
  extends SimpleScriptable
{
  private PluginArray plugins_;
  private MimeTypeArray mimeTypes_;
  
  @JsxGetter
  public String getAppCodeName()
  {
    return getBrowserVersion().getApplicationCodeName();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getAppMinorVersion()
  {
    return getBrowserVersion().getApplicationMinorVersion();
  }
  
  @JsxGetter
  public String getAppName()
  {
    return getBrowserVersion().getApplicationName();
  }
  
  @JsxGetter
  public String getAppVersion()
  {
    return getBrowserVersion().getApplicationVersion();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBrowserLanguage()
  {
    return getBrowserVersion().getBrowserLanguage();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getLanguage()
  {
    return getBrowserVersion().getBrowserLanguage();
  }
  
  @JsxGetter
  public boolean getCookieEnabled()
  {
    return getWindow().getWebWindow().getWebClient().getCookieManager().isCookiesEnabled();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getCpuClass()
  {
    return getBrowserVersion().getCpuClass();
  }
  
  @JsxGetter
  public boolean getOnLine()
  {
    return getBrowserVersion().isOnLine();
  }
  
  @JsxGetter
  public String getPlatform()
  {
    return getBrowserVersion().getPlatform();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getProduct()
  {
    return "Gecko";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getProductSub()
  {
    return "20100215";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getSystemLanguage()
  {
    return getBrowserVersion().getSystemLanguage();
  }
  
  @JsxGetter
  public String getUserAgent()
  {
    return getBrowserVersion().getUserAgent();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getUserLanguage()
  {
    return getBrowserVersion().getUserLanguage();
  }
  
  @JsxGetter
  public Object getPlugins()
  {
    initPlugins();
    return this.plugins_;
  }
  
  private void initPlugins()
  {
    if (this.plugins_ != null) {
      return;
    }
    this.plugins_ = new PluginArray();
    this.plugins_.setParentScope(this);
    this.plugins_.setPrototype(getPrototype(PluginArray.class));
    
    this.mimeTypes_ = new MimeTypeArray();
    this.mimeTypes_.setParentScope(this);
    this.mimeTypes_.setPrototype(getPrototype(MimeTypeArray.class));
    for (PluginConfiguration pluginConfig : getBrowserVersion().getPlugins())
    {
      plugin = new Plugin(pluginConfig.getName(), pluginConfig.getDescription(), pluginConfig.getFilename());
      
      plugin.setParentScope(this);
      plugin.setPrototype(getPrototype(Plugin.class));
      this.plugins_.add(plugin);
      for (PluginConfiguration.MimeType mimeTypeConfig : pluginConfig.getMimeTypes())
      {
        MimeType mimeType = new MimeType(mimeTypeConfig.getType(), mimeTypeConfig.getDescription(), mimeTypeConfig.getSuffixes(), plugin);
        
        mimeType.setParentScope(this);
        mimeType.setPrototype(getPrototype(MimeType.class));
        this.mimeTypes_.add(mimeType);
        plugin.add(mimeType);
      }
    }
    Plugin plugin;
  }
  
  @JsxGetter
  public Object getMimeTypes()
  {
    initPlugins();
    return this.mimeTypes_;
  }
  
  @JsxFunction
  public boolean javaEnabled()
  {
    return getWindow().getWebWindow().getWebClient().getOptions().isAppletEnabled();
  }
  
  @JsxFunction
  public boolean taintEnabled()
  {
    return false;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public Geolocation getGeolocation()
  {
    Geolocation geolocation = new Geolocation();
    geolocation.setPrototype(getPrototype(geolocation.getClass()));
    geolocation.setParentScope(getParentScope());
    return geolocation;
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getBuildID()
  {
    BrowserVersion browser = getBrowserVersion();
    if ("FF17".equals(browser.getNickname())) {
      return "20121129151842";
    }
    if ("FF3.6".equals(browser.getNickname())) {
      return "20120306064154";
    }
    return "20120713134347";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getVendor()
  {
    BrowserVersion browser = getBrowserVersion();
    if (browser.getNickname().startsWith("FF")) {
      return "";
    }
    return "Google Inc.";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF), @com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.CHROME)})
  public String getVendorSub()
  {
    return "";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(value=com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF, minVersion=10.0F)})
  public String getDoNotTrack()
  {
    if (getWindow().getWebWindow().getWebClient().getOptions().isDoNotTrackEnabled()) {
      return "yes";
    }
    return "unspecified";
  }
  
  public String getMsDoNotTrack()
  {
    if (getWindow().getWebWindow().getWebClient().getOptions().isDoNotTrackEnabled()) {
      return "1";
    }
    return "0";
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getOscpu()
  {
    return "Windows NT 6.1";
  }
}
