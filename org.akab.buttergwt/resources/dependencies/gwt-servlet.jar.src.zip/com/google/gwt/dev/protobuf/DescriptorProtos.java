package com.google.gwt.dev.protobuf;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class DescriptorProtos
{
  private static Descriptors.Descriptor internal_static_google_protobuf_FileDescriptorSet_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_FileDescriptorSet_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_FileDescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_FileDescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_DescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_DescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_DescriptorProto_ExtensionRange_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_DescriptorProto_ExtensionRange_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_FieldDescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_FieldDescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_EnumDescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_EnumDescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_EnumValueDescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_EnumValueDescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_ServiceDescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_ServiceDescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_MethodDescriptorProto_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_MethodDescriptorProto_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_FileOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_FileOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_MessageOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_MessageOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_FieldOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_FieldOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_EnumOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_EnumOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_EnumValueOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_EnumValueOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_ServiceOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_ServiceOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_MethodOptions_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_MethodOptions_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_UninterpretedOption_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_UninterpretedOption_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_UninterpretedOption_NamePart_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_UninterpretedOption_NamePart_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_SourceCodeInfo_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_SourceCodeInfo_fieldAccessorTable;
  private static Descriptors.Descriptor internal_static_google_protobuf_SourceCodeInfo_Location_descriptor;
  private static GeneratedMessage.FieldAccessorTable internal_static_google_protobuf_SourceCodeInfo_Location_fieldAccessorTable;
  private static Descriptors.FileDescriptor descriptor;
  public static void registerAllExtensions(ExtensionRegistry registry) {}
  
  public static abstract interface FileDescriptorSetOrBuilder
    extends MessageOrBuilder
  {
    public abstract List<DescriptorProtos.FileDescriptorProto> getFileList();
    
    public abstract DescriptorProtos.FileDescriptorProto getFile(int paramInt);
    
    public abstract int getFileCount();
    
    public abstract List<? extends DescriptorProtos.FileDescriptorProtoOrBuilder> getFileOrBuilderList();
    
    public abstract DescriptorProtos.FileDescriptorProtoOrBuilder getFileOrBuilder(int paramInt);
  }
  
  public static final class FileDescriptorSet
    extends GeneratedMessage
    implements DescriptorProtos.FileDescriptorSetOrBuilder
  {
    private static final FileDescriptorSet defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private FileDescriptorSet(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private FileDescriptorSet(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static FileDescriptorSet getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public FileDescriptorSet getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    /* Error */
    private FileDescriptorSet(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      // Byte code:
      //   0: aload_0
      //   1: invokespecial 91	com/google/gwt/dev/protobuf/GeneratedMessage:<init>	()V
      //   4: aload_0
      //   5: iconst_m1
      //   6: putfield 75	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:memoizedIsInitialized	B
      //   9: aload_0
      //   10: iconst_m1
      //   11: putfield 77	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:memoizedSerializedSize	I
      //   14: aload_0
      //   15: invokespecial 108	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:initFields	()V
      //   18: iconst_0
      //   19: istore_3
      //   20: invokestatic 112	com/google/gwt/dev/protobuf/UnknownFieldSet:newBuilder	()Lcom/google/gwt/dev/protobuf/UnknownFieldSet$Builder;
      //   23: astore 4
      //   25: iconst_0
      //   26: istore 5
      //   28: iload 5
      //   30: ifne +106 -> 136
      //   33: aload_1
      //   34: invokevirtual 118	com/google/gwt/dev/protobuf/CodedInputStream:readTag	()I
      //   37: istore 6
      //   39: iload 6
      //   41: lookupswitch	default:+33->74, 0:+27->68, 10:+52->93
      //   68: iconst_1
      //   69: istore 5
      //   71: goto +62 -> 133
      //   74: aload_0
      //   75: aload_1
      //   76: aload 4
      //   78: aload_2
      //   79: iload 6
      //   81: invokevirtual 122	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:parseUnknownField	(Lcom/google/gwt/dev/protobuf/CodedInputStream;Lcom/google/gwt/dev/protobuf/UnknownFieldSet$Builder;Lcom/google/gwt/dev/protobuf/ExtensionRegistryLite;I)Z
      //   84: ifne +49 -> 133
      //   87: iconst_1
      //   88: istore 5
      //   90: goto +43 -> 133
      //   93: iload_3
      //   94: iconst_1
      //   95: iand
      //   96: iconst_1
      //   97: if_icmpeq +18 -> 115
      //   100: aload_0
      //   101: new 124	java/util/ArrayList
      //   104: dup
      //   105: invokespecial 125	java/util/ArrayList:<init>	()V
      //   108: putfield 127	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:file_	Ljava/util/List;
      //   111: iload_3
      //   112: iconst_1
      //   113: ior
      //   114: istore_3
      //   115: aload_0
      //   116: getfield 127	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:file_	Ljava/util/List;
      //   119: aload_1
      //   120: getstatic 129	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorProto:PARSER	Lcom/google/gwt/dev/protobuf/Parser;
      //   123: aload_2
      //   124: invokevirtual 133	com/google/gwt/dev/protobuf/CodedInputStream:readMessage	(Lcom/google/gwt/dev/protobuf/Parser;Lcom/google/gwt/dev/protobuf/ExtensionRegistryLite;)Lcom/google/gwt/dev/protobuf/MessageLite;
      //   127: invokeinterface 139 2 0
      //   132: pop
      //   133: goto -105 -> 28
      //   136: iload_3
      //   137: iconst_1
      //   138: iand
      //   139: iconst_1
      //   140: if_icmpne +14 -> 154
      //   143: aload_0
      //   144: aload_0
      //   145: getfield 127	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:file_	Ljava/util/List;
      //   148: invokestatic 145	java/util/Collections:unmodifiableList	(Ljava/util/List;)Ljava/util/List;
      //   151: putfield 127	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:file_	Ljava/util/List;
      //   154: aload_0
      //   155: aload 4
      //   157: invokevirtual 148	com/google/gwt/dev/protobuf/UnknownFieldSet$Builder:build	()Lcom/google/gwt/dev/protobuf/UnknownFieldSet;
      //   160: putfield 83	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:unknownFields	Lcom/google/gwt/dev/protobuf/UnknownFieldSet;
      //   163: aload_0
      //   164: invokevirtual 151	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:makeExtensionsImmutable	()V
      //   167: goto +67 -> 234
      //   170: astore 5
      //   172: aload 5
      //   174: aload_0
      //   175: invokevirtual 155	com/google/gwt/dev/protobuf/InvalidProtocolBufferException:setUnfinishedMessage	(Lcom/google/gwt/dev/protobuf/MessageLite;)Lcom/google/gwt/dev/protobuf/InvalidProtocolBufferException;
      //   178: athrow
      //   179: astore 5
      //   181: new 103	com/google/gwt/dev/protobuf/InvalidProtocolBufferException
      //   184: dup
      //   185: aload 5
      //   187: invokevirtual 159	java/io/IOException:getMessage	()Ljava/lang/String;
      //   190: invokespecial 162	com/google/gwt/dev/protobuf/InvalidProtocolBufferException:<init>	(Ljava/lang/String;)V
      //   193: aload_0
      //   194: invokevirtual 155	com/google/gwt/dev/protobuf/InvalidProtocolBufferException:setUnfinishedMessage	(Lcom/google/gwt/dev/protobuf/MessageLite;)Lcom/google/gwt/dev/protobuf/InvalidProtocolBufferException;
      //   197: athrow
      //   198: astore 7
      //   200: iload_3
      //   201: iconst_1
      //   202: iand
      //   203: iconst_1
      //   204: if_icmpne +14 -> 218
      //   207: aload_0
      //   208: aload_0
      //   209: getfield 127	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:file_	Ljava/util/List;
      //   212: invokestatic 145	java/util/Collections:unmodifiableList	(Ljava/util/List;)Ljava/util/List;
      //   215: putfield 127	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:file_	Ljava/util/List;
      //   218: aload_0
      //   219: aload 4
      //   221: invokevirtual 148	com/google/gwt/dev/protobuf/UnknownFieldSet$Builder:build	()Lcom/google/gwt/dev/protobuf/UnknownFieldSet;
      //   224: putfield 83	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:unknownFields	Lcom/google/gwt/dev/protobuf/UnknownFieldSet;
      //   227: aload_0
      //   228: invokevirtual 151	com/google/gwt/dev/protobuf/DescriptorProtos$FileDescriptorSet:makeExtensionsImmutable	()V
      //   231: aload 7
      //   233: athrow
      //   234: return
      // Line number table:
      //   Java source line #75	-> byte code offset #0
      //   Java source line #184	-> byte code offset #4
      //   Java source line #208	-> byte code offset #9
      //   Java source line #76	-> byte code offset #14
      //   Java source line #77	-> byte code offset #18
      //   Java source line #78	-> byte code offset #20
      //   Java source line #81	-> byte code offset #25
      //   Java source line #82	-> byte code offset #28
      //   Java source line #83	-> byte code offset #33
      //   Java source line #84	-> byte code offset #39
      //   Java source line #86	-> byte code offset #68
      //   Java source line #87	-> byte code offset #71
      //   Java source line #89	-> byte code offset #74
      //   Java source line #91	-> byte code offset #87
      //   Java source line #96	-> byte code offset #93
      //   Java source line #97	-> byte code offset #100
      //   Java source line #98	-> byte code offset #111
      //   Java source line #100	-> byte code offset #115
      //   Java source line #104	-> byte code offset #133
      //   Java source line #111	-> byte code offset #136
      //   Java source line #112	-> byte code offset #143
      //   Java source line #114	-> byte code offset #154
      //   Java source line #115	-> byte code offset #163
      //   Java source line #116	-> byte code offset #167
      //   Java source line #105	-> byte code offset #170
      //   Java source line #106	-> byte code offset #172
      //   Java source line #107	-> byte code offset #179
      //   Java source line #108	-> byte code offset #181
      //   Java source line #111	-> byte code offset #198
      //   Java source line #112	-> byte code offset #207
      //   Java source line #114	-> byte code offset #218
      //   Java source line #115	-> byte code offset #227
      //   Java source line #117	-> byte code offset #234
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	235	0	this	FileDescriptorSet
      //   0	235	1	input	CodedInputStream
      //   0	235	2	extensionRegistry	ExtensionRegistryLite
      //   19	182	3	mutable_bitField0_	int
      //   23	197	4	unknownFields	UnknownFieldSet.Builder
      //   26	63	5	done	boolean
      //   170	3	5	e	InvalidProtocolBufferException
      //   179	7	5	e	IOException
      //   37	43	6	tag	int
      //   198	34	7	localObject	Object
      // Exception table:
      //   from	to	target	type
      //   25	136	170	com/google/gwt/dev/protobuf/InvalidProtocolBufferException
      //   25	136	179	java/io/IOException
      //   25	136	198	finally
      //   170	200	198	finally
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_FileDescriptorSet_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_FileDescriptorSet_fieldAccessorTable.ensureFieldAccessorsInitialized(FileDescriptorSet.class, Builder.class);
    }
    
    public static Parser<FileDescriptorSet> PARSER = new AbstractParser()
    {
      public DescriptorProtos.FileDescriptorSet parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.FileDescriptorSet(input, extensionRegistry, null);
      }
    };
    public static final int FILE_FIELD_NUMBER = 1;
    private List<DescriptorProtos.FileDescriptorProto> file_;
    
    public Parser<FileDescriptorSet> getParserForType()
    {
      return PARSER;
    }
    
    public List<DescriptorProtos.FileDescriptorProto> getFileList()
    {
      return this.file_;
    }
    
    public List<? extends DescriptorProtos.FileDescriptorProtoOrBuilder> getFileOrBuilderList()
    {
      return this.file_;
    }
    
    public int getFileCount()
    {
      return this.file_.size();
    }
    
    public DescriptorProtos.FileDescriptorProto getFile(int index)
    {
      return (DescriptorProtos.FileDescriptorProto)this.file_.get(index);
    }
    
    public DescriptorProtos.FileDescriptorProtoOrBuilder getFileOrBuilder(int index)
    {
      return (DescriptorProtos.FileDescriptorProtoOrBuilder)this.file_.get(index);
    }
    
    private void initFields()
    {
      this.file_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getFileCount(); i++) {
        if (!getFile(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      for (int i = 0; i < this.file_.size(); i++) {
        output.writeMessage(1, (MessageLite)this.file_.get(i));
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      for (int i = 0; i < this.file_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(1, (MessageLite)this.file_.get(i));
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static FileDescriptorSet parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorSet)PARSER.parseFrom(data);
    }
    
    public static FileDescriptorSet parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorSet)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FileDescriptorSet parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorSet)PARSER.parseFrom(data);
    }
    
    public static FileDescriptorSet parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorSet)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FileDescriptorSet parseFrom(InputStream input)
      throws IOException
    {
      return (FileDescriptorSet)PARSER.parseFrom(input);
    }
    
    public static FileDescriptorSet parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileDescriptorSet)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static FileDescriptorSet parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (FileDescriptorSet)PARSER.parseDelimitedFrom(input);
    }
    
    public static FileDescriptorSet parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileDescriptorSet)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static FileDescriptorSet parseFrom(CodedInputStream input)
      throws IOException
    {
      return (FileDescriptorSet)PARSER.parseFrom(input);
    }
    
    public static FileDescriptorSet parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileDescriptorSet)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$300();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(FileDescriptorSet prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.FileDescriptorSetOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileDescriptorSet_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileDescriptorSet_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.FileDescriptorSet.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getFileFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        if (this.fileBuilder_ == null)
        {
          this.file_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          this.fileBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileDescriptorSet_descriptor;
      }
      
      public DescriptorProtos.FileDescriptorSet getDefaultInstanceForType()
      {
        return DescriptorProtos.FileDescriptorSet.getDefaultInstance();
      }
      
      public DescriptorProtos.FileDescriptorSet build()
      {
        DescriptorProtos.FileDescriptorSet result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.FileDescriptorSet buildPartial()
      {
        DescriptorProtos.FileDescriptorSet result = new DescriptorProtos.FileDescriptorSet(this, null);
        int from_bitField0_ = this.bitField0_;
        if (this.fileBuilder_ == null)
        {
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.file_ = Collections.unmodifiableList(this.file_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.file_ = this.file_;
        }
        else
        {
          result.file_ = this.fileBuilder_.build();
        }
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.FileDescriptorSet)) {
          return mergeFrom((DescriptorProtos.FileDescriptorSet)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.FileDescriptorSet other)
      {
        if (other == DescriptorProtos.FileDescriptorSet.getDefaultInstance()) {
          return this;
        }
        if (this.fileBuilder_ == null)
        {
          if (!other.file_.isEmpty())
          {
            if (this.file_.isEmpty())
            {
              this.file_ = other.file_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensureFileIsMutable();
              this.file_.addAll(other.file_);
            }
            onChanged();
          }
        }
        else if (!other.file_.isEmpty()) {
          if (this.fileBuilder_.isEmpty())
          {
            this.fileBuilder_.dispose();
            this.fileBuilder_ = null;
            this.file_ = other.file_;
            this.bitField0_ &= 0xFFFFFFFE;
            this.fileBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getFileFieldBuilder() : null);
          }
          else
          {
            this.fileBuilder_.addAllMessages(other.file_);
          }
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getFileCount(); i++) {
          if (!getFile(i).isInitialized()) {
            return false;
          }
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.FileDescriptorSet parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.FileDescriptorSet)DescriptorProtos.FileDescriptorSet.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.FileDescriptorSet)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private List<DescriptorProtos.FileDescriptorProto> file_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.FileDescriptorProto, DescriptorProtos.FileDescriptorProto.Builder, DescriptorProtos.FileDescriptorProtoOrBuilder> fileBuilder_;
      
      private void ensureFileIsMutable()
      {
        if ((this.bitField0_ & 0x1) != 1)
        {
          this.file_ = new ArrayList(this.file_);
          this.bitField0_ |= 0x1;
        }
      }
      
      public List<DescriptorProtos.FileDescriptorProto> getFileList()
      {
        if (this.fileBuilder_ == null) {
          return Collections.unmodifiableList(this.file_);
        }
        return this.fileBuilder_.getMessageList();
      }
      
      public int getFileCount()
      {
        if (this.fileBuilder_ == null) {
          return this.file_.size();
        }
        return this.fileBuilder_.getCount();
      }
      
      public DescriptorProtos.FileDescriptorProto getFile(int index)
      {
        if (this.fileBuilder_ == null) {
          return (DescriptorProtos.FileDescriptorProto)this.file_.get(index);
        }
        return (DescriptorProtos.FileDescriptorProto)this.fileBuilder_.getMessage(index);
      }
      
      public Builder setFile(int index, DescriptorProtos.FileDescriptorProto value)
      {
        if (this.fileBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureFileIsMutable();
          this.file_.set(index, value);
          onChanged();
        }
        else
        {
          this.fileBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setFile(int index, DescriptorProtos.FileDescriptorProto.Builder builderForValue)
      {
        if (this.fileBuilder_ == null)
        {
          ensureFileIsMutable();
          this.file_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.fileBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addFile(DescriptorProtos.FileDescriptorProto value)
      {
        if (this.fileBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureFileIsMutable();
          this.file_.add(value);
          onChanged();
        }
        else
        {
          this.fileBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addFile(int index, DescriptorProtos.FileDescriptorProto value)
      {
        if (this.fileBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureFileIsMutable();
          this.file_.add(index, value);
          onChanged();
        }
        else
        {
          this.fileBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addFile(DescriptorProtos.FileDescriptorProto.Builder builderForValue)
      {
        if (this.fileBuilder_ == null)
        {
          ensureFileIsMutable();
          this.file_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.fileBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addFile(int index, DescriptorProtos.FileDescriptorProto.Builder builderForValue)
      {
        if (this.fileBuilder_ == null)
        {
          ensureFileIsMutable();
          this.file_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.fileBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllFile(Iterable<? extends DescriptorProtos.FileDescriptorProto> values)
      {
        if (this.fileBuilder_ == null)
        {
          ensureFileIsMutable();
          GeneratedMessage.Builder.addAll(values, this.file_);
          onChanged();
        }
        else
        {
          this.fileBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearFile()
      {
        if (this.fileBuilder_ == null)
        {
          this.file_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
        }
        else
        {
          this.fileBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeFile(int index)
      {
        if (this.fileBuilder_ == null)
        {
          ensureFileIsMutable();
          this.file_.remove(index);
          onChanged();
        }
        else
        {
          this.fileBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.FileDescriptorProto.Builder getFileBuilder(int index)
      {
        return (DescriptorProtos.FileDescriptorProto.Builder)getFileFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.FileDescriptorProtoOrBuilder getFileOrBuilder(int index)
      {
        if (this.fileBuilder_ == null) {
          return (DescriptorProtos.FileDescriptorProtoOrBuilder)this.file_.get(index);
        }
        return (DescriptorProtos.FileDescriptorProtoOrBuilder)this.fileBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.FileDescriptorProtoOrBuilder> getFileOrBuilderList()
      {
        if (this.fileBuilder_ != null) {
          return this.fileBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.file_);
      }
      
      public DescriptorProtos.FileDescriptorProto.Builder addFileBuilder()
      {
        return (DescriptorProtos.FileDescriptorProto.Builder)getFileFieldBuilder().addBuilder(DescriptorProtos.FileDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.FileDescriptorProto.Builder addFileBuilder(int index)
      {
        return (DescriptorProtos.FileDescriptorProto.Builder)getFileFieldBuilder().addBuilder(index, DescriptorProtos.FileDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.FileDescriptorProto.Builder> getFileBuilderList()
      {
        return getFileFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.FileDescriptorProto, DescriptorProtos.FileDescriptorProto.Builder, DescriptorProtos.FileDescriptorProtoOrBuilder> getFileFieldBuilder()
      {
        if (this.fileBuilder_ == null)
        {
          this.fileBuilder_ = new RepeatedFieldBuilder(this.file_, (this.bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
          
          this.file_ = null;
        }
        return this.fileBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new FileDescriptorSet(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface FileDescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract boolean hasPackage();
    
    public abstract String getPackage();
    
    public abstract ByteString getPackageBytes();
    
    public abstract List<String> getDependencyList();
    
    public abstract int getDependencyCount();
    
    public abstract String getDependency(int paramInt);
    
    public abstract ByteString getDependencyBytes(int paramInt);
    
    public abstract List<Integer> getPublicDependencyList();
    
    public abstract int getPublicDependencyCount();
    
    public abstract int getPublicDependency(int paramInt);
    
    public abstract List<Integer> getWeakDependencyList();
    
    public abstract int getWeakDependencyCount();
    
    public abstract int getWeakDependency(int paramInt);
    
    public abstract List<DescriptorProtos.DescriptorProto> getMessageTypeList();
    
    public abstract DescriptorProtos.DescriptorProto getMessageType(int paramInt);
    
    public abstract int getMessageTypeCount();
    
    public abstract List<? extends DescriptorProtos.DescriptorProtoOrBuilder> getMessageTypeOrBuilderList();
    
    public abstract DescriptorProtos.DescriptorProtoOrBuilder getMessageTypeOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList();
    
    public abstract DescriptorProtos.EnumDescriptorProto getEnumType(int paramInt);
    
    public abstract int getEnumTypeCount();
    
    public abstract List<? extends DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeOrBuilderList();
    
    public abstract DescriptorProtos.EnumDescriptorProtoOrBuilder getEnumTypeOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.ServiceDescriptorProto> getServiceList();
    
    public abstract DescriptorProtos.ServiceDescriptorProto getService(int paramInt);
    
    public abstract int getServiceCount();
    
    public abstract List<? extends DescriptorProtos.ServiceDescriptorProtoOrBuilder> getServiceOrBuilderList();
    
    public abstract DescriptorProtos.ServiceDescriptorProtoOrBuilder getServiceOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.FieldDescriptorProto> getExtensionList();
    
    public abstract DescriptorProtos.FieldDescriptorProto getExtension(int paramInt);
    
    public abstract int getExtensionCount();
    
    public abstract List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionOrBuilderList();
    
    public abstract DescriptorProtos.FieldDescriptorProtoOrBuilder getExtensionOrBuilder(int paramInt);
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.FileOptions getOptions();
    
    public abstract DescriptorProtos.FileOptionsOrBuilder getOptionsOrBuilder();
    
    public abstract boolean hasSourceCodeInfo();
    
    public abstract DescriptorProtos.SourceCodeInfo getSourceCodeInfo();
    
    public abstract DescriptorProtos.SourceCodeInfoOrBuilder getSourceCodeInfoOrBuilder();
  }
  
  public static final class FileDescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.FileDescriptorProtoOrBuilder
  {
    private static final FileDescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private FileDescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private FileDescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static FileDescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public FileDescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private FileDescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 18: 
            this.bitField0_ |= 0x2;
            this.package_ = input.readBytes();
            break;
          case 26: 
            if ((mutable_bitField0_ & 0x4) != 4)
            {
              this.dependency_ = new LazyStringArrayList();
              mutable_bitField0_ |= 0x4;
            }
            this.dependency_.add(input.readBytes());
            break;
          case 34: 
            if ((mutable_bitField0_ & 0x20) != 32)
            {
              this.messageType_ = new ArrayList();
              mutable_bitField0_ |= 0x20;
            }
            this.messageType_.add(input.readMessage(DescriptorProtos.DescriptorProto.PARSER, extensionRegistry));
            break;
          case 42: 
            if ((mutable_bitField0_ & 0x40) != 64)
            {
              this.enumType_ = new ArrayList();
              mutable_bitField0_ |= 0x40;
            }
            this.enumType_.add(input.readMessage(DescriptorProtos.EnumDescriptorProto.PARSER, extensionRegistry));
            break;
          case 50: 
            if ((mutable_bitField0_ & 0x80) != 128)
            {
              this.service_ = new ArrayList();
              mutable_bitField0_ |= 0x80;
            }
            this.service_.add(input.readMessage(DescriptorProtos.ServiceDescriptorProto.PARSER, extensionRegistry));
            break;
          case 58: 
            if ((mutable_bitField0_ & 0x100) != 256)
            {
              this.extension_ = new ArrayList();
              mutable_bitField0_ |= 0x100;
            }
            this.extension_.add(input.readMessage(DescriptorProtos.FieldDescriptorProto.PARSER, extensionRegistry));
            break;
          case 66: 
            DescriptorProtos.FileOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x4) == 4) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.FileOptions)input.readMessage(DescriptorProtos.FileOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x4;
            break;
          case 74: 
            DescriptorProtos.SourceCodeInfo.Builder subBuilder = null;
            if ((this.bitField0_ & 0x8) == 8) {
              subBuilder = this.sourceCodeInfo_.toBuilder();
            }
            this.sourceCodeInfo_ = ((DescriptorProtos.SourceCodeInfo)input.readMessage(DescriptorProtos.SourceCodeInfo.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.sourceCodeInfo_);
              this.sourceCodeInfo_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x8;
            break;
          case 80: 
            if ((mutable_bitField0_ & 0x8) != 8)
            {
              this.publicDependency_ = new ArrayList();
              mutable_bitField0_ |= 0x8;
            }
            this.publicDependency_.add(Integer.valueOf(input.readInt32()));
            break;
          case 82: 
            int length = input.readRawVarint32();
            int limit = input.pushLimit(length);
            if (((mutable_bitField0_ & 0x8) != 8) && (input.getBytesUntilLimit() > 0))
            {
              this.publicDependency_ = new ArrayList();
              mutable_bitField0_ |= 0x8;
            }
            while (input.getBytesUntilLimit() > 0) {
              this.publicDependency_.add(Integer.valueOf(input.readInt32()));
            }
            input.popLimit(limit);
            break;
          case 88: 
            if ((mutable_bitField0_ & 0x10) != 16)
            {
              this.weakDependency_ = new ArrayList();
              mutable_bitField0_ |= 0x10;
            }
            this.weakDependency_.add(Integer.valueOf(input.readInt32()));
            break;
          case 90: 
            int length = input.readRawVarint32();
            int limit = input.pushLimit(length);
            if (((mutable_bitField0_ & 0x10) != 16) && (input.getBytesUntilLimit() > 0))
            {
              this.weakDependency_ = new ArrayList();
              mutable_bitField0_ |= 0x10;
            }
            while (input.getBytesUntilLimit() > 0) {
              this.weakDependency_.add(Integer.valueOf(input.readInt32()));
            }
            input.popLimit(limit);
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x4) == 4) {
          this.dependency_ = new UnmodifiableLazyStringList(this.dependency_);
        }
        if ((mutable_bitField0_ & 0x20) == 32) {
          this.messageType_ = Collections.unmodifiableList(this.messageType_);
        }
        if ((mutable_bitField0_ & 0x40) == 64) {
          this.enumType_ = Collections.unmodifiableList(this.enumType_);
        }
        if ((mutable_bitField0_ & 0x80) == 128) {
          this.service_ = Collections.unmodifiableList(this.service_);
        }
        if ((mutable_bitField0_ & 0x100) == 256) {
          this.extension_ = Collections.unmodifiableList(this.extension_);
        }
        if ((mutable_bitField0_ & 0x8) == 8) {
          this.publicDependency_ = Collections.unmodifiableList(this.publicDependency_);
        }
        if ((mutable_bitField0_ & 0x10) == 16) {
          this.weakDependency_ = Collections.unmodifiableList(this.weakDependency_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_FileDescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_FileDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(FileDescriptorProto.class, Builder.class);
    }
    
    public static Parser<FileDescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.FileDescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.FileDescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int PACKAGE_FIELD_NUMBER = 2;
    private Object package_;
    public static final int DEPENDENCY_FIELD_NUMBER = 3;
    private LazyStringList dependency_;
    public static final int PUBLIC_DEPENDENCY_FIELD_NUMBER = 10;
    private List<Integer> publicDependency_;
    public static final int WEAK_DEPENDENCY_FIELD_NUMBER = 11;
    private List<Integer> weakDependency_;
    public static final int MESSAGE_TYPE_FIELD_NUMBER = 4;
    private List<DescriptorProtos.DescriptorProto> messageType_;
    public static final int ENUM_TYPE_FIELD_NUMBER = 5;
    private List<DescriptorProtos.EnumDescriptorProto> enumType_;
    public static final int SERVICE_FIELD_NUMBER = 6;
    private List<DescriptorProtos.ServiceDescriptorProto> service_;
    public static final int EXTENSION_FIELD_NUMBER = 7;
    private List<DescriptorProtos.FieldDescriptorProto> extension_;
    public static final int OPTIONS_FIELD_NUMBER = 8;
    private DescriptorProtos.FileOptions options_;
    public static final int SOURCE_CODE_INFO_FIELD_NUMBER = 9;
    private DescriptorProtos.SourceCodeInfo sourceCodeInfo_;
    
    public Parser<FileDescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasPackage()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public String getPackage()
    {
      Object ref = this.package_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.package_ = s;
      }
      return s;
    }
    
    public ByteString getPackageBytes()
    {
      Object ref = this.package_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.package_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public List<String> getDependencyList()
    {
      return this.dependency_;
    }
    
    public int getDependencyCount()
    {
      return this.dependency_.size();
    }
    
    public String getDependency(int index)
    {
      return (String)this.dependency_.get(index);
    }
    
    public ByteString getDependencyBytes(int index)
    {
      return this.dependency_.getByteString(index);
    }
    
    public List<Integer> getPublicDependencyList()
    {
      return this.publicDependency_;
    }
    
    public int getPublicDependencyCount()
    {
      return this.publicDependency_.size();
    }
    
    public int getPublicDependency(int index)
    {
      return ((Integer)this.publicDependency_.get(index)).intValue();
    }
    
    public List<Integer> getWeakDependencyList()
    {
      return this.weakDependency_;
    }
    
    public int getWeakDependencyCount()
    {
      return this.weakDependency_.size();
    }
    
    public int getWeakDependency(int index)
    {
      return ((Integer)this.weakDependency_.get(index)).intValue();
    }
    
    public List<DescriptorProtos.DescriptorProto> getMessageTypeList()
    {
      return this.messageType_;
    }
    
    public List<? extends DescriptorProtos.DescriptorProtoOrBuilder> getMessageTypeOrBuilderList()
    {
      return this.messageType_;
    }
    
    public int getMessageTypeCount()
    {
      return this.messageType_.size();
    }
    
    public DescriptorProtos.DescriptorProto getMessageType(int index)
    {
      return (DescriptorProtos.DescriptorProto)this.messageType_.get(index);
    }
    
    public DescriptorProtos.DescriptorProtoOrBuilder getMessageTypeOrBuilder(int index)
    {
      return (DescriptorProtos.DescriptorProtoOrBuilder)this.messageType_.get(index);
    }
    
    public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList()
    {
      return this.enumType_;
    }
    
    public List<? extends DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeOrBuilderList()
    {
      return this.enumType_;
    }
    
    public int getEnumTypeCount()
    {
      return this.enumType_.size();
    }
    
    public DescriptorProtos.EnumDescriptorProto getEnumType(int index)
    {
      return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
    }
    
    public DescriptorProtos.EnumDescriptorProtoOrBuilder getEnumTypeOrBuilder(int index)
    {
      return (DescriptorProtos.EnumDescriptorProtoOrBuilder)this.enumType_.get(index);
    }
    
    public List<DescriptorProtos.ServiceDescriptorProto> getServiceList()
    {
      return this.service_;
    }
    
    public List<? extends DescriptorProtos.ServiceDescriptorProtoOrBuilder> getServiceOrBuilderList()
    {
      return this.service_;
    }
    
    public int getServiceCount()
    {
      return this.service_.size();
    }
    
    public DescriptorProtos.ServiceDescriptorProto getService(int index)
    {
      return (DescriptorProtos.ServiceDescriptorProto)this.service_.get(index);
    }
    
    public DescriptorProtos.ServiceDescriptorProtoOrBuilder getServiceOrBuilder(int index)
    {
      return (DescriptorProtos.ServiceDescriptorProtoOrBuilder)this.service_.get(index);
    }
    
    public List<DescriptorProtos.FieldDescriptorProto> getExtensionList()
    {
      return this.extension_;
    }
    
    public List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionOrBuilderList()
    {
      return this.extension_;
    }
    
    public int getExtensionCount()
    {
      return this.extension_.size();
    }
    
    public DescriptorProtos.FieldDescriptorProto getExtension(int index)
    {
      return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
    }
    
    public DescriptorProtos.FieldDescriptorProtoOrBuilder getExtensionOrBuilder(int index)
    {
      return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.extension_.get(index);
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public DescriptorProtos.FileOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.FileOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    public boolean hasSourceCodeInfo()
    {
      return (this.bitField0_ & 0x8) == 8;
    }
    
    public DescriptorProtos.SourceCodeInfo getSourceCodeInfo()
    {
      return this.sourceCodeInfo_;
    }
    
    public DescriptorProtos.SourceCodeInfoOrBuilder getSourceCodeInfoOrBuilder()
    {
      return this.sourceCodeInfo_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.package_ = "";
      this.dependency_ = LazyStringArrayList.EMPTY;
      this.publicDependency_ = Collections.emptyList();
      this.weakDependency_ = Collections.emptyList();
      this.messageType_ = Collections.emptyList();
      this.enumType_ = Collections.emptyList();
      this.service_ = Collections.emptyList();
      this.extension_ = Collections.emptyList();
      this.options_ = DescriptorProtos.FileOptions.getDefaultInstance();
      this.sourceCodeInfo_ = DescriptorProtos.SourceCodeInfo.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getMessageTypeCount(); i++) {
        if (!getMessageType(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      for (int i = 0; i < getEnumTypeCount(); i++) {
        if (!getEnumType(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      for (int i = 0; i < getServiceCount(); i++) {
        if (!getService(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      for (int i = 0; i < getExtensionCount(); i++) {
        if (!getExtension(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeBytes(2, getPackageBytes());
      }
      for (int i = 0; i < this.dependency_.size(); i++) {
        output.writeBytes(3, this.dependency_.getByteString(i));
      }
      for (int i = 0; i < this.messageType_.size(); i++) {
        output.writeMessage(4, (MessageLite)this.messageType_.get(i));
      }
      for (int i = 0; i < this.enumType_.size(); i++) {
        output.writeMessage(5, (MessageLite)this.enumType_.get(i));
      }
      for (int i = 0; i < this.service_.size(); i++) {
        output.writeMessage(6, (MessageLite)this.service_.get(i));
      }
      for (int i = 0; i < this.extension_.size(); i++) {
        output.writeMessage(7, (MessageLite)this.extension_.get(i));
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeMessage(8, this.options_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        output.writeMessage(9, this.sourceCodeInfo_);
      }
      for (int i = 0; i < this.publicDependency_.size(); i++) {
        output.writeInt32(10, ((Integer)this.publicDependency_.get(i)).intValue());
      }
      for (int i = 0; i < this.weakDependency_.size(); i++) {
        output.writeInt32(11, ((Integer)this.weakDependency_.get(i)).intValue());
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeBytesSize(2, getPackageBytes());
      }
      int dataSize = 0;
      for (int i = 0; i < this.dependency_.size(); i++) {
        dataSize += CodedOutputStream.computeBytesSizeNoTag(this.dependency_.getByteString(i));
      }
      size += dataSize;
      size += 1 * getDependencyList().size();
      for (int i = 0; i < this.messageType_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(4, (MessageLite)this.messageType_.get(i));
      }
      for (int i = 0; i < this.enumType_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(5, (MessageLite)this.enumType_.get(i));
      }
      for (int i = 0; i < this.service_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(6, (MessageLite)this.service_.get(i));
      }
      for (int i = 0; i < this.extension_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(7, (MessageLite)this.extension_.get(i));
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeMessageSize(8, this.options_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        size += CodedOutputStream.computeMessageSize(9, this.sourceCodeInfo_);
      }
      int dataSize = 0;
      for (int i = 0; i < this.publicDependency_.size(); i++) {
        dataSize += CodedOutputStream.computeInt32SizeNoTag(((Integer)this.publicDependency_.get(i)).intValue());
      }
      size += dataSize;
      size += 1 * getPublicDependencyList().size();
      
      int dataSize = 0;
      for (int i = 0; i < this.weakDependency_.size(); i++) {
        dataSize += CodedOutputStream.computeInt32SizeNoTag(((Integer)this.weakDependency_.get(i)).intValue());
      }
      size += dataSize;
      size += 1 * getWeakDependencyList().size();
      
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static FileDescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static FileDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FileDescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static FileDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FileDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FileDescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (FileDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static FileDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static FileDescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (FileDescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static FileDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileDescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static FileDescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (FileDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static FileDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$1000();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(FileDescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.FileDescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileDescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.FileDescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders)
        {
          getMessageTypeFieldBuilder();
          getEnumTypeFieldBuilder();
          getServiceFieldBuilder();
          getExtensionFieldBuilder();
          getOptionsFieldBuilder();
          getSourceCodeInfoFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        this.package_ = "";
        this.bitField0_ &= 0xFFFFFFFD;
        this.dependency_ = LazyStringArrayList.EMPTY;
        this.bitField0_ &= 0xFFFFFFFB;
        this.publicDependency_ = Collections.emptyList();
        this.bitField0_ &= 0xFFFFFFF7;
        this.weakDependency_ = Collections.emptyList();
        this.bitField0_ &= 0xFFFFFFEF;
        if (this.messageTypeBuilder_ == null)
        {
          this.messageType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFDF;
        }
        else
        {
          this.messageTypeBuilder_.clear();
        }
        if (this.enumTypeBuilder_ == null)
        {
          this.enumType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFBF;
        }
        else
        {
          this.enumTypeBuilder_.clear();
        }
        if (this.serviceBuilder_ == null)
        {
          this.service_ = Collections.emptyList();
          this.bitField0_ &= 0xFF7F;
        }
        else
        {
          this.serviceBuilder_.clear();
        }
        if (this.extensionBuilder_ == null)
        {
          this.extension_ = Collections.emptyList();
          this.bitField0_ &= 0xFEFF;
        }
        else
        {
          this.extensionBuilder_.clear();
        }
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.FileOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFDFF;
        if (this.sourceCodeInfoBuilder_ == null) {
          this.sourceCodeInfo_ = DescriptorProtos.SourceCodeInfo.getDefaultInstance();
        } else {
          this.sourceCodeInfoBuilder_.clear();
        }
        this.bitField0_ &= 0xFBFF;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileDescriptorProto_descriptor;
      }
      
      public DescriptorProtos.FileDescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.FileDescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.FileDescriptorProto build()
      {
        DescriptorProtos.FileDescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.FileDescriptorProto buildPartial()
      {
        DescriptorProtos.FileDescriptorProto result = new DescriptorProtos.FileDescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.package_ = this.package_;
        if ((this.bitField0_ & 0x4) == 4)
        {
          this.dependency_ = new UnmodifiableLazyStringList(this.dependency_);
          
          this.bitField0_ &= 0xFFFFFFFB;
        }
        result.dependency_ = this.dependency_;
        if ((this.bitField0_ & 0x8) == 8)
        {
          this.publicDependency_ = Collections.unmodifiableList(this.publicDependency_);
          this.bitField0_ &= 0xFFFFFFF7;
        }
        result.publicDependency_ = this.publicDependency_;
        if ((this.bitField0_ & 0x10) == 16)
        {
          this.weakDependency_ = Collections.unmodifiableList(this.weakDependency_);
          this.bitField0_ &= 0xFFFFFFEF;
        }
        result.weakDependency_ = this.weakDependency_;
        if (this.messageTypeBuilder_ == null)
        {
          if ((this.bitField0_ & 0x20) == 32)
          {
            this.messageType_ = Collections.unmodifiableList(this.messageType_);
            this.bitField0_ &= 0xFFFFFFDF;
          }
          result.messageType_ = this.messageType_;
        }
        else
        {
          result.messageType_ = this.messageTypeBuilder_.build();
        }
        if (this.enumTypeBuilder_ == null)
        {
          if ((this.bitField0_ & 0x40) == 64)
          {
            this.enumType_ = Collections.unmodifiableList(this.enumType_);
            this.bitField0_ &= 0xFFFFFFBF;
          }
          result.enumType_ = this.enumType_;
        }
        else
        {
          result.enumType_ = this.enumTypeBuilder_.build();
        }
        if (this.serviceBuilder_ == null)
        {
          if ((this.bitField0_ & 0x80) == 128)
          {
            this.service_ = Collections.unmodifiableList(this.service_);
            this.bitField0_ &= 0xFF7F;
          }
          result.service_ = this.service_;
        }
        else
        {
          result.service_ = this.serviceBuilder_.build();
        }
        if (this.extensionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x100) == 256)
          {
            this.extension_ = Collections.unmodifiableList(this.extension_);
            this.bitField0_ &= 0xFEFF;
          }
          result.extension_ = this.extension_;
        }
        else
        {
          result.extension_ = this.extensionBuilder_.build();
        }
        if ((from_bitField0_ & 0x200) == 512) {
          to_bitField0_ |= 0x4;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.FileOptions)this.optionsBuilder_.build());
        }
        if ((from_bitField0_ & 0x400) == 1024) {
          to_bitField0_ |= 0x8;
        }
        if (this.sourceCodeInfoBuilder_ == null) {
          result.sourceCodeInfo_ = this.sourceCodeInfo_;
        } else {
          result.sourceCodeInfo_ = ((DescriptorProtos.SourceCodeInfo)this.sourceCodeInfoBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.FileDescriptorProto)) {
          return mergeFrom((DescriptorProtos.FileDescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.FileDescriptorProto other)
      {
        if (other == DescriptorProtos.FileDescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (other.hasPackage())
        {
          this.bitField0_ |= 0x2;
          this.package_ = other.package_;
          onChanged();
        }
        if (!other.dependency_.isEmpty())
        {
          if (this.dependency_.isEmpty())
          {
            this.dependency_ = other.dependency_;
            this.bitField0_ &= 0xFFFFFFFB;
          }
          else
          {
            ensureDependencyIsMutable();
            this.dependency_.addAll(other.dependency_);
          }
          onChanged();
        }
        if (!other.publicDependency_.isEmpty())
        {
          if (this.publicDependency_.isEmpty())
          {
            this.publicDependency_ = other.publicDependency_;
            this.bitField0_ &= 0xFFFFFFF7;
          }
          else
          {
            ensurePublicDependencyIsMutable();
            this.publicDependency_.addAll(other.publicDependency_);
          }
          onChanged();
        }
        if (!other.weakDependency_.isEmpty())
        {
          if (this.weakDependency_.isEmpty())
          {
            this.weakDependency_ = other.weakDependency_;
            this.bitField0_ &= 0xFFFFFFEF;
          }
          else
          {
            ensureWeakDependencyIsMutable();
            this.weakDependency_.addAll(other.weakDependency_);
          }
          onChanged();
        }
        if (this.messageTypeBuilder_ == null)
        {
          if (!other.messageType_.isEmpty())
          {
            if (this.messageType_.isEmpty())
            {
              this.messageType_ = other.messageType_;
              this.bitField0_ &= 0xFFFFFFDF;
            }
            else
            {
              ensureMessageTypeIsMutable();
              this.messageType_.addAll(other.messageType_);
            }
            onChanged();
          }
        }
        else if (!other.messageType_.isEmpty()) {
          if (this.messageTypeBuilder_.isEmpty())
          {
            this.messageTypeBuilder_.dispose();
            this.messageTypeBuilder_ = null;
            this.messageType_ = other.messageType_;
            this.bitField0_ &= 0xFFFFFFDF;
            this.messageTypeBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getMessageTypeFieldBuilder() : null);
          }
          else
          {
            this.messageTypeBuilder_.addAllMessages(other.messageType_);
          }
        }
        if (this.enumTypeBuilder_ == null)
        {
          if (!other.enumType_.isEmpty())
          {
            if (this.enumType_.isEmpty())
            {
              this.enumType_ = other.enumType_;
              this.bitField0_ &= 0xFFFFFFBF;
            }
            else
            {
              ensureEnumTypeIsMutable();
              this.enumType_.addAll(other.enumType_);
            }
            onChanged();
          }
        }
        else if (!other.enumType_.isEmpty()) {
          if (this.enumTypeBuilder_.isEmpty())
          {
            this.enumTypeBuilder_.dispose();
            this.enumTypeBuilder_ = null;
            this.enumType_ = other.enumType_;
            this.bitField0_ &= 0xFFFFFFBF;
            this.enumTypeBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getEnumTypeFieldBuilder() : null);
          }
          else
          {
            this.enumTypeBuilder_.addAllMessages(other.enumType_);
          }
        }
        if (this.serviceBuilder_ == null)
        {
          if (!other.service_.isEmpty())
          {
            if (this.service_.isEmpty())
            {
              this.service_ = other.service_;
              this.bitField0_ &= 0xFF7F;
            }
            else
            {
              ensureServiceIsMutable();
              this.service_.addAll(other.service_);
            }
            onChanged();
          }
        }
        else if (!other.service_.isEmpty()) {
          if (this.serviceBuilder_.isEmpty())
          {
            this.serviceBuilder_.dispose();
            this.serviceBuilder_ = null;
            this.service_ = other.service_;
            this.bitField0_ &= 0xFF7F;
            this.serviceBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getServiceFieldBuilder() : null);
          }
          else
          {
            this.serviceBuilder_.addAllMessages(other.service_);
          }
        }
        if (this.extensionBuilder_ == null)
        {
          if (!other.extension_.isEmpty())
          {
            if (this.extension_.isEmpty())
            {
              this.extension_ = other.extension_;
              this.bitField0_ &= 0xFEFF;
            }
            else
            {
              ensureExtensionIsMutable();
              this.extension_.addAll(other.extension_);
            }
            onChanged();
          }
        }
        else if (!other.extension_.isEmpty()) {
          if (this.extensionBuilder_.isEmpty())
          {
            this.extensionBuilder_.dispose();
            this.extensionBuilder_ = null;
            this.extension_ = other.extension_;
            this.bitField0_ &= 0xFEFF;
            this.extensionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getExtensionFieldBuilder() : null);
          }
          else
          {
            this.extensionBuilder_.addAllMessages(other.extension_);
          }
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        if (other.hasSourceCodeInfo()) {
          mergeSourceCodeInfo(other.getSourceCodeInfo());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getMessageTypeCount(); i++) {
          if (!getMessageType(i).isInitialized()) {
            return false;
          }
        }
        for (int i = 0; i < getEnumTypeCount(); i++) {
          if (!getEnumType(i).isInitialized()) {
            return false;
          }
        }
        for (int i = 0; i < getServiceCount(); i++) {
          if (!getService(i).isInitialized()) {
            return false;
          }
        }
        for (int i = 0; i < getExtensionCount(); i++) {
          if (!getExtension(i).isInitialized()) {
            return false;
          }
        }
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.FileDescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.FileDescriptorProto)DescriptorProtos.FileDescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.FileDescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.FileDescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      private Object package_ = "";
      
      public boolean hasPackage()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public String getPackage()
      {
        Object ref = this.package_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.package_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getPackageBytes()
      {
        Object ref = this.package_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.package_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setPackage(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.package_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearPackage()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.package_ = DescriptorProtos.FileDescriptorProto.getDefaultInstance().getPackage();
        onChanged();
        return this;
      }
      
      public Builder setPackageBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.package_ = value;
        onChanged();
        return this;
      }
      
      private LazyStringList dependency_ = LazyStringArrayList.EMPTY;
      
      private void ensureDependencyIsMutable()
      {
        if ((this.bitField0_ & 0x4) != 4)
        {
          this.dependency_ = new LazyStringArrayList(this.dependency_);
          this.bitField0_ |= 0x4;
        }
      }
      
      public List<String> getDependencyList()
      {
        return Collections.unmodifiableList(this.dependency_);
      }
      
      public int getDependencyCount()
      {
        return this.dependency_.size();
      }
      
      public String getDependency(int index)
      {
        return (String)this.dependency_.get(index);
      }
      
      public ByteString getDependencyBytes(int index)
      {
        return this.dependency_.getByteString(index);
      }
      
      public Builder setDependency(int index, String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        ensureDependencyIsMutable();
        this.dependency_.set(index, value);
        onChanged();
        return this;
      }
      
      public Builder addDependency(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        ensureDependencyIsMutable();
        this.dependency_.add(value);
        onChanged();
        return this;
      }
      
      public Builder addAllDependency(Iterable<String> values)
      {
        ensureDependencyIsMutable();
        GeneratedMessage.Builder.addAll(values, this.dependency_);
        onChanged();
        return this;
      }
      
      public Builder clearDependency()
      {
        this.dependency_ = LazyStringArrayList.EMPTY;
        this.bitField0_ &= 0xFFFFFFFB;
        onChanged();
        return this;
      }
      
      public Builder addDependencyBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        ensureDependencyIsMutable();
        this.dependency_.add(value);
        onChanged();
        return this;
      }
      
      private List<Integer> publicDependency_ = Collections.emptyList();
      
      private void ensurePublicDependencyIsMutable()
      {
        if ((this.bitField0_ & 0x8) != 8)
        {
          this.publicDependency_ = new ArrayList(this.publicDependency_);
          this.bitField0_ |= 0x8;
        }
      }
      
      public List<Integer> getPublicDependencyList()
      {
        return Collections.unmodifiableList(this.publicDependency_);
      }
      
      public int getPublicDependencyCount()
      {
        return this.publicDependency_.size();
      }
      
      public int getPublicDependency(int index)
      {
        return ((Integer)this.publicDependency_.get(index)).intValue();
      }
      
      public Builder setPublicDependency(int index, int value)
      {
        ensurePublicDependencyIsMutable();
        this.publicDependency_.set(index, Integer.valueOf(value));
        onChanged();
        return this;
      }
      
      public Builder addPublicDependency(int value)
      {
        ensurePublicDependencyIsMutable();
        this.publicDependency_.add(Integer.valueOf(value));
        onChanged();
        return this;
      }
      
      public Builder addAllPublicDependency(Iterable<? extends Integer> values)
      {
        ensurePublicDependencyIsMutable();
        GeneratedMessage.Builder.addAll(values, this.publicDependency_);
        onChanged();
        return this;
      }
      
      public Builder clearPublicDependency()
      {
        this.publicDependency_ = Collections.emptyList();
        this.bitField0_ &= 0xFFFFFFF7;
        onChanged();
        return this;
      }
      
      private List<Integer> weakDependency_ = Collections.emptyList();
      
      private void ensureWeakDependencyIsMutable()
      {
        if ((this.bitField0_ & 0x10) != 16)
        {
          this.weakDependency_ = new ArrayList(this.weakDependency_);
          this.bitField0_ |= 0x10;
        }
      }
      
      public List<Integer> getWeakDependencyList()
      {
        return Collections.unmodifiableList(this.weakDependency_);
      }
      
      public int getWeakDependencyCount()
      {
        return this.weakDependency_.size();
      }
      
      public int getWeakDependency(int index)
      {
        return ((Integer)this.weakDependency_.get(index)).intValue();
      }
      
      public Builder setWeakDependency(int index, int value)
      {
        ensureWeakDependencyIsMutable();
        this.weakDependency_.set(index, Integer.valueOf(value));
        onChanged();
        return this;
      }
      
      public Builder addWeakDependency(int value)
      {
        ensureWeakDependencyIsMutable();
        this.weakDependency_.add(Integer.valueOf(value));
        onChanged();
        return this;
      }
      
      public Builder addAllWeakDependency(Iterable<? extends Integer> values)
      {
        ensureWeakDependencyIsMutable();
        GeneratedMessage.Builder.addAll(values, this.weakDependency_);
        onChanged();
        return this;
      }
      
      public Builder clearWeakDependency()
      {
        this.weakDependency_ = Collections.emptyList();
        this.bitField0_ &= 0xFFFFFFEF;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.DescriptorProto> messageType_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.DescriptorProto, DescriptorProtos.DescriptorProto.Builder, DescriptorProtos.DescriptorProtoOrBuilder> messageTypeBuilder_;
      
      private void ensureMessageTypeIsMutable()
      {
        if ((this.bitField0_ & 0x20) != 32)
        {
          this.messageType_ = new ArrayList(this.messageType_);
          this.bitField0_ |= 0x20;
        }
      }
      
      public List<DescriptorProtos.DescriptorProto> getMessageTypeList()
      {
        if (this.messageTypeBuilder_ == null) {
          return Collections.unmodifiableList(this.messageType_);
        }
        return this.messageTypeBuilder_.getMessageList();
      }
      
      public int getMessageTypeCount()
      {
        if (this.messageTypeBuilder_ == null) {
          return this.messageType_.size();
        }
        return this.messageTypeBuilder_.getCount();
      }
      
      public DescriptorProtos.DescriptorProto getMessageType(int index)
      {
        if (this.messageTypeBuilder_ == null) {
          return (DescriptorProtos.DescriptorProto)this.messageType_.get(index);
        }
        return (DescriptorProtos.DescriptorProto)this.messageTypeBuilder_.getMessage(index);
      }
      
      public Builder setMessageType(int index, DescriptorProtos.DescriptorProto value)
      {
        if (this.messageTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureMessageTypeIsMutable();
          this.messageType_.set(index, value);
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setMessageType(int index, DescriptorProtos.DescriptorProto.Builder builderForValue)
      {
        if (this.messageTypeBuilder_ == null)
        {
          ensureMessageTypeIsMutable();
          this.messageType_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addMessageType(DescriptorProtos.DescriptorProto value)
      {
        if (this.messageTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureMessageTypeIsMutable();
          this.messageType_.add(value);
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addMessageType(int index, DescriptorProtos.DescriptorProto value)
      {
        if (this.messageTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureMessageTypeIsMutable();
          this.messageType_.add(index, value);
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addMessageType(DescriptorProtos.DescriptorProto.Builder builderForValue)
      {
        if (this.messageTypeBuilder_ == null)
        {
          ensureMessageTypeIsMutable();
          this.messageType_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addMessageType(int index, DescriptorProtos.DescriptorProto.Builder builderForValue)
      {
        if (this.messageTypeBuilder_ == null)
        {
          ensureMessageTypeIsMutable();
          this.messageType_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllMessageType(Iterable<? extends DescriptorProtos.DescriptorProto> values)
      {
        if (this.messageTypeBuilder_ == null)
        {
          ensureMessageTypeIsMutable();
          GeneratedMessage.Builder.addAll(values, this.messageType_);
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearMessageType()
      {
        if (this.messageTypeBuilder_ == null)
        {
          this.messageType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFDF;
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeMessageType(int index)
      {
        if (this.messageTypeBuilder_ == null)
        {
          ensureMessageTypeIsMutable();
          this.messageType_.remove(index);
          onChanged();
        }
        else
        {
          this.messageTypeBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.DescriptorProto.Builder getMessageTypeBuilder(int index)
      {
        return (DescriptorProtos.DescriptorProto.Builder)getMessageTypeFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.DescriptorProtoOrBuilder getMessageTypeOrBuilder(int index)
      {
        if (this.messageTypeBuilder_ == null) {
          return (DescriptorProtos.DescriptorProtoOrBuilder)this.messageType_.get(index);
        }
        return (DescriptorProtos.DescriptorProtoOrBuilder)this.messageTypeBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.DescriptorProtoOrBuilder> getMessageTypeOrBuilderList()
      {
        if (this.messageTypeBuilder_ != null) {
          return this.messageTypeBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.messageType_);
      }
      
      public DescriptorProtos.DescriptorProto.Builder addMessageTypeBuilder()
      {
        return (DescriptorProtos.DescriptorProto.Builder)getMessageTypeFieldBuilder().addBuilder(DescriptorProtos.DescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.DescriptorProto.Builder addMessageTypeBuilder(int index)
      {
        return (DescriptorProtos.DescriptorProto.Builder)getMessageTypeFieldBuilder().addBuilder(index, DescriptorProtos.DescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.DescriptorProto.Builder> getMessageTypeBuilderList()
      {
        return getMessageTypeFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.DescriptorProto, DescriptorProtos.DescriptorProto.Builder, DescriptorProtos.DescriptorProtoOrBuilder> getMessageTypeFieldBuilder()
      {
        if (this.messageTypeBuilder_ == null)
        {
          this.messageTypeBuilder_ = new RepeatedFieldBuilder(this.messageType_, (this.bitField0_ & 0x20) == 32, getParentForChildren(), isClean());
          
          this.messageType_ = null;
        }
        return this.messageTypeBuilder_;
      }
      
      private List<DescriptorProtos.EnumDescriptorProto> enumType_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.EnumDescriptorProto, DescriptorProtos.EnumDescriptorProto.Builder, DescriptorProtos.EnumDescriptorProtoOrBuilder> enumTypeBuilder_;
      
      private void ensureEnumTypeIsMutable()
      {
        if ((this.bitField0_ & 0x40) != 64)
        {
          this.enumType_ = new ArrayList(this.enumType_);
          this.bitField0_ |= 0x40;
        }
      }
      
      public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList()
      {
        if (this.enumTypeBuilder_ == null) {
          return Collections.unmodifiableList(this.enumType_);
        }
        return this.enumTypeBuilder_.getMessageList();
      }
      
      public int getEnumTypeCount()
      {
        if (this.enumTypeBuilder_ == null) {
          return this.enumType_.size();
        }
        return this.enumTypeBuilder_.getCount();
      }
      
      public DescriptorProtos.EnumDescriptorProto getEnumType(int index)
      {
        if (this.enumTypeBuilder_ == null) {
          return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
        }
        return (DescriptorProtos.EnumDescriptorProto)this.enumTypeBuilder_.getMessage(index);
      }
      
      public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto value)
      {
        if (this.enumTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureEnumTypeIsMutable();
          this.enumType_.set(index, value);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto.Builder builderForValue)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addEnumType(DescriptorProtos.EnumDescriptorProto value)
      {
        if (this.enumTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureEnumTypeIsMutable();
          this.enumType_.add(value);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addEnumType(int index, DescriptorProtos.EnumDescriptorProto value)
      {
        if (this.enumTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureEnumTypeIsMutable();
          this.enumType_.add(index, value);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addEnumType(DescriptorProtos.EnumDescriptorProto.Builder builderForValue)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addEnumType(int index, DescriptorProtos.EnumDescriptorProto.Builder builderForValue)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllEnumType(Iterable<? extends DescriptorProtos.EnumDescriptorProto> values)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          GeneratedMessage.Builder.addAll(values, this.enumType_);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearEnumType()
      {
        if (this.enumTypeBuilder_ == null)
        {
          this.enumType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFBF;
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeEnumType(int index)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.remove(index);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.EnumDescriptorProto.Builder getEnumTypeBuilder(int index)
      {
        return (DescriptorProtos.EnumDescriptorProto.Builder)getEnumTypeFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.EnumDescriptorProtoOrBuilder getEnumTypeOrBuilder(int index)
      {
        if (this.enumTypeBuilder_ == null) {
          return (DescriptorProtos.EnumDescriptorProtoOrBuilder)this.enumType_.get(index);
        }
        return (DescriptorProtos.EnumDescriptorProtoOrBuilder)this.enumTypeBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeOrBuilderList()
      {
        if (this.enumTypeBuilder_ != null) {
          return this.enumTypeBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.enumType_);
      }
      
      public DescriptorProtos.EnumDescriptorProto.Builder addEnumTypeBuilder()
      {
        return (DescriptorProtos.EnumDescriptorProto.Builder)getEnumTypeFieldBuilder().addBuilder(DescriptorProtos.EnumDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.EnumDescriptorProto.Builder addEnumTypeBuilder(int index)
      {
        return (DescriptorProtos.EnumDescriptorProto.Builder)getEnumTypeFieldBuilder().addBuilder(index, DescriptorProtos.EnumDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.EnumDescriptorProto.Builder> getEnumTypeBuilderList()
      {
        return getEnumTypeFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.EnumDescriptorProto, DescriptorProtos.EnumDescriptorProto.Builder, DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeFieldBuilder()
      {
        if (this.enumTypeBuilder_ == null)
        {
          this.enumTypeBuilder_ = new RepeatedFieldBuilder(this.enumType_, (this.bitField0_ & 0x40) == 64, getParentForChildren(), isClean());
          
          this.enumType_ = null;
        }
        return this.enumTypeBuilder_;
      }
      
      private List<DescriptorProtos.ServiceDescriptorProto> service_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.ServiceDescriptorProto, DescriptorProtos.ServiceDescriptorProto.Builder, DescriptorProtos.ServiceDescriptorProtoOrBuilder> serviceBuilder_;
      
      private void ensureServiceIsMutable()
      {
        if ((this.bitField0_ & 0x80) != 128)
        {
          this.service_ = new ArrayList(this.service_);
          this.bitField0_ |= 0x80;
        }
      }
      
      public List<DescriptorProtos.ServiceDescriptorProto> getServiceList()
      {
        if (this.serviceBuilder_ == null) {
          return Collections.unmodifiableList(this.service_);
        }
        return this.serviceBuilder_.getMessageList();
      }
      
      public int getServiceCount()
      {
        if (this.serviceBuilder_ == null) {
          return this.service_.size();
        }
        return this.serviceBuilder_.getCount();
      }
      
      public DescriptorProtos.ServiceDescriptorProto getService(int index)
      {
        if (this.serviceBuilder_ == null) {
          return (DescriptorProtos.ServiceDescriptorProto)this.service_.get(index);
        }
        return (DescriptorProtos.ServiceDescriptorProto)this.serviceBuilder_.getMessage(index);
      }
      
      public Builder setService(int index, DescriptorProtos.ServiceDescriptorProto value)
      {
        if (this.serviceBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureServiceIsMutable();
          this.service_.set(index, value);
          onChanged();
        }
        else
        {
          this.serviceBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setService(int index, DescriptorProtos.ServiceDescriptorProto.Builder builderForValue)
      {
        if (this.serviceBuilder_ == null)
        {
          ensureServiceIsMutable();
          this.service_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.serviceBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addService(DescriptorProtos.ServiceDescriptorProto value)
      {
        if (this.serviceBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureServiceIsMutable();
          this.service_.add(value);
          onChanged();
        }
        else
        {
          this.serviceBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addService(int index, DescriptorProtos.ServiceDescriptorProto value)
      {
        if (this.serviceBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureServiceIsMutable();
          this.service_.add(index, value);
          onChanged();
        }
        else
        {
          this.serviceBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addService(DescriptorProtos.ServiceDescriptorProto.Builder builderForValue)
      {
        if (this.serviceBuilder_ == null)
        {
          ensureServiceIsMutable();
          this.service_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.serviceBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addService(int index, DescriptorProtos.ServiceDescriptorProto.Builder builderForValue)
      {
        if (this.serviceBuilder_ == null)
        {
          ensureServiceIsMutable();
          this.service_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.serviceBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllService(Iterable<? extends DescriptorProtos.ServiceDescriptorProto> values)
      {
        if (this.serviceBuilder_ == null)
        {
          ensureServiceIsMutable();
          GeneratedMessage.Builder.addAll(values, this.service_);
          onChanged();
        }
        else
        {
          this.serviceBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearService()
      {
        if (this.serviceBuilder_ == null)
        {
          this.service_ = Collections.emptyList();
          this.bitField0_ &= 0xFF7F;
          onChanged();
        }
        else
        {
          this.serviceBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeService(int index)
      {
        if (this.serviceBuilder_ == null)
        {
          ensureServiceIsMutable();
          this.service_.remove(index);
          onChanged();
        }
        else
        {
          this.serviceBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.ServiceDescriptorProto.Builder getServiceBuilder(int index)
      {
        return (DescriptorProtos.ServiceDescriptorProto.Builder)getServiceFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.ServiceDescriptorProtoOrBuilder getServiceOrBuilder(int index)
      {
        if (this.serviceBuilder_ == null) {
          return (DescriptorProtos.ServiceDescriptorProtoOrBuilder)this.service_.get(index);
        }
        return (DescriptorProtos.ServiceDescriptorProtoOrBuilder)this.serviceBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.ServiceDescriptorProtoOrBuilder> getServiceOrBuilderList()
      {
        if (this.serviceBuilder_ != null) {
          return this.serviceBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.service_);
      }
      
      public DescriptorProtos.ServiceDescriptorProto.Builder addServiceBuilder()
      {
        return (DescriptorProtos.ServiceDescriptorProto.Builder)getServiceFieldBuilder().addBuilder(DescriptorProtos.ServiceDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.ServiceDescriptorProto.Builder addServiceBuilder(int index)
      {
        return (DescriptorProtos.ServiceDescriptorProto.Builder)getServiceFieldBuilder().addBuilder(index, DescriptorProtos.ServiceDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.ServiceDescriptorProto.Builder> getServiceBuilderList()
      {
        return getServiceFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.ServiceDescriptorProto, DescriptorProtos.ServiceDescriptorProto.Builder, DescriptorProtos.ServiceDescriptorProtoOrBuilder> getServiceFieldBuilder()
      {
        if (this.serviceBuilder_ == null)
        {
          this.serviceBuilder_ = new RepeatedFieldBuilder(this.service_, (this.bitField0_ & 0x80) == 128, getParentForChildren(), isClean());
          
          this.service_ = null;
        }
        return this.serviceBuilder_;
      }
      
      private List<DescriptorProtos.FieldDescriptorProto> extension_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.FieldDescriptorProto, DescriptorProtos.FieldDescriptorProto.Builder, DescriptorProtos.FieldDescriptorProtoOrBuilder> extensionBuilder_;
      
      private void ensureExtensionIsMutable()
      {
        if ((this.bitField0_ & 0x100) != 256)
        {
          this.extension_ = new ArrayList(this.extension_);
          this.bitField0_ |= 0x100;
        }
      }
      
      public List<DescriptorProtos.FieldDescriptorProto> getExtensionList()
      {
        if (this.extensionBuilder_ == null) {
          return Collections.unmodifiableList(this.extension_);
        }
        return this.extensionBuilder_.getMessageList();
      }
      
      public int getExtensionCount()
      {
        if (this.extensionBuilder_ == null) {
          return this.extension_.size();
        }
        return this.extensionBuilder_.getCount();
      }
      
      public DescriptorProtos.FieldDescriptorProto getExtension(int index)
      {
        if (this.extensionBuilder_ == null) {
          return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
        }
        return (DescriptorProtos.FieldDescriptorProto)this.extensionBuilder_.getMessage(index);
      }
      
      public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.extensionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionIsMutable();
          this.extension_.set(index, value);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addExtension(DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.extensionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionIsMutable();
          this.extension_.add(value);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addExtension(int index, DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.extensionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionIsMutable();
          this.extension_.add(index, value);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addExtension(DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addExtension(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllExtension(Iterable<? extends DescriptorProtos.FieldDescriptorProto> values)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          GeneratedMessage.Builder.addAll(values, this.extension_);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearExtension()
      {
        if (this.extensionBuilder_ == null)
        {
          this.extension_ = Collections.emptyList();
          this.bitField0_ &= 0xFEFF;
          onChanged();
        }
        else
        {
          this.extensionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeExtension(int index)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.remove(index);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder getExtensionBuilder(int index)
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getExtensionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.FieldDescriptorProtoOrBuilder getExtensionOrBuilder(int index)
      {
        if (this.extensionBuilder_ == null) {
          return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.extension_.get(index);
        }
        return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.extensionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionOrBuilderList()
      {
        if (this.extensionBuilder_ != null) {
          return this.extensionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.extension_);
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder addExtensionBuilder()
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getExtensionFieldBuilder().addBuilder(DescriptorProtos.FieldDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder addExtensionBuilder(int index)
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getExtensionFieldBuilder().addBuilder(index, DescriptorProtos.FieldDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.FieldDescriptorProto.Builder> getExtensionBuilderList()
      {
        return getExtensionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.FieldDescriptorProto, DescriptorProtos.FieldDescriptorProto.Builder, DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionFieldBuilder()
      {
        if (this.extensionBuilder_ == null)
        {
          this.extensionBuilder_ = new RepeatedFieldBuilder(this.extension_, (this.bitField0_ & 0x100) == 256, getParentForChildren(), isClean());
          
          this.extension_ = null;
        }
        return this.extensionBuilder_;
      }
      
      private DescriptorProtos.FileOptions options_ = DescriptorProtos.FileOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.FileOptions, DescriptorProtos.FileOptions.Builder, DescriptorProtos.FileOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x200) == 512;
      }
      
      public DescriptorProtos.FileOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.FileOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.FileOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x200;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.FileOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x200;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.FileOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x200) == 512) && (this.options_ != DescriptorProtos.FileOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.FileOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x200;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.FileOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFDFF;
        return this;
      }
      
      public DescriptorProtos.FileOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x200;
        onChanged();
        return (DescriptorProtos.FileOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.FileOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.FileOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.FileOptions, DescriptorProtos.FileOptions.Builder, DescriptorProtos.FileOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
      
      private DescriptorProtos.SourceCodeInfo sourceCodeInfo_ = DescriptorProtos.SourceCodeInfo.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.SourceCodeInfo, DescriptorProtos.SourceCodeInfo.Builder, DescriptorProtos.SourceCodeInfoOrBuilder> sourceCodeInfoBuilder_;
      
      public boolean hasSourceCodeInfo()
      {
        return (this.bitField0_ & 0x400) == 1024;
      }
      
      public DescriptorProtos.SourceCodeInfo getSourceCodeInfo()
      {
        if (this.sourceCodeInfoBuilder_ == null) {
          return this.sourceCodeInfo_;
        }
        return (DescriptorProtos.SourceCodeInfo)this.sourceCodeInfoBuilder_.getMessage();
      }
      
      public Builder setSourceCodeInfo(DescriptorProtos.SourceCodeInfo value)
      {
        if (this.sourceCodeInfoBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.sourceCodeInfo_ = value;
          onChanged();
        }
        else
        {
          this.sourceCodeInfoBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x400;
        return this;
      }
      
      public Builder setSourceCodeInfo(DescriptorProtos.SourceCodeInfo.Builder builderForValue)
      {
        if (this.sourceCodeInfoBuilder_ == null)
        {
          this.sourceCodeInfo_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.sourceCodeInfoBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x400;
        return this;
      }
      
      public Builder mergeSourceCodeInfo(DescriptorProtos.SourceCodeInfo value)
      {
        if (this.sourceCodeInfoBuilder_ == null)
        {
          if (((this.bitField0_ & 0x400) == 1024) && (this.sourceCodeInfo_ != DescriptorProtos.SourceCodeInfo.getDefaultInstance())) {
            this.sourceCodeInfo_ = DescriptorProtos.SourceCodeInfo.newBuilder(this.sourceCodeInfo_).mergeFrom(value).buildPartial();
          } else {
            this.sourceCodeInfo_ = value;
          }
          onChanged();
        }
        else
        {
          this.sourceCodeInfoBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x400;
        return this;
      }
      
      public Builder clearSourceCodeInfo()
      {
        if (this.sourceCodeInfoBuilder_ == null)
        {
          this.sourceCodeInfo_ = DescriptorProtos.SourceCodeInfo.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.sourceCodeInfoBuilder_.clear();
        }
        this.bitField0_ &= 0xFBFF;
        return this;
      }
      
      public DescriptorProtos.SourceCodeInfo.Builder getSourceCodeInfoBuilder()
      {
        this.bitField0_ |= 0x400;
        onChanged();
        return (DescriptorProtos.SourceCodeInfo.Builder)getSourceCodeInfoFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.SourceCodeInfoOrBuilder getSourceCodeInfoOrBuilder()
      {
        if (this.sourceCodeInfoBuilder_ != null) {
          return (DescriptorProtos.SourceCodeInfoOrBuilder)this.sourceCodeInfoBuilder_.getMessageOrBuilder();
        }
        return this.sourceCodeInfo_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.SourceCodeInfo, DescriptorProtos.SourceCodeInfo.Builder, DescriptorProtos.SourceCodeInfoOrBuilder> getSourceCodeInfoFieldBuilder()
      {
        if (this.sourceCodeInfoBuilder_ == null)
        {
          this.sourceCodeInfoBuilder_ = new SingleFieldBuilder(this.sourceCodeInfo_, getParentForChildren(), isClean());
          
          this.sourceCodeInfo_ = null;
        }
        return this.sourceCodeInfoBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new FileDescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface DescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract List<DescriptorProtos.FieldDescriptorProto> getFieldList();
    
    public abstract DescriptorProtos.FieldDescriptorProto getField(int paramInt);
    
    public abstract int getFieldCount();
    
    public abstract List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getFieldOrBuilderList();
    
    public abstract DescriptorProtos.FieldDescriptorProtoOrBuilder getFieldOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.FieldDescriptorProto> getExtensionList();
    
    public abstract DescriptorProtos.FieldDescriptorProto getExtension(int paramInt);
    
    public abstract int getExtensionCount();
    
    public abstract List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionOrBuilderList();
    
    public abstract DescriptorProtos.FieldDescriptorProtoOrBuilder getExtensionOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.DescriptorProto> getNestedTypeList();
    
    public abstract DescriptorProtos.DescriptorProto getNestedType(int paramInt);
    
    public abstract int getNestedTypeCount();
    
    public abstract List<? extends DescriptorProtoOrBuilder> getNestedTypeOrBuilderList();
    
    public abstract DescriptorProtoOrBuilder getNestedTypeOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList();
    
    public abstract DescriptorProtos.EnumDescriptorProto getEnumType(int paramInt);
    
    public abstract int getEnumTypeCount();
    
    public abstract List<? extends DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeOrBuilderList();
    
    public abstract DescriptorProtos.EnumDescriptorProtoOrBuilder getEnumTypeOrBuilder(int paramInt);
    
    public abstract List<DescriptorProtos.DescriptorProto.ExtensionRange> getExtensionRangeList();
    
    public abstract DescriptorProtos.DescriptorProto.ExtensionRange getExtensionRange(int paramInt);
    
    public abstract int getExtensionRangeCount();
    
    public abstract List<? extends DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder> getExtensionRangeOrBuilderList();
    
    public abstract DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder getExtensionRangeOrBuilder(int paramInt);
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.MessageOptions getOptions();
    
    public abstract DescriptorProtos.MessageOptionsOrBuilder getOptionsOrBuilder();
  }
  
  public static final class DescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.DescriptorProtoOrBuilder
  {
    private static final DescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private DescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private DescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static DescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public DescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private DescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 18: 
            if ((mutable_bitField0_ & 0x2) != 2)
            {
              this.field_ = new ArrayList();
              mutable_bitField0_ |= 0x2;
            }
            this.field_.add(input.readMessage(DescriptorProtos.FieldDescriptorProto.PARSER, extensionRegistry));
            break;
          case 26: 
            if ((mutable_bitField0_ & 0x8) != 8)
            {
              this.nestedType_ = new ArrayList();
              mutable_bitField0_ |= 0x8;
            }
            this.nestedType_.add(input.readMessage(PARSER, extensionRegistry));
            break;
          case 34: 
            if ((mutable_bitField0_ & 0x10) != 16)
            {
              this.enumType_ = new ArrayList();
              mutable_bitField0_ |= 0x10;
            }
            this.enumType_.add(input.readMessage(DescriptorProtos.EnumDescriptorProto.PARSER, extensionRegistry));
            break;
          case 42: 
            if ((mutable_bitField0_ & 0x20) != 32)
            {
              this.extensionRange_ = new ArrayList();
              mutable_bitField0_ |= 0x20;
            }
            this.extensionRange_.add(input.readMessage(ExtensionRange.PARSER, extensionRegistry));
            break;
          case 50: 
            if ((mutable_bitField0_ & 0x4) != 4)
            {
              this.extension_ = new ArrayList();
              mutable_bitField0_ |= 0x4;
            }
            this.extension_.add(input.readMessage(DescriptorProtos.FieldDescriptorProto.PARSER, extensionRegistry));
            break;
          case 58: 
            DescriptorProtos.MessageOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x2) == 2) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.MessageOptions)input.readMessage(DescriptorProtos.MessageOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x2;
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x2) == 2) {
          this.field_ = Collections.unmodifiableList(this.field_);
        }
        if ((mutable_bitField0_ & 0x8) == 8) {
          this.nestedType_ = Collections.unmodifiableList(this.nestedType_);
        }
        if ((mutable_bitField0_ & 0x10) == 16) {
          this.enumType_ = Collections.unmodifiableList(this.enumType_);
        }
        if ((mutable_bitField0_ & 0x20) == 32) {
          this.extensionRange_ = Collections.unmodifiableList(this.extensionRange_);
        }
        if ((mutable_bitField0_ & 0x4) == 4) {
          this.extension_ = Collections.unmodifiableList(this.extension_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProto.class, Builder.class);
    }
    
    public static Parser<DescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.DescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.DescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int FIELD_FIELD_NUMBER = 2;
    private List<DescriptorProtos.FieldDescriptorProto> field_;
    public static final int EXTENSION_FIELD_NUMBER = 6;
    private List<DescriptorProtos.FieldDescriptorProto> extension_;
    public static final int NESTED_TYPE_FIELD_NUMBER = 3;
    private List<DescriptorProto> nestedType_;
    public static final int ENUM_TYPE_FIELD_NUMBER = 4;
    private List<DescriptorProtos.EnumDescriptorProto> enumType_;
    public static final int EXTENSION_RANGE_FIELD_NUMBER = 5;
    private List<ExtensionRange> extensionRange_;
    public static final int OPTIONS_FIELD_NUMBER = 7;
    private DescriptorProtos.MessageOptions options_;
    
    public Parser<DescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public static abstract interface ExtensionRangeOrBuilder
      extends MessageOrBuilder
    {
      public abstract boolean hasStart();
      
      public abstract int getStart();
      
      public abstract boolean hasEnd();
      
      public abstract int getEnd();
    }
    
    public static final class ExtensionRange
      extends GeneratedMessage
      implements DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder
    {
      private static final ExtensionRange defaultInstance;
      private final UnknownFieldSet unknownFields;
      
      private ExtensionRange(GeneratedMessage.Builder<?> builder)
      {
        super();
        this.unknownFields = builder.getUnknownFields();
      }
      
      private ExtensionRange(boolean noInit)
      {
        this.unknownFields = UnknownFieldSet.getDefaultInstance();
      }
      
      public static ExtensionRange getDefaultInstance()
      {
        return defaultInstance;
      }
      
      public ExtensionRange getDefaultInstanceForType()
      {
        return defaultInstance;
      }
      
      public final UnknownFieldSet getUnknownFields()
      {
        return this.unknownFields;
      }
      
      private ExtensionRange(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        initFields();
        int mutable_bitField0_ = 0;
        UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
        try
        {
          boolean done = false;
          while (!done)
          {
            int tag = input.readTag();
            switch (tag)
            {
            case 0: 
              done = true;
              break;
            default: 
              if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
                done = true;
              }
              break;
            case 8: 
              this.bitField0_ |= 0x1;
              this.start_ = input.readInt32();
              break;
            case 16: 
              this.bitField0_ |= 0x2;
              this.end_ = input.readInt32();
            }
          }
        }
        catch (InvalidProtocolBufferException e)
        {
          throw e.setUnfinishedMessage(this);
        }
        catch (IOException e)
        {
          throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
        }
        finally
        {
          this.unknownFields = unknownFields.build();
          makeExtensionsImmutable();
        }
      }
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_ExtensionRange_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_ExtensionRange_fieldAccessorTable.ensureFieldAccessorsInitialized(ExtensionRange.class, Builder.class);
      }
      
      public static Parser<ExtensionRange> PARSER = new AbstractParser()
      {
        public DescriptorProtos.DescriptorProto.ExtensionRange parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
          throws InvalidProtocolBufferException
        {
          return new DescriptorProtos.DescriptorProto.ExtensionRange(input, extensionRegistry, null);
        }
      };
      private int bitField0_;
      public static final int START_FIELD_NUMBER = 1;
      private int start_;
      public static final int END_FIELD_NUMBER = 2;
      private int end_;
      
      public Parser<ExtensionRange> getParserForType()
      {
        return PARSER;
      }
      
      public boolean hasStart()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public int getStart()
      {
        return this.start_;
      }
      
      public boolean hasEnd()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public int getEnd()
      {
        return this.end_;
      }
      
      private void initFields()
      {
        this.start_ = 0;
        this.end_ = 0;
      }
      
      private byte memoizedIsInitialized = -1;
      
      public final boolean isInitialized()
      {
        byte isInitialized = this.memoizedIsInitialized;
        if (isInitialized != -1) {
          return isInitialized == 1;
        }
        this.memoizedIsInitialized = 1;
        return true;
      }
      
      public void writeTo(CodedOutputStream output)
        throws IOException
      {
        getSerializedSize();
        if ((this.bitField0_ & 0x1) == 1) {
          output.writeInt32(1, this.start_);
        }
        if ((this.bitField0_ & 0x2) == 2) {
          output.writeInt32(2, this.end_);
        }
        getUnknownFields().writeTo(output);
      }
      
      private int memoizedSerializedSize = -1;
      private static final long serialVersionUID = 0L;
      
      public int getSerializedSize()
      {
        int size = this.memoizedSerializedSize;
        if (size != -1) {
          return size;
        }
        size = 0;
        if ((this.bitField0_ & 0x1) == 1) {
          size += CodedOutputStream.computeInt32Size(1, this.start_);
        }
        if ((this.bitField0_ & 0x2) == 2) {
          size += CodedOutputStream.computeInt32Size(2, this.end_);
        }
        size += getUnknownFields().getSerializedSize();
        this.memoizedSerializedSize = size;
        return size;
      }
      
      protected Object writeReplace()
        throws ObjectStreamException
      {
        return super.writeReplace();
      }
      
      public static ExtensionRange parseFrom(ByteString data)
        throws InvalidProtocolBufferException
      {
        return (ExtensionRange)PARSER.parseFrom(data);
      }
      
      public static ExtensionRange parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return (ExtensionRange)PARSER.parseFrom(data, extensionRegistry);
      }
      
      public static ExtensionRange parseFrom(byte[] data)
        throws InvalidProtocolBufferException
      {
        return (ExtensionRange)PARSER.parseFrom(data);
      }
      
      public static ExtensionRange parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return (ExtensionRange)PARSER.parseFrom(data, extensionRegistry);
      }
      
      public static ExtensionRange parseFrom(InputStream input)
        throws IOException
      {
        return (ExtensionRange)PARSER.parseFrom(input);
      }
      
      public static ExtensionRange parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (ExtensionRange)PARSER.parseFrom(input, extensionRegistry);
      }
      
      public static ExtensionRange parseDelimitedFrom(InputStream input)
        throws IOException
      {
        return (ExtensionRange)PARSER.parseDelimitedFrom(input);
      }
      
      public static ExtensionRange parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (ExtensionRange)PARSER.parseDelimitedFrom(input, extensionRegistry);
      }
      
      public static ExtensionRange parseFrom(CodedInputStream input)
        throws IOException
      {
        return (ExtensionRange)PARSER.parseFrom(input);
      }
      
      public static ExtensionRange parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (ExtensionRange)PARSER.parseFrom(input, extensionRegistry);
      }
      
      public static Builder newBuilder()
      {
        return Builder.access$3100();
      }
      
      public Builder newBuilderForType()
      {
        return newBuilder();
      }
      
      public static Builder newBuilder(ExtensionRange prototype)
      {
        return newBuilder().mergeFrom(prototype);
      }
      
      public Builder toBuilder()
      {
        return newBuilder(this);
      }
      
      protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
      {
        Builder builder = new Builder(parent, null);
        return builder;
      }
      
      public static final class Builder
        extends GeneratedMessage.Builder<Builder>
        implements DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder
      {
        private int bitField0_;
        private int start_;
        private int end_;
        
        public static final Descriptors.Descriptor getDescriptor()
        {
          return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_ExtensionRange_descriptor;
        }
        
        protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
        {
          return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_ExtensionRange_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.DescriptorProto.ExtensionRange.class, Builder.class);
        }
        
        private Builder()
        {
          maybeForceBuilderInitialization();
        }
        
        private Builder(GeneratedMessage.BuilderParent parent)
        {
          super();
          maybeForceBuilderInitialization();
        }
        
        private void maybeForceBuilderInitialization()
        {
          if (GeneratedMessage.alwaysUseFieldBuilders) {}
        }
        
        private static Builder create()
        {
          return new Builder();
        }
        
        public Builder clear()
        {
          super.clear();
          this.start_ = 0;
          this.bitField0_ &= 0xFFFFFFFE;
          this.end_ = 0;
          this.bitField0_ &= 0xFFFFFFFD;
          return this;
        }
        
        public Builder clone()
        {
          return create().mergeFrom(buildPartial());
        }
        
        public Descriptors.Descriptor getDescriptorForType()
        {
          return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_ExtensionRange_descriptor;
        }
        
        public DescriptorProtos.DescriptorProto.ExtensionRange getDefaultInstanceForType()
        {
          return DescriptorProtos.DescriptorProto.ExtensionRange.getDefaultInstance();
        }
        
        public DescriptorProtos.DescriptorProto.ExtensionRange build()
        {
          DescriptorProtos.DescriptorProto.ExtensionRange result = buildPartial();
          if (!result.isInitialized()) {
            throw newUninitializedMessageException(result);
          }
          return result;
        }
        
        public DescriptorProtos.DescriptorProto.ExtensionRange buildPartial()
        {
          DescriptorProtos.DescriptorProto.ExtensionRange result = new DescriptorProtos.DescriptorProto.ExtensionRange(this, null);
          int from_bitField0_ = this.bitField0_;
          int to_bitField0_ = 0;
          if ((from_bitField0_ & 0x1) == 1) {
            to_bitField0_ |= 0x1;
          }
          result.start_ = this.start_;
          if ((from_bitField0_ & 0x2) == 2) {
            to_bitField0_ |= 0x2;
          }
          result.end_ = this.end_;
          result.bitField0_ = to_bitField0_;
          onBuilt();
          return result;
        }
        
        public Builder mergeFrom(Message other)
        {
          if ((other instanceof DescriptorProtos.DescriptorProto.ExtensionRange)) {
            return mergeFrom((DescriptorProtos.DescriptorProto.ExtensionRange)other);
          }
          super.mergeFrom(other);
          return this;
        }
        
        public Builder mergeFrom(DescriptorProtos.DescriptorProto.ExtensionRange other)
        {
          if (other == DescriptorProtos.DescriptorProto.ExtensionRange.getDefaultInstance()) {
            return this;
          }
          if (other.hasStart()) {
            setStart(other.getStart());
          }
          if (other.hasEnd()) {
            setEnd(other.getEnd());
          }
          mergeUnknownFields(other.getUnknownFields());
          return this;
        }
        
        public final boolean isInitialized()
        {
          return true;
        }
        
        public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
          throws IOException
        {
          DescriptorProtos.DescriptorProto.ExtensionRange parsedMessage = null;
          try
          {
            parsedMessage = (DescriptorProtos.DescriptorProto.ExtensionRange)DescriptorProtos.DescriptorProto.ExtensionRange.PARSER.parsePartialFrom(input, extensionRegistry);
          }
          catch (InvalidProtocolBufferException e)
          {
            parsedMessage = (DescriptorProtos.DescriptorProto.ExtensionRange)e.getUnfinishedMessage();
            throw e;
          }
          finally
          {
            if (parsedMessage != null) {
              mergeFrom(parsedMessage);
            }
          }
          return this;
        }
        
        public boolean hasStart()
        {
          return (this.bitField0_ & 0x1) == 1;
        }
        
        public int getStart()
        {
          return this.start_;
        }
        
        public Builder setStart(int value)
        {
          this.bitField0_ |= 0x1;
          this.start_ = value;
          onChanged();
          return this;
        }
        
        public Builder clearStart()
        {
          this.bitField0_ &= 0xFFFFFFFE;
          this.start_ = 0;
          onChanged();
          return this;
        }
        
        public boolean hasEnd()
        {
          return (this.bitField0_ & 0x2) == 2;
        }
        
        public int getEnd()
        {
          return this.end_;
        }
        
        public Builder setEnd(int value)
        {
          this.bitField0_ |= 0x2;
          this.end_ = value;
          onChanged();
          return this;
        }
        
        public Builder clearEnd()
        {
          this.bitField0_ &= 0xFFFFFFFD;
          this.end_ = 0;
          onChanged();
          return this;
        }
      }
      
      static
      {
        defaultInstance = new ExtensionRange(true);
        defaultInstance.initFields();
      }
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public List<DescriptorProtos.FieldDescriptorProto> getFieldList()
    {
      return this.field_;
    }
    
    public List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getFieldOrBuilderList()
    {
      return this.field_;
    }
    
    public int getFieldCount()
    {
      return this.field_.size();
    }
    
    public DescriptorProtos.FieldDescriptorProto getField(int index)
    {
      return (DescriptorProtos.FieldDescriptorProto)this.field_.get(index);
    }
    
    public DescriptorProtos.FieldDescriptorProtoOrBuilder getFieldOrBuilder(int index)
    {
      return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.field_.get(index);
    }
    
    public List<DescriptorProtos.FieldDescriptorProto> getExtensionList()
    {
      return this.extension_;
    }
    
    public List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionOrBuilderList()
    {
      return this.extension_;
    }
    
    public int getExtensionCount()
    {
      return this.extension_.size();
    }
    
    public DescriptorProtos.FieldDescriptorProto getExtension(int index)
    {
      return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
    }
    
    public DescriptorProtos.FieldDescriptorProtoOrBuilder getExtensionOrBuilder(int index)
    {
      return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.extension_.get(index);
    }
    
    public List<DescriptorProto> getNestedTypeList()
    {
      return this.nestedType_;
    }
    
    public List<? extends DescriptorProtos.DescriptorProtoOrBuilder> getNestedTypeOrBuilderList()
    {
      return this.nestedType_;
    }
    
    public int getNestedTypeCount()
    {
      return this.nestedType_.size();
    }
    
    public DescriptorProto getNestedType(int index)
    {
      return (DescriptorProto)this.nestedType_.get(index);
    }
    
    public DescriptorProtos.DescriptorProtoOrBuilder getNestedTypeOrBuilder(int index)
    {
      return (DescriptorProtos.DescriptorProtoOrBuilder)this.nestedType_.get(index);
    }
    
    public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList()
    {
      return this.enumType_;
    }
    
    public List<? extends DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeOrBuilderList()
    {
      return this.enumType_;
    }
    
    public int getEnumTypeCount()
    {
      return this.enumType_.size();
    }
    
    public DescriptorProtos.EnumDescriptorProto getEnumType(int index)
    {
      return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
    }
    
    public DescriptorProtos.EnumDescriptorProtoOrBuilder getEnumTypeOrBuilder(int index)
    {
      return (DescriptorProtos.EnumDescriptorProtoOrBuilder)this.enumType_.get(index);
    }
    
    public List<ExtensionRange> getExtensionRangeList()
    {
      return this.extensionRange_;
    }
    
    public List<? extends ExtensionRangeOrBuilder> getExtensionRangeOrBuilderList()
    {
      return this.extensionRange_;
    }
    
    public int getExtensionRangeCount()
    {
      return this.extensionRange_.size();
    }
    
    public ExtensionRange getExtensionRange(int index)
    {
      return (ExtensionRange)this.extensionRange_.get(index);
    }
    
    public ExtensionRangeOrBuilder getExtensionRangeOrBuilder(int index)
    {
      return (ExtensionRangeOrBuilder)this.extensionRange_.get(index);
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public DescriptorProtos.MessageOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.MessageOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.field_ = Collections.emptyList();
      this.extension_ = Collections.emptyList();
      this.nestedType_ = Collections.emptyList();
      this.enumType_ = Collections.emptyList();
      this.extensionRange_ = Collections.emptyList();
      this.options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getFieldCount(); i++) {
        if (!getField(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      for (int i = 0; i < getExtensionCount(); i++) {
        if (!getExtension(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      for (int i = 0; i < getNestedTypeCount(); i++) {
        if (!getNestedType(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      for (int i = 0; i < getEnumTypeCount(); i++) {
        if (!getEnumType(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      for (int i = 0; i < this.field_.size(); i++) {
        output.writeMessage(2, (MessageLite)this.field_.get(i));
      }
      for (int i = 0; i < this.nestedType_.size(); i++) {
        output.writeMessage(3, (MessageLite)this.nestedType_.get(i));
      }
      for (int i = 0; i < this.enumType_.size(); i++) {
        output.writeMessage(4, (MessageLite)this.enumType_.get(i));
      }
      for (int i = 0; i < this.extensionRange_.size(); i++) {
        output.writeMessage(5, (MessageLite)this.extensionRange_.get(i));
      }
      for (int i = 0; i < this.extension_.size(); i++) {
        output.writeMessage(6, (MessageLite)this.extension_.get(i));
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeMessage(7, this.options_);
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      for (int i = 0; i < this.field_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(2, (MessageLite)this.field_.get(i));
      }
      for (int i = 0; i < this.nestedType_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(3, (MessageLite)this.nestedType_.get(i));
      }
      for (int i = 0; i < this.enumType_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(4, (MessageLite)this.enumType_.get(i));
      }
      for (int i = 0; i < this.extensionRange_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(5, (MessageLite)this.extensionRange_.get(i));
      }
      for (int i = 0; i < this.extension_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(6, (MessageLite)this.extension_.get(i));
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeMessageSize(7, this.options_);
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static DescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (DescriptorProto)PARSER.parseFrom(data);
    }
    
    public static DescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (DescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static DescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (DescriptorProto)PARSER.parseFrom(data);
    }
    
    public static DescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (DescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static DescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (DescriptorProto)PARSER.parseFrom(input);
    }
    
    public static DescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (DescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static DescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (DescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static DescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (DescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static DescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (DescriptorProto)PARSER.parseFrom(input);
    }
    
    public static DescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (DescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$3700();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(DescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.DescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.DescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders)
        {
          getFieldFieldBuilder();
          getExtensionFieldBuilder();
          getNestedTypeFieldBuilder();
          getEnumTypeFieldBuilder();
          getExtensionRangeFieldBuilder();
          getOptionsFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        if (this.fieldBuilder_ == null)
        {
          this.field_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
        }
        else
        {
          this.fieldBuilder_.clear();
        }
        if (this.extensionBuilder_ == null)
        {
          this.extension_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFB;
        }
        else
        {
          this.extensionBuilder_.clear();
        }
        if (this.nestedTypeBuilder_ == null)
        {
          this.nestedType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFF7;
        }
        else
        {
          this.nestedTypeBuilder_.clear();
        }
        if (this.enumTypeBuilder_ == null)
        {
          this.enumType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFEF;
        }
        else
        {
          this.enumTypeBuilder_.clear();
        }
        if (this.extensionRangeBuilder_ == null)
        {
          this.extensionRange_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFDF;
        }
        else
        {
          this.extensionRangeBuilder_.clear();
        }
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFBF;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_DescriptorProto_descriptor;
      }
      
      public DescriptorProtos.DescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.DescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.DescriptorProto build()
      {
        DescriptorProtos.DescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.DescriptorProto buildPartial()
      {
        DescriptorProtos.DescriptorProto result = new DescriptorProtos.DescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if (this.fieldBuilder_ == null)
        {
          if ((this.bitField0_ & 0x2) == 2)
          {
            this.field_ = Collections.unmodifiableList(this.field_);
            this.bitField0_ &= 0xFFFFFFFD;
          }
          result.field_ = this.field_;
        }
        else
        {
          result.field_ = this.fieldBuilder_.build();
        }
        if (this.extensionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x4) == 4)
          {
            this.extension_ = Collections.unmodifiableList(this.extension_);
            this.bitField0_ &= 0xFFFFFFFB;
          }
          result.extension_ = this.extension_;
        }
        else
        {
          result.extension_ = this.extensionBuilder_.build();
        }
        if (this.nestedTypeBuilder_ == null)
        {
          if ((this.bitField0_ & 0x8) == 8)
          {
            this.nestedType_ = Collections.unmodifiableList(this.nestedType_);
            this.bitField0_ &= 0xFFFFFFF7;
          }
          result.nestedType_ = this.nestedType_;
        }
        else
        {
          result.nestedType_ = this.nestedTypeBuilder_.build();
        }
        if (this.enumTypeBuilder_ == null)
        {
          if ((this.bitField0_ & 0x10) == 16)
          {
            this.enumType_ = Collections.unmodifiableList(this.enumType_);
            this.bitField0_ &= 0xFFFFFFEF;
          }
          result.enumType_ = this.enumType_;
        }
        else
        {
          result.enumType_ = this.enumTypeBuilder_.build();
        }
        if (this.extensionRangeBuilder_ == null)
        {
          if ((this.bitField0_ & 0x20) == 32)
          {
            this.extensionRange_ = Collections.unmodifiableList(this.extensionRange_);
            this.bitField0_ &= 0xFFFFFFDF;
          }
          result.extensionRange_ = this.extensionRange_;
        }
        else
        {
          result.extensionRange_ = this.extensionRangeBuilder_.build();
        }
        if ((from_bitField0_ & 0x40) == 64) {
          to_bitField0_ |= 0x2;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.MessageOptions)this.optionsBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.DescriptorProto)) {
          return mergeFrom((DescriptorProtos.DescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.DescriptorProto other)
      {
        if (other == DescriptorProtos.DescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (this.fieldBuilder_ == null)
        {
          if (!other.field_.isEmpty())
          {
            if (this.field_.isEmpty())
            {
              this.field_ = other.field_;
              this.bitField0_ &= 0xFFFFFFFD;
            }
            else
            {
              ensureFieldIsMutable();
              this.field_.addAll(other.field_);
            }
            onChanged();
          }
        }
        else if (!other.field_.isEmpty()) {
          if (this.fieldBuilder_.isEmpty())
          {
            this.fieldBuilder_.dispose();
            this.fieldBuilder_ = null;
            this.field_ = other.field_;
            this.bitField0_ &= 0xFFFFFFFD;
            this.fieldBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getFieldFieldBuilder() : null);
          }
          else
          {
            this.fieldBuilder_.addAllMessages(other.field_);
          }
        }
        if (this.extensionBuilder_ == null)
        {
          if (!other.extension_.isEmpty())
          {
            if (this.extension_.isEmpty())
            {
              this.extension_ = other.extension_;
              this.bitField0_ &= 0xFFFFFFFB;
            }
            else
            {
              ensureExtensionIsMutable();
              this.extension_.addAll(other.extension_);
            }
            onChanged();
          }
        }
        else if (!other.extension_.isEmpty()) {
          if (this.extensionBuilder_.isEmpty())
          {
            this.extensionBuilder_.dispose();
            this.extensionBuilder_ = null;
            this.extension_ = other.extension_;
            this.bitField0_ &= 0xFFFFFFFB;
            this.extensionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getExtensionFieldBuilder() : null);
          }
          else
          {
            this.extensionBuilder_.addAllMessages(other.extension_);
          }
        }
        if (this.nestedTypeBuilder_ == null)
        {
          if (!other.nestedType_.isEmpty())
          {
            if (this.nestedType_.isEmpty())
            {
              this.nestedType_ = other.nestedType_;
              this.bitField0_ &= 0xFFFFFFF7;
            }
            else
            {
              ensureNestedTypeIsMutable();
              this.nestedType_.addAll(other.nestedType_);
            }
            onChanged();
          }
        }
        else if (!other.nestedType_.isEmpty()) {
          if (this.nestedTypeBuilder_.isEmpty())
          {
            this.nestedTypeBuilder_.dispose();
            this.nestedTypeBuilder_ = null;
            this.nestedType_ = other.nestedType_;
            this.bitField0_ &= 0xFFFFFFF7;
            this.nestedTypeBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getNestedTypeFieldBuilder() : null);
          }
          else
          {
            this.nestedTypeBuilder_.addAllMessages(other.nestedType_);
          }
        }
        if (this.enumTypeBuilder_ == null)
        {
          if (!other.enumType_.isEmpty())
          {
            if (this.enumType_.isEmpty())
            {
              this.enumType_ = other.enumType_;
              this.bitField0_ &= 0xFFFFFFEF;
            }
            else
            {
              ensureEnumTypeIsMutable();
              this.enumType_.addAll(other.enumType_);
            }
            onChanged();
          }
        }
        else if (!other.enumType_.isEmpty()) {
          if (this.enumTypeBuilder_.isEmpty())
          {
            this.enumTypeBuilder_.dispose();
            this.enumTypeBuilder_ = null;
            this.enumType_ = other.enumType_;
            this.bitField0_ &= 0xFFFFFFEF;
            this.enumTypeBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getEnumTypeFieldBuilder() : null);
          }
          else
          {
            this.enumTypeBuilder_.addAllMessages(other.enumType_);
          }
        }
        if (this.extensionRangeBuilder_ == null)
        {
          if (!other.extensionRange_.isEmpty())
          {
            if (this.extensionRange_.isEmpty())
            {
              this.extensionRange_ = other.extensionRange_;
              this.bitField0_ &= 0xFFFFFFDF;
            }
            else
            {
              ensureExtensionRangeIsMutable();
              this.extensionRange_.addAll(other.extensionRange_);
            }
            onChanged();
          }
        }
        else if (!other.extensionRange_.isEmpty()) {
          if (this.extensionRangeBuilder_.isEmpty())
          {
            this.extensionRangeBuilder_.dispose();
            this.extensionRangeBuilder_ = null;
            this.extensionRange_ = other.extensionRange_;
            this.bitField0_ &= 0xFFFFFFDF;
            this.extensionRangeBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getExtensionRangeFieldBuilder() : null);
          }
          else
          {
            this.extensionRangeBuilder_.addAllMessages(other.extensionRange_);
          }
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getFieldCount(); i++) {
          if (!getField(i).isInitialized()) {
            return false;
          }
        }
        for (int i = 0; i < getExtensionCount(); i++) {
          if (!getExtension(i).isInitialized()) {
            return false;
          }
        }
        for (int i = 0; i < getNestedTypeCount(); i++) {
          if (!getNestedType(i).isInitialized()) {
            return false;
          }
        }
        for (int i = 0; i < getEnumTypeCount(); i++) {
          if (!getEnumType(i).isInitialized()) {
            return false;
          }
        }
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.DescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.DescriptorProto)DescriptorProtos.DescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.DescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.DescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.FieldDescriptorProto> field_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.FieldDescriptorProto, DescriptorProtos.FieldDescriptorProto.Builder, DescriptorProtos.FieldDescriptorProtoOrBuilder> fieldBuilder_;
      
      private void ensureFieldIsMutable()
      {
        if ((this.bitField0_ & 0x2) != 2)
        {
          this.field_ = new ArrayList(this.field_);
          this.bitField0_ |= 0x2;
        }
      }
      
      public List<DescriptorProtos.FieldDescriptorProto> getFieldList()
      {
        if (this.fieldBuilder_ == null) {
          return Collections.unmodifiableList(this.field_);
        }
        return this.fieldBuilder_.getMessageList();
      }
      
      public int getFieldCount()
      {
        if (this.fieldBuilder_ == null) {
          return this.field_.size();
        }
        return this.fieldBuilder_.getCount();
      }
      
      public DescriptorProtos.FieldDescriptorProto getField(int index)
      {
        if (this.fieldBuilder_ == null) {
          return (DescriptorProtos.FieldDescriptorProto)this.field_.get(index);
        }
        return (DescriptorProtos.FieldDescriptorProto)this.fieldBuilder_.getMessage(index);
      }
      
      public Builder setField(int index, DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.fieldBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureFieldIsMutable();
          this.field_.set(index, value);
          onChanged();
        }
        else
        {
          this.fieldBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setField(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.fieldBuilder_ == null)
        {
          ensureFieldIsMutable();
          this.field_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.fieldBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addField(DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.fieldBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureFieldIsMutable();
          this.field_.add(value);
          onChanged();
        }
        else
        {
          this.fieldBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addField(int index, DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.fieldBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureFieldIsMutable();
          this.field_.add(index, value);
          onChanged();
        }
        else
        {
          this.fieldBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addField(DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.fieldBuilder_ == null)
        {
          ensureFieldIsMutable();
          this.field_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.fieldBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addField(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.fieldBuilder_ == null)
        {
          ensureFieldIsMutable();
          this.field_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.fieldBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllField(Iterable<? extends DescriptorProtos.FieldDescriptorProto> values)
      {
        if (this.fieldBuilder_ == null)
        {
          ensureFieldIsMutable();
          GeneratedMessage.Builder.addAll(values, this.field_);
          onChanged();
        }
        else
        {
          this.fieldBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearField()
      {
        if (this.fieldBuilder_ == null)
        {
          this.field_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
          onChanged();
        }
        else
        {
          this.fieldBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeField(int index)
      {
        if (this.fieldBuilder_ == null)
        {
          ensureFieldIsMutable();
          this.field_.remove(index);
          onChanged();
        }
        else
        {
          this.fieldBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder getFieldBuilder(int index)
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getFieldFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.FieldDescriptorProtoOrBuilder getFieldOrBuilder(int index)
      {
        if (this.fieldBuilder_ == null) {
          return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.field_.get(index);
        }
        return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.fieldBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getFieldOrBuilderList()
      {
        if (this.fieldBuilder_ != null) {
          return this.fieldBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.field_);
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder addFieldBuilder()
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getFieldFieldBuilder().addBuilder(DescriptorProtos.FieldDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder addFieldBuilder(int index)
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getFieldFieldBuilder().addBuilder(index, DescriptorProtos.FieldDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.FieldDescriptorProto.Builder> getFieldBuilderList()
      {
        return getFieldFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.FieldDescriptorProto, DescriptorProtos.FieldDescriptorProto.Builder, DescriptorProtos.FieldDescriptorProtoOrBuilder> getFieldFieldBuilder()
      {
        if (this.fieldBuilder_ == null)
        {
          this.fieldBuilder_ = new RepeatedFieldBuilder(this.field_, (this.bitField0_ & 0x2) == 2, getParentForChildren(), isClean());
          
          this.field_ = null;
        }
        return this.fieldBuilder_;
      }
      
      private List<DescriptorProtos.FieldDescriptorProto> extension_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.FieldDescriptorProto, DescriptorProtos.FieldDescriptorProto.Builder, DescriptorProtos.FieldDescriptorProtoOrBuilder> extensionBuilder_;
      
      private void ensureExtensionIsMutable()
      {
        if ((this.bitField0_ & 0x4) != 4)
        {
          this.extension_ = new ArrayList(this.extension_);
          this.bitField0_ |= 0x4;
        }
      }
      
      public List<DescriptorProtos.FieldDescriptorProto> getExtensionList()
      {
        if (this.extensionBuilder_ == null) {
          return Collections.unmodifiableList(this.extension_);
        }
        return this.extensionBuilder_.getMessageList();
      }
      
      public int getExtensionCount()
      {
        if (this.extensionBuilder_ == null) {
          return this.extension_.size();
        }
        return this.extensionBuilder_.getCount();
      }
      
      public DescriptorProtos.FieldDescriptorProto getExtension(int index)
      {
        if (this.extensionBuilder_ == null) {
          return (DescriptorProtos.FieldDescriptorProto)this.extension_.get(index);
        }
        return (DescriptorProtos.FieldDescriptorProto)this.extensionBuilder_.getMessage(index);
      }
      
      public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.extensionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionIsMutable();
          this.extension_.set(index, value);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setExtension(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addExtension(DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.extensionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionIsMutable();
          this.extension_.add(value);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addExtension(int index, DescriptorProtos.FieldDescriptorProto value)
      {
        if (this.extensionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionIsMutable();
          this.extension_.add(index, value);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addExtension(DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addExtension(int index, DescriptorProtos.FieldDescriptorProto.Builder builderForValue)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllExtension(Iterable<? extends DescriptorProtos.FieldDescriptorProto> values)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          GeneratedMessage.Builder.addAll(values, this.extension_);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearExtension()
      {
        if (this.extensionBuilder_ == null)
        {
          this.extension_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFB;
          onChanged();
        }
        else
        {
          this.extensionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeExtension(int index)
      {
        if (this.extensionBuilder_ == null)
        {
          ensureExtensionIsMutable();
          this.extension_.remove(index);
          onChanged();
        }
        else
        {
          this.extensionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder getExtensionBuilder(int index)
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getExtensionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.FieldDescriptorProtoOrBuilder getExtensionOrBuilder(int index)
      {
        if (this.extensionBuilder_ == null) {
          return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.extension_.get(index);
        }
        return (DescriptorProtos.FieldDescriptorProtoOrBuilder)this.extensionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionOrBuilderList()
      {
        if (this.extensionBuilder_ != null) {
          return this.extensionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.extension_);
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder addExtensionBuilder()
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getExtensionFieldBuilder().addBuilder(DescriptorProtos.FieldDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.FieldDescriptorProto.Builder addExtensionBuilder(int index)
      {
        return (DescriptorProtos.FieldDescriptorProto.Builder)getExtensionFieldBuilder().addBuilder(index, DescriptorProtos.FieldDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.FieldDescriptorProto.Builder> getExtensionBuilderList()
      {
        return getExtensionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.FieldDescriptorProto, DescriptorProtos.FieldDescriptorProto.Builder, DescriptorProtos.FieldDescriptorProtoOrBuilder> getExtensionFieldBuilder()
      {
        if (this.extensionBuilder_ == null)
        {
          this.extensionBuilder_ = new RepeatedFieldBuilder(this.extension_, (this.bitField0_ & 0x4) == 4, getParentForChildren(), isClean());
          
          this.extension_ = null;
        }
        return this.extensionBuilder_;
      }
      
      private List<DescriptorProtos.DescriptorProto> nestedType_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.DescriptorProto, Builder, DescriptorProtos.DescriptorProtoOrBuilder> nestedTypeBuilder_;
      
      private void ensureNestedTypeIsMutable()
      {
        if ((this.bitField0_ & 0x8) != 8)
        {
          this.nestedType_ = new ArrayList(this.nestedType_);
          this.bitField0_ |= 0x8;
        }
      }
      
      public List<DescriptorProtos.DescriptorProto> getNestedTypeList()
      {
        if (this.nestedTypeBuilder_ == null) {
          return Collections.unmodifiableList(this.nestedType_);
        }
        return this.nestedTypeBuilder_.getMessageList();
      }
      
      public int getNestedTypeCount()
      {
        if (this.nestedTypeBuilder_ == null) {
          return this.nestedType_.size();
        }
        return this.nestedTypeBuilder_.getCount();
      }
      
      public DescriptorProtos.DescriptorProto getNestedType(int index)
      {
        if (this.nestedTypeBuilder_ == null) {
          return (DescriptorProtos.DescriptorProto)this.nestedType_.get(index);
        }
        return (DescriptorProtos.DescriptorProto)this.nestedTypeBuilder_.getMessage(index);
      }
      
      public Builder setNestedType(int index, DescriptorProtos.DescriptorProto value)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureNestedTypeIsMutable();
          this.nestedType_.set(index, value);
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setNestedType(int index, Builder builderForValue)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          ensureNestedTypeIsMutable();
          this.nestedType_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addNestedType(DescriptorProtos.DescriptorProto value)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureNestedTypeIsMutable();
          this.nestedType_.add(value);
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addNestedType(int index, DescriptorProtos.DescriptorProto value)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureNestedTypeIsMutable();
          this.nestedType_.add(index, value);
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addNestedType(Builder builderForValue)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          ensureNestedTypeIsMutable();
          this.nestedType_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addNestedType(int index, Builder builderForValue)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          ensureNestedTypeIsMutable();
          this.nestedType_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllNestedType(Iterable<? extends DescriptorProtos.DescriptorProto> values)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          ensureNestedTypeIsMutable();
          GeneratedMessage.Builder.addAll(values, this.nestedType_);
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearNestedType()
      {
        if (this.nestedTypeBuilder_ == null)
        {
          this.nestedType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFF7;
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeNestedType(int index)
      {
        if (this.nestedTypeBuilder_ == null)
        {
          ensureNestedTypeIsMutable();
          this.nestedType_.remove(index);
          onChanged();
        }
        else
        {
          this.nestedTypeBuilder_.remove(index);
        }
        return this;
      }
      
      public Builder getNestedTypeBuilder(int index)
      {
        return (Builder)getNestedTypeFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.DescriptorProtoOrBuilder getNestedTypeOrBuilder(int index)
      {
        if (this.nestedTypeBuilder_ == null) {
          return (DescriptorProtos.DescriptorProtoOrBuilder)this.nestedType_.get(index);
        }
        return (DescriptorProtos.DescriptorProtoOrBuilder)this.nestedTypeBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.DescriptorProtoOrBuilder> getNestedTypeOrBuilderList()
      {
        if (this.nestedTypeBuilder_ != null) {
          return this.nestedTypeBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.nestedType_);
      }
      
      public Builder addNestedTypeBuilder()
      {
        return (Builder)getNestedTypeFieldBuilder().addBuilder(DescriptorProtos.DescriptorProto.getDefaultInstance());
      }
      
      public Builder addNestedTypeBuilder(int index)
      {
        return (Builder)getNestedTypeFieldBuilder().addBuilder(index, DescriptorProtos.DescriptorProto.getDefaultInstance());
      }
      
      public List<Builder> getNestedTypeBuilderList()
      {
        return getNestedTypeFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.DescriptorProto, Builder, DescriptorProtos.DescriptorProtoOrBuilder> getNestedTypeFieldBuilder()
      {
        if (this.nestedTypeBuilder_ == null)
        {
          this.nestedTypeBuilder_ = new RepeatedFieldBuilder(this.nestedType_, (this.bitField0_ & 0x8) == 8, getParentForChildren(), isClean());
          
          this.nestedType_ = null;
        }
        return this.nestedTypeBuilder_;
      }
      
      private List<DescriptorProtos.EnumDescriptorProto> enumType_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.EnumDescriptorProto, DescriptorProtos.EnumDescriptorProto.Builder, DescriptorProtos.EnumDescriptorProtoOrBuilder> enumTypeBuilder_;
      
      private void ensureEnumTypeIsMutable()
      {
        if ((this.bitField0_ & 0x10) != 16)
        {
          this.enumType_ = new ArrayList(this.enumType_);
          this.bitField0_ |= 0x10;
        }
      }
      
      public List<DescriptorProtos.EnumDescriptorProto> getEnumTypeList()
      {
        if (this.enumTypeBuilder_ == null) {
          return Collections.unmodifiableList(this.enumType_);
        }
        return this.enumTypeBuilder_.getMessageList();
      }
      
      public int getEnumTypeCount()
      {
        if (this.enumTypeBuilder_ == null) {
          return this.enumType_.size();
        }
        return this.enumTypeBuilder_.getCount();
      }
      
      public DescriptorProtos.EnumDescriptorProto getEnumType(int index)
      {
        if (this.enumTypeBuilder_ == null) {
          return (DescriptorProtos.EnumDescriptorProto)this.enumType_.get(index);
        }
        return (DescriptorProtos.EnumDescriptorProto)this.enumTypeBuilder_.getMessage(index);
      }
      
      public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto value)
      {
        if (this.enumTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureEnumTypeIsMutable();
          this.enumType_.set(index, value);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setEnumType(int index, DescriptorProtos.EnumDescriptorProto.Builder builderForValue)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addEnumType(DescriptorProtos.EnumDescriptorProto value)
      {
        if (this.enumTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureEnumTypeIsMutable();
          this.enumType_.add(value);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addEnumType(int index, DescriptorProtos.EnumDescriptorProto value)
      {
        if (this.enumTypeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureEnumTypeIsMutable();
          this.enumType_.add(index, value);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addEnumType(DescriptorProtos.EnumDescriptorProto.Builder builderForValue)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addEnumType(int index, DescriptorProtos.EnumDescriptorProto.Builder builderForValue)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllEnumType(Iterable<? extends DescriptorProtos.EnumDescriptorProto> values)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          GeneratedMessage.Builder.addAll(values, this.enumType_);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearEnumType()
      {
        if (this.enumTypeBuilder_ == null)
        {
          this.enumType_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFEF;
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeEnumType(int index)
      {
        if (this.enumTypeBuilder_ == null)
        {
          ensureEnumTypeIsMutable();
          this.enumType_.remove(index);
          onChanged();
        }
        else
        {
          this.enumTypeBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.EnumDescriptorProto.Builder getEnumTypeBuilder(int index)
      {
        return (DescriptorProtos.EnumDescriptorProto.Builder)getEnumTypeFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.EnumDescriptorProtoOrBuilder getEnumTypeOrBuilder(int index)
      {
        if (this.enumTypeBuilder_ == null) {
          return (DescriptorProtos.EnumDescriptorProtoOrBuilder)this.enumType_.get(index);
        }
        return (DescriptorProtos.EnumDescriptorProtoOrBuilder)this.enumTypeBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeOrBuilderList()
      {
        if (this.enumTypeBuilder_ != null) {
          return this.enumTypeBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.enumType_);
      }
      
      public DescriptorProtos.EnumDescriptorProto.Builder addEnumTypeBuilder()
      {
        return (DescriptorProtos.EnumDescriptorProto.Builder)getEnumTypeFieldBuilder().addBuilder(DescriptorProtos.EnumDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.EnumDescriptorProto.Builder addEnumTypeBuilder(int index)
      {
        return (DescriptorProtos.EnumDescriptorProto.Builder)getEnumTypeFieldBuilder().addBuilder(index, DescriptorProtos.EnumDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.EnumDescriptorProto.Builder> getEnumTypeBuilderList()
      {
        return getEnumTypeFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.EnumDescriptorProto, DescriptorProtos.EnumDescriptorProto.Builder, DescriptorProtos.EnumDescriptorProtoOrBuilder> getEnumTypeFieldBuilder()
      {
        if (this.enumTypeBuilder_ == null)
        {
          this.enumTypeBuilder_ = new RepeatedFieldBuilder(this.enumType_, (this.bitField0_ & 0x10) == 16, getParentForChildren(), isClean());
          
          this.enumType_ = null;
        }
        return this.enumTypeBuilder_;
      }
      
      private List<DescriptorProtos.DescriptorProto.ExtensionRange> extensionRange_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.DescriptorProto.ExtensionRange, DescriptorProtos.DescriptorProto.ExtensionRange.Builder, DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder> extensionRangeBuilder_;
      
      private void ensureExtensionRangeIsMutable()
      {
        if ((this.bitField0_ & 0x20) != 32)
        {
          this.extensionRange_ = new ArrayList(this.extensionRange_);
          this.bitField0_ |= 0x20;
        }
      }
      
      public List<DescriptorProtos.DescriptorProto.ExtensionRange> getExtensionRangeList()
      {
        if (this.extensionRangeBuilder_ == null) {
          return Collections.unmodifiableList(this.extensionRange_);
        }
        return this.extensionRangeBuilder_.getMessageList();
      }
      
      public int getExtensionRangeCount()
      {
        if (this.extensionRangeBuilder_ == null) {
          return this.extensionRange_.size();
        }
        return this.extensionRangeBuilder_.getCount();
      }
      
      public DescriptorProtos.DescriptorProto.ExtensionRange getExtensionRange(int index)
      {
        if (this.extensionRangeBuilder_ == null) {
          return (DescriptorProtos.DescriptorProto.ExtensionRange)this.extensionRange_.get(index);
        }
        return (DescriptorProtos.DescriptorProto.ExtensionRange)this.extensionRangeBuilder_.getMessage(index);
      }
      
      public Builder setExtensionRange(int index, DescriptorProtos.DescriptorProto.ExtensionRange value)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionRangeIsMutable();
          this.extensionRange_.set(index, value);
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setExtensionRange(int index, DescriptorProtos.DescriptorProto.ExtensionRange.Builder builderForValue)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          ensureExtensionRangeIsMutable();
          this.extensionRange_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addExtensionRange(DescriptorProtos.DescriptorProto.ExtensionRange value)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionRangeIsMutable();
          this.extensionRange_.add(value);
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addExtensionRange(int index, DescriptorProtos.DescriptorProto.ExtensionRange value)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureExtensionRangeIsMutable();
          this.extensionRange_.add(index, value);
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addExtensionRange(DescriptorProtos.DescriptorProto.ExtensionRange.Builder builderForValue)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          ensureExtensionRangeIsMutable();
          this.extensionRange_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addExtensionRange(int index, DescriptorProtos.DescriptorProto.ExtensionRange.Builder builderForValue)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          ensureExtensionRangeIsMutable();
          this.extensionRange_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllExtensionRange(Iterable<? extends DescriptorProtos.DescriptorProto.ExtensionRange> values)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          ensureExtensionRangeIsMutable();
          GeneratedMessage.Builder.addAll(values, this.extensionRange_);
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearExtensionRange()
      {
        if (this.extensionRangeBuilder_ == null)
        {
          this.extensionRange_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFDF;
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeExtensionRange(int index)
      {
        if (this.extensionRangeBuilder_ == null)
        {
          ensureExtensionRangeIsMutable();
          this.extensionRange_.remove(index);
          onChanged();
        }
        else
        {
          this.extensionRangeBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.DescriptorProto.ExtensionRange.Builder getExtensionRangeBuilder(int index)
      {
        return (DescriptorProtos.DescriptorProto.ExtensionRange.Builder)getExtensionRangeFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder getExtensionRangeOrBuilder(int index)
      {
        if (this.extensionRangeBuilder_ == null) {
          return (DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder)this.extensionRange_.get(index);
        }
        return (DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder)this.extensionRangeBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder> getExtensionRangeOrBuilderList()
      {
        if (this.extensionRangeBuilder_ != null) {
          return this.extensionRangeBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.extensionRange_);
      }
      
      public DescriptorProtos.DescriptorProto.ExtensionRange.Builder addExtensionRangeBuilder()
      {
        return (DescriptorProtos.DescriptorProto.ExtensionRange.Builder)getExtensionRangeFieldBuilder().addBuilder(DescriptorProtos.DescriptorProto.ExtensionRange.getDefaultInstance());
      }
      
      public DescriptorProtos.DescriptorProto.ExtensionRange.Builder addExtensionRangeBuilder(int index)
      {
        return (DescriptorProtos.DescriptorProto.ExtensionRange.Builder)getExtensionRangeFieldBuilder().addBuilder(index, DescriptorProtos.DescriptorProto.ExtensionRange.getDefaultInstance());
      }
      
      public List<DescriptorProtos.DescriptorProto.ExtensionRange.Builder> getExtensionRangeBuilderList()
      {
        return getExtensionRangeFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.DescriptorProto.ExtensionRange, DescriptorProtos.DescriptorProto.ExtensionRange.Builder, DescriptorProtos.DescriptorProto.ExtensionRangeOrBuilder> getExtensionRangeFieldBuilder()
      {
        if (this.extensionRangeBuilder_ == null)
        {
          this.extensionRangeBuilder_ = new RepeatedFieldBuilder(this.extensionRange_, (this.bitField0_ & 0x20) == 32, getParentForChildren(), isClean());
          
          this.extensionRange_ = null;
        }
        return this.extensionRangeBuilder_;
      }
      
      private DescriptorProtos.MessageOptions options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.MessageOptions, DescriptorProtos.MessageOptions.Builder, DescriptorProtos.MessageOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x40) == 64;
      }
      
      public DescriptorProtos.MessageOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.MessageOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.MessageOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x40;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.MessageOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x40;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.MessageOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x40) == 64) && (this.options_ != DescriptorProtos.MessageOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.MessageOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x40;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.MessageOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFBF;
        return this;
      }
      
      public DescriptorProtos.MessageOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x40;
        onChanged();
        return (DescriptorProtos.MessageOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.MessageOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.MessageOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.MessageOptions, DescriptorProtos.MessageOptions.Builder, DescriptorProtos.MessageOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new DescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface FieldDescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract boolean hasNumber();
    
    public abstract int getNumber();
    
    public abstract boolean hasLabel();
    
    public abstract DescriptorProtos.FieldDescriptorProto.Label getLabel();
    
    public abstract boolean hasType();
    
    public abstract DescriptorProtos.FieldDescriptorProto.Type getType();
    
    public abstract boolean hasTypeName();
    
    public abstract String getTypeName();
    
    public abstract ByteString getTypeNameBytes();
    
    public abstract boolean hasExtendee();
    
    public abstract String getExtendee();
    
    public abstract ByteString getExtendeeBytes();
    
    public abstract boolean hasDefaultValue();
    
    public abstract String getDefaultValue();
    
    public abstract ByteString getDefaultValueBytes();
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.FieldOptions getOptions();
    
    public abstract DescriptorProtos.FieldOptionsOrBuilder getOptionsOrBuilder();
  }
  
  public static final class FieldDescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.FieldDescriptorProtoOrBuilder
  {
    private static final FieldDescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private FieldDescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private FieldDescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static FieldDescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public FieldDescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private FieldDescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 18: 
            this.bitField0_ |= 0x20;
            this.extendee_ = input.readBytes();
            break;
          case 24: 
            this.bitField0_ |= 0x2;
            this.number_ = input.readInt32();
            break;
          case 32: 
            int rawValue = input.readEnum();
            Label value = Label.valueOf(rawValue);
            if (value == null)
            {
              unknownFields.mergeVarintField(4, rawValue);
            }
            else
            {
              this.bitField0_ |= 0x4;
              this.label_ = value;
            }
            break;
          case 40: 
            int rawValue = input.readEnum();
            Type value = Type.valueOf(rawValue);
            if (value == null)
            {
              unknownFields.mergeVarintField(5, rawValue);
            }
            else
            {
              this.bitField0_ |= 0x8;
              this.type_ = value;
            }
            break;
          case 50: 
            this.bitField0_ |= 0x10;
            this.typeName_ = input.readBytes();
            break;
          case 58: 
            this.bitField0_ |= 0x40;
            this.defaultValue_ = input.readBytes();
            break;
          case 66: 
            DescriptorProtos.FieldOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x80) == 128) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.FieldOptions)input.readMessage(DescriptorProtos.FieldOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x80;
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_FieldDescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_FieldDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(FieldDescriptorProto.class, Builder.class);
    }
    
    public static Parser<FieldDescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.FieldDescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.FieldDescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int NUMBER_FIELD_NUMBER = 3;
    private int number_;
    public static final int LABEL_FIELD_NUMBER = 4;
    private Label label_;
    public static final int TYPE_FIELD_NUMBER = 5;
    private Type type_;
    public static final int TYPE_NAME_FIELD_NUMBER = 6;
    private Object typeName_;
    public static final int EXTENDEE_FIELD_NUMBER = 2;
    private Object extendee_;
    public static final int DEFAULT_VALUE_FIELD_NUMBER = 7;
    private Object defaultValue_;
    public static final int OPTIONS_FIELD_NUMBER = 8;
    private DescriptorProtos.FieldOptions options_;
    
    public Parser<FieldDescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public static enum Type
      implements ProtocolMessageEnum
    {
      TYPE_DOUBLE(0, 1),  TYPE_FLOAT(1, 2),  TYPE_INT64(2, 3),  TYPE_UINT64(3, 4),  TYPE_INT32(4, 5),  TYPE_FIXED64(5, 6),  TYPE_FIXED32(6, 7),  TYPE_BOOL(7, 8),  TYPE_STRING(8, 9),  TYPE_GROUP(9, 10),  TYPE_MESSAGE(10, 11),  TYPE_BYTES(11, 12),  TYPE_UINT32(12, 13),  TYPE_ENUM(13, 14),  TYPE_SFIXED32(14, 15),  TYPE_SFIXED64(15, 16),  TYPE_SINT32(16, 17),  TYPE_SINT64(17, 18);
      
      public static final int TYPE_DOUBLE_VALUE = 1;
      public static final int TYPE_FLOAT_VALUE = 2;
      public static final int TYPE_INT64_VALUE = 3;
      public static final int TYPE_UINT64_VALUE = 4;
      public static final int TYPE_INT32_VALUE = 5;
      public static final int TYPE_FIXED64_VALUE = 6;
      public static final int TYPE_FIXED32_VALUE = 7;
      public static final int TYPE_BOOL_VALUE = 8;
      public static final int TYPE_STRING_VALUE = 9;
      public static final int TYPE_GROUP_VALUE = 10;
      public static final int TYPE_MESSAGE_VALUE = 11;
      public static final int TYPE_BYTES_VALUE = 12;
      public static final int TYPE_UINT32_VALUE = 13;
      public static final int TYPE_ENUM_VALUE = 14;
      public static final int TYPE_SFIXED32_VALUE = 15;
      public static final int TYPE_SFIXED64_VALUE = 16;
      public static final int TYPE_SINT32_VALUE = 17;
      public static final int TYPE_SINT64_VALUE = 18;
      
      public final int getNumber()
      {
        return this.value;
      }
      
      public static Type valueOf(int value)
      {
        switch (value)
        {
        case 1: 
          return TYPE_DOUBLE;
        case 2: 
          return TYPE_FLOAT;
        case 3: 
          return TYPE_INT64;
        case 4: 
          return TYPE_UINT64;
        case 5: 
          return TYPE_INT32;
        case 6: 
          return TYPE_FIXED64;
        case 7: 
          return TYPE_FIXED32;
        case 8: 
          return TYPE_BOOL;
        case 9: 
          return TYPE_STRING;
        case 10: 
          return TYPE_GROUP;
        case 11: 
          return TYPE_MESSAGE;
        case 12: 
          return TYPE_BYTES;
        case 13: 
          return TYPE_UINT32;
        case 14: 
          return TYPE_ENUM;
        case 15: 
          return TYPE_SFIXED32;
        case 16: 
          return TYPE_SFIXED64;
        case 17: 
          return TYPE_SINT32;
        case 18: 
          return TYPE_SINT64;
        }
        return null;
      }
      
      public static Internal.EnumLiteMap<Type> internalGetValueMap()
      {
        return internalValueMap;
      }
      
      private static Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap()
      {
        public DescriptorProtos.FieldDescriptorProto.Type findValueByNumber(int number)
        {
          return DescriptorProtos.FieldDescriptorProto.Type.valueOf(number);
        }
      };
      
      public final Descriptors.EnumValueDescriptor getValueDescriptor()
      {
        return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
      }
      
      public final Descriptors.EnumDescriptor getDescriptorForType()
      {
        return getDescriptor();
      }
      
      public static final Descriptors.EnumDescriptor getDescriptor()
      {
        return (Descriptors.EnumDescriptor)DescriptorProtos.FieldDescriptorProto.getDescriptor().getEnumTypes().get(0);
      }
      
      private static final Type[] VALUES = values();
      private final int index;
      private final int value;
      
      public static Type valueOf(Descriptors.EnumValueDescriptor desc)
      {
        if (desc.getType() != getDescriptor()) {
          throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
        }
        return VALUES[desc.getIndex()];
      }
      
      private Type(int index, int value)
      {
        this.index = index;
        this.value = value;
      }
    }
    
    public static enum Label
      implements ProtocolMessageEnum
    {
      LABEL_OPTIONAL(0, 1),  LABEL_REQUIRED(1, 2),  LABEL_REPEATED(2, 3);
      
      public static final int LABEL_OPTIONAL_VALUE = 1;
      public static final int LABEL_REQUIRED_VALUE = 2;
      public static final int LABEL_REPEATED_VALUE = 3;
      
      public final int getNumber()
      {
        return this.value;
      }
      
      public static Label valueOf(int value)
      {
        switch (value)
        {
        case 1: 
          return LABEL_OPTIONAL;
        case 2: 
          return LABEL_REQUIRED;
        case 3: 
          return LABEL_REPEATED;
        }
        return null;
      }
      
      public static Internal.EnumLiteMap<Label> internalGetValueMap()
      {
        return internalValueMap;
      }
      
      private static Internal.EnumLiteMap<Label> internalValueMap = new Internal.EnumLiteMap()
      {
        public DescriptorProtos.FieldDescriptorProto.Label findValueByNumber(int number)
        {
          return DescriptorProtos.FieldDescriptorProto.Label.valueOf(number);
        }
      };
      
      public final Descriptors.EnumValueDescriptor getValueDescriptor()
      {
        return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
      }
      
      public final Descriptors.EnumDescriptor getDescriptorForType()
      {
        return getDescriptor();
      }
      
      public static final Descriptors.EnumDescriptor getDescriptor()
      {
        return (Descriptors.EnumDescriptor)DescriptorProtos.FieldDescriptorProto.getDescriptor().getEnumTypes().get(1);
      }
      
      private static final Label[] VALUES = values();
      private final int index;
      private final int value;
      
      public static Label valueOf(Descriptors.EnumValueDescriptor desc)
      {
        if (desc.getType() != getDescriptor()) {
          throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
        }
        return VALUES[desc.getIndex()];
      }
      
      private Label(int index, int value)
      {
        this.index = index;
        this.value = value;
      }
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasNumber()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public int getNumber()
    {
      return this.number_;
    }
    
    public boolean hasLabel()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public Label getLabel()
    {
      return this.label_;
    }
    
    public boolean hasType()
    {
      return (this.bitField0_ & 0x8) == 8;
    }
    
    public Type getType()
    {
      return this.type_;
    }
    
    public boolean hasTypeName()
    {
      return (this.bitField0_ & 0x10) == 16;
    }
    
    public String getTypeName()
    {
      Object ref = this.typeName_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.typeName_ = s;
      }
      return s;
    }
    
    public ByteString getTypeNameBytes()
    {
      Object ref = this.typeName_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.typeName_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasExtendee()
    {
      return (this.bitField0_ & 0x20) == 32;
    }
    
    public String getExtendee()
    {
      Object ref = this.extendee_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.extendee_ = s;
      }
      return s;
    }
    
    public ByteString getExtendeeBytes()
    {
      Object ref = this.extendee_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.extendee_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasDefaultValue()
    {
      return (this.bitField0_ & 0x40) == 64;
    }
    
    public String getDefaultValue()
    {
      Object ref = this.defaultValue_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.defaultValue_ = s;
      }
      return s;
    }
    
    public ByteString getDefaultValueBytes()
    {
      Object ref = this.defaultValue_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.defaultValue_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x80) == 128;
    }
    
    public DescriptorProtos.FieldOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.FieldOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.number_ = 0;
      this.label_ = Label.LABEL_OPTIONAL;
      this.type_ = Type.TYPE_DOUBLE;
      this.typeName_ = "";
      this.extendee_ = "";
      this.defaultValue_ = "";
      this.options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x20) == 32) {
        output.writeBytes(2, getExtendeeBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeInt32(3, this.number_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeEnum(4, this.label_.getNumber());
      }
      if ((this.bitField0_ & 0x8) == 8) {
        output.writeEnum(5, this.type_.getNumber());
      }
      if ((this.bitField0_ & 0x10) == 16) {
        output.writeBytes(6, getTypeNameBytes());
      }
      if ((this.bitField0_ & 0x40) == 64) {
        output.writeBytes(7, getDefaultValueBytes());
      }
      if ((this.bitField0_ & 0x80) == 128) {
        output.writeMessage(8, this.options_);
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x20) == 32) {
        size += CodedOutputStream.computeBytesSize(2, getExtendeeBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeInt32Size(3, this.number_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeEnumSize(4, this.label_.getNumber());
      }
      if ((this.bitField0_ & 0x8) == 8) {
        size += CodedOutputStream.computeEnumSize(5, this.type_.getNumber());
      }
      if ((this.bitField0_ & 0x10) == 16) {
        size += CodedOutputStream.computeBytesSize(6, getTypeNameBytes());
      }
      if ((this.bitField0_ & 0x40) == 64) {
        size += CodedOutputStream.computeBytesSize(7, getDefaultValueBytes());
      }
      if ((this.bitField0_ & 0x80) == 128) {
        size += CodedOutputStream.computeMessageSize(8, this.options_);
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static FieldDescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static FieldDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FieldDescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static FieldDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FieldDescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static FieldDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static FieldDescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (FieldDescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static FieldDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FieldDescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static FieldDescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static FieldDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FieldDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$5100();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(FieldDescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.FieldDescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_FieldDescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_FieldDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.FieldDescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getOptionsFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        this.number_ = 0;
        this.bitField0_ &= 0xFFFFFFFD;
        this.label_ = DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
        this.bitField0_ &= 0xFFFFFFFB;
        this.type_ = DescriptorProtos.FieldDescriptorProto.Type.TYPE_DOUBLE;
        this.bitField0_ &= 0xFFFFFFF7;
        this.typeName_ = "";
        this.bitField0_ &= 0xFFFFFFEF;
        this.extendee_ = "";
        this.bitField0_ &= 0xFFFFFFDF;
        this.defaultValue_ = "";
        this.bitField0_ &= 0xFFFFFFBF;
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFF7F;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_FieldDescriptorProto_descriptor;
      }
      
      public DescriptorProtos.FieldDescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.FieldDescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.FieldDescriptorProto build()
      {
        DescriptorProtos.FieldDescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.FieldDescriptorProto buildPartial()
      {
        DescriptorProtos.FieldDescriptorProto result = new DescriptorProtos.FieldDescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.number_ = this.number_;
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x4;
        }
        result.label_ = this.label_;
        if ((from_bitField0_ & 0x8) == 8) {
          to_bitField0_ |= 0x8;
        }
        result.type_ = this.type_;
        if ((from_bitField0_ & 0x10) == 16) {
          to_bitField0_ |= 0x10;
        }
        result.typeName_ = this.typeName_;
        if ((from_bitField0_ & 0x20) == 32) {
          to_bitField0_ |= 0x20;
        }
        result.extendee_ = this.extendee_;
        if ((from_bitField0_ & 0x40) == 64) {
          to_bitField0_ |= 0x40;
        }
        result.defaultValue_ = this.defaultValue_;
        if ((from_bitField0_ & 0x80) == 128) {
          to_bitField0_ |= 0x80;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.FieldOptions)this.optionsBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.FieldDescriptorProto)) {
          return mergeFrom((DescriptorProtos.FieldDescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.FieldDescriptorProto other)
      {
        if (other == DescriptorProtos.FieldDescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (other.hasNumber()) {
          setNumber(other.getNumber());
        }
        if (other.hasLabel()) {
          setLabel(other.getLabel());
        }
        if (other.hasType()) {
          setType(other.getType());
        }
        if (other.hasTypeName())
        {
          this.bitField0_ |= 0x10;
          this.typeName_ = other.typeName_;
          onChanged();
        }
        if (other.hasExtendee())
        {
          this.bitField0_ |= 0x20;
          this.extendee_ = other.extendee_;
          onChanged();
        }
        if (other.hasDefaultValue())
        {
          this.bitField0_ |= 0x40;
          this.defaultValue_ = other.defaultValue_;
          onChanged();
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.FieldDescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.FieldDescriptorProto)DescriptorProtos.FieldDescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.FieldDescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      private int number_;
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public boolean hasNumber()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public int getNumber()
      {
        return this.number_;
      }
      
      public Builder setNumber(int value)
      {
        this.bitField0_ |= 0x2;
        this.number_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearNumber()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.number_ = 0;
        onChanged();
        return this;
      }
      
      private DescriptorProtos.FieldDescriptorProto.Label label_ = DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
      
      public boolean hasLabel()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public DescriptorProtos.FieldDescriptorProto.Label getLabel()
      {
        return this.label_;
      }
      
      public Builder setLabel(DescriptorProtos.FieldDescriptorProto.Label value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x4;
        this.label_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearLabel()
      {
        this.bitField0_ &= 0xFFFFFFFB;
        this.label_ = DescriptorProtos.FieldDescriptorProto.Label.LABEL_OPTIONAL;
        onChanged();
        return this;
      }
      
      private DescriptorProtos.FieldDescriptorProto.Type type_ = DescriptorProtos.FieldDescriptorProto.Type.TYPE_DOUBLE;
      
      public boolean hasType()
      {
        return (this.bitField0_ & 0x8) == 8;
      }
      
      public DescriptorProtos.FieldDescriptorProto.Type getType()
      {
        return this.type_;
      }
      
      public Builder setType(DescriptorProtos.FieldDescriptorProto.Type value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x8;
        this.type_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearType()
      {
        this.bitField0_ &= 0xFFFFFFF7;
        this.type_ = DescriptorProtos.FieldDescriptorProto.Type.TYPE_DOUBLE;
        onChanged();
        return this;
      }
      
      private Object typeName_ = "";
      
      public boolean hasTypeName()
      {
        return (this.bitField0_ & 0x10) == 16;
      }
      
      public String getTypeName()
      {
        Object ref = this.typeName_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.typeName_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getTypeNameBytes()
      {
        Object ref = this.typeName_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.typeName_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setTypeName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x10;
        this.typeName_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearTypeName()
      {
        this.bitField0_ &= 0xFFFFFFEF;
        this.typeName_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getTypeName();
        onChanged();
        return this;
      }
      
      public Builder setTypeNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x10;
        this.typeName_ = value;
        onChanged();
        return this;
      }
      
      private Object extendee_ = "";
      
      public boolean hasExtendee()
      {
        return (this.bitField0_ & 0x20) == 32;
      }
      
      public String getExtendee()
      {
        Object ref = this.extendee_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.extendee_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getExtendeeBytes()
      {
        Object ref = this.extendee_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.extendee_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setExtendee(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x20;
        this.extendee_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearExtendee()
      {
        this.bitField0_ &= 0xFFFFFFDF;
        this.extendee_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getExtendee();
        onChanged();
        return this;
      }
      
      public Builder setExtendeeBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x20;
        this.extendee_ = value;
        onChanged();
        return this;
      }
      
      private Object defaultValue_ = "";
      
      public boolean hasDefaultValue()
      {
        return (this.bitField0_ & 0x40) == 64;
      }
      
      public String getDefaultValue()
      {
        Object ref = this.defaultValue_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.defaultValue_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getDefaultValueBytes()
      {
        Object ref = this.defaultValue_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.defaultValue_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setDefaultValue(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x40;
        this.defaultValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearDefaultValue()
      {
        this.bitField0_ &= 0xFFFFFFBF;
        this.defaultValue_ = DescriptorProtos.FieldDescriptorProto.getDefaultInstance().getDefaultValue();
        onChanged();
        return this;
      }
      
      public Builder setDefaultValueBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x40;
        this.defaultValue_ = value;
        onChanged();
        return this;
      }
      
      private DescriptorProtos.FieldOptions options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.FieldOptions, DescriptorProtos.FieldOptions.Builder, DescriptorProtos.FieldOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x80) == 128;
      }
      
      public DescriptorProtos.FieldOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.FieldOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.FieldOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x80;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.FieldOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x80;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.FieldOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x80) == 128) && (this.options_ != DescriptorProtos.FieldOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.FieldOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x80;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.FieldOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFF7F;
        return this;
      }
      
      public DescriptorProtos.FieldOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x80;
        onChanged();
        return (DescriptorProtos.FieldOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.FieldOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.FieldOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.FieldOptions, DescriptorProtos.FieldOptions.Builder, DescriptorProtos.FieldOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new FieldDescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface EnumDescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract List<DescriptorProtos.EnumValueDescriptorProto> getValueList();
    
    public abstract DescriptorProtos.EnumValueDescriptorProto getValue(int paramInt);
    
    public abstract int getValueCount();
    
    public abstract List<? extends DescriptorProtos.EnumValueDescriptorProtoOrBuilder> getValueOrBuilderList();
    
    public abstract DescriptorProtos.EnumValueDescriptorProtoOrBuilder getValueOrBuilder(int paramInt);
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.EnumOptions getOptions();
    
    public abstract DescriptorProtos.EnumOptionsOrBuilder getOptionsOrBuilder();
  }
  
  public static final class EnumDescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.EnumDescriptorProtoOrBuilder
  {
    private static final EnumDescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private EnumDescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private EnumDescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static EnumDescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public EnumDescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private EnumDescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 18: 
            if ((mutable_bitField0_ & 0x2) != 2)
            {
              this.value_ = new ArrayList();
              mutable_bitField0_ |= 0x2;
            }
            this.value_.add(input.readMessage(DescriptorProtos.EnumValueDescriptorProto.PARSER, extensionRegistry));
            break;
          case 26: 
            DescriptorProtos.EnumOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x2) == 2) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.EnumOptions)input.readMessage(DescriptorProtos.EnumOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x2;
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x2) == 2) {
          this.value_ = Collections.unmodifiableList(this.value_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumDescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(EnumDescriptorProto.class, Builder.class);
    }
    
    public static Parser<EnumDescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.EnumDescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.EnumDescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int VALUE_FIELD_NUMBER = 2;
    private List<DescriptorProtos.EnumValueDescriptorProto> value_;
    public static final int OPTIONS_FIELD_NUMBER = 3;
    private DescriptorProtos.EnumOptions options_;
    
    public Parser<EnumDescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public List<DescriptorProtos.EnumValueDescriptorProto> getValueList()
    {
      return this.value_;
    }
    
    public List<? extends DescriptorProtos.EnumValueDescriptorProtoOrBuilder> getValueOrBuilderList()
    {
      return this.value_;
    }
    
    public int getValueCount()
    {
      return this.value_.size();
    }
    
    public DescriptorProtos.EnumValueDescriptorProto getValue(int index)
    {
      return (DescriptorProtos.EnumValueDescriptorProto)this.value_.get(index);
    }
    
    public DescriptorProtos.EnumValueDescriptorProtoOrBuilder getValueOrBuilder(int index)
    {
      return (DescriptorProtos.EnumValueDescriptorProtoOrBuilder)this.value_.get(index);
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public DescriptorProtos.EnumOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.EnumOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.value_ = Collections.emptyList();
      this.options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getValueCount(); i++) {
        if (!getValue(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      for (int i = 0; i < this.value_.size(); i++) {
        output.writeMessage(2, (MessageLite)this.value_.get(i));
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeMessage(3, this.options_);
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      for (int i = 0; i < this.value_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(2, (MessageLite)this.value_.get(i));
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeMessageSize(3, this.options_);
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static EnumDescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static EnumDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumDescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static EnumDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumDescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static EnumDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static EnumDescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (EnumDescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static EnumDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumDescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static EnumDescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static EnumDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$6600();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(EnumDescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.EnumDescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumDescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.EnumDescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders)
        {
          getValueFieldBuilder();
          getOptionsFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        if (this.valueBuilder_ == null)
        {
          this.value_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
        }
        else
        {
          this.valueBuilder_.clear();
        }
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFFB;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumDescriptorProto_descriptor;
      }
      
      public DescriptorProtos.EnumDescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.EnumDescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.EnumDescriptorProto build()
      {
        DescriptorProtos.EnumDescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.EnumDescriptorProto buildPartial()
      {
        DescriptorProtos.EnumDescriptorProto result = new DescriptorProtos.EnumDescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if (this.valueBuilder_ == null)
        {
          if ((this.bitField0_ & 0x2) == 2)
          {
            this.value_ = Collections.unmodifiableList(this.value_);
            this.bitField0_ &= 0xFFFFFFFD;
          }
          result.value_ = this.value_;
        }
        else
        {
          result.value_ = this.valueBuilder_.build();
        }
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x2;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.EnumOptions)this.optionsBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.EnumDescriptorProto)) {
          return mergeFrom((DescriptorProtos.EnumDescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.EnumDescriptorProto other)
      {
        if (other == DescriptorProtos.EnumDescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (this.valueBuilder_ == null)
        {
          if (!other.value_.isEmpty())
          {
            if (this.value_.isEmpty())
            {
              this.value_ = other.value_;
              this.bitField0_ &= 0xFFFFFFFD;
            }
            else
            {
              ensureValueIsMutable();
              this.value_.addAll(other.value_);
            }
            onChanged();
          }
        }
        else if (!other.value_.isEmpty()) {
          if (this.valueBuilder_.isEmpty())
          {
            this.valueBuilder_.dispose();
            this.valueBuilder_ = null;
            this.value_ = other.value_;
            this.bitField0_ &= 0xFFFFFFFD;
            this.valueBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getValueFieldBuilder() : null);
          }
          else
          {
            this.valueBuilder_.addAllMessages(other.value_);
          }
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getValueCount(); i++) {
          if (!getValue(i).isInitialized()) {
            return false;
          }
        }
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.EnumDescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.EnumDescriptorProto)DescriptorProtos.EnumDescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.EnumDescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.EnumDescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.EnumValueDescriptorProto> value_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.EnumValueDescriptorProto, DescriptorProtos.EnumValueDescriptorProto.Builder, DescriptorProtos.EnumValueDescriptorProtoOrBuilder> valueBuilder_;
      
      private void ensureValueIsMutable()
      {
        if ((this.bitField0_ & 0x2) != 2)
        {
          this.value_ = new ArrayList(this.value_);
          this.bitField0_ |= 0x2;
        }
      }
      
      public List<DescriptorProtos.EnumValueDescriptorProto> getValueList()
      {
        if (this.valueBuilder_ == null) {
          return Collections.unmodifiableList(this.value_);
        }
        return this.valueBuilder_.getMessageList();
      }
      
      public int getValueCount()
      {
        if (this.valueBuilder_ == null) {
          return this.value_.size();
        }
        return this.valueBuilder_.getCount();
      }
      
      public DescriptorProtos.EnumValueDescriptorProto getValue(int index)
      {
        if (this.valueBuilder_ == null) {
          return (DescriptorProtos.EnumValueDescriptorProto)this.value_.get(index);
        }
        return (DescriptorProtos.EnumValueDescriptorProto)this.valueBuilder_.getMessage(index);
      }
      
      public Builder setValue(int index, DescriptorProtos.EnumValueDescriptorProto value)
      {
        if (this.valueBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureValueIsMutable();
          this.value_.set(index, value);
          onChanged();
        }
        else
        {
          this.valueBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setValue(int index, DescriptorProtos.EnumValueDescriptorProto.Builder builderForValue)
      {
        if (this.valueBuilder_ == null)
        {
          ensureValueIsMutable();
          this.value_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.valueBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addValue(DescriptorProtos.EnumValueDescriptorProto value)
      {
        if (this.valueBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureValueIsMutable();
          this.value_.add(value);
          onChanged();
        }
        else
        {
          this.valueBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addValue(int index, DescriptorProtos.EnumValueDescriptorProto value)
      {
        if (this.valueBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureValueIsMutable();
          this.value_.add(index, value);
          onChanged();
        }
        else
        {
          this.valueBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addValue(DescriptorProtos.EnumValueDescriptorProto.Builder builderForValue)
      {
        if (this.valueBuilder_ == null)
        {
          ensureValueIsMutable();
          this.value_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.valueBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addValue(int index, DescriptorProtos.EnumValueDescriptorProto.Builder builderForValue)
      {
        if (this.valueBuilder_ == null)
        {
          ensureValueIsMutable();
          this.value_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.valueBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllValue(Iterable<? extends DescriptorProtos.EnumValueDescriptorProto> values)
      {
        if (this.valueBuilder_ == null)
        {
          ensureValueIsMutable();
          GeneratedMessage.Builder.addAll(values, this.value_);
          onChanged();
        }
        else
        {
          this.valueBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearValue()
      {
        if (this.valueBuilder_ == null)
        {
          this.value_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
          onChanged();
        }
        else
        {
          this.valueBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeValue(int index)
      {
        if (this.valueBuilder_ == null)
        {
          ensureValueIsMutable();
          this.value_.remove(index);
          onChanged();
        }
        else
        {
          this.valueBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.EnumValueDescriptorProto.Builder getValueBuilder(int index)
      {
        return (DescriptorProtos.EnumValueDescriptorProto.Builder)getValueFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.EnumValueDescriptorProtoOrBuilder getValueOrBuilder(int index)
      {
        if (this.valueBuilder_ == null) {
          return (DescriptorProtos.EnumValueDescriptorProtoOrBuilder)this.value_.get(index);
        }
        return (DescriptorProtos.EnumValueDescriptorProtoOrBuilder)this.valueBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.EnumValueDescriptorProtoOrBuilder> getValueOrBuilderList()
      {
        if (this.valueBuilder_ != null) {
          return this.valueBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.value_);
      }
      
      public DescriptorProtos.EnumValueDescriptorProto.Builder addValueBuilder()
      {
        return (DescriptorProtos.EnumValueDescriptorProto.Builder)getValueFieldBuilder().addBuilder(DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.EnumValueDescriptorProto.Builder addValueBuilder(int index)
      {
        return (DescriptorProtos.EnumValueDescriptorProto.Builder)getValueFieldBuilder().addBuilder(index, DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.EnumValueDescriptorProto.Builder> getValueBuilderList()
      {
        return getValueFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.EnumValueDescriptorProto, DescriptorProtos.EnumValueDescriptorProto.Builder, DescriptorProtos.EnumValueDescriptorProtoOrBuilder> getValueFieldBuilder()
      {
        if (this.valueBuilder_ == null)
        {
          this.valueBuilder_ = new RepeatedFieldBuilder(this.value_, (this.bitField0_ & 0x2) == 2, getParentForChildren(), isClean());
          
          this.value_ = null;
        }
        return this.valueBuilder_;
      }
      
      private DescriptorProtos.EnumOptions options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.EnumOptions, DescriptorProtos.EnumOptions.Builder, DescriptorProtos.EnumOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public DescriptorProtos.EnumOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.EnumOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.EnumOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.EnumOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.EnumOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x4) == 4) && (this.options_ != DescriptorProtos.EnumOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.EnumOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.EnumOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFFB;
        return this;
      }
      
      public DescriptorProtos.EnumOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x4;
        onChanged();
        return (DescriptorProtos.EnumOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.EnumOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.EnumOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.EnumOptions, DescriptorProtos.EnumOptions.Builder, DescriptorProtos.EnumOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new EnumDescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface EnumValueDescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract boolean hasNumber();
    
    public abstract int getNumber();
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.EnumValueOptions getOptions();
    
    public abstract DescriptorProtos.EnumValueOptionsOrBuilder getOptionsOrBuilder();
  }
  
  public static final class EnumValueDescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.EnumValueDescriptorProtoOrBuilder
  {
    private static final EnumValueDescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private EnumValueDescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private EnumValueDescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static EnumValueDescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public EnumValueDescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private EnumValueDescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 16: 
            this.bitField0_ |= 0x2;
            this.number_ = input.readInt32();
            break;
          case 26: 
            DescriptorProtos.EnumValueOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x4) == 4) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.EnumValueOptions)input.readMessage(DescriptorProtos.EnumValueOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x4;
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumValueDescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumValueDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(EnumValueDescriptorProto.class, Builder.class);
    }
    
    public static Parser<EnumValueDescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.EnumValueDescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.EnumValueDescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int NUMBER_FIELD_NUMBER = 2;
    private int number_;
    public static final int OPTIONS_FIELD_NUMBER = 3;
    private DescriptorProtos.EnumValueOptions options_;
    
    public Parser<EnumValueDescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasNumber()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public int getNumber()
    {
      return this.number_;
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public DescriptorProtos.EnumValueOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.EnumValueOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.number_ = 0;
      this.options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeInt32(2, this.number_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeMessage(3, this.options_);
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeInt32Size(2, this.number_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeMessageSize(3, this.options_);
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static EnumValueDescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static EnumValueDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumValueDescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static EnumValueDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumValueDescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static EnumValueDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static EnumValueDescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (EnumValueDescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static EnumValueDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumValueDescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static EnumValueDescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static EnumValueDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumValueDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$7600();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(EnumValueDescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.EnumValueDescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumValueDescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumValueDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.EnumValueDescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getOptionsFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        this.number_ = 0;
        this.bitField0_ &= 0xFFFFFFFD;
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFFB;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumValueDescriptorProto_descriptor;
      }
      
      public DescriptorProtos.EnumValueDescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.EnumValueDescriptorProto build()
      {
        DescriptorProtos.EnumValueDescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.EnumValueDescriptorProto buildPartial()
      {
        DescriptorProtos.EnumValueDescriptorProto result = new DescriptorProtos.EnumValueDescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.number_ = this.number_;
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x4;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.EnumValueOptions)this.optionsBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.EnumValueDescriptorProto)) {
          return mergeFrom((DescriptorProtos.EnumValueDescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.EnumValueDescriptorProto other)
      {
        if (other == DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (other.hasNumber()) {
          setNumber(other.getNumber());
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.EnumValueDescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.EnumValueDescriptorProto)DescriptorProtos.EnumValueDescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.EnumValueDescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      private int number_;
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.EnumValueDescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public boolean hasNumber()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public int getNumber()
      {
        return this.number_;
      }
      
      public Builder setNumber(int value)
      {
        this.bitField0_ |= 0x2;
        this.number_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearNumber()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.number_ = 0;
        onChanged();
        return this;
      }
      
      private DescriptorProtos.EnumValueOptions options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.EnumValueOptions, DescriptorProtos.EnumValueOptions.Builder, DescriptorProtos.EnumValueOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public DescriptorProtos.EnumValueOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.EnumValueOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.EnumValueOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.EnumValueOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.EnumValueOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x4) == 4) && (this.options_ != DescriptorProtos.EnumValueOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.EnumValueOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.EnumValueOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFFB;
        return this;
      }
      
      public DescriptorProtos.EnumValueOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x4;
        onChanged();
        return (DescriptorProtos.EnumValueOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.EnumValueOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.EnumValueOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.EnumValueOptions, DescriptorProtos.EnumValueOptions.Builder, DescriptorProtos.EnumValueOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new EnumValueDescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface ServiceDescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract List<DescriptorProtos.MethodDescriptorProto> getMethodList();
    
    public abstract DescriptorProtos.MethodDescriptorProto getMethod(int paramInt);
    
    public abstract int getMethodCount();
    
    public abstract List<? extends DescriptorProtos.MethodDescriptorProtoOrBuilder> getMethodOrBuilderList();
    
    public abstract DescriptorProtos.MethodDescriptorProtoOrBuilder getMethodOrBuilder(int paramInt);
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.ServiceOptions getOptions();
    
    public abstract DescriptorProtos.ServiceOptionsOrBuilder getOptionsOrBuilder();
  }
  
  public static final class ServiceDescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.ServiceDescriptorProtoOrBuilder
  {
    private static final ServiceDescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private ServiceDescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private ServiceDescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static ServiceDescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public ServiceDescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private ServiceDescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 18: 
            if ((mutable_bitField0_ & 0x2) != 2)
            {
              this.method_ = new ArrayList();
              mutable_bitField0_ |= 0x2;
            }
            this.method_.add(input.readMessage(DescriptorProtos.MethodDescriptorProto.PARSER, extensionRegistry));
            break;
          case 26: 
            DescriptorProtos.ServiceOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x2) == 2) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.ServiceOptions)input.readMessage(DescriptorProtos.ServiceOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x2;
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x2) == 2) {
          this.method_ = Collections.unmodifiableList(this.method_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_ServiceDescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_ServiceDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(ServiceDescriptorProto.class, Builder.class);
    }
    
    public static Parser<ServiceDescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.ServiceDescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.ServiceDescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int METHOD_FIELD_NUMBER = 2;
    private List<DescriptorProtos.MethodDescriptorProto> method_;
    public static final int OPTIONS_FIELD_NUMBER = 3;
    private DescriptorProtos.ServiceOptions options_;
    
    public Parser<ServiceDescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public List<DescriptorProtos.MethodDescriptorProto> getMethodList()
    {
      return this.method_;
    }
    
    public List<? extends DescriptorProtos.MethodDescriptorProtoOrBuilder> getMethodOrBuilderList()
    {
      return this.method_;
    }
    
    public int getMethodCount()
    {
      return this.method_.size();
    }
    
    public DescriptorProtos.MethodDescriptorProto getMethod(int index)
    {
      return (DescriptorProtos.MethodDescriptorProto)this.method_.get(index);
    }
    
    public DescriptorProtos.MethodDescriptorProtoOrBuilder getMethodOrBuilder(int index)
    {
      return (DescriptorProtos.MethodDescriptorProtoOrBuilder)this.method_.get(index);
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public DescriptorProtos.ServiceOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.ServiceOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.method_ = Collections.emptyList();
      this.options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getMethodCount(); i++) {
        if (!getMethod(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      for (int i = 0; i < this.method_.size(); i++) {
        output.writeMessage(2, (MessageLite)this.method_.get(i));
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeMessage(3, this.options_);
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      for (int i = 0; i < this.method_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(2, (MessageLite)this.method_.get(i));
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeMessageSize(3, this.options_);
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static ServiceDescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static ServiceDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static ServiceDescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static ServiceDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static ServiceDescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static ServiceDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static ServiceDescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (ServiceDescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static ServiceDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (ServiceDescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static ServiceDescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static ServiceDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (ServiceDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$8600();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(ServiceDescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.ServiceDescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_ServiceDescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_ServiceDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.ServiceDescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders)
        {
          getMethodFieldBuilder();
          getOptionsFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        if (this.methodBuilder_ == null)
        {
          this.method_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
        }
        else
        {
          this.methodBuilder_.clear();
        }
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFFB;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_ServiceDescriptorProto_descriptor;
      }
      
      public DescriptorProtos.ServiceDescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.ServiceDescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.ServiceDescriptorProto build()
      {
        DescriptorProtos.ServiceDescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.ServiceDescriptorProto buildPartial()
      {
        DescriptorProtos.ServiceDescriptorProto result = new DescriptorProtos.ServiceDescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if (this.methodBuilder_ == null)
        {
          if ((this.bitField0_ & 0x2) == 2)
          {
            this.method_ = Collections.unmodifiableList(this.method_);
            this.bitField0_ &= 0xFFFFFFFD;
          }
          result.method_ = this.method_;
        }
        else
        {
          result.method_ = this.methodBuilder_.build();
        }
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x2;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.ServiceOptions)this.optionsBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.ServiceDescriptorProto)) {
          return mergeFrom((DescriptorProtos.ServiceDescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.ServiceDescriptorProto other)
      {
        if (other == DescriptorProtos.ServiceDescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (this.methodBuilder_ == null)
        {
          if (!other.method_.isEmpty())
          {
            if (this.method_.isEmpty())
            {
              this.method_ = other.method_;
              this.bitField0_ &= 0xFFFFFFFD;
            }
            else
            {
              ensureMethodIsMutable();
              this.method_.addAll(other.method_);
            }
            onChanged();
          }
        }
        else if (!other.method_.isEmpty()) {
          if (this.methodBuilder_.isEmpty())
          {
            this.methodBuilder_.dispose();
            this.methodBuilder_ = null;
            this.method_ = other.method_;
            this.bitField0_ &= 0xFFFFFFFD;
            this.methodBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getMethodFieldBuilder() : null);
          }
          else
          {
            this.methodBuilder_.addAllMessages(other.method_);
          }
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getMethodCount(); i++) {
          if (!getMethod(i).isInitialized()) {
            return false;
          }
        }
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.ServiceDescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.ServiceDescriptorProto)DescriptorProtos.ServiceDescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.ServiceDescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.ServiceDescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.MethodDescriptorProto> method_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.MethodDescriptorProto, DescriptorProtos.MethodDescriptorProto.Builder, DescriptorProtos.MethodDescriptorProtoOrBuilder> methodBuilder_;
      
      private void ensureMethodIsMutable()
      {
        if ((this.bitField0_ & 0x2) != 2)
        {
          this.method_ = new ArrayList(this.method_);
          this.bitField0_ |= 0x2;
        }
      }
      
      public List<DescriptorProtos.MethodDescriptorProto> getMethodList()
      {
        if (this.methodBuilder_ == null) {
          return Collections.unmodifiableList(this.method_);
        }
        return this.methodBuilder_.getMessageList();
      }
      
      public int getMethodCount()
      {
        if (this.methodBuilder_ == null) {
          return this.method_.size();
        }
        return this.methodBuilder_.getCount();
      }
      
      public DescriptorProtos.MethodDescriptorProto getMethod(int index)
      {
        if (this.methodBuilder_ == null) {
          return (DescriptorProtos.MethodDescriptorProto)this.method_.get(index);
        }
        return (DescriptorProtos.MethodDescriptorProto)this.methodBuilder_.getMessage(index);
      }
      
      public Builder setMethod(int index, DescriptorProtos.MethodDescriptorProto value)
      {
        if (this.methodBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureMethodIsMutable();
          this.method_.set(index, value);
          onChanged();
        }
        else
        {
          this.methodBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setMethod(int index, DescriptorProtos.MethodDescriptorProto.Builder builderForValue)
      {
        if (this.methodBuilder_ == null)
        {
          ensureMethodIsMutable();
          this.method_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.methodBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addMethod(DescriptorProtos.MethodDescriptorProto value)
      {
        if (this.methodBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureMethodIsMutable();
          this.method_.add(value);
          onChanged();
        }
        else
        {
          this.methodBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addMethod(int index, DescriptorProtos.MethodDescriptorProto value)
      {
        if (this.methodBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureMethodIsMutable();
          this.method_.add(index, value);
          onChanged();
        }
        else
        {
          this.methodBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addMethod(DescriptorProtos.MethodDescriptorProto.Builder builderForValue)
      {
        if (this.methodBuilder_ == null)
        {
          ensureMethodIsMutable();
          this.method_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.methodBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addMethod(int index, DescriptorProtos.MethodDescriptorProto.Builder builderForValue)
      {
        if (this.methodBuilder_ == null)
        {
          ensureMethodIsMutable();
          this.method_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.methodBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllMethod(Iterable<? extends DescriptorProtos.MethodDescriptorProto> values)
      {
        if (this.methodBuilder_ == null)
        {
          ensureMethodIsMutable();
          GeneratedMessage.Builder.addAll(values, this.method_);
          onChanged();
        }
        else
        {
          this.methodBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearMethod()
      {
        if (this.methodBuilder_ == null)
        {
          this.method_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
          onChanged();
        }
        else
        {
          this.methodBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeMethod(int index)
      {
        if (this.methodBuilder_ == null)
        {
          ensureMethodIsMutable();
          this.method_.remove(index);
          onChanged();
        }
        else
        {
          this.methodBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.MethodDescriptorProto.Builder getMethodBuilder(int index)
      {
        return (DescriptorProtos.MethodDescriptorProto.Builder)getMethodFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.MethodDescriptorProtoOrBuilder getMethodOrBuilder(int index)
      {
        if (this.methodBuilder_ == null) {
          return (DescriptorProtos.MethodDescriptorProtoOrBuilder)this.method_.get(index);
        }
        return (DescriptorProtos.MethodDescriptorProtoOrBuilder)this.methodBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.MethodDescriptorProtoOrBuilder> getMethodOrBuilderList()
      {
        if (this.methodBuilder_ != null) {
          return this.methodBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.method_);
      }
      
      public DescriptorProtos.MethodDescriptorProto.Builder addMethodBuilder()
      {
        return (DescriptorProtos.MethodDescriptorProto.Builder)getMethodFieldBuilder().addBuilder(DescriptorProtos.MethodDescriptorProto.getDefaultInstance());
      }
      
      public DescriptorProtos.MethodDescriptorProto.Builder addMethodBuilder(int index)
      {
        return (DescriptorProtos.MethodDescriptorProto.Builder)getMethodFieldBuilder().addBuilder(index, DescriptorProtos.MethodDescriptorProto.getDefaultInstance());
      }
      
      public List<DescriptorProtos.MethodDescriptorProto.Builder> getMethodBuilderList()
      {
        return getMethodFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.MethodDescriptorProto, DescriptorProtos.MethodDescriptorProto.Builder, DescriptorProtos.MethodDescriptorProtoOrBuilder> getMethodFieldBuilder()
      {
        if (this.methodBuilder_ == null)
        {
          this.methodBuilder_ = new RepeatedFieldBuilder(this.method_, (this.bitField0_ & 0x2) == 2, getParentForChildren(), isClean());
          
          this.method_ = null;
        }
        return this.methodBuilder_;
      }
      
      private DescriptorProtos.ServiceOptions options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.ServiceOptions, DescriptorProtos.ServiceOptions.Builder, DescriptorProtos.ServiceOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public DescriptorProtos.ServiceOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.ServiceOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.ServiceOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.ServiceOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.ServiceOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x4) == 4) && (this.options_ != DescriptorProtos.ServiceOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.ServiceOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x4;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.ServiceOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFFB;
        return this;
      }
      
      public DescriptorProtos.ServiceOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x4;
        onChanged();
        return (DescriptorProtos.ServiceOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.ServiceOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.ServiceOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.ServiceOptions, DescriptorProtos.ServiceOptions.Builder, DescriptorProtos.ServiceOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new ServiceDescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface MethodDescriptorProtoOrBuilder
    extends MessageOrBuilder
  {
    public abstract boolean hasName();
    
    public abstract String getName();
    
    public abstract ByteString getNameBytes();
    
    public abstract boolean hasInputType();
    
    public abstract String getInputType();
    
    public abstract ByteString getInputTypeBytes();
    
    public abstract boolean hasOutputType();
    
    public abstract String getOutputType();
    
    public abstract ByteString getOutputTypeBytes();
    
    public abstract boolean hasOptions();
    
    public abstract DescriptorProtos.MethodOptions getOptions();
    
    public abstract DescriptorProtos.MethodOptionsOrBuilder getOptionsOrBuilder();
  }
  
  public static final class MethodDescriptorProto
    extends GeneratedMessage
    implements DescriptorProtos.MethodDescriptorProtoOrBuilder
  {
    private static final MethodDescriptorProto defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private MethodDescriptorProto(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private MethodDescriptorProto(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static MethodDescriptorProto getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public MethodDescriptorProto getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private MethodDescriptorProto(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.name_ = input.readBytes();
            break;
          case 18: 
            this.bitField0_ |= 0x2;
            this.inputType_ = input.readBytes();
            break;
          case 26: 
            this.bitField0_ |= 0x4;
            this.outputType_ = input.readBytes();
            break;
          case 34: 
            DescriptorProtos.MethodOptions.Builder subBuilder = null;
            if ((this.bitField0_ & 0x8) == 8) {
              subBuilder = this.options_.toBuilder();
            }
            this.options_ = ((DescriptorProtos.MethodOptions)input.readMessage(DescriptorProtos.MethodOptions.PARSER, extensionRegistry));
            if (subBuilder != null)
            {
              subBuilder.mergeFrom(this.options_);
              this.options_ = subBuilder.buildPartial();
            }
            this.bitField0_ |= 0x8;
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_MethodDescriptorProto_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_MethodDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(MethodDescriptorProto.class, Builder.class);
    }
    
    public static Parser<MethodDescriptorProto> PARSER = new AbstractParser()
    {
      public DescriptorProtos.MethodDescriptorProto parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.MethodDescriptorProto(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 1;
    private Object name_;
    public static final int INPUT_TYPE_FIELD_NUMBER = 2;
    private Object inputType_;
    public static final int OUTPUT_TYPE_FIELD_NUMBER = 3;
    private Object outputType_;
    public static final int OPTIONS_FIELD_NUMBER = 4;
    private DescriptorProtos.MethodOptions options_;
    
    public Parser<MethodDescriptorProto> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasName()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getName()
    {
      Object ref = this.name_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.name_ = s;
      }
      return s;
    }
    
    public ByteString getNameBytes()
    {
      Object ref = this.name_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.name_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasInputType()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public String getInputType()
    {
      Object ref = this.inputType_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.inputType_ = s;
      }
      return s;
    }
    
    public ByteString getInputTypeBytes()
    {
      Object ref = this.inputType_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.inputType_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasOutputType()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public String getOutputType()
    {
      Object ref = this.outputType_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.outputType_ = s;
      }
      return s;
    }
    
    public ByteString getOutputTypeBytes()
    {
      Object ref = this.outputType_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.outputType_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasOptions()
    {
      return (this.bitField0_ & 0x8) == 8;
    }
    
    public DescriptorProtos.MethodOptions getOptions()
    {
      return this.options_;
    }
    
    public DescriptorProtos.MethodOptionsOrBuilder getOptionsOrBuilder()
    {
      return this.options_;
    }
    
    private void initFields()
    {
      this.name_ = "";
      this.inputType_ = "";
      this.outputType_ = "";
      this.options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      if ((hasOptions()) && 
        (!getOptions().isInitialized()))
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeBytes(2, getInputTypeBytes());
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeBytes(3, getOutputTypeBytes());
      }
      if ((this.bitField0_ & 0x8) == 8) {
        output.writeMessage(4, this.options_);
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getNameBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeBytesSize(2, getInputTypeBytes());
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeBytesSize(3, getOutputTypeBytes());
      }
      if ((this.bitField0_ & 0x8) == 8) {
        size += CodedOutputStream.computeMessageSize(4, this.options_);
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static MethodDescriptorProto parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static MethodDescriptorProto parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static MethodDescriptorProto parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(data);
    }
    
    public static MethodDescriptorProto parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static MethodDescriptorProto parseFrom(InputStream input)
      throws IOException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static MethodDescriptorProto parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static MethodDescriptorProto parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (MethodDescriptorProto)PARSER.parseDelimitedFrom(input);
    }
    
    public static MethodDescriptorProto parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MethodDescriptorProto)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static MethodDescriptorProto parseFrom(CodedInputStream input)
      throws IOException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(input);
    }
    
    public static MethodDescriptorProto parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MethodDescriptorProto)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$9600();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(MethodDescriptorProto prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.MethodDescriptorProtoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_MethodDescriptorProto_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_MethodDescriptorProto_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.MethodDescriptorProto.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getOptionsFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.name_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        this.inputType_ = "";
        this.bitField0_ &= 0xFFFFFFFD;
        this.outputType_ = "";
        this.bitField0_ &= 0xFFFFFFFB;
        if (this.optionsBuilder_ == null) {
          this.options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
        } else {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFF7;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_MethodDescriptorProto_descriptor;
      }
      
      public DescriptorProtos.MethodDescriptorProto getDefaultInstanceForType()
      {
        return DescriptorProtos.MethodDescriptorProto.getDefaultInstance();
      }
      
      public DescriptorProtos.MethodDescriptorProto build()
      {
        DescriptorProtos.MethodDescriptorProto result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.MethodDescriptorProto buildPartial()
      {
        DescriptorProtos.MethodDescriptorProto result = new DescriptorProtos.MethodDescriptorProto(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.name_ = this.name_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.inputType_ = this.inputType_;
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x4;
        }
        result.outputType_ = this.outputType_;
        if ((from_bitField0_ & 0x8) == 8) {
          to_bitField0_ |= 0x8;
        }
        if (this.optionsBuilder_ == null) {
          result.options_ = this.options_;
        } else {
          result.options_ = ((DescriptorProtos.MethodOptions)this.optionsBuilder_.build());
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.MethodDescriptorProto)) {
          return mergeFrom((DescriptorProtos.MethodDescriptorProto)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.MethodDescriptorProto other)
      {
        if (other == DescriptorProtos.MethodDescriptorProto.getDefaultInstance()) {
          return this;
        }
        if (other.hasName())
        {
          this.bitField0_ |= 0x1;
          this.name_ = other.name_;
          onChanged();
        }
        if (other.hasInputType())
        {
          this.bitField0_ |= 0x2;
          this.inputType_ = other.inputType_;
          onChanged();
        }
        if (other.hasOutputType())
        {
          this.bitField0_ |= 0x4;
          this.outputType_ = other.outputType_;
          onChanged();
        }
        if (other.hasOptions()) {
          mergeOptions(other.getOptions());
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        if ((hasOptions()) && 
          (!getOptions().isInitialized())) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.MethodDescriptorProto parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.MethodDescriptorProto)DescriptorProtos.MethodDescriptorProto.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.MethodDescriptorProto)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object name_ = "";
      
      public boolean hasName()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getName()
      {
        Object ref = this.name_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.name_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getNameBytes()
      {
        Object ref = this.name_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.name_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setName(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearName()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.name_ = DescriptorProtos.MethodDescriptorProto.getDefaultInstance().getName();
        onChanged();
        return this;
      }
      
      public Builder setNameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.name_ = value;
        onChanged();
        return this;
      }
      
      private Object inputType_ = "";
      
      public boolean hasInputType()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public String getInputType()
      {
        Object ref = this.inputType_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.inputType_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getInputTypeBytes()
      {
        Object ref = this.inputType_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.inputType_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setInputType(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.inputType_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearInputType()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.inputType_ = DescriptorProtos.MethodDescriptorProto.getDefaultInstance().getInputType();
        onChanged();
        return this;
      }
      
      public Builder setInputTypeBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.inputType_ = value;
        onChanged();
        return this;
      }
      
      private Object outputType_ = "";
      
      public boolean hasOutputType()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public String getOutputType()
      {
        Object ref = this.outputType_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.outputType_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getOutputTypeBytes()
      {
        Object ref = this.outputType_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.outputType_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setOutputType(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x4;
        this.outputType_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearOutputType()
      {
        this.bitField0_ &= 0xFFFFFFFB;
        this.outputType_ = DescriptorProtos.MethodDescriptorProto.getDefaultInstance().getOutputType();
        onChanged();
        return this;
      }
      
      public Builder setOutputTypeBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x4;
        this.outputType_ = value;
        onChanged();
        return this;
      }
      
      private DescriptorProtos.MethodOptions options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
      private SingleFieldBuilder<DescriptorProtos.MethodOptions, DescriptorProtos.MethodOptions.Builder, DescriptorProtos.MethodOptionsOrBuilder> optionsBuilder_;
      
      public boolean hasOptions()
      {
        return (this.bitField0_ & 0x8) == 8;
      }
      
      public DescriptorProtos.MethodOptions getOptions()
      {
        if (this.optionsBuilder_ == null) {
          return this.options_;
        }
        return (DescriptorProtos.MethodOptions)this.optionsBuilder_.getMessage();
      }
      
      public Builder setOptions(DescriptorProtos.MethodOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.options_ = value;
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(value);
        }
        this.bitField0_ |= 0x8;
        return this;
      }
      
      public Builder setOptions(DescriptorProtos.MethodOptions.Builder builderForValue)
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = builderForValue.build();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.setMessage(builderForValue.build());
        }
        this.bitField0_ |= 0x8;
        return this;
      }
      
      public Builder mergeOptions(DescriptorProtos.MethodOptions value)
      {
        if (this.optionsBuilder_ == null)
        {
          if (((this.bitField0_ & 0x8) == 8) && (this.options_ != DescriptorProtos.MethodOptions.getDefaultInstance())) {
            this.options_ = DescriptorProtos.MethodOptions.newBuilder(this.options_).mergeFrom(value).buildPartial();
          } else {
            this.options_ = value;
          }
          onChanged();
        }
        else
        {
          this.optionsBuilder_.mergeFrom(value);
        }
        this.bitField0_ |= 0x8;
        return this;
      }
      
      public Builder clearOptions()
      {
        if (this.optionsBuilder_ == null)
        {
          this.options_ = DescriptorProtos.MethodOptions.getDefaultInstance();
          onChanged();
        }
        else
        {
          this.optionsBuilder_.clear();
        }
        this.bitField0_ &= 0xFFFFFFF7;
        return this;
      }
      
      public DescriptorProtos.MethodOptions.Builder getOptionsBuilder()
      {
        this.bitField0_ |= 0x8;
        onChanged();
        return (DescriptorProtos.MethodOptions.Builder)getOptionsFieldBuilder().getBuilder();
      }
      
      public DescriptorProtos.MethodOptionsOrBuilder getOptionsOrBuilder()
      {
        if (this.optionsBuilder_ != null) {
          return (DescriptorProtos.MethodOptionsOrBuilder)this.optionsBuilder_.getMessageOrBuilder();
        }
        return this.options_;
      }
      
      private SingleFieldBuilder<DescriptorProtos.MethodOptions, DescriptorProtos.MethodOptions.Builder, DescriptorProtos.MethodOptionsOrBuilder> getOptionsFieldBuilder()
      {
        if (this.optionsBuilder_ == null)
        {
          this.optionsBuilder_ = new SingleFieldBuilder(this.options_, getParentForChildren(), isClean());
          
          this.options_ = null;
        }
        return this.optionsBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new MethodDescriptorProto(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface FileOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.FileOptions>
  {
    public abstract boolean hasJavaPackage();
    
    public abstract String getJavaPackage();
    
    public abstract ByteString getJavaPackageBytes();
    
    public abstract boolean hasJavaOuterClassname();
    
    public abstract String getJavaOuterClassname();
    
    public abstract ByteString getJavaOuterClassnameBytes();
    
    public abstract boolean hasJavaMultipleFiles();
    
    public abstract boolean getJavaMultipleFiles();
    
    public abstract boolean hasJavaGenerateEqualsAndHash();
    
    public abstract boolean getJavaGenerateEqualsAndHash();
    
    public abstract boolean hasOptimizeFor();
    
    public abstract DescriptorProtos.FileOptions.OptimizeMode getOptimizeFor();
    
    public abstract boolean hasGoPackage();
    
    public abstract String getGoPackage();
    
    public abstract ByteString getGoPackageBytes();
    
    public abstract boolean hasCcGenericServices();
    
    public abstract boolean getCcGenericServices();
    
    public abstract boolean hasJavaGenericServices();
    
    public abstract boolean getJavaGenericServices();
    
    public abstract boolean hasPyGenericServices();
    
    public abstract boolean getPyGenericServices();
    
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class FileOptions
    extends GeneratedMessage.ExtendableMessage<FileOptions>
    implements DescriptorProtos.FileOptionsOrBuilder
  {
    private static final FileOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private FileOptions(GeneratedMessage.ExtendableBuilder<FileOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private FileOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static FileOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public FileOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private FileOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            this.bitField0_ |= 0x1;
            this.javaPackage_ = input.readBytes();
            break;
          case 66: 
            this.bitField0_ |= 0x2;
            this.javaOuterClassname_ = input.readBytes();
            break;
          case 72: 
            int rawValue = input.readEnum();
            OptimizeMode value = OptimizeMode.valueOf(rawValue);
            if (value == null)
            {
              unknownFields.mergeVarintField(9, rawValue);
            }
            else
            {
              this.bitField0_ |= 0x10;
              this.optimizeFor_ = value;
            }
            break;
          case 80: 
            this.bitField0_ |= 0x4;
            this.javaMultipleFiles_ = input.readBool();
            break;
          case 90: 
            this.bitField0_ |= 0x20;
            this.goPackage_ = input.readBytes();
            break;
          case 128: 
            this.bitField0_ |= 0x40;
            this.ccGenericServices_ = input.readBool();
            break;
          case 136: 
            this.bitField0_ |= 0x80;
            this.javaGenericServices_ = input.readBool();
            break;
          case 144: 
            this.bitField0_ |= 0x100;
            this.pyGenericServices_ = input.readBool();
            break;
          case 160: 
            this.bitField0_ |= 0x8;
            this.javaGenerateEqualsAndHash_ = input.readBool();
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x200) != 512)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x200;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x200) == 512) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_FileOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_FileOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(FileOptions.class, Builder.class);
    }
    
    public static Parser<FileOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.FileOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.FileOptions(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int JAVA_PACKAGE_FIELD_NUMBER = 1;
    private Object javaPackage_;
    public static final int JAVA_OUTER_CLASSNAME_FIELD_NUMBER = 8;
    private Object javaOuterClassname_;
    public static final int JAVA_MULTIPLE_FILES_FIELD_NUMBER = 10;
    private boolean javaMultipleFiles_;
    public static final int JAVA_GENERATE_EQUALS_AND_HASH_FIELD_NUMBER = 20;
    private boolean javaGenerateEqualsAndHash_;
    public static final int OPTIMIZE_FOR_FIELD_NUMBER = 9;
    private OptimizeMode optimizeFor_;
    public static final int GO_PACKAGE_FIELD_NUMBER = 11;
    private Object goPackage_;
    public static final int CC_GENERIC_SERVICES_FIELD_NUMBER = 16;
    private boolean ccGenericServices_;
    public static final int JAVA_GENERIC_SERVICES_FIELD_NUMBER = 17;
    private boolean javaGenericServices_;
    public static final int PY_GENERIC_SERVICES_FIELD_NUMBER = 18;
    private boolean pyGenericServices_;
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<FileOptions> getParserForType()
    {
      return PARSER;
    }
    
    public static enum OptimizeMode
      implements ProtocolMessageEnum
    {
      SPEED(0, 1),  CODE_SIZE(1, 2),  LITE_RUNTIME(2, 3);
      
      public static final int SPEED_VALUE = 1;
      public static final int CODE_SIZE_VALUE = 2;
      public static final int LITE_RUNTIME_VALUE = 3;
      
      public final int getNumber()
      {
        return this.value;
      }
      
      public static OptimizeMode valueOf(int value)
      {
        switch (value)
        {
        case 1: 
          return SPEED;
        case 2: 
          return CODE_SIZE;
        case 3: 
          return LITE_RUNTIME;
        }
        return null;
      }
      
      public static Internal.EnumLiteMap<OptimizeMode> internalGetValueMap()
      {
        return internalValueMap;
      }
      
      private static Internal.EnumLiteMap<OptimizeMode> internalValueMap = new Internal.EnumLiteMap()
      {
        public DescriptorProtos.FileOptions.OptimizeMode findValueByNumber(int number)
        {
          return DescriptorProtos.FileOptions.OptimizeMode.valueOf(number);
        }
      };
      
      public final Descriptors.EnumValueDescriptor getValueDescriptor()
      {
        return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
      }
      
      public final Descriptors.EnumDescriptor getDescriptorForType()
      {
        return getDescriptor();
      }
      
      public static final Descriptors.EnumDescriptor getDescriptor()
      {
        return (Descriptors.EnumDescriptor)DescriptorProtos.FileOptions.getDescriptor().getEnumTypes().get(0);
      }
      
      private static final OptimizeMode[] VALUES = values();
      private final int index;
      private final int value;
      
      public static OptimizeMode valueOf(Descriptors.EnumValueDescriptor desc)
      {
        if (desc.getType() != getDescriptor()) {
          throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
        }
        return VALUES[desc.getIndex()];
      }
      
      private OptimizeMode(int index, int value)
      {
        this.index = index;
        this.value = value;
      }
    }
    
    public boolean hasJavaPackage()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getJavaPackage()
    {
      Object ref = this.javaPackage_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.javaPackage_ = s;
      }
      return s;
    }
    
    public ByteString getJavaPackageBytes()
    {
      Object ref = this.javaPackage_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.javaPackage_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasJavaOuterClassname()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public String getJavaOuterClassname()
    {
      Object ref = this.javaOuterClassname_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.javaOuterClassname_ = s;
      }
      return s;
    }
    
    public ByteString getJavaOuterClassnameBytes()
    {
      Object ref = this.javaOuterClassname_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.javaOuterClassname_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasJavaMultipleFiles()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public boolean getJavaMultipleFiles()
    {
      return this.javaMultipleFiles_;
    }
    
    public boolean hasJavaGenerateEqualsAndHash()
    {
      return (this.bitField0_ & 0x8) == 8;
    }
    
    public boolean getJavaGenerateEqualsAndHash()
    {
      return this.javaGenerateEqualsAndHash_;
    }
    
    public boolean hasOptimizeFor()
    {
      return (this.bitField0_ & 0x10) == 16;
    }
    
    public OptimizeMode getOptimizeFor()
    {
      return this.optimizeFor_;
    }
    
    public boolean hasGoPackage()
    {
      return (this.bitField0_ & 0x20) == 32;
    }
    
    public String getGoPackage()
    {
      Object ref = this.goPackage_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.goPackage_ = s;
      }
      return s;
    }
    
    public ByteString getGoPackageBytes()
    {
      Object ref = this.goPackage_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.goPackage_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasCcGenericServices()
    {
      return (this.bitField0_ & 0x40) == 64;
    }
    
    public boolean getCcGenericServices()
    {
      return this.ccGenericServices_;
    }
    
    public boolean hasJavaGenericServices()
    {
      return (this.bitField0_ & 0x80) == 128;
    }
    
    public boolean getJavaGenericServices()
    {
      return this.javaGenericServices_;
    }
    
    public boolean hasPyGenericServices()
    {
      return (this.bitField0_ & 0x100) == 256;
    }
    
    public boolean getPyGenericServices()
    {
      return this.pyGenericServices_;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.javaPackage_ = "";
      this.javaOuterClassname_ = "";
      this.javaMultipleFiles_ = false;
      this.javaGenerateEqualsAndHash_ = false;
      this.optimizeFor_ = OptimizeMode.SPEED;
      this.goPackage_ = "";
      this.ccGenericServices_ = false;
      this.javaGenericServices_ = false;
      this.pyGenericServices_ = false;
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<FileOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(1, getJavaPackageBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeBytes(8, getJavaOuterClassnameBytes());
      }
      if ((this.bitField0_ & 0x10) == 16) {
        output.writeEnum(9, this.optimizeFor_.getNumber());
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeBool(10, this.javaMultipleFiles_);
      }
      if ((this.bitField0_ & 0x20) == 32) {
        output.writeBytes(11, getGoPackageBytes());
      }
      if ((this.bitField0_ & 0x40) == 64) {
        output.writeBool(16, this.ccGenericServices_);
      }
      if ((this.bitField0_ & 0x80) == 128) {
        output.writeBool(17, this.javaGenericServices_);
      }
      if ((this.bitField0_ & 0x100) == 256) {
        output.writeBool(18, this.pyGenericServices_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        output.writeBool(20, this.javaGenerateEqualsAndHash_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(1, getJavaPackageBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeBytesSize(8, getJavaOuterClassnameBytes());
      }
      if ((this.bitField0_ & 0x10) == 16) {
        size += CodedOutputStream.computeEnumSize(9, this.optimizeFor_.getNumber());
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeBoolSize(10, this.javaMultipleFiles_);
      }
      if ((this.bitField0_ & 0x20) == 32) {
        size += CodedOutputStream.computeBytesSize(11, getGoPackageBytes());
      }
      if ((this.bitField0_ & 0x40) == 64) {
        size += CodedOutputStream.computeBoolSize(16, this.ccGenericServices_);
      }
      if ((this.bitField0_ & 0x80) == 128) {
        size += CodedOutputStream.computeBoolSize(17, this.javaGenericServices_);
      }
      if ((this.bitField0_ & 0x100) == 256) {
        size += CodedOutputStream.computeBoolSize(18, this.pyGenericServices_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        size += CodedOutputStream.computeBoolSize(20, this.javaGenerateEqualsAndHash_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static FileOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (FileOptions)PARSER.parseFrom(data);
    }
    
    public static FileOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FileOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FileOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (FileOptions)PARSER.parseFrom(data);
    }
    
    public static FileOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FileOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FileOptions parseFrom(InputStream input)
      throws IOException
    {
      return (FileOptions)PARSER.parseFrom(input);
    }
    
    public static FileOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static FileOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (FileOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static FileOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static FileOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (FileOptions)PARSER.parseFrom(input);
    }
    
    public static FileOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FileOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$10700();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(FileOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.FileOptions, Builder>
      implements DescriptorProtos.FileOptionsOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.FileOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.javaPackage_ = "";
        this.bitField0_ &= 0xFFFFFFFE;
        this.javaOuterClassname_ = "";
        this.bitField0_ &= 0xFFFFFFFD;
        this.javaMultipleFiles_ = false;
        this.bitField0_ &= 0xFFFFFFFB;
        this.javaGenerateEqualsAndHash_ = false;
        this.bitField0_ &= 0xFFFFFFF7;
        this.optimizeFor_ = DescriptorProtos.FileOptions.OptimizeMode.SPEED;
        this.bitField0_ &= 0xFFFFFFEF;
        this.goPackage_ = "";
        this.bitField0_ &= 0xFFFFFFDF;
        this.ccGenericServices_ = false;
        this.bitField0_ &= 0xFFFFFFBF;
        this.javaGenericServices_ = false;
        this.bitField0_ &= 0xFF7F;
        this.pyGenericServices_ = false;
        this.bitField0_ &= 0xFEFF;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFDFF;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_FileOptions_descriptor;
      }
      
      public DescriptorProtos.FileOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.FileOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.FileOptions build()
      {
        DescriptorProtos.FileOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.FileOptions buildPartial()
      {
        DescriptorProtos.FileOptions result = new DescriptorProtos.FileOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.javaPackage_ = this.javaPackage_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.javaOuterClassname_ = this.javaOuterClassname_;
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x4;
        }
        result.javaMultipleFiles_ = this.javaMultipleFiles_;
        if ((from_bitField0_ & 0x8) == 8) {
          to_bitField0_ |= 0x8;
        }
        result.javaGenerateEqualsAndHash_ = this.javaGenerateEqualsAndHash_;
        if ((from_bitField0_ & 0x10) == 16) {
          to_bitField0_ |= 0x10;
        }
        result.optimizeFor_ = this.optimizeFor_;
        if ((from_bitField0_ & 0x20) == 32) {
          to_bitField0_ |= 0x20;
        }
        result.goPackage_ = this.goPackage_;
        if ((from_bitField0_ & 0x40) == 64) {
          to_bitField0_ |= 0x40;
        }
        result.ccGenericServices_ = this.ccGenericServices_;
        if ((from_bitField0_ & 0x80) == 128) {
          to_bitField0_ |= 0x80;
        }
        result.javaGenericServices_ = this.javaGenericServices_;
        if ((from_bitField0_ & 0x100) == 256) {
          to_bitField0_ |= 0x100;
        }
        result.pyGenericServices_ = this.pyGenericServices_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x200) == 512)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFDFF;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.FileOptions)) {
          return mergeFrom((DescriptorProtos.FileOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.FileOptions other)
      {
        if (other == DescriptorProtos.FileOptions.getDefaultInstance()) {
          return this;
        }
        if (other.hasJavaPackage())
        {
          this.bitField0_ |= 0x1;
          this.javaPackage_ = other.javaPackage_;
          onChanged();
        }
        if (other.hasJavaOuterClassname())
        {
          this.bitField0_ |= 0x2;
          this.javaOuterClassname_ = other.javaOuterClassname_;
          onChanged();
        }
        if (other.hasJavaMultipleFiles()) {
          setJavaMultipleFiles(other.getJavaMultipleFiles());
        }
        if (other.hasJavaGenerateEqualsAndHash()) {
          setJavaGenerateEqualsAndHash(other.getJavaGenerateEqualsAndHash());
        }
        if (other.hasOptimizeFor()) {
          setOptimizeFor(other.getOptimizeFor());
        }
        if (other.hasGoPackage())
        {
          this.bitField0_ |= 0x20;
          this.goPackage_ = other.goPackage_;
          onChanged();
        }
        if (other.hasCcGenericServices()) {
          setCcGenericServices(other.getCcGenericServices());
        }
        if (other.hasJavaGenericServices()) {
          setJavaGenericServices(other.getJavaGenericServices());
        }
        if (other.hasPyGenericServices()) {
          setPyGenericServices(other.getPyGenericServices());
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFDFF;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFDFF;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.FileOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.FileOptions)DescriptorProtos.FileOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.FileOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private Object javaPackage_ = "";
      
      public boolean hasJavaPackage()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getJavaPackage()
      {
        Object ref = this.javaPackage_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.javaPackage_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getJavaPackageBytes()
      {
        Object ref = this.javaPackage_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.javaPackage_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setJavaPackage(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.javaPackage_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearJavaPackage()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.javaPackage_ = DescriptorProtos.FileOptions.getDefaultInstance().getJavaPackage();
        onChanged();
        return this;
      }
      
      public Builder setJavaPackageBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.javaPackage_ = value;
        onChanged();
        return this;
      }
      
      private Object javaOuterClassname_ = "";
      private boolean javaMultipleFiles_;
      private boolean javaGenerateEqualsAndHash_;
      
      public boolean hasJavaOuterClassname()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public String getJavaOuterClassname()
      {
        Object ref = this.javaOuterClassname_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.javaOuterClassname_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getJavaOuterClassnameBytes()
      {
        Object ref = this.javaOuterClassname_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.javaOuterClassname_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setJavaOuterClassname(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.javaOuterClassname_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearJavaOuterClassname()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.javaOuterClassname_ = DescriptorProtos.FileOptions.getDefaultInstance().getJavaOuterClassname();
        onChanged();
        return this;
      }
      
      public Builder setJavaOuterClassnameBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.javaOuterClassname_ = value;
        onChanged();
        return this;
      }
      
      public boolean hasJavaMultipleFiles()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public boolean getJavaMultipleFiles()
      {
        return this.javaMultipleFiles_;
      }
      
      public Builder setJavaMultipleFiles(boolean value)
      {
        this.bitField0_ |= 0x4;
        this.javaMultipleFiles_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearJavaMultipleFiles()
      {
        this.bitField0_ &= 0xFFFFFFFB;
        this.javaMultipleFiles_ = false;
        onChanged();
        return this;
      }
      
      public boolean hasJavaGenerateEqualsAndHash()
      {
        return (this.bitField0_ & 0x8) == 8;
      }
      
      public boolean getJavaGenerateEqualsAndHash()
      {
        return this.javaGenerateEqualsAndHash_;
      }
      
      public Builder setJavaGenerateEqualsAndHash(boolean value)
      {
        this.bitField0_ |= 0x8;
        this.javaGenerateEqualsAndHash_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearJavaGenerateEqualsAndHash()
      {
        this.bitField0_ &= 0xFFFFFFF7;
        this.javaGenerateEqualsAndHash_ = false;
        onChanged();
        return this;
      }
      
      private DescriptorProtos.FileOptions.OptimizeMode optimizeFor_ = DescriptorProtos.FileOptions.OptimizeMode.SPEED;
      
      public boolean hasOptimizeFor()
      {
        return (this.bitField0_ & 0x10) == 16;
      }
      
      public DescriptorProtos.FileOptions.OptimizeMode getOptimizeFor()
      {
        return this.optimizeFor_;
      }
      
      public Builder setOptimizeFor(DescriptorProtos.FileOptions.OptimizeMode value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x10;
        this.optimizeFor_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearOptimizeFor()
      {
        this.bitField0_ &= 0xFFFFFFEF;
        this.optimizeFor_ = DescriptorProtos.FileOptions.OptimizeMode.SPEED;
        onChanged();
        return this;
      }
      
      private Object goPackage_ = "";
      private boolean ccGenericServices_;
      private boolean javaGenericServices_;
      private boolean pyGenericServices_;
      
      public boolean hasGoPackage()
      {
        return (this.bitField0_ & 0x20) == 32;
      }
      
      public String getGoPackage()
      {
        Object ref = this.goPackage_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.goPackage_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getGoPackageBytes()
      {
        Object ref = this.goPackage_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.goPackage_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setGoPackage(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x20;
        this.goPackage_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearGoPackage()
      {
        this.bitField0_ &= 0xFFFFFFDF;
        this.goPackage_ = DescriptorProtos.FileOptions.getDefaultInstance().getGoPackage();
        onChanged();
        return this;
      }
      
      public Builder setGoPackageBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x20;
        this.goPackage_ = value;
        onChanged();
        return this;
      }
      
      public boolean hasCcGenericServices()
      {
        return (this.bitField0_ & 0x40) == 64;
      }
      
      public boolean getCcGenericServices()
      {
        return this.ccGenericServices_;
      }
      
      public Builder setCcGenericServices(boolean value)
      {
        this.bitField0_ |= 0x40;
        this.ccGenericServices_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearCcGenericServices()
      {
        this.bitField0_ &= 0xFFFFFFBF;
        this.ccGenericServices_ = false;
        onChanged();
        return this;
      }
      
      public boolean hasJavaGenericServices()
      {
        return (this.bitField0_ & 0x80) == 128;
      }
      
      public boolean getJavaGenericServices()
      {
        return this.javaGenericServices_;
      }
      
      public Builder setJavaGenericServices(boolean value)
      {
        this.bitField0_ |= 0x80;
        this.javaGenericServices_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearJavaGenericServices()
      {
        this.bitField0_ &= 0xFF7F;
        this.javaGenericServices_ = false;
        onChanged();
        return this;
      }
      
      public boolean hasPyGenericServices()
      {
        return (this.bitField0_ & 0x100) == 256;
      }
      
      public boolean getPyGenericServices()
      {
        return this.pyGenericServices_;
      }
      
      public Builder setPyGenericServices(boolean value)
      {
        this.bitField0_ |= 0x100;
        this.pyGenericServices_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearPyGenericServices()
      {
        this.bitField0_ &= 0xFEFF;
        this.pyGenericServices_ = false;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x200) != 512)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x200;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFDFF;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x200) == 512, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new FileOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface MessageOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.MessageOptions>
  {
    public abstract boolean hasMessageSetWireFormat();
    
    public abstract boolean getMessageSetWireFormat();
    
    public abstract boolean hasNoStandardDescriptorAccessor();
    
    public abstract boolean getNoStandardDescriptorAccessor();
    
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class MessageOptions
    extends GeneratedMessage.ExtendableMessage<MessageOptions>
    implements DescriptorProtos.MessageOptionsOrBuilder
  {
    private static final MessageOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private MessageOptions(GeneratedMessage.ExtendableBuilder<MessageOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private MessageOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static MessageOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public MessageOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private MessageOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 8: 
            this.bitField0_ |= 0x1;
            this.messageSetWireFormat_ = input.readBool();
            break;
          case 16: 
            this.bitField0_ |= 0x2;
            this.noStandardDescriptorAccessor_ = input.readBool();
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x4) != 4)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x4;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x4) == 4) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_MessageOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_MessageOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(MessageOptions.class, Builder.class);
    }
    
    public static Parser<MessageOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.MessageOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.MessageOptions(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int MESSAGE_SET_WIRE_FORMAT_FIELD_NUMBER = 1;
    private boolean messageSetWireFormat_;
    public static final int NO_STANDARD_DESCRIPTOR_ACCESSOR_FIELD_NUMBER = 2;
    private boolean noStandardDescriptorAccessor_;
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<MessageOptions> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasMessageSetWireFormat()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public boolean getMessageSetWireFormat()
    {
      return this.messageSetWireFormat_;
    }
    
    public boolean hasNoStandardDescriptorAccessor()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public boolean getNoStandardDescriptorAccessor()
    {
      return this.noStandardDescriptorAccessor_;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.messageSetWireFormat_ = false;
      this.noStandardDescriptorAccessor_ = false;
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<MessageOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBool(1, this.messageSetWireFormat_);
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeBool(2, this.noStandardDescriptorAccessor_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBoolSize(1, this.messageSetWireFormat_);
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeBoolSize(2, this.noStandardDescriptorAccessor_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static MessageOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (MessageOptions)PARSER.parseFrom(data);
    }
    
    public static MessageOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (MessageOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static MessageOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (MessageOptions)PARSER.parseFrom(data);
    }
    
    public static MessageOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (MessageOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static MessageOptions parseFrom(InputStream input)
      throws IOException
    {
      return (MessageOptions)PARSER.parseFrom(input);
    }
    
    public static MessageOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MessageOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static MessageOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (MessageOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static MessageOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MessageOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static MessageOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (MessageOptions)PARSER.parseFrom(input);
    }
    
    public static MessageOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MessageOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$12400();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(MessageOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.MessageOptions, Builder>
      implements DescriptorProtos.MessageOptionsOrBuilder
    {
      private int bitField0_;
      private boolean messageSetWireFormat_;
      private boolean noStandardDescriptorAccessor_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_MessageOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_MessageOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.MessageOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.messageSetWireFormat_ = false;
        this.bitField0_ &= 0xFFFFFFFE;
        this.noStandardDescriptorAccessor_ = false;
        this.bitField0_ &= 0xFFFFFFFD;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFB;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_MessageOptions_descriptor;
      }
      
      public DescriptorProtos.MessageOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.MessageOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.MessageOptions build()
      {
        DescriptorProtos.MessageOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.MessageOptions buildPartial()
      {
        DescriptorProtos.MessageOptions result = new DescriptorProtos.MessageOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.messageSetWireFormat_ = this.messageSetWireFormat_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.noStandardDescriptorAccessor_ = this.noStandardDescriptorAccessor_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x4) == 4)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFFFFFFFB;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.MessageOptions)) {
          return mergeFrom((DescriptorProtos.MessageOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.MessageOptions other)
      {
        if (other == DescriptorProtos.MessageOptions.getDefaultInstance()) {
          return this;
        }
        if (other.hasMessageSetWireFormat()) {
          setMessageSetWireFormat(other.getMessageSetWireFormat());
        }
        if (other.hasNoStandardDescriptorAccessor()) {
          setNoStandardDescriptorAccessor(other.getNoStandardDescriptorAccessor());
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFFFFFFFB;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFFFFFFFB;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.MessageOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.MessageOptions)DescriptorProtos.MessageOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.MessageOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      public boolean hasMessageSetWireFormat()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public boolean getMessageSetWireFormat()
      {
        return this.messageSetWireFormat_;
      }
      
      public Builder setMessageSetWireFormat(boolean value)
      {
        this.bitField0_ |= 0x1;
        this.messageSetWireFormat_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearMessageSetWireFormat()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.messageSetWireFormat_ = false;
        onChanged();
        return this;
      }
      
      public boolean hasNoStandardDescriptorAccessor()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public boolean getNoStandardDescriptorAccessor()
      {
        return this.noStandardDescriptorAccessor_;
      }
      
      public Builder setNoStandardDescriptorAccessor(boolean value)
      {
        this.bitField0_ |= 0x2;
        this.noStandardDescriptorAccessor_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearNoStandardDescriptorAccessor()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.noStandardDescriptorAccessor_ = false;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x4) != 4)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x4;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFB;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x4) == 4, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new MessageOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface FieldOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.FieldOptions>
  {
    public abstract boolean hasCtype();
    
    public abstract DescriptorProtos.FieldOptions.CType getCtype();
    
    public abstract boolean hasPacked();
    
    public abstract boolean getPacked();
    
    public abstract boolean hasLazy();
    
    public abstract boolean getLazy();
    
    public abstract boolean hasDeprecated();
    
    public abstract boolean getDeprecated();
    
    public abstract boolean hasExperimentalMapKey();
    
    public abstract String getExperimentalMapKey();
    
    public abstract ByteString getExperimentalMapKeyBytes();
    
    public abstract boolean hasWeak();
    
    public abstract boolean getWeak();
    
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class FieldOptions
    extends GeneratedMessage.ExtendableMessage<FieldOptions>
    implements DescriptorProtos.FieldOptionsOrBuilder
  {
    private static final FieldOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private FieldOptions(GeneratedMessage.ExtendableBuilder<FieldOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private FieldOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static FieldOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public FieldOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private FieldOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 8: 
            int rawValue = input.readEnum();
            CType value = CType.valueOf(rawValue);
            if (value == null)
            {
              unknownFields.mergeVarintField(1, rawValue);
            }
            else
            {
              this.bitField0_ |= 0x1;
              this.ctype_ = value;
            }
            break;
          case 16: 
            this.bitField0_ |= 0x2;
            this.packed_ = input.readBool();
            break;
          case 24: 
            this.bitField0_ |= 0x8;
            this.deprecated_ = input.readBool();
            break;
          case 40: 
            this.bitField0_ |= 0x4;
            this.lazy_ = input.readBool();
            break;
          case 74: 
            this.bitField0_ |= 0x10;
            this.experimentalMapKey_ = input.readBytes();
            break;
          case 80: 
            this.bitField0_ |= 0x20;
            this.weak_ = input.readBool();
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x40) != 64)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x40;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x40) == 64) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_FieldOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_FieldOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(FieldOptions.class, Builder.class);
    }
    
    public static Parser<FieldOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.FieldOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.FieldOptions(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int CTYPE_FIELD_NUMBER = 1;
    private CType ctype_;
    public static final int PACKED_FIELD_NUMBER = 2;
    private boolean packed_;
    public static final int LAZY_FIELD_NUMBER = 5;
    private boolean lazy_;
    public static final int DEPRECATED_FIELD_NUMBER = 3;
    private boolean deprecated_;
    public static final int EXPERIMENTAL_MAP_KEY_FIELD_NUMBER = 9;
    private Object experimentalMapKey_;
    public static final int WEAK_FIELD_NUMBER = 10;
    private boolean weak_;
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<FieldOptions> getParserForType()
    {
      return PARSER;
    }
    
    public static enum CType
      implements ProtocolMessageEnum
    {
      STRING(0, 0),  CORD(1, 1),  STRING_PIECE(2, 2);
      
      public static final int STRING_VALUE = 0;
      public static final int CORD_VALUE = 1;
      public static final int STRING_PIECE_VALUE = 2;
      
      public final int getNumber()
      {
        return this.value;
      }
      
      public static CType valueOf(int value)
      {
        switch (value)
        {
        case 0: 
          return STRING;
        case 1: 
          return CORD;
        case 2: 
          return STRING_PIECE;
        }
        return null;
      }
      
      public static Internal.EnumLiteMap<CType> internalGetValueMap()
      {
        return internalValueMap;
      }
      
      private static Internal.EnumLiteMap<CType> internalValueMap = new Internal.EnumLiteMap()
      {
        public DescriptorProtos.FieldOptions.CType findValueByNumber(int number)
        {
          return DescriptorProtos.FieldOptions.CType.valueOf(number);
        }
      };
      
      public final Descriptors.EnumValueDescriptor getValueDescriptor()
      {
        return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(this.index);
      }
      
      public final Descriptors.EnumDescriptor getDescriptorForType()
      {
        return getDescriptor();
      }
      
      public static final Descriptors.EnumDescriptor getDescriptor()
      {
        return (Descriptors.EnumDescriptor)DescriptorProtos.FieldOptions.getDescriptor().getEnumTypes().get(0);
      }
      
      private static final CType[] VALUES = values();
      private final int index;
      private final int value;
      
      public static CType valueOf(Descriptors.EnumValueDescriptor desc)
      {
        if (desc.getType() != getDescriptor()) {
          throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
        }
        return VALUES[desc.getIndex()];
      }
      
      private CType(int index, int value)
      {
        this.index = index;
        this.value = value;
      }
    }
    
    public boolean hasCtype()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public CType getCtype()
    {
      return this.ctype_;
    }
    
    public boolean hasPacked()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public boolean getPacked()
    {
      return this.packed_;
    }
    
    public boolean hasLazy()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public boolean getLazy()
    {
      return this.lazy_;
    }
    
    public boolean hasDeprecated()
    {
      return (this.bitField0_ & 0x8) == 8;
    }
    
    public boolean getDeprecated()
    {
      return this.deprecated_;
    }
    
    public boolean hasExperimentalMapKey()
    {
      return (this.bitField0_ & 0x10) == 16;
    }
    
    public String getExperimentalMapKey()
    {
      Object ref = this.experimentalMapKey_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.experimentalMapKey_ = s;
      }
      return s;
    }
    
    public ByteString getExperimentalMapKeyBytes()
    {
      Object ref = this.experimentalMapKey_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.experimentalMapKey_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasWeak()
    {
      return (this.bitField0_ & 0x20) == 32;
    }
    
    public boolean getWeak()
    {
      return this.weak_;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.ctype_ = CType.STRING;
      this.packed_ = false;
      this.lazy_ = false;
      this.deprecated_ = false;
      this.experimentalMapKey_ = "";
      this.weak_ = false;
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<FieldOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeEnum(1, this.ctype_.getNumber());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeBool(2, this.packed_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        output.writeBool(3, this.deprecated_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeBool(5, this.lazy_);
      }
      if ((this.bitField0_ & 0x10) == 16) {
        output.writeBytes(9, getExperimentalMapKeyBytes());
      }
      if ((this.bitField0_ & 0x20) == 32) {
        output.writeBool(10, this.weak_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeEnumSize(1, this.ctype_.getNumber());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeBoolSize(2, this.packed_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        size += CodedOutputStream.computeBoolSize(3, this.deprecated_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeBoolSize(5, this.lazy_);
      }
      if ((this.bitField0_ & 0x10) == 16) {
        size += CodedOutputStream.computeBytesSize(9, getExperimentalMapKeyBytes());
      }
      if ((this.bitField0_ & 0x20) == 32) {
        size += CodedOutputStream.computeBoolSize(10, this.weak_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static FieldOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (FieldOptions)PARSER.parseFrom(data);
    }
    
    public static FieldOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FieldOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FieldOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (FieldOptions)PARSER.parseFrom(data);
    }
    
    public static FieldOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (FieldOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static FieldOptions parseFrom(InputStream input)
      throws IOException
    {
      return (FieldOptions)PARSER.parseFrom(input);
    }
    
    public static FieldOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FieldOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static FieldOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (FieldOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static FieldOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FieldOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static FieldOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (FieldOptions)PARSER.parseFrom(input);
    }
    
    public static FieldOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (FieldOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$13400();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(FieldOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.FieldOptions, Builder>
      implements DescriptorProtos.FieldOptionsOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_FieldOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_FieldOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.FieldOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.ctype_ = DescriptorProtos.FieldOptions.CType.STRING;
        this.bitField0_ &= 0xFFFFFFFE;
        this.packed_ = false;
        this.bitField0_ &= 0xFFFFFFFD;
        this.lazy_ = false;
        this.bitField0_ &= 0xFFFFFFFB;
        this.deprecated_ = false;
        this.bitField0_ &= 0xFFFFFFF7;
        this.experimentalMapKey_ = "";
        this.bitField0_ &= 0xFFFFFFEF;
        this.weak_ = false;
        this.bitField0_ &= 0xFFFFFFDF;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFBF;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_FieldOptions_descriptor;
      }
      
      public DescriptorProtos.FieldOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.FieldOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.FieldOptions build()
      {
        DescriptorProtos.FieldOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.FieldOptions buildPartial()
      {
        DescriptorProtos.FieldOptions result = new DescriptorProtos.FieldOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.ctype_ = this.ctype_;
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x2;
        }
        result.packed_ = this.packed_;
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x4;
        }
        result.lazy_ = this.lazy_;
        if ((from_bitField0_ & 0x8) == 8) {
          to_bitField0_ |= 0x8;
        }
        result.deprecated_ = this.deprecated_;
        if ((from_bitField0_ & 0x10) == 16) {
          to_bitField0_ |= 0x10;
        }
        result.experimentalMapKey_ = this.experimentalMapKey_;
        if ((from_bitField0_ & 0x20) == 32) {
          to_bitField0_ |= 0x20;
        }
        result.weak_ = this.weak_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x40) == 64)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFFFFFFBF;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.FieldOptions)) {
          return mergeFrom((DescriptorProtos.FieldOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.FieldOptions other)
      {
        if (other == DescriptorProtos.FieldOptions.getDefaultInstance()) {
          return this;
        }
        if (other.hasCtype()) {
          setCtype(other.getCtype());
        }
        if (other.hasPacked()) {
          setPacked(other.getPacked());
        }
        if (other.hasLazy()) {
          setLazy(other.getLazy());
        }
        if (other.hasDeprecated()) {
          setDeprecated(other.getDeprecated());
        }
        if (other.hasExperimentalMapKey())
        {
          this.bitField0_ |= 0x10;
          this.experimentalMapKey_ = other.experimentalMapKey_;
          onChanged();
        }
        if (other.hasWeak()) {
          setWeak(other.getWeak());
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFFFFFFBF;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFFFFFFBF;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.FieldOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.FieldOptions)DescriptorProtos.FieldOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.FieldOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private DescriptorProtos.FieldOptions.CType ctype_ = DescriptorProtos.FieldOptions.CType.STRING;
      private boolean packed_;
      private boolean lazy_;
      private boolean deprecated_;
      
      public boolean hasCtype()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public DescriptorProtos.FieldOptions.CType getCtype()
      {
        return this.ctype_;
      }
      
      public Builder setCtype(DescriptorProtos.FieldOptions.CType value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x1;
        this.ctype_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearCtype()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.ctype_ = DescriptorProtos.FieldOptions.CType.STRING;
        onChanged();
        return this;
      }
      
      public boolean hasPacked()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public boolean getPacked()
      {
        return this.packed_;
      }
      
      public Builder setPacked(boolean value)
      {
        this.bitField0_ |= 0x2;
        this.packed_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearPacked()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.packed_ = false;
        onChanged();
        return this;
      }
      
      public boolean hasLazy()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public boolean getLazy()
      {
        return this.lazy_;
      }
      
      public Builder setLazy(boolean value)
      {
        this.bitField0_ |= 0x4;
        this.lazy_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearLazy()
      {
        this.bitField0_ &= 0xFFFFFFFB;
        this.lazy_ = false;
        onChanged();
        return this;
      }
      
      public boolean hasDeprecated()
      {
        return (this.bitField0_ & 0x8) == 8;
      }
      
      public boolean getDeprecated()
      {
        return this.deprecated_;
      }
      
      public Builder setDeprecated(boolean value)
      {
        this.bitField0_ |= 0x8;
        this.deprecated_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearDeprecated()
      {
        this.bitField0_ &= 0xFFFFFFF7;
        this.deprecated_ = false;
        onChanged();
        return this;
      }
      
      private Object experimentalMapKey_ = "";
      private boolean weak_;
      
      public boolean hasExperimentalMapKey()
      {
        return (this.bitField0_ & 0x10) == 16;
      }
      
      public String getExperimentalMapKey()
      {
        Object ref = this.experimentalMapKey_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.experimentalMapKey_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getExperimentalMapKeyBytes()
      {
        Object ref = this.experimentalMapKey_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.experimentalMapKey_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setExperimentalMapKey(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x10;
        this.experimentalMapKey_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearExperimentalMapKey()
      {
        this.bitField0_ &= 0xFFFFFFEF;
        this.experimentalMapKey_ = DescriptorProtos.FieldOptions.getDefaultInstance().getExperimentalMapKey();
        onChanged();
        return this;
      }
      
      public Builder setExperimentalMapKeyBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x10;
        this.experimentalMapKey_ = value;
        onChanged();
        return this;
      }
      
      public boolean hasWeak()
      {
        return (this.bitField0_ & 0x20) == 32;
      }
      
      public boolean getWeak()
      {
        return this.weak_;
      }
      
      public Builder setWeak(boolean value)
      {
        this.bitField0_ |= 0x20;
        this.weak_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearWeak()
      {
        this.bitField0_ &= 0xFFFFFFDF;
        this.weak_ = false;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x40) != 64)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x40;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFBF;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x40) == 64, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new FieldOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface EnumOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.EnumOptions>
  {
    public abstract boolean hasAllowAlias();
    
    public abstract boolean getAllowAlias();
    
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class EnumOptions
    extends GeneratedMessage.ExtendableMessage<EnumOptions>
    implements DescriptorProtos.EnumOptionsOrBuilder
  {
    private static final EnumOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private EnumOptions(GeneratedMessage.ExtendableBuilder<EnumOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private EnumOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static EnumOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public EnumOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private EnumOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 16: 
            this.bitField0_ |= 0x1;
            this.allowAlias_ = input.readBool();
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x2) != 2)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x2;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x2) == 2) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(EnumOptions.class, Builder.class);
    }
    
    public static Parser<EnumOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.EnumOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.EnumOptions(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int ALLOW_ALIAS_FIELD_NUMBER = 2;
    private boolean allowAlias_;
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<EnumOptions> getParserForType()
    {
      return PARSER;
    }
    
    public boolean hasAllowAlias()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public boolean getAllowAlias()
    {
      return this.allowAlias_;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.allowAlias_ = true;
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<EnumOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBool(2, this.allowAlias_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBoolSize(2, this.allowAlias_);
      }
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static EnumOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (EnumOptions)PARSER.parseFrom(data);
    }
    
    public static EnumOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (EnumOptions)PARSER.parseFrom(data);
    }
    
    public static EnumOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumOptions parseFrom(InputStream input)
      throws IOException
    {
      return (EnumOptions)PARSER.parseFrom(input);
    }
    
    public static EnumOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static EnumOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (EnumOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static EnumOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static EnumOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (EnumOptions)PARSER.parseFrom(input);
    }
    
    public static EnumOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$14800();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(EnumOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.EnumOptions, Builder>
      implements DescriptorProtos.EnumOptionsOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.EnumOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        this.allowAlias_ = true;
        this.bitField0_ &= 0xFFFFFFFE;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumOptions_descriptor;
      }
      
      public DescriptorProtos.EnumOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.EnumOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.EnumOptions build()
      {
        DescriptorProtos.EnumOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.EnumOptions buildPartial()
      {
        DescriptorProtos.EnumOptions result = new DescriptorProtos.EnumOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if ((from_bitField0_ & 0x1) == 1) {
          to_bitField0_ |= 0x1;
        }
        result.allowAlias_ = this.allowAlias_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x2) == 2)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFFFFFFFD;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.EnumOptions)) {
          return mergeFrom((DescriptorProtos.EnumOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.EnumOptions other)
      {
        if (other == DescriptorProtos.EnumOptions.getDefaultInstance()) {
          return this;
        }
        if (other.hasAllowAlias()) {
          setAllowAlias(other.getAllowAlias());
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFFFFFFFD;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFFFFFFFD;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.EnumOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.EnumOptions)DescriptorProtos.EnumOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.EnumOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private boolean allowAlias_ = true;
      
      public boolean hasAllowAlias()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public boolean getAllowAlias()
      {
        return this.allowAlias_;
      }
      
      public Builder setAllowAlias(boolean value)
      {
        this.bitField0_ |= 0x1;
        this.allowAlias_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearAllowAlias()
      {
        this.bitField0_ &= 0xFFFFFFFE;
        this.allowAlias_ = true;
        onChanged();
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x2) != 2)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x2;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x2) == 2, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new EnumOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface EnumValueOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.EnumValueOptions>
  {
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class EnumValueOptions
    extends GeneratedMessage.ExtendableMessage<EnumValueOptions>
    implements DescriptorProtos.EnumValueOptionsOrBuilder
  {
    private static final EnumValueOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private EnumValueOptions(GeneratedMessage.ExtendableBuilder<EnumValueOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private EnumValueOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static EnumValueOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public EnumValueOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private EnumValueOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x1) != 1)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x1;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x1) == 1) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumValueOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_EnumValueOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(EnumValueOptions.class, Builder.class);
    }
    
    public static Parser<EnumValueOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.EnumValueOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.EnumValueOptions(input, extensionRegistry, null);
      }
    };
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<EnumValueOptions> getParserForType()
    {
      return PARSER;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<EnumValueOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static EnumValueOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (EnumValueOptions)PARSER.parseFrom(data);
    }
    
    public static EnumValueOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumValueOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumValueOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (EnumValueOptions)PARSER.parseFrom(data);
    }
    
    public static EnumValueOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (EnumValueOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static EnumValueOptions parseFrom(InputStream input)
      throws IOException
    {
      return (EnumValueOptions)PARSER.parseFrom(input);
    }
    
    public static EnumValueOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumValueOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static EnumValueOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (EnumValueOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static EnumValueOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumValueOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static EnumValueOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (EnumValueOptions)PARSER.parseFrom(input);
    }
    
    public static EnumValueOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (EnumValueOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$15700();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(EnumValueOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.EnumValueOptions, Builder>
      implements DescriptorProtos.EnumValueOptionsOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumValueOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumValueOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.EnumValueOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_EnumValueOptions_descriptor;
      }
      
      public DescriptorProtos.EnumValueOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.EnumValueOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.EnumValueOptions build()
      {
        DescriptorProtos.EnumValueOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.EnumValueOptions buildPartial()
      {
        DescriptorProtos.EnumValueOptions result = new DescriptorProtos.EnumValueOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.EnumValueOptions)) {
          return mergeFrom((DescriptorProtos.EnumValueOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.EnumValueOptions other)
      {
        if (other == DescriptorProtos.EnumValueOptions.getDefaultInstance()) {
          return this;
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFFFFFFFE;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.EnumValueOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.EnumValueOptions)DescriptorProtos.EnumValueOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.EnumValueOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x1) != 1)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x1;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new EnumValueOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface ServiceOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.ServiceOptions>
  {
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class ServiceOptions
    extends GeneratedMessage.ExtendableMessage<ServiceOptions>
    implements DescriptorProtos.ServiceOptionsOrBuilder
  {
    private static final ServiceOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private ServiceOptions(GeneratedMessage.ExtendableBuilder<ServiceOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private ServiceOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static ServiceOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public ServiceOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private ServiceOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x1) != 1)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x1;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x1) == 1) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_ServiceOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_ServiceOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(ServiceOptions.class, Builder.class);
    }
    
    public static Parser<ServiceOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.ServiceOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.ServiceOptions(input, extensionRegistry, null);
      }
    };
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<ServiceOptions> getParserForType()
    {
      return PARSER;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<ServiceOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static ServiceOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (ServiceOptions)PARSER.parseFrom(data);
    }
    
    public static ServiceOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (ServiceOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static ServiceOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (ServiceOptions)PARSER.parseFrom(data);
    }
    
    public static ServiceOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (ServiceOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static ServiceOptions parseFrom(InputStream input)
      throws IOException
    {
      return (ServiceOptions)PARSER.parseFrom(input);
    }
    
    public static ServiceOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (ServiceOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static ServiceOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (ServiceOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static ServiceOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (ServiceOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static ServiceOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (ServiceOptions)PARSER.parseFrom(input);
    }
    
    public static ServiceOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (ServiceOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$16400();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(ServiceOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.ServiceOptions, Builder>
      implements DescriptorProtos.ServiceOptionsOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_ServiceOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_ServiceOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.ServiceOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_ServiceOptions_descriptor;
      }
      
      public DescriptorProtos.ServiceOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.ServiceOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.ServiceOptions build()
      {
        DescriptorProtos.ServiceOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.ServiceOptions buildPartial()
      {
        DescriptorProtos.ServiceOptions result = new DescriptorProtos.ServiceOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.ServiceOptions)) {
          return mergeFrom((DescriptorProtos.ServiceOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.ServiceOptions other)
      {
        if (other == DescriptorProtos.ServiceOptions.getDefaultInstance()) {
          return this;
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFFFFFFFE;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.ServiceOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.ServiceOptions)DescriptorProtos.ServiceOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.ServiceOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x1) != 1)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x1;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new ServiceOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface MethodOptionsOrBuilder
    extends GeneratedMessage.ExtendableMessageOrBuilder<DescriptorProtos.MethodOptions>
  {
    public abstract List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList();
    
    public abstract DescriptorProtos.UninterpretedOption getUninterpretedOption(int paramInt);
    
    public abstract int getUninterpretedOptionCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int paramInt);
  }
  
  public static final class MethodOptions
    extends GeneratedMessage.ExtendableMessage<MethodOptions>
    implements DescriptorProtos.MethodOptionsOrBuilder
  {
    private static final MethodOptions defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private MethodOptions(GeneratedMessage.ExtendableBuilder<MethodOptions, ?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private MethodOptions(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static MethodOptions getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public MethodOptions getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private MethodOptions(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 7994: 
            if ((mutable_bitField0_ & 0x1) != 1)
            {
              this.uninterpretedOption_ = new ArrayList();
              mutable_bitField0_ |= 0x1;
            }
            this.uninterpretedOption_.add(input.readMessage(DescriptorProtos.UninterpretedOption.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x1) == 1) {
          this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_MethodOptions_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_MethodOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(MethodOptions.class, Builder.class);
    }
    
    public static Parser<MethodOptions> PARSER = new AbstractParser()
    {
      public DescriptorProtos.MethodOptions parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.MethodOptions(input, extensionRegistry, null);
      }
    };
    public static final int UNINTERPRETED_OPTION_FIELD_NUMBER = 999;
    private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_;
    
    public Parser<MethodOptions> getParserForType()
    {
      return PARSER;
    }
    
    public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
    {
      return this.uninterpretedOption_;
    }
    
    public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
    {
      return this.uninterpretedOption_;
    }
    
    public int getUninterpretedOptionCount()
    {
      return this.uninterpretedOption_.size();
    }
    
    public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
    {
      return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
    }
    
    public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
    {
      return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
    }
    
    private void initFields()
    {
      this.uninterpretedOption_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getUninterpretedOptionCount(); i++) {
        if (!getUninterpretedOption(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      if (!extensionsAreInitialized())
      {
        this.memoizedIsInitialized = 0;
        return false;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      
      GeneratedMessage.ExtendableMessage<MethodOptions>.ExtensionWriter extensionWriter = newExtensionWriter();
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        output.writeMessage(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      extensionWriter.writeUntil(536870912, output);
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      for (int i = 0; i < this.uninterpretedOption_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(999, (MessageLite)this.uninterpretedOption_.get(i));
      }
      size += extensionsSerializedSize();
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static MethodOptions parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (MethodOptions)PARSER.parseFrom(data);
    }
    
    public static MethodOptions parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (MethodOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static MethodOptions parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (MethodOptions)PARSER.parseFrom(data);
    }
    
    public static MethodOptions parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (MethodOptions)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static MethodOptions parseFrom(InputStream input)
      throws IOException
    {
      return (MethodOptions)PARSER.parseFrom(input);
    }
    
    public static MethodOptions parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MethodOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static MethodOptions parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (MethodOptions)PARSER.parseDelimitedFrom(input);
    }
    
    public static MethodOptions parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MethodOptions)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static MethodOptions parseFrom(CodedInputStream input)
      throws IOException
    {
      return (MethodOptions)PARSER.parseFrom(input);
    }
    
    public static MethodOptions parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (MethodOptions)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$17100();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(MethodOptions prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.ExtendableBuilder<DescriptorProtos.MethodOptions, Builder>
      implements DescriptorProtos.MethodOptionsOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_MethodOptions_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_MethodOptions_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.MethodOptions.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getUninterpretedOptionFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_MethodOptions_descriptor;
      }
      
      public DescriptorProtos.MethodOptions getDefaultInstanceForType()
      {
        return DescriptorProtos.MethodOptions.getDefaultInstance();
      }
      
      public DescriptorProtos.MethodOptions build()
      {
        DescriptorProtos.MethodOptions result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.MethodOptions buildPartial()
      {
        DescriptorProtos.MethodOptions result = new DescriptorProtos.MethodOptions(this, null);
        int from_bitField0_ = this.bitField0_;
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.uninterpretedOption_ = Collections.unmodifiableList(this.uninterpretedOption_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.uninterpretedOption_ = this.uninterpretedOption_;
        }
        else
        {
          result.uninterpretedOption_ = this.uninterpretedOptionBuilder_.build();
        }
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.MethodOptions)) {
          return mergeFrom((DescriptorProtos.MethodOptions)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.MethodOptions other)
      {
        if (other == DescriptorProtos.MethodOptions.getDefaultInstance()) {
          return this;
        }
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (!other.uninterpretedOption_.isEmpty())
          {
            if (this.uninterpretedOption_.isEmpty())
            {
              this.uninterpretedOption_ = other.uninterpretedOption_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensureUninterpretedOptionIsMutable();
              this.uninterpretedOption_.addAll(other.uninterpretedOption_);
            }
            onChanged();
          }
        }
        else if (!other.uninterpretedOption_.isEmpty()) {
          if (this.uninterpretedOptionBuilder_.isEmpty())
          {
            this.uninterpretedOptionBuilder_.dispose();
            this.uninterpretedOptionBuilder_ = null;
            this.uninterpretedOption_ = other.uninterpretedOption_;
            this.bitField0_ &= 0xFFFFFFFE;
            this.uninterpretedOptionBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getUninterpretedOptionFieldBuilder() : null);
          }
          else
          {
            this.uninterpretedOptionBuilder_.addAllMessages(other.uninterpretedOption_);
          }
        }
        mergeExtensionFields(other);
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getUninterpretedOptionCount(); i++) {
          if (!getUninterpretedOption(i).isInitialized()) {
            return false;
          }
        }
        if (!extensionsAreInitialized()) {
          return false;
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.MethodOptions parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.MethodOptions)DescriptorProtos.MethodOptions.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.MethodOptions)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption> uninterpretedOption_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> uninterpretedOptionBuilder_;
      
      private void ensureUninterpretedOptionIsMutable()
      {
        if ((this.bitField0_ & 0x1) != 1)
        {
          this.uninterpretedOption_ = new ArrayList(this.uninterpretedOption_);
          this.bitField0_ |= 0x1;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption> getUninterpretedOptionList()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return Collections.unmodifiableList(this.uninterpretedOption_);
        }
        return this.uninterpretedOptionBuilder_.getMessageList();
      }
      
      public int getUninterpretedOptionCount()
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return this.uninterpretedOption_.size();
        }
        return this.uninterpretedOptionBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption getUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption)this.uninterpretedOptionBuilder_.getMessage(index);
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption value)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, value);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addUninterpretedOption(DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addUninterpretedOption(int index, DescriptorProtos.UninterpretedOption.Builder builderForValue)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllUninterpretedOption(Iterable<? extends DescriptorProtos.UninterpretedOption> values)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          GeneratedMessage.ExtendableBuilder.addAll(values, this.uninterpretedOption_);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearUninterpretedOption()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOption_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeUninterpretedOption(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          ensureUninterpretedOptionIsMutable();
          this.uninterpretedOption_.remove(index);
          onChanged();
        }
        else
        {
          this.uninterpretedOptionBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.Builder getUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOptionOrBuilder getUninterpretedOptionOrBuilder(int index)
      {
        if (this.uninterpretedOptionBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOption_.get(index);
        }
        return (DescriptorProtos.UninterpretedOptionOrBuilder)this.uninterpretedOptionBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionOrBuilderList()
      {
        if (this.uninterpretedOptionBuilder_ != null) {
          return this.uninterpretedOptionBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.uninterpretedOption_);
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.Builder addUninterpretedOptionBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.Builder)getUninterpretedOptionFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.Builder> getUninterpretedOptionBuilderList()
      {
        return getUninterpretedOptionFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption, DescriptorProtos.UninterpretedOption.Builder, DescriptorProtos.UninterpretedOptionOrBuilder> getUninterpretedOptionFieldBuilder()
      {
        if (this.uninterpretedOptionBuilder_ == null)
        {
          this.uninterpretedOptionBuilder_ = new RepeatedFieldBuilder(this.uninterpretedOption_, (this.bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
          
          this.uninterpretedOption_ = null;
        }
        return this.uninterpretedOptionBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new MethodOptions(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface UninterpretedOptionOrBuilder
    extends MessageOrBuilder
  {
    public abstract List<DescriptorProtos.UninterpretedOption.NamePart> getNameList();
    
    public abstract DescriptorProtos.UninterpretedOption.NamePart getName(int paramInt);
    
    public abstract int getNameCount();
    
    public abstract List<? extends DescriptorProtos.UninterpretedOption.NamePartOrBuilder> getNameOrBuilderList();
    
    public abstract DescriptorProtos.UninterpretedOption.NamePartOrBuilder getNameOrBuilder(int paramInt);
    
    public abstract boolean hasIdentifierValue();
    
    public abstract String getIdentifierValue();
    
    public abstract ByteString getIdentifierValueBytes();
    
    public abstract boolean hasPositiveIntValue();
    
    public abstract long getPositiveIntValue();
    
    public abstract boolean hasNegativeIntValue();
    
    public abstract long getNegativeIntValue();
    
    public abstract boolean hasDoubleValue();
    
    public abstract double getDoubleValue();
    
    public abstract boolean hasStringValue();
    
    public abstract ByteString getStringValue();
    
    public abstract boolean hasAggregateValue();
    
    public abstract String getAggregateValue();
    
    public abstract ByteString getAggregateValueBytes();
  }
  
  public static final class UninterpretedOption
    extends GeneratedMessage
    implements DescriptorProtos.UninterpretedOptionOrBuilder
  {
    private static final UninterpretedOption defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private UninterpretedOption(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private UninterpretedOption(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static UninterpretedOption getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public UninterpretedOption getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private UninterpretedOption(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 18: 
            if ((mutable_bitField0_ & 0x1) != 1)
            {
              this.name_ = new ArrayList();
              mutable_bitField0_ |= 0x1;
            }
            this.name_.add(input.readMessage(NamePart.PARSER, extensionRegistry));
            break;
          case 26: 
            this.bitField0_ |= 0x1;
            this.identifierValue_ = input.readBytes();
            break;
          case 32: 
            this.bitField0_ |= 0x2;
            this.positiveIntValue_ = input.readUInt64();
            break;
          case 40: 
            this.bitField0_ |= 0x4;
            this.negativeIntValue_ = input.readInt64();
            break;
          case 49: 
            this.bitField0_ |= 0x8;
            this.doubleValue_ = input.readDouble();
            break;
          case 58: 
            this.bitField0_ |= 0x10;
            this.stringValue_ = input.readBytes();
            break;
          case 66: 
            this.bitField0_ |= 0x20;
            this.aggregateValue_ = input.readBytes();
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x1) == 1) {
          this.name_ = Collections.unmodifiableList(this.name_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_fieldAccessorTable.ensureFieldAccessorsInitialized(UninterpretedOption.class, Builder.class);
    }
    
    public static Parser<UninterpretedOption> PARSER = new AbstractParser()
    {
      public DescriptorProtos.UninterpretedOption parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.UninterpretedOption(input, extensionRegistry, null);
      }
    };
    private int bitField0_;
    public static final int NAME_FIELD_NUMBER = 2;
    private List<NamePart> name_;
    public static final int IDENTIFIER_VALUE_FIELD_NUMBER = 3;
    private Object identifierValue_;
    public static final int POSITIVE_INT_VALUE_FIELD_NUMBER = 4;
    private long positiveIntValue_;
    public static final int NEGATIVE_INT_VALUE_FIELD_NUMBER = 5;
    private long negativeIntValue_;
    public static final int DOUBLE_VALUE_FIELD_NUMBER = 6;
    private double doubleValue_;
    public static final int STRING_VALUE_FIELD_NUMBER = 7;
    private ByteString stringValue_;
    public static final int AGGREGATE_VALUE_FIELD_NUMBER = 8;
    private Object aggregateValue_;
    
    public Parser<UninterpretedOption> getParserForType()
    {
      return PARSER;
    }
    
    public static abstract interface NamePartOrBuilder
      extends MessageOrBuilder
    {
      public abstract boolean hasNamePart();
      
      public abstract String getNamePart();
      
      public abstract ByteString getNamePartBytes();
      
      public abstract boolean hasIsExtension();
      
      public abstract boolean getIsExtension();
    }
    
    public static final class NamePart
      extends GeneratedMessage
      implements DescriptorProtos.UninterpretedOption.NamePartOrBuilder
    {
      private static final NamePart defaultInstance;
      private final UnknownFieldSet unknownFields;
      
      private NamePart(GeneratedMessage.Builder<?> builder)
      {
        super();
        this.unknownFields = builder.getUnknownFields();
      }
      
      private NamePart(boolean noInit)
      {
        this.unknownFields = UnknownFieldSet.getDefaultInstance();
      }
      
      public static NamePart getDefaultInstance()
      {
        return defaultInstance;
      }
      
      public NamePart getDefaultInstanceForType()
      {
        return defaultInstance;
      }
      
      public final UnknownFieldSet getUnknownFields()
      {
        return this.unknownFields;
      }
      
      private NamePart(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        initFields();
        int mutable_bitField0_ = 0;
        UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
        try
        {
          boolean done = false;
          while (!done)
          {
            int tag = input.readTag();
            switch (tag)
            {
            case 0: 
              done = true;
              break;
            default: 
              if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
                done = true;
              }
              break;
            case 10: 
              this.bitField0_ |= 0x1;
              this.namePart_ = input.readBytes();
              break;
            case 16: 
              this.bitField0_ |= 0x2;
              this.isExtension_ = input.readBool();
            }
          }
        }
        catch (InvalidProtocolBufferException e)
        {
          throw e.setUnfinishedMessage(this);
        }
        catch (IOException e)
        {
          throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
        }
        finally
        {
          this.unknownFields = unknownFields.build();
          makeExtensionsImmutable();
        }
      }
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_NamePart_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_NamePart_fieldAccessorTable.ensureFieldAccessorsInitialized(NamePart.class, Builder.class);
      }
      
      public static Parser<NamePart> PARSER = new AbstractParser()
      {
        public DescriptorProtos.UninterpretedOption.NamePart parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
          throws InvalidProtocolBufferException
        {
          return new DescriptorProtos.UninterpretedOption.NamePart(input, extensionRegistry, null);
        }
      };
      private int bitField0_;
      public static final int NAME_PART_FIELD_NUMBER = 1;
      private Object namePart_;
      public static final int IS_EXTENSION_FIELD_NUMBER = 2;
      private boolean isExtension_;
      
      public Parser<NamePart> getParserForType()
      {
        return PARSER;
      }
      
      public boolean hasNamePart()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getNamePart()
      {
        Object ref = this.namePart_;
        if ((ref instanceof String)) {
          return (String)ref;
        }
        ByteString bs = (ByteString)ref;
        
        String s = bs.toStringUtf8();
        if (bs.isValidUtf8()) {
          this.namePart_ = s;
        }
        return s;
      }
      
      public ByteString getNamePartBytes()
      {
        Object ref = this.namePart_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.namePart_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public boolean hasIsExtension()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public boolean getIsExtension()
      {
        return this.isExtension_;
      }
      
      private void initFields()
      {
        this.namePart_ = "";
        this.isExtension_ = false;
      }
      
      private byte memoizedIsInitialized = -1;
      
      public final boolean isInitialized()
      {
        byte isInitialized = this.memoizedIsInitialized;
        if (isInitialized != -1) {
          return isInitialized == 1;
        }
        if (!hasNamePart())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
        if (!hasIsExtension())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
        this.memoizedIsInitialized = 1;
        return true;
      }
      
      public void writeTo(CodedOutputStream output)
        throws IOException
      {
        getSerializedSize();
        if ((this.bitField0_ & 0x1) == 1) {
          output.writeBytes(1, getNamePartBytes());
        }
        if ((this.bitField0_ & 0x2) == 2) {
          output.writeBool(2, this.isExtension_);
        }
        getUnknownFields().writeTo(output);
      }
      
      private int memoizedSerializedSize = -1;
      private static final long serialVersionUID = 0L;
      
      public int getSerializedSize()
      {
        int size = this.memoizedSerializedSize;
        if (size != -1) {
          return size;
        }
        size = 0;
        if ((this.bitField0_ & 0x1) == 1) {
          size += CodedOutputStream.computeBytesSize(1, getNamePartBytes());
        }
        if ((this.bitField0_ & 0x2) == 2) {
          size += CodedOutputStream.computeBoolSize(2, this.isExtension_);
        }
        size += getUnknownFields().getSerializedSize();
        this.memoizedSerializedSize = size;
        return size;
      }
      
      protected Object writeReplace()
        throws ObjectStreamException
      {
        return super.writeReplace();
      }
      
      public static NamePart parseFrom(ByteString data)
        throws InvalidProtocolBufferException
      {
        return (NamePart)PARSER.parseFrom(data);
      }
      
      public static NamePart parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return (NamePart)PARSER.parseFrom(data, extensionRegistry);
      }
      
      public static NamePart parseFrom(byte[] data)
        throws InvalidProtocolBufferException
      {
        return (NamePart)PARSER.parseFrom(data);
      }
      
      public static NamePart parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return (NamePart)PARSER.parseFrom(data, extensionRegistry);
      }
      
      public static NamePart parseFrom(InputStream input)
        throws IOException
      {
        return (NamePart)PARSER.parseFrom(input);
      }
      
      public static NamePart parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (NamePart)PARSER.parseFrom(input, extensionRegistry);
      }
      
      public static NamePart parseDelimitedFrom(InputStream input)
        throws IOException
      {
        return (NamePart)PARSER.parseDelimitedFrom(input);
      }
      
      public static NamePart parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (NamePart)PARSER.parseDelimitedFrom(input, extensionRegistry);
      }
      
      public static NamePart parseFrom(CodedInputStream input)
        throws IOException
      {
        return (NamePart)PARSER.parseFrom(input);
      }
      
      public static NamePart parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (NamePart)PARSER.parseFrom(input, extensionRegistry);
      }
      
      public static Builder newBuilder()
      {
        return Builder.access$18100();
      }
      
      public Builder newBuilderForType()
      {
        return newBuilder();
      }
      
      public static Builder newBuilder(NamePart prototype)
      {
        return newBuilder().mergeFrom(prototype);
      }
      
      public Builder toBuilder()
      {
        return newBuilder(this);
      }
      
      protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
      {
        Builder builder = new Builder(parent, null);
        return builder;
      }
      
      public static final class Builder
        extends GeneratedMessage.Builder<Builder>
        implements DescriptorProtos.UninterpretedOption.NamePartOrBuilder
      {
        private int bitField0_;
        
        public static final Descriptors.Descriptor getDescriptor()
        {
          return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_NamePart_descriptor;
        }
        
        protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
        {
          return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_NamePart_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.UninterpretedOption.NamePart.class, Builder.class);
        }
        
        private Builder()
        {
          maybeForceBuilderInitialization();
        }
        
        private Builder(GeneratedMessage.BuilderParent parent)
        {
          super();
          maybeForceBuilderInitialization();
        }
        
        private void maybeForceBuilderInitialization()
        {
          if (GeneratedMessage.alwaysUseFieldBuilders) {}
        }
        
        private static Builder create()
        {
          return new Builder();
        }
        
        public Builder clear()
        {
          super.clear();
          this.namePart_ = "";
          this.bitField0_ &= 0xFFFFFFFE;
          this.isExtension_ = false;
          this.bitField0_ &= 0xFFFFFFFD;
          return this;
        }
        
        public Builder clone()
        {
          return create().mergeFrom(buildPartial());
        }
        
        public Descriptors.Descriptor getDescriptorForType()
        {
          return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_NamePart_descriptor;
        }
        
        public DescriptorProtos.UninterpretedOption.NamePart getDefaultInstanceForType()
        {
          return DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance();
        }
        
        public DescriptorProtos.UninterpretedOption.NamePart build()
        {
          DescriptorProtos.UninterpretedOption.NamePart result = buildPartial();
          if (!result.isInitialized()) {
            throw newUninitializedMessageException(result);
          }
          return result;
        }
        
        public DescriptorProtos.UninterpretedOption.NamePart buildPartial()
        {
          DescriptorProtos.UninterpretedOption.NamePart result = new DescriptorProtos.UninterpretedOption.NamePart(this, null);
          int from_bitField0_ = this.bitField0_;
          int to_bitField0_ = 0;
          if ((from_bitField0_ & 0x1) == 1) {
            to_bitField0_ |= 0x1;
          }
          result.namePart_ = this.namePart_;
          if ((from_bitField0_ & 0x2) == 2) {
            to_bitField0_ |= 0x2;
          }
          result.isExtension_ = this.isExtension_;
          result.bitField0_ = to_bitField0_;
          onBuilt();
          return result;
        }
        
        public Builder mergeFrom(Message other)
        {
          if ((other instanceof DescriptorProtos.UninterpretedOption.NamePart)) {
            return mergeFrom((DescriptorProtos.UninterpretedOption.NamePart)other);
          }
          super.mergeFrom(other);
          return this;
        }
        
        public Builder mergeFrom(DescriptorProtos.UninterpretedOption.NamePart other)
        {
          if (other == DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance()) {
            return this;
          }
          if (other.hasNamePart())
          {
            this.bitField0_ |= 0x1;
            this.namePart_ = other.namePart_;
            onChanged();
          }
          if (other.hasIsExtension()) {
            setIsExtension(other.getIsExtension());
          }
          mergeUnknownFields(other.getUnknownFields());
          return this;
        }
        
        public final boolean isInitialized()
        {
          if (!hasNamePart()) {
            return false;
          }
          if (!hasIsExtension()) {
            return false;
          }
          return true;
        }
        
        public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
          throws IOException
        {
          DescriptorProtos.UninterpretedOption.NamePart parsedMessage = null;
          try
          {
            parsedMessage = (DescriptorProtos.UninterpretedOption.NamePart)DescriptorProtos.UninterpretedOption.NamePart.PARSER.parsePartialFrom(input, extensionRegistry);
          }
          catch (InvalidProtocolBufferException e)
          {
            parsedMessage = (DescriptorProtos.UninterpretedOption.NamePart)e.getUnfinishedMessage();
            throw e;
          }
          finally
          {
            if (parsedMessage != null) {
              mergeFrom(parsedMessage);
            }
          }
          return this;
        }
        
        private Object namePart_ = "";
        private boolean isExtension_;
        
        public boolean hasNamePart()
        {
          return (this.bitField0_ & 0x1) == 1;
        }
        
        public String getNamePart()
        {
          Object ref = this.namePart_;
          if (!(ref instanceof String))
          {
            String s = ((ByteString)ref).toStringUtf8();
            
            this.namePart_ = s;
            return s;
          }
          return (String)ref;
        }
        
        public ByteString getNamePartBytes()
        {
          Object ref = this.namePart_;
          if ((ref instanceof String))
          {
            ByteString b = ByteString.copyFromUtf8((String)ref);
            
            this.namePart_ = b;
            return b;
          }
          return (ByteString)ref;
        }
        
        public Builder setNamePart(String value)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.bitField0_ |= 0x1;
          this.namePart_ = value;
          onChanged();
          return this;
        }
        
        public Builder clearNamePart()
        {
          this.bitField0_ &= 0xFFFFFFFE;
          this.namePart_ = DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance().getNamePart();
          onChanged();
          return this;
        }
        
        public Builder setNamePartBytes(ByteString value)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.bitField0_ |= 0x1;
          this.namePart_ = value;
          onChanged();
          return this;
        }
        
        public boolean hasIsExtension()
        {
          return (this.bitField0_ & 0x2) == 2;
        }
        
        public boolean getIsExtension()
        {
          return this.isExtension_;
        }
        
        public Builder setIsExtension(boolean value)
        {
          this.bitField0_ |= 0x2;
          this.isExtension_ = value;
          onChanged();
          return this;
        }
        
        public Builder clearIsExtension()
        {
          this.bitField0_ &= 0xFFFFFFFD;
          this.isExtension_ = false;
          onChanged();
          return this;
        }
      }
      
      static
      {
        defaultInstance = new NamePart(true);
        defaultInstance.initFields();
      }
    }
    
    public List<NamePart> getNameList()
    {
      return this.name_;
    }
    
    public List<? extends NamePartOrBuilder> getNameOrBuilderList()
    {
      return this.name_;
    }
    
    public int getNameCount()
    {
      return this.name_.size();
    }
    
    public NamePart getName(int index)
    {
      return (NamePart)this.name_.get(index);
    }
    
    public NamePartOrBuilder getNameOrBuilder(int index)
    {
      return (NamePartOrBuilder)this.name_.get(index);
    }
    
    public boolean hasIdentifierValue()
    {
      return (this.bitField0_ & 0x1) == 1;
    }
    
    public String getIdentifierValue()
    {
      Object ref = this.identifierValue_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.identifierValue_ = s;
      }
      return s;
    }
    
    public ByteString getIdentifierValueBytes()
    {
      Object ref = this.identifierValue_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.identifierValue_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public boolean hasPositiveIntValue()
    {
      return (this.bitField0_ & 0x2) == 2;
    }
    
    public long getPositiveIntValue()
    {
      return this.positiveIntValue_;
    }
    
    public boolean hasNegativeIntValue()
    {
      return (this.bitField0_ & 0x4) == 4;
    }
    
    public long getNegativeIntValue()
    {
      return this.negativeIntValue_;
    }
    
    public boolean hasDoubleValue()
    {
      return (this.bitField0_ & 0x8) == 8;
    }
    
    public double getDoubleValue()
    {
      return this.doubleValue_;
    }
    
    public boolean hasStringValue()
    {
      return (this.bitField0_ & 0x10) == 16;
    }
    
    public ByteString getStringValue()
    {
      return this.stringValue_;
    }
    
    public boolean hasAggregateValue()
    {
      return (this.bitField0_ & 0x20) == 32;
    }
    
    public String getAggregateValue()
    {
      Object ref = this.aggregateValue_;
      if ((ref instanceof String)) {
        return (String)ref;
      }
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        this.aggregateValue_ = s;
      }
      return s;
    }
    
    public ByteString getAggregateValueBytes()
    {
      Object ref = this.aggregateValue_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        this.aggregateValue_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    private void initFields()
    {
      this.name_ = Collections.emptyList();
      this.identifierValue_ = "";
      this.positiveIntValue_ = 0L;
      this.negativeIntValue_ = 0L;
      this.doubleValue_ = 0.0D;
      this.stringValue_ = ByteString.EMPTY;
      this.aggregateValue_ = "";
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      for (int i = 0; i < getNameCount(); i++) {
        if (!getName(i).isInitialized())
        {
          this.memoizedIsInitialized = 0;
          return false;
        }
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      for (int i = 0; i < this.name_.size(); i++) {
        output.writeMessage(2, (MessageLite)this.name_.get(i));
      }
      if ((this.bitField0_ & 0x1) == 1) {
        output.writeBytes(3, getIdentifierValueBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        output.writeUInt64(4, this.positiveIntValue_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        output.writeInt64(5, this.negativeIntValue_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        output.writeDouble(6, this.doubleValue_);
      }
      if ((this.bitField0_ & 0x10) == 16) {
        output.writeBytes(7, this.stringValue_);
      }
      if ((this.bitField0_ & 0x20) == 32) {
        output.writeBytes(8, getAggregateValueBytes());
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      for (int i = 0; i < this.name_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(2, (MessageLite)this.name_.get(i));
      }
      if ((this.bitField0_ & 0x1) == 1) {
        size += CodedOutputStream.computeBytesSize(3, getIdentifierValueBytes());
      }
      if ((this.bitField0_ & 0x2) == 2) {
        size += CodedOutputStream.computeUInt64Size(4, this.positiveIntValue_);
      }
      if ((this.bitField0_ & 0x4) == 4) {
        size += CodedOutputStream.computeInt64Size(5, this.negativeIntValue_);
      }
      if ((this.bitField0_ & 0x8) == 8) {
        size += CodedOutputStream.computeDoubleSize(6, this.doubleValue_);
      }
      if ((this.bitField0_ & 0x10) == 16) {
        size += CodedOutputStream.computeBytesSize(7, this.stringValue_);
      }
      if ((this.bitField0_ & 0x20) == 32) {
        size += CodedOutputStream.computeBytesSize(8, getAggregateValueBytes());
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static UninterpretedOption parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (UninterpretedOption)PARSER.parseFrom(data);
    }
    
    public static UninterpretedOption parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (UninterpretedOption)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static UninterpretedOption parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (UninterpretedOption)PARSER.parseFrom(data);
    }
    
    public static UninterpretedOption parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (UninterpretedOption)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static UninterpretedOption parseFrom(InputStream input)
      throws IOException
    {
      return (UninterpretedOption)PARSER.parseFrom(input);
    }
    
    public static UninterpretedOption parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (UninterpretedOption)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static UninterpretedOption parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (UninterpretedOption)PARSER.parseDelimitedFrom(input);
    }
    
    public static UninterpretedOption parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (UninterpretedOption)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static UninterpretedOption parseFrom(CodedInputStream input)
      throws IOException
    {
      return (UninterpretedOption)PARSER.parseFrom(input);
    }
    
    public static UninterpretedOption parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (UninterpretedOption)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$18700();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(UninterpretedOption prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.UninterpretedOptionOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.UninterpretedOption.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getNameFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        if (this.nameBuilder_ == null)
        {
          this.name_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          this.nameBuilder_.clear();
        }
        this.identifierValue_ = "";
        this.bitField0_ &= 0xFFFFFFFD;
        this.positiveIntValue_ = 0L;
        this.bitField0_ &= 0xFFFFFFFB;
        this.negativeIntValue_ = 0L;
        this.bitField0_ &= 0xFFFFFFF7;
        this.doubleValue_ = 0.0D;
        this.bitField0_ &= 0xFFFFFFEF;
        this.stringValue_ = ByteString.EMPTY;
        this.bitField0_ &= 0xFFFFFFDF;
        this.aggregateValue_ = "";
        this.bitField0_ &= 0xFFFFFFBF;
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_descriptor;
      }
      
      public DescriptorProtos.UninterpretedOption getDefaultInstanceForType()
      {
        return DescriptorProtos.UninterpretedOption.getDefaultInstance();
      }
      
      public DescriptorProtos.UninterpretedOption build()
      {
        DescriptorProtos.UninterpretedOption result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.UninterpretedOption buildPartial()
      {
        DescriptorProtos.UninterpretedOption result = new DescriptorProtos.UninterpretedOption(this, null);
        int from_bitField0_ = this.bitField0_;
        int to_bitField0_ = 0;
        if (this.nameBuilder_ == null)
        {
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.name_ = Collections.unmodifiableList(this.name_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.name_ = this.name_;
        }
        else
        {
          result.name_ = this.nameBuilder_.build();
        }
        if ((from_bitField0_ & 0x2) == 2) {
          to_bitField0_ |= 0x1;
        }
        result.identifierValue_ = this.identifierValue_;
        if ((from_bitField0_ & 0x4) == 4) {
          to_bitField0_ |= 0x2;
        }
        result.positiveIntValue_ = this.positiveIntValue_;
        if ((from_bitField0_ & 0x8) == 8) {
          to_bitField0_ |= 0x4;
        }
        result.negativeIntValue_ = this.negativeIntValue_;
        if ((from_bitField0_ & 0x10) == 16) {
          to_bitField0_ |= 0x8;
        }
        result.doubleValue_ = this.doubleValue_;
        if ((from_bitField0_ & 0x20) == 32) {
          to_bitField0_ |= 0x10;
        }
        result.stringValue_ = this.stringValue_;
        if ((from_bitField0_ & 0x40) == 64) {
          to_bitField0_ |= 0x20;
        }
        result.aggregateValue_ = this.aggregateValue_;
        result.bitField0_ = to_bitField0_;
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.UninterpretedOption)) {
          return mergeFrom((DescriptorProtos.UninterpretedOption)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.UninterpretedOption other)
      {
        if (other == DescriptorProtos.UninterpretedOption.getDefaultInstance()) {
          return this;
        }
        if (this.nameBuilder_ == null)
        {
          if (!other.name_.isEmpty())
          {
            if (this.name_.isEmpty())
            {
              this.name_ = other.name_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensureNameIsMutable();
              this.name_.addAll(other.name_);
            }
            onChanged();
          }
        }
        else if (!other.name_.isEmpty()) {
          if (this.nameBuilder_.isEmpty())
          {
            this.nameBuilder_.dispose();
            this.nameBuilder_ = null;
            this.name_ = other.name_;
            this.bitField0_ &= 0xFFFFFFFE;
            this.nameBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getNameFieldBuilder() : null);
          }
          else
          {
            this.nameBuilder_.addAllMessages(other.name_);
          }
        }
        if (other.hasIdentifierValue())
        {
          this.bitField0_ |= 0x2;
          this.identifierValue_ = other.identifierValue_;
          onChanged();
        }
        if (other.hasPositiveIntValue()) {
          setPositiveIntValue(other.getPositiveIntValue());
        }
        if (other.hasNegativeIntValue()) {
          setNegativeIntValue(other.getNegativeIntValue());
        }
        if (other.hasDoubleValue()) {
          setDoubleValue(other.getDoubleValue());
        }
        if (other.hasStringValue()) {
          setStringValue(other.getStringValue());
        }
        if (other.hasAggregateValue())
        {
          this.bitField0_ |= 0x40;
          this.aggregateValue_ = other.aggregateValue_;
          onChanged();
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        for (int i = 0; i < getNameCount(); i++) {
          if (!getName(i).isInitialized()) {
            return false;
          }
        }
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.UninterpretedOption parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.UninterpretedOption)DescriptorProtos.UninterpretedOption.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.UninterpretedOption)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private List<DescriptorProtos.UninterpretedOption.NamePart> name_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption.NamePart, DescriptorProtos.UninterpretedOption.NamePart.Builder, DescriptorProtos.UninterpretedOption.NamePartOrBuilder> nameBuilder_;
      
      private void ensureNameIsMutable()
      {
        if ((this.bitField0_ & 0x1) != 1)
        {
          this.name_ = new ArrayList(this.name_);
          this.bitField0_ |= 0x1;
        }
      }
      
      public List<DescriptorProtos.UninterpretedOption.NamePart> getNameList()
      {
        if (this.nameBuilder_ == null) {
          return Collections.unmodifiableList(this.name_);
        }
        return this.nameBuilder_.getMessageList();
      }
      
      public int getNameCount()
      {
        if (this.nameBuilder_ == null) {
          return this.name_.size();
        }
        return this.nameBuilder_.getCount();
      }
      
      public DescriptorProtos.UninterpretedOption.NamePart getName(int index)
      {
        if (this.nameBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption.NamePart)this.name_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption.NamePart)this.nameBuilder_.getMessage(index);
      }
      
      public Builder setName(int index, DescriptorProtos.UninterpretedOption.NamePart value)
      {
        if (this.nameBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureNameIsMutable();
          this.name_.set(index, value);
          onChanged();
        }
        else
        {
          this.nameBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setName(int index, DescriptorProtos.UninterpretedOption.NamePart.Builder builderForValue)
      {
        if (this.nameBuilder_ == null)
        {
          ensureNameIsMutable();
          this.name_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.nameBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addName(DescriptorProtos.UninterpretedOption.NamePart value)
      {
        if (this.nameBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureNameIsMutable();
          this.name_.add(value);
          onChanged();
        }
        else
        {
          this.nameBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addName(int index, DescriptorProtos.UninterpretedOption.NamePart value)
      {
        if (this.nameBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureNameIsMutable();
          this.name_.add(index, value);
          onChanged();
        }
        else
        {
          this.nameBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addName(DescriptorProtos.UninterpretedOption.NamePart.Builder builderForValue)
      {
        if (this.nameBuilder_ == null)
        {
          ensureNameIsMutable();
          this.name_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.nameBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addName(int index, DescriptorProtos.UninterpretedOption.NamePart.Builder builderForValue)
      {
        if (this.nameBuilder_ == null)
        {
          ensureNameIsMutable();
          this.name_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.nameBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllName(Iterable<? extends DescriptorProtos.UninterpretedOption.NamePart> values)
      {
        if (this.nameBuilder_ == null)
        {
          ensureNameIsMutable();
          GeneratedMessage.Builder.addAll(values, this.name_);
          onChanged();
        }
        else
        {
          this.nameBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearName()
      {
        if (this.nameBuilder_ == null)
        {
          this.name_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
        }
        else
        {
          this.nameBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeName(int index)
      {
        if (this.nameBuilder_ == null)
        {
          ensureNameIsMutable();
          this.name_.remove(index);
          onChanged();
        }
        else
        {
          this.nameBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.UninterpretedOption.NamePart.Builder getNameBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.NamePart.Builder)getNameFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.UninterpretedOption.NamePartOrBuilder getNameOrBuilder(int index)
      {
        if (this.nameBuilder_ == null) {
          return (DescriptorProtos.UninterpretedOption.NamePartOrBuilder)this.name_.get(index);
        }
        return (DescriptorProtos.UninterpretedOption.NamePartOrBuilder)this.nameBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.UninterpretedOption.NamePartOrBuilder> getNameOrBuilderList()
      {
        if (this.nameBuilder_ != null) {
          return this.nameBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.name_);
      }
      
      public DescriptorProtos.UninterpretedOption.NamePart.Builder addNameBuilder()
      {
        return (DescriptorProtos.UninterpretedOption.NamePart.Builder)getNameFieldBuilder().addBuilder(DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance());
      }
      
      public DescriptorProtos.UninterpretedOption.NamePart.Builder addNameBuilder(int index)
      {
        return (DescriptorProtos.UninterpretedOption.NamePart.Builder)getNameFieldBuilder().addBuilder(index, DescriptorProtos.UninterpretedOption.NamePart.getDefaultInstance());
      }
      
      public List<DescriptorProtos.UninterpretedOption.NamePart.Builder> getNameBuilderList()
      {
        return getNameFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.UninterpretedOption.NamePart, DescriptorProtos.UninterpretedOption.NamePart.Builder, DescriptorProtos.UninterpretedOption.NamePartOrBuilder> getNameFieldBuilder()
      {
        if (this.nameBuilder_ == null)
        {
          this.nameBuilder_ = new RepeatedFieldBuilder(this.name_, (this.bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
          
          this.name_ = null;
        }
        return this.nameBuilder_;
      }
      
      private Object identifierValue_ = "";
      private long positiveIntValue_;
      private long negativeIntValue_;
      private double doubleValue_;
      
      public boolean hasIdentifierValue()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public String getIdentifierValue()
      {
        Object ref = this.identifierValue_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.identifierValue_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getIdentifierValueBytes()
      {
        Object ref = this.identifierValue_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.identifierValue_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setIdentifierValue(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.identifierValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearIdentifierValue()
      {
        this.bitField0_ &= 0xFFFFFFFD;
        this.identifierValue_ = DescriptorProtos.UninterpretedOption.getDefaultInstance().getIdentifierValue();
        onChanged();
        return this;
      }
      
      public Builder setIdentifierValueBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x2;
        this.identifierValue_ = value;
        onChanged();
        return this;
      }
      
      public boolean hasPositiveIntValue()
      {
        return (this.bitField0_ & 0x4) == 4;
      }
      
      public long getPositiveIntValue()
      {
        return this.positiveIntValue_;
      }
      
      public Builder setPositiveIntValue(long value)
      {
        this.bitField0_ |= 0x4;
        this.positiveIntValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearPositiveIntValue()
      {
        this.bitField0_ &= 0xFFFFFFFB;
        this.positiveIntValue_ = 0L;
        onChanged();
        return this;
      }
      
      public boolean hasNegativeIntValue()
      {
        return (this.bitField0_ & 0x8) == 8;
      }
      
      public long getNegativeIntValue()
      {
        return this.negativeIntValue_;
      }
      
      public Builder setNegativeIntValue(long value)
      {
        this.bitField0_ |= 0x8;
        this.negativeIntValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearNegativeIntValue()
      {
        this.bitField0_ &= 0xFFFFFFF7;
        this.negativeIntValue_ = 0L;
        onChanged();
        return this;
      }
      
      public boolean hasDoubleValue()
      {
        return (this.bitField0_ & 0x10) == 16;
      }
      
      public double getDoubleValue()
      {
        return this.doubleValue_;
      }
      
      public Builder setDoubleValue(double value)
      {
        this.bitField0_ |= 0x10;
        this.doubleValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearDoubleValue()
      {
        this.bitField0_ &= 0xFFFFFFEF;
        this.doubleValue_ = 0.0D;
        onChanged();
        return this;
      }
      
      private ByteString stringValue_ = ByteString.EMPTY;
      
      public boolean hasStringValue()
      {
        return (this.bitField0_ & 0x20) == 32;
      }
      
      public ByteString getStringValue()
      {
        return this.stringValue_;
      }
      
      public Builder setStringValue(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x20;
        this.stringValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearStringValue()
      {
        this.bitField0_ &= 0xFFFFFFDF;
        this.stringValue_ = DescriptorProtos.UninterpretedOption.getDefaultInstance().getStringValue();
        onChanged();
        return this;
      }
      
      private Object aggregateValue_ = "";
      
      public boolean hasAggregateValue()
      {
        return (this.bitField0_ & 0x40) == 64;
      }
      
      public String getAggregateValue()
      {
        Object ref = this.aggregateValue_;
        if (!(ref instanceof String))
        {
          String s = ((ByteString)ref).toStringUtf8();
          
          this.aggregateValue_ = s;
          return s;
        }
        return (String)ref;
      }
      
      public ByteString getAggregateValueBytes()
      {
        Object ref = this.aggregateValue_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.aggregateValue_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public Builder setAggregateValue(String value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x40;
        this.aggregateValue_ = value;
        onChanged();
        return this;
      }
      
      public Builder clearAggregateValue()
      {
        this.bitField0_ &= 0xFFFFFFBF;
        this.aggregateValue_ = DescriptorProtos.UninterpretedOption.getDefaultInstance().getAggregateValue();
        onChanged();
        return this;
      }
      
      public Builder setAggregateValueBytes(ByteString value)
      {
        if (value == null) {
          throw new NullPointerException();
        }
        this.bitField0_ |= 0x40;
        this.aggregateValue_ = value;
        onChanged();
        return this;
      }
    }
    
    static
    {
      defaultInstance = new UninterpretedOption(true);
      defaultInstance.initFields();
    }
  }
  
  public static abstract interface SourceCodeInfoOrBuilder
    extends MessageOrBuilder
  {
    public abstract List<DescriptorProtos.SourceCodeInfo.Location> getLocationList();
    
    public abstract DescriptorProtos.SourceCodeInfo.Location getLocation(int paramInt);
    
    public abstract int getLocationCount();
    
    public abstract List<? extends DescriptorProtos.SourceCodeInfo.LocationOrBuilder> getLocationOrBuilderList();
    
    public abstract DescriptorProtos.SourceCodeInfo.LocationOrBuilder getLocationOrBuilder(int paramInt);
  }
  
  public static final class SourceCodeInfo
    extends GeneratedMessage
    implements DescriptorProtos.SourceCodeInfoOrBuilder
  {
    private static final SourceCodeInfo defaultInstance;
    private final UnknownFieldSet unknownFields;
    
    private SourceCodeInfo(GeneratedMessage.Builder<?> builder)
    {
      super();
      this.unknownFields = builder.getUnknownFields();
    }
    
    private SourceCodeInfo(boolean noInit)
    {
      this.unknownFields = UnknownFieldSet.getDefaultInstance();
    }
    
    public static SourceCodeInfo getDefaultInstance()
    {
      return defaultInstance;
    }
    
    public SourceCodeInfo getDefaultInstanceForType()
    {
      return defaultInstance;
    }
    
    public final UnknownFieldSet getUnknownFields()
    {
      return this.unknownFields;
    }
    
    private SourceCodeInfo(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      initFields();
      int mutable_bitField0_ = 0;
      UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
      try
      {
        boolean done = false;
        while (!done)
        {
          int tag = input.readTag();
          switch (tag)
          {
          case 0: 
            done = true;
            break;
          default: 
            if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
              done = true;
            }
            break;
          case 10: 
            if ((mutable_bitField0_ & 0x1) != 1)
            {
              this.location_ = new ArrayList();
              mutable_bitField0_ |= 0x1;
            }
            this.location_.add(input.readMessage(Location.PARSER, extensionRegistry));
          }
        }
      }
      catch (InvalidProtocolBufferException e)
      {
        throw e.setUnfinishedMessage(this);
      }
      catch (IOException e)
      {
        throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
      }
      finally
      {
        if ((mutable_bitField0_ & 0x1) == 1) {
          this.location_ = Collections.unmodifiableList(this.location_);
        }
        this.unknownFields = unknownFields.build();
        makeExtensionsImmutable();
      }
    }
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_descriptor;
    }
    
    protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_fieldAccessorTable.ensureFieldAccessorsInitialized(SourceCodeInfo.class, Builder.class);
    }
    
    public static Parser<SourceCodeInfo> PARSER = new AbstractParser()
    {
      public DescriptorProtos.SourceCodeInfo parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return new DescriptorProtos.SourceCodeInfo(input, extensionRegistry, null);
      }
    };
    public static final int LOCATION_FIELD_NUMBER = 1;
    private List<Location> location_;
    
    public Parser<SourceCodeInfo> getParserForType()
    {
      return PARSER;
    }
    
    public static abstract interface LocationOrBuilder
      extends MessageOrBuilder
    {
      public abstract List<Integer> getPathList();
      
      public abstract int getPathCount();
      
      public abstract int getPath(int paramInt);
      
      public abstract List<Integer> getSpanList();
      
      public abstract int getSpanCount();
      
      public abstract int getSpan(int paramInt);
      
      public abstract boolean hasLeadingComments();
      
      public abstract String getLeadingComments();
      
      public abstract ByteString getLeadingCommentsBytes();
      
      public abstract boolean hasTrailingComments();
      
      public abstract String getTrailingComments();
      
      public abstract ByteString getTrailingCommentsBytes();
    }
    
    public static final class Location
      extends GeneratedMessage
      implements DescriptorProtos.SourceCodeInfo.LocationOrBuilder
    {
      private static final Location defaultInstance;
      private final UnknownFieldSet unknownFields;
      
      private Location(GeneratedMessage.Builder<?> builder)
      {
        super();
        this.unknownFields = builder.getUnknownFields();
      }
      
      private Location(boolean noInit)
      {
        this.unknownFields = UnknownFieldSet.getDefaultInstance();
      }
      
      public static Location getDefaultInstance()
      {
        return defaultInstance;
      }
      
      public Location getDefaultInstanceForType()
      {
        return defaultInstance;
      }
      
      public final UnknownFieldSet getUnknownFields()
      {
        return this.unknownFields;
      }
      
      private Location(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        initFields();
        int mutable_bitField0_ = 0;
        UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
        try
        {
          boolean done = false;
          while (!done)
          {
            int tag = input.readTag();
            switch (tag)
            {
            case 0: 
              done = true;
              break;
            default: 
              if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
                done = true;
              }
              break;
            case 8: 
              if ((mutable_bitField0_ & 0x1) != 1)
              {
                this.path_ = new ArrayList();
                mutable_bitField0_ |= 0x1;
              }
              this.path_.add(Integer.valueOf(input.readInt32()));
              break;
            case 10: 
              int length = input.readRawVarint32();
              int limit = input.pushLimit(length);
              if (((mutable_bitField0_ & 0x1) != 1) && (input.getBytesUntilLimit() > 0))
              {
                this.path_ = new ArrayList();
                mutable_bitField0_ |= 0x1;
              }
              while (input.getBytesUntilLimit() > 0) {
                this.path_.add(Integer.valueOf(input.readInt32()));
              }
              input.popLimit(limit);
              break;
            case 16: 
              if ((mutable_bitField0_ & 0x2) != 2)
              {
                this.span_ = new ArrayList();
                mutable_bitField0_ |= 0x2;
              }
              this.span_.add(Integer.valueOf(input.readInt32()));
              break;
            case 18: 
              int length = input.readRawVarint32();
              int limit = input.pushLimit(length);
              if (((mutable_bitField0_ & 0x2) != 2) && (input.getBytesUntilLimit() > 0))
              {
                this.span_ = new ArrayList();
                mutable_bitField0_ |= 0x2;
              }
              while (input.getBytesUntilLimit() > 0) {
                this.span_.add(Integer.valueOf(input.readInt32()));
              }
              input.popLimit(limit);
              break;
            case 26: 
              this.bitField0_ |= 0x1;
              this.leadingComments_ = input.readBytes();
              break;
            case 34: 
              this.bitField0_ |= 0x2;
              this.trailingComments_ = input.readBytes();
            }
          }
        }
        catch (InvalidProtocolBufferException e)
        {
          throw e.setUnfinishedMessage(this);
        }
        catch (IOException e)
        {
          throw new InvalidProtocolBufferException(e.getMessage()).setUnfinishedMessage(this);
        }
        finally
        {
          if ((mutable_bitField0_ & 0x1) == 1) {
            this.path_ = Collections.unmodifiableList(this.path_);
          }
          if ((mutable_bitField0_ & 0x2) == 2) {
            this.span_ = Collections.unmodifiableList(this.span_);
          }
          this.unknownFields = unknownFields.build();
          makeExtensionsImmutable();
        }
      }
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_Location_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_Location_fieldAccessorTable.ensureFieldAccessorsInitialized(Location.class, Builder.class);
      }
      
      public static Parser<Location> PARSER = new AbstractParser()
      {
        public DescriptorProtos.SourceCodeInfo.Location parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
          throws InvalidProtocolBufferException
        {
          return new DescriptorProtos.SourceCodeInfo.Location(input, extensionRegistry, null);
        }
      };
      private int bitField0_;
      public static final int PATH_FIELD_NUMBER = 1;
      private List<Integer> path_;
      
      public Parser<Location> getParserForType()
      {
        return PARSER;
      }
      
      public List<Integer> getPathList()
      {
        return this.path_;
      }
      
      public int getPathCount()
      {
        return this.path_.size();
      }
      
      public int getPath(int index)
      {
        return ((Integer)this.path_.get(index)).intValue();
      }
      
      private int pathMemoizedSerializedSize = -1;
      public static final int SPAN_FIELD_NUMBER = 2;
      private List<Integer> span_;
      
      public List<Integer> getSpanList()
      {
        return this.span_;
      }
      
      public int getSpanCount()
      {
        return this.span_.size();
      }
      
      public int getSpan(int index)
      {
        return ((Integer)this.span_.get(index)).intValue();
      }
      
      private int spanMemoizedSerializedSize = -1;
      public static final int LEADING_COMMENTS_FIELD_NUMBER = 3;
      private Object leadingComments_;
      public static final int TRAILING_COMMENTS_FIELD_NUMBER = 4;
      private Object trailingComments_;
      
      public boolean hasLeadingComments()
      {
        return (this.bitField0_ & 0x1) == 1;
      }
      
      public String getLeadingComments()
      {
        Object ref = this.leadingComments_;
        if ((ref instanceof String)) {
          return (String)ref;
        }
        ByteString bs = (ByteString)ref;
        
        String s = bs.toStringUtf8();
        if (bs.isValidUtf8()) {
          this.leadingComments_ = s;
        }
        return s;
      }
      
      public ByteString getLeadingCommentsBytes()
      {
        Object ref = this.leadingComments_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.leadingComments_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      public boolean hasTrailingComments()
      {
        return (this.bitField0_ & 0x2) == 2;
      }
      
      public String getTrailingComments()
      {
        Object ref = this.trailingComments_;
        if ((ref instanceof String)) {
          return (String)ref;
        }
        ByteString bs = (ByteString)ref;
        
        String s = bs.toStringUtf8();
        if (bs.isValidUtf8()) {
          this.trailingComments_ = s;
        }
        return s;
      }
      
      public ByteString getTrailingCommentsBytes()
      {
        Object ref = this.trailingComments_;
        if ((ref instanceof String))
        {
          ByteString b = ByteString.copyFromUtf8((String)ref);
          
          this.trailingComments_ = b;
          return b;
        }
        return (ByteString)ref;
      }
      
      private void initFields()
      {
        this.path_ = Collections.emptyList();
        this.span_ = Collections.emptyList();
        this.leadingComments_ = "";
        this.trailingComments_ = "";
      }
      
      private byte memoizedIsInitialized = -1;
      
      public final boolean isInitialized()
      {
        byte isInitialized = this.memoizedIsInitialized;
        if (isInitialized != -1) {
          return isInitialized == 1;
        }
        this.memoizedIsInitialized = 1;
        return true;
      }
      
      public void writeTo(CodedOutputStream output)
        throws IOException
      {
        getSerializedSize();
        if (getPathList().size() > 0)
        {
          output.writeRawVarint32(10);
          output.writeRawVarint32(this.pathMemoizedSerializedSize);
        }
        for (int i = 0; i < this.path_.size(); i++) {
          output.writeInt32NoTag(((Integer)this.path_.get(i)).intValue());
        }
        if (getSpanList().size() > 0)
        {
          output.writeRawVarint32(18);
          output.writeRawVarint32(this.spanMemoizedSerializedSize);
        }
        for (int i = 0; i < this.span_.size(); i++) {
          output.writeInt32NoTag(((Integer)this.span_.get(i)).intValue());
        }
        if ((this.bitField0_ & 0x1) == 1) {
          output.writeBytes(3, getLeadingCommentsBytes());
        }
        if ((this.bitField0_ & 0x2) == 2) {
          output.writeBytes(4, getTrailingCommentsBytes());
        }
        getUnknownFields().writeTo(output);
      }
      
      private int memoizedSerializedSize = -1;
      private static final long serialVersionUID = 0L;
      
      public int getSerializedSize()
      {
        int size = this.memoizedSerializedSize;
        if (size != -1) {
          return size;
        }
        size = 0;
        
        int dataSize = 0;
        for (int i = 0; i < this.path_.size(); i++) {
          dataSize += CodedOutputStream.computeInt32SizeNoTag(((Integer)this.path_.get(i)).intValue());
        }
        size += dataSize;
        if (!getPathList().isEmpty())
        {
          size++;
          size += CodedOutputStream.computeInt32SizeNoTag(dataSize);
        }
        this.pathMemoizedSerializedSize = dataSize;
        
        int dataSize = 0;
        for (int i = 0; i < this.span_.size(); i++) {
          dataSize += CodedOutputStream.computeInt32SizeNoTag(((Integer)this.span_.get(i)).intValue());
        }
        size += dataSize;
        if (!getSpanList().isEmpty())
        {
          size++;
          size += CodedOutputStream.computeInt32SizeNoTag(dataSize);
        }
        this.spanMemoizedSerializedSize = dataSize;
        if ((this.bitField0_ & 0x1) == 1) {
          size += CodedOutputStream.computeBytesSize(3, getLeadingCommentsBytes());
        }
        if ((this.bitField0_ & 0x2) == 2) {
          size += CodedOutputStream.computeBytesSize(4, getTrailingCommentsBytes());
        }
        size += getUnknownFields().getSerializedSize();
        this.memoizedSerializedSize = size;
        return size;
      }
      
      protected Object writeReplace()
        throws ObjectStreamException
      {
        return super.writeReplace();
      }
      
      public static Location parseFrom(ByteString data)
        throws InvalidProtocolBufferException
      {
        return (Location)PARSER.parseFrom(data);
      }
      
      public static Location parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return (Location)PARSER.parseFrom(data, extensionRegistry);
      }
      
      public static Location parseFrom(byte[] data)
        throws InvalidProtocolBufferException
      {
        return (Location)PARSER.parseFrom(data);
      }
      
      public static Location parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
        throws InvalidProtocolBufferException
      {
        return (Location)PARSER.parseFrom(data, extensionRegistry);
      }
      
      public static Location parseFrom(InputStream input)
        throws IOException
      {
        return (Location)PARSER.parseFrom(input);
      }
      
      public static Location parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (Location)PARSER.parseFrom(input, extensionRegistry);
      }
      
      public static Location parseDelimitedFrom(InputStream input)
        throws IOException
      {
        return (Location)PARSER.parseDelimitedFrom(input);
      }
      
      public static Location parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (Location)PARSER.parseDelimitedFrom(input, extensionRegistry);
      }
      
      public static Location parseFrom(CodedInputStream input)
        throws IOException
      {
        return (Location)PARSER.parseFrom(input);
      }
      
      public static Location parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        return (Location)PARSER.parseFrom(input, extensionRegistry);
      }
      
      public static Builder newBuilder()
      {
        return Builder.access$20400();
      }
      
      public Builder newBuilderForType()
      {
        return newBuilder();
      }
      
      public static Builder newBuilder(Location prototype)
      {
        return newBuilder().mergeFrom(prototype);
      }
      
      public Builder toBuilder()
      {
        return newBuilder(this);
      }
      
      protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
      {
        Builder builder = new Builder(parent, null);
        return builder;
      }
      
      public static final class Builder
        extends GeneratedMessage.Builder<Builder>
        implements DescriptorProtos.SourceCodeInfo.LocationOrBuilder
      {
        private int bitField0_;
        
        public static final Descriptors.Descriptor getDescriptor()
        {
          return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_Location_descriptor;
        }
        
        protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
        {
          return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_Location_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.SourceCodeInfo.Location.class, Builder.class);
        }
        
        private Builder()
        {
          maybeForceBuilderInitialization();
        }
        
        private Builder(GeneratedMessage.BuilderParent parent)
        {
          super();
          maybeForceBuilderInitialization();
        }
        
        private void maybeForceBuilderInitialization()
        {
          if (GeneratedMessage.alwaysUseFieldBuilders) {}
        }
        
        private static Builder create()
        {
          return new Builder();
        }
        
        public Builder clear()
        {
          super.clear();
          this.path_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          this.span_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
          this.leadingComments_ = "";
          this.bitField0_ &= 0xFFFFFFFB;
          this.trailingComments_ = "";
          this.bitField0_ &= 0xFFFFFFF7;
          return this;
        }
        
        public Builder clone()
        {
          return create().mergeFrom(buildPartial());
        }
        
        public Descriptors.Descriptor getDescriptorForType()
        {
          return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_Location_descriptor;
        }
        
        public DescriptorProtos.SourceCodeInfo.Location getDefaultInstanceForType()
        {
          return DescriptorProtos.SourceCodeInfo.Location.getDefaultInstance();
        }
        
        public DescriptorProtos.SourceCodeInfo.Location build()
        {
          DescriptorProtos.SourceCodeInfo.Location result = buildPartial();
          if (!result.isInitialized()) {
            throw newUninitializedMessageException(result);
          }
          return result;
        }
        
        public DescriptorProtos.SourceCodeInfo.Location buildPartial()
        {
          DescriptorProtos.SourceCodeInfo.Location result = new DescriptorProtos.SourceCodeInfo.Location(this, null);
          int from_bitField0_ = this.bitField0_;
          int to_bitField0_ = 0;
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.path_ = Collections.unmodifiableList(this.path_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.path_ = this.path_;
          if ((this.bitField0_ & 0x2) == 2)
          {
            this.span_ = Collections.unmodifiableList(this.span_);
            this.bitField0_ &= 0xFFFFFFFD;
          }
          result.span_ = this.span_;
          if ((from_bitField0_ & 0x4) == 4) {
            to_bitField0_ |= 0x1;
          }
          result.leadingComments_ = this.leadingComments_;
          if ((from_bitField0_ & 0x8) == 8) {
            to_bitField0_ |= 0x2;
          }
          result.trailingComments_ = this.trailingComments_;
          result.bitField0_ = to_bitField0_;
          onBuilt();
          return result;
        }
        
        public Builder mergeFrom(Message other)
        {
          if ((other instanceof DescriptorProtos.SourceCodeInfo.Location)) {
            return mergeFrom((DescriptorProtos.SourceCodeInfo.Location)other);
          }
          super.mergeFrom(other);
          return this;
        }
        
        public Builder mergeFrom(DescriptorProtos.SourceCodeInfo.Location other)
        {
          if (other == DescriptorProtos.SourceCodeInfo.Location.getDefaultInstance()) {
            return this;
          }
          if (!other.path_.isEmpty())
          {
            if (this.path_.isEmpty())
            {
              this.path_ = other.path_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensurePathIsMutable();
              this.path_.addAll(other.path_);
            }
            onChanged();
          }
          if (!other.span_.isEmpty())
          {
            if (this.span_.isEmpty())
            {
              this.span_ = other.span_;
              this.bitField0_ &= 0xFFFFFFFD;
            }
            else
            {
              ensureSpanIsMutable();
              this.span_.addAll(other.span_);
            }
            onChanged();
          }
          if (other.hasLeadingComments())
          {
            this.bitField0_ |= 0x4;
            this.leadingComments_ = other.leadingComments_;
            onChanged();
          }
          if (other.hasTrailingComments())
          {
            this.bitField0_ |= 0x8;
            this.trailingComments_ = other.trailingComments_;
            onChanged();
          }
          mergeUnknownFields(other.getUnknownFields());
          return this;
        }
        
        public final boolean isInitialized()
        {
          return true;
        }
        
        public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
          throws IOException
        {
          DescriptorProtos.SourceCodeInfo.Location parsedMessage = null;
          try
          {
            parsedMessage = (DescriptorProtos.SourceCodeInfo.Location)DescriptorProtos.SourceCodeInfo.Location.PARSER.parsePartialFrom(input, extensionRegistry);
          }
          catch (InvalidProtocolBufferException e)
          {
            parsedMessage = (DescriptorProtos.SourceCodeInfo.Location)e.getUnfinishedMessage();
            throw e;
          }
          finally
          {
            if (parsedMessage != null) {
              mergeFrom(parsedMessage);
            }
          }
          return this;
        }
        
        private List<Integer> path_ = Collections.emptyList();
        
        private void ensurePathIsMutable()
        {
          if ((this.bitField0_ & 0x1) != 1)
          {
            this.path_ = new ArrayList(this.path_);
            this.bitField0_ |= 0x1;
          }
        }
        
        public List<Integer> getPathList()
        {
          return Collections.unmodifiableList(this.path_);
        }
        
        public int getPathCount()
        {
          return this.path_.size();
        }
        
        public int getPath(int index)
        {
          return ((Integer)this.path_.get(index)).intValue();
        }
        
        public Builder setPath(int index, int value)
        {
          ensurePathIsMutable();
          this.path_.set(index, Integer.valueOf(value));
          onChanged();
          return this;
        }
        
        public Builder addPath(int value)
        {
          ensurePathIsMutable();
          this.path_.add(Integer.valueOf(value));
          onChanged();
          return this;
        }
        
        public Builder addAllPath(Iterable<? extends Integer> values)
        {
          ensurePathIsMutable();
          GeneratedMessage.Builder.addAll(values, this.path_);
          onChanged();
          return this;
        }
        
        public Builder clearPath()
        {
          this.path_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
          return this;
        }
        
        private List<Integer> span_ = Collections.emptyList();
        
        private void ensureSpanIsMutable()
        {
          if ((this.bitField0_ & 0x2) != 2)
          {
            this.span_ = new ArrayList(this.span_);
            this.bitField0_ |= 0x2;
          }
        }
        
        public List<Integer> getSpanList()
        {
          return Collections.unmodifiableList(this.span_);
        }
        
        public int getSpanCount()
        {
          return this.span_.size();
        }
        
        public int getSpan(int index)
        {
          return ((Integer)this.span_.get(index)).intValue();
        }
        
        public Builder setSpan(int index, int value)
        {
          ensureSpanIsMutable();
          this.span_.set(index, Integer.valueOf(value));
          onChanged();
          return this;
        }
        
        public Builder addSpan(int value)
        {
          ensureSpanIsMutable();
          this.span_.add(Integer.valueOf(value));
          onChanged();
          return this;
        }
        
        public Builder addAllSpan(Iterable<? extends Integer> values)
        {
          ensureSpanIsMutable();
          GeneratedMessage.Builder.addAll(values, this.span_);
          onChanged();
          return this;
        }
        
        public Builder clearSpan()
        {
          this.span_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFD;
          onChanged();
          return this;
        }
        
        private Object leadingComments_ = "";
        
        public boolean hasLeadingComments()
        {
          return (this.bitField0_ & 0x4) == 4;
        }
        
        public String getLeadingComments()
        {
          Object ref = this.leadingComments_;
          if (!(ref instanceof String))
          {
            String s = ((ByteString)ref).toStringUtf8();
            
            this.leadingComments_ = s;
            return s;
          }
          return (String)ref;
        }
        
        public ByteString getLeadingCommentsBytes()
        {
          Object ref = this.leadingComments_;
          if ((ref instanceof String))
          {
            ByteString b = ByteString.copyFromUtf8((String)ref);
            
            this.leadingComments_ = b;
            return b;
          }
          return (ByteString)ref;
        }
        
        public Builder setLeadingComments(String value)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.bitField0_ |= 0x4;
          this.leadingComments_ = value;
          onChanged();
          return this;
        }
        
        public Builder clearLeadingComments()
        {
          this.bitField0_ &= 0xFFFFFFFB;
          this.leadingComments_ = DescriptorProtos.SourceCodeInfo.Location.getDefaultInstance().getLeadingComments();
          onChanged();
          return this;
        }
        
        public Builder setLeadingCommentsBytes(ByteString value)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.bitField0_ |= 0x4;
          this.leadingComments_ = value;
          onChanged();
          return this;
        }
        
        private Object trailingComments_ = "";
        
        public boolean hasTrailingComments()
        {
          return (this.bitField0_ & 0x8) == 8;
        }
        
        public String getTrailingComments()
        {
          Object ref = this.trailingComments_;
          if (!(ref instanceof String))
          {
            String s = ((ByteString)ref).toStringUtf8();
            
            this.trailingComments_ = s;
            return s;
          }
          return (String)ref;
        }
        
        public ByteString getTrailingCommentsBytes()
        {
          Object ref = this.trailingComments_;
          if ((ref instanceof String))
          {
            ByteString b = ByteString.copyFromUtf8((String)ref);
            
            this.trailingComments_ = b;
            return b;
          }
          return (ByteString)ref;
        }
        
        public Builder setTrailingComments(String value)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.bitField0_ |= 0x8;
          this.trailingComments_ = value;
          onChanged();
          return this;
        }
        
        public Builder clearTrailingComments()
        {
          this.bitField0_ &= 0xFFFFFFF7;
          this.trailingComments_ = DescriptorProtos.SourceCodeInfo.Location.getDefaultInstance().getTrailingComments();
          onChanged();
          return this;
        }
        
        public Builder setTrailingCommentsBytes(ByteString value)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          this.bitField0_ |= 0x8;
          this.trailingComments_ = value;
          onChanged();
          return this;
        }
      }
      
      static
      {
        defaultInstance = new Location(true);
        defaultInstance.initFields();
      }
    }
    
    public List<Location> getLocationList()
    {
      return this.location_;
    }
    
    public List<? extends LocationOrBuilder> getLocationOrBuilderList()
    {
      return this.location_;
    }
    
    public int getLocationCount()
    {
      return this.location_.size();
    }
    
    public Location getLocation(int index)
    {
      return (Location)this.location_.get(index);
    }
    
    public LocationOrBuilder getLocationOrBuilder(int index)
    {
      return (LocationOrBuilder)this.location_.get(index);
    }
    
    private void initFields()
    {
      this.location_ = Collections.emptyList();
    }
    
    private byte memoizedIsInitialized = -1;
    
    public final boolean isInitialized()
    {
      byte isInitialized = this.memoizedIsInitialized;
      if (isInitialized != -1) {
        return isInitialized == 1;
      }
      this.memoizedIsInitialized = 1;
      return true;
    }
    
    public void writeTo(CodedOutputStream output)
      throws IOException
    {
      getSerializedSize();
      for (int i = 0; i < this.location_.size(); i++) {
        output.writeMessage(1, (MessageLite)this.location_.get(i));
      }
      getUnknownFields().writeTo(output);
    }
    
    private int memoizedSerializedSize = -1;
    private static final long serialVersionUID = 0L;
    
    public int getSerializedSize()
    {
      int size = this.memoizedSerializedSize;
      if (size != -1) {
        return size;
      }
      size = 0;
      for (int i = 0; i < this.location_.size(); i++) {
        size += CodedOutputStream.computeMessageSize(1, (MessageLite)this.location_.get(i));
      }
      size += getUnknownFields().getSerializedSize();
      this.memoizedSerializedSize = size;
      return size;
    }
    
    protected Object writeReplace()
      throws ObjectStreamException
    {
      return super.writeReplace();
    }
    
    public static SourceCodeInfo parseFrom(ByteString data)
      throws InvalidProtocolBufferException
    {
      return (SourceCodeInfo)PARSER.parseFrom(data);
    }
    
    public static SourceCodeInfo parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (SourceCodeInfo)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static SourceCodeInfo parseFrom(byte[] data)
      throws InvalidProtocolBufferException
    {
      return (SourceCodeInfo)PARSER.parseFrom(data);
    }
    
    public static SourceCodeInfo parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return (SourceCodeInfo)PARSER.parseFrom(data, extensionRegistry);
    }
    
    public static SourceCodeInfo parseFrom(InputStream input)
      throws IOException
    {
      return (SourceCodeInfo)PARSER.parseFrom(input);
    }
    
    public static SourceCodeInfo parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (SourceCodeInfo)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static SourceCodeInfo parseDelimitedFrom(InputStream input)
      throws IOException
    {
      return (SourceCodeInfo)PARSER.parseDelimitedFrom(input);
    }
    
    public static SourceCodeInfo parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (SourceCodeInfo)PARSER.parseDelimitedFrom(input, extensionRegistry);
    }
    
    public static SourceCodeInfo parseFrom(CodedInputStream input)
      throws IOException
    {
      return (SourceCodeInfo)PARSER.parseFrom(input);
    }
    
    public static SourceCodeInfo parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      return (SourceCodeInfo)PARSER.parseFrom(input, extensionRegistry);
    }
    
    public static Builder newBuilder()
    {
      return Builder.access$21200();
    }
    
    public Builder newBuilderForType()
    {
      return newBuilder();
    }
    
    public static Builder newBuilder(SourceCodeInfo prototype)
    {
      return newBuilder().mergeFrom(prototype);
    }
    
    public Builder toBuilder()
    {
      return newBuilder(this);
    }
    
    protected Builder newBuilderForType(GeneratedMessage.BuilderParent parent)
    {
      Builder builder = new Builder(parent, null);
      return builder;
    }
    
    public static final class Builder
      extends GeneratedMessage.Builder<Builder>
      implements DescriptorProtos.SourceCodeInfoOrBuilder
    {
      private int bitField0_;
      
      public static final Descriptors.Descriptor getDescriptor()
      {
        return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_descriptor;
      }
      
      protected GeneratedMessage.FieldAccessorTable internalGetFieldAccessorTable()
      {
        return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_fieldAccessorTable.ensureFieldAccessorsInitialized(DescriptorProtos.SourceCodeInfo.class, Builder.class);
      }
      
      private Builder()
      {
        maybeForceBuilderInitialization();
      }
      
      private Builder(GeneratedMessage.BuilderParent parent)
      {
        super();
        maybeForceBuilderInitialization();
      }
      
      private void maybeForceBuilderInitialization()
      {
        if (GeneratedMessage.alwaysUseFieldBuilders) {
          getLocationFieldBuilder();
        }
      }
      
      private static Builder create()
      {
        return new Builder();
      }
      
      public Builder clear()
      {
        super.clear();
        if (this.locationBuilder_ == null)
        {
          this.location_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          this.locationBuilder_.clear();
        }
        return this;
      }
      
      public Builder clone()
      {
        return create().mergeFrom(buildPartial());
      }
      
      public Descriptors.Descriptor getDescriptorForType()
      {
        return DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_descriptor;
      }
      
      public DescriptorProtos.SourceCodeInfo getDefaultInstanceForType()
      {
        return DescriptorProtos.SourceCodeInfo.getDefaultInstance();
      }
      
      public DescriptorProtos.SourceCodeInfo build()
      {
        DescriptorProtos.SourceCodeInfo result = buildPartial();
        if (!result.isInitialized()) {
          throw newUninitializedMessageException(result);
        }
        return result;
      }
      
      public DescriptorProtos.SourceCodeInfo buildPartial()
      {
        DescriptorProtos.SourceCodeInfo result = new DescriptorProtos.SourceCodeInfo(this, null);
        int from_bitField0_ = this.bitField0_;
        if (this.locationBuilder_ == null)
        {
          if ((this.bitField0_ & 0x1) == 1)
          {
            this.location_ = Collections.unmodifiableList(this.location_);
            this.bitField0_ &= 0xFFFFFFFE;
          }
          result.location_ = this.location_;
        }
        else
        {
          result.location_ = this.locationBuilder_.build();
        }
        onBuilt();
        return result;
      }
      
      public Builder mergeFrom(Message other)
      {
        if ((other instanceof DescriptorProtos.SourceCodeInfo)) {
          return mergeFrom((DescriptorProtos.SourceCodeInfo)other);
        }
        super.mergeFrom(other);
        return this;
      }
      
      public Builder mergeFrom(DescriptorProtos.SourceCodeInfo other)
      {
        if (other == DescriptorProtos.SourceCodeInfo.getDefaultInstance()) {
          return this;
        }
        if (this.locationBuilder_ == null)
        {
          if (!other.location_.isEmpty())
          {
            if (this.location_.isEmpty())
            {
              this.location_ = other.location_;
              this.bitField0_ &= 0xFFFFFFFE;
            }
            else
            {
              ensureLocationIsMutable();
              this.location_.addAll(other.location_);
            }
            onChanged();
          }
        }
        else if (!other.location_.isEmpty()) {
          if (this.locationBuilder_.isEmpty())
          {
            this.locationBuilder_.dispose();
            this.locationBuilder_ = null;
            this.location_ = other.location_;
            this.bitField0_ &= 0xFFFFFFFE;
            this.locationBuilder_ = (GeneratedMessage.alwaysUseFieldBuilders ? getLocationFieldBuilder() : null);
          }
          else
          {
            this.locationBuilder_.addAllMessages(other.location_);
          }
        }
        mergeUnknownFields(other.getUnknownFields());
        return this;
      }
      
      public final boolean isInitialized()
      {
        return true;
      }
      
      public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
        throws IOException
      {
        DescriptorProtos.SourceCodeInfo parsedMessage = null;
        try
        {
          parsedMessage = (DescriptorProtos.SourceCodeInfo)DescriptorProtos.SourceCodeInfo.PARSER.parsePartialFrom(input, extensionRegistry);
        }
        catch (InvalidProtocolBufferException e)
        {
          parsedMessage = (DescriptorProtos.SourceCodeInfo)e.getUnfinishedMessage();
          throw e;
        }
        finally
        {
          if (parsedMessage != null) {
            mergeFrom(parsedMessage);
          }
        }
        return this;
      }
      
      private List<DescriptorProtos.SourceCodeInfo.Location> location_ = Collections.emptyList();
      private RepeatedFieldBuilder<DescriptorProtos.SourceCodeInfo.Location, DescriptorProtos.SourceCodeInfo.Location.Builder, DescriptorProtos.SourceCodeInfo.LocationOrBuilder> locationBuilder_;
      
      private void ensureLocationIsMutable()
      {
        if ((this.bitField0_ & 0x1) != 1)
        {
          this.location_ = new ArrayList(this.location_);
          this.bitField0_ |= 0x1;
        }
      }
      
      public List<DescriptorProtos.SourceCodeInfo.Location> getLocationList()
      {
        if (this.locationBuilder_ == null) {
          return Collections.unmodifiableList(this.location_);
        }
        return this.locationBuilder_.getMessageList();
      }
      
      public int getLocationCount()
      {
        if (this.locationBuilder_ == null) {
          return this.location_.size();
        }
        return this.locationBuilder_.getCount();
      }
      
      public DescriptorProtos.SourceCodeInfo.Location getLocation(int index)
      {
        if (this.locationBuilder_ == null) {
          return (DescriptorProtos.SourceCodeInfo.Location)this.location_.get(index);
        }
        return (DescriptorProtos.SourceCodeInfo.Location)this.locationBuilder_.getMessage(index);
      }
      
      public Builder setLocation(int index, DescriptorProtos.SourceCodeInfo.Location value)
      {
        if (this.locationBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureLocationIsMutable();
          this.location_.set(index, value);
          onChanged();
        }
        else
        {
          this.locationBuilder_.setMessage(index, value);
        }
        return this;
      }
      
      public Builder setLocation(int index, DescriptorProtos.SourceCodeInfo.Location.Builder builderForValue)
      {
        if (this.locationBuilder_ == null)
        {
          ensureLocationIsMutable();
          this.location_.set(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.locationBuilder_.setMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addLocation(DescriptorProtos.SourceCodeInfo.Location value)
      {
        if (this.locationBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureLocationIsMutable();
          this.location_.add(value);
          onChanged();
        }
        else
        {
          this.locationBuilder_.addMessage(value);
        }
        return this;
      }
      
      public Builder addLocation(int index, DescriptorProtos.SourceCodeInfo.Location value)
      {
        if (this.locationBuilder_ == null)
        {
          if (value == null) {
            throw new NullPointerException();
          }
          ensureLocationIsMutable();
          this.location_.add(index, value);
          onChanged();
        }
        else
        {
          this.locationBuilder_.addMessage(index, value);
        }
        return this;
      }
      
      public Builder addLocation(DescriptorProtos.SourceCodeInfo.Location.Builder builderForValue)
      {
        if (this.locationBuilder_ == null)
        {
          ensureLocationIsMutable();
          this.location_.add(builderForValue.build());
          onChanged();
        }
        else
        {
          this.locationBuilder_.addMessage(builderForValue.build());
        }
        return this;
      }
      
      public Builder addLocation(int index, DescriptorProtos.SourceCodeInfo.Location.Builder builderForValue)
      {
        if (this.locationBuilder_ == null)
        {
          ensureLocationIsMutable();
          this.location_.add(index, builderForValue.build());
          onChanged();
        }
        else
        {
          this.locationBuilder_.addMessage(index, builderForValue.build());
        }
        return this;
      }
      
      public Builder addAllLocation(Iterable<? extends DescriptorProtos.SourceCodeInfo.Location> values)
      {
        if (this.locationBuilder_ == null)
        {
          ensureLocationIsMutable();
          GeneratedMessage.Builder.addAll(values, this.location_);
          onChanged();
        }
        else
        {
          this.locationBuilder_.addAllMessages(values);
        }
        return this;
      }
      
      public Builder clearLocation()
      {
        if (this.locationBuilder_ == null)
        {
          this.location_ = Collections.emptyList();
          this.bitField0_ &= 0xFFFFFFFE;
          onChanged();
        }
        else
        {
          this.locationBuilder_.clear();
        }
        return this;
      }
      
      public Builder removeLocation(int index)
      {
        if (this.locationBuilder_ == null)
        {
          ensureLocationIsMutable();
          this.location_.remove(index);
          onChanged();
        }
        else
        {
          this.locationBuilder_.remove(index);
        }
        return this;
      }
      
      public DescriptorProtos.SourceCodeInfo.Location.Builder getLocationBuilder(int index)
      {
        return (DescriptorProtos.SourceCodeInfo.Location.Builder)getLocationFieldBuilder().getBuilder(index);
      }
      
      public DescriptorProtos.SourceCodeInfo.LocationOrBuilder getLocationOrBuilder(int index)
      {
        if (this.locationBuilder_ == null) {
          return (DescriptorProtos.SourceCodeInfo.LocationOrBuilder)this.location_.get(index);
        }
        return (DescriptorProtos.SourceCodeInfo.LocationOrBuilder)this.locationBuilder_.getMessageOrBuilder(index);
      }
      
      public List<? extends DescriptorProtos.SourceCodeInfo.LocationOrBuilder> getLocationOrBuilderList()
      {
        if (this.locationBuilder_ != null) {
          return this.locationBuilder_.getMessageOrBuilderList();
        }
        return Collections.unmodifiableList(this.location_);
      }
      
      public DescriptorProtos.SourceCodeInfo.Location.Builder addLocationBuilder()
      {
        return (DescriptorProtos.SourceCodeInfo.Location.Builder)getLocationFieldBuilder().addBuilder(DescriptorProtos.SourceCodeInfo.Location.getDefaultInstance());
      }
      
      public DescriptorProtos.SourceCodeInfo.Location.Builder addLocationBuilder(int index)
      {
        return (DescriptorProtos.SourceCodeInfo.Location.Builder)getLocationFieldBuilder().addBuilder(index, DescriptorProtos.SourceCodeInfo.Location.getDefaultInstance());
      }
      
      public List<DescriptorProtos.SourceCodeInfo.Location.Builder> getLocationBuilderList()
      {
        return getLocationFieldBuilder().getBuilderList();
      }
      
      private RepeatedFieldBuilder<DescriptorProtos.SourceCodeInfo.Location, DescriptorProtos.SourceCodeInfo.Location.Builder, DescriptorProtos.SourceCodeInfo.LocationOrBuilder> getLocationFieldBuilder()
      {
        if (this.locationBuilder_ == null)
        {
          this.locationBuilder_ = new RepeatedFieldBuilder(this.location_, (this.bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
          
          this.location_ = null;
        }
        return this.locationBuilder_;
      }
    }
    
    static
    {
      defaultInstance = new SourceCodeInfo(true);
      defaultInstance.initFields();
    }
  }
  
  public static Descriptors.FileDescriptor getDescriptor()
  {
    return descriptor;
  }
  
  static
  {
    String[] descriptorData = { "\n google/protobuf/descriptor.proto\022\017google.protobuf\"G\n\021FileDescriptorSet\0222\n\004file\030\001 \003(\0132$.google.protobuf.FileDescriptorProto\"Ë\003\n\023FileDescriptorProto\022\f\n\004name\030\001 \001(\t\022\017\n\007package\030\002 \001(\t\022\022\n\ndependency\030\003 \003(\t\022\031\n\021public_dependency\030\n \003(\005\022\027\n\017weak_dependency\030\013 \003(\005\0226\n\fmessage_type\030\004 \003(\0132 .google.protobuf.DescriptorProto\0227\n\tenum_type\030\005 \003(\0132$.google.protobuf.EnumDescriptorProto\0228\n\007service\030\006 \003(\0132'.google.protobuf.", "ServiceDescriptorProto\0228\n\textension\030\007 \003(\0132%.google.protobuf.FieldDescriptorProto\022-\n\007options\030\b \001(\0132\034.google.protobuf.FileOptions\0229\n\020source_code_info\030\t \001(\0132\037.google.protobuf.SourceCodeInfo\"©\003\n\017DescriptorProto\022\f\n\004name\030\001 \001(\t\0224\n\005field\030\002 \003(\0132%.google.protobuf.FieldDescriptorProto\0228\n\textension\030\006 \003(\0132%.google.protobuf.FieldDescriptorProto\0225\n\013nested_type\030\003 \003(\0132 .google.protobuf.DescriptorProto\0227\n\tenum_type", "\030\004 \003(\0132$.google.protobuf.EnumDescriptorProto\022H\n\017extension_range\030\005 \003(\0132/.google.protobuf.DescriptorProto.ExtensionRange\0220\n\007options\030\007 \001(\0132\037.google.protobuf.MessageOptions\032,\n\016ExtensionRange\022\r\n\005start\030\001 \001(\005\022\013\n\003end\030\002 \001(\005\"\005\n\024FieldDescriptorProto\022\f\n\004name\030\001 \001(\t\022\016\n\006number\030\003 \001(\005\022:\n\005label\030\004 \001(\0162+.google.protobuf.FieldDescriptorProto.Label\0228\n\004type\030\005 \001(\0162*.google.protobuf.FieldDescriptorProto.Type\022\021\n\ttype_name", "\030\006 \001(\t\022\020\n\bextendee\030\002 \001(\t\022\025\n\rdefault_value\030\007 \001(\t\022.\n\007options\030\b \001(\0132\035.google.protobuf.FieldOptions\"¶\002\n\004Type\022\017\n\013TYPE_DOUBLE\020\001\022\016\n\nTYPE_FLOAT\020\002\022\016\n\nTYPE_INT64\020\003\022\017\n\013TYPE_UINT64\020\004\022\016\n\nTYPE_INT32\020\005\022\020\n\fTYPE_FIXED64\020\006\022\020\n\fTYPE_FIXED32\020\007\022\r\n\tTYPE_BOOL\020\b\022\017\n\013TYPE_STRING\020\t\022\016\n\nTYPE_GROUP\020\n\022\020\n\fTYPE_MESSAGE\020\013\022\016\n\nTYPE_BYTES\020\f\022\017\n\013TYPE_UINT32\020\r\022\r\n\tTYPE_ENUM\020\016\022\021\n\rTYPE_SFIXED32\020\017\022\021\n\rTYPE_SFIXED64\020\020\022\017\n\013TYPE_SINT32\020\021\022\017\n\013TYPE_", "SINT64\020\022\"C\n\005Label\022\022\n\016LABEL_OPTIONAL\020\001\022\022\n\016LABEL_REQUIRED\020\002\022\022\n\016LABEL_REPEATED\020\003\"\001\n\023EnumDescriptorProto\022\f\n\004name\030\001 \001(\t\0228\n\005value\030\002 \003(\0132).google.protobuf.EnumValueDescriptorProto\022-\n\007options\030\003 \001(\0132\034.google.protobuf.EnumOptions\"l\n\030EnumValueDescriptorProto\022\f\n\004name\030\001 \001(\t\022\016\n\006number\030\002 \001(\005\0222\n\007options\030\003 \001(\0132!.google.protobuf.EnumValueOptions\"\001\n\026ServiceDescriptorProto\022\f\n\004name\030\001 \001(\t\0226\n\006method\030\002 \003(\0132&.google.pro", "tobuf.MethodDescriptorProto\0220\n\007options\030\003 \001(\0132\037.google.protobuf.ServiceOptions\"\n\025MethodDescriptorProto\022\f\n\004name\030\001 \001(\t\022\022\n\ninput_type\030\002 \001(\t\022\023\n\013output_type\030\003 \001(\t\022/\n\007options\030\004 \001(\0132\036.google.protobuf.MethodOptions\"é\003\n\013FileOptions\022\024\n\fjava_package\030\001 \001(\t\022\034\n\024java_outer_classname\030\b \001(\t\022\"\n\023java_multiple_files\030\n \001(\b:\005false\022,\n\035java_generate_equals_and_hash\030\024 \001(\b:\005false\022F\n\foptimize_for\030\t \001(\0162).google.protobuf.Fil", "eOptions.OptimizeMode:\005SPEED\022\022\n\ngo_package\030\013 \001(\t\022\"\n\023cc_generic_services\030\020 \001(\b:\005false\022$\n\025java_generic_services\030\021 \001(\b:\005false\022\"\n\023py_generic_services\030\022 \001(\b:\005false\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.UninterpretedOption\":\n\fOptimizeMode\022\t\n\005SPEED\020\001\022\r\n\tCODE_SIZE\020\002\022\020\n\fLITE_RUNTIME\020\003*\t\bè\007\020\002\"¸\001\n\016MessageOptions\022&\n\027message_set_wire_format\030\001 \001(\b:\005false\022.\n\037no_standard_descriptor_accessor\030\002 \001(\b:\005", "false\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.UninterpretedOption*\t\bè\007\020\002\"¾\002\n\fFieldOptions\022:\n\005ctype\030\001 \001(\0162#.google.protobuf.FieldOptions.CType:\006STRING\022\016\n\006packed\030\002 \001(\b\022\023\n\004lazy\030\005 \001(\b:\005false\022\031\n\ndeprecated\030\003 \001(\b:\005false\022\034\n\024experimental_map_key\030\t \001(\t\022\023\n\004weak\030\n \001(\b:\005false\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.UninterpretedOption\"/\n\005CType\022\n\n\006STRING\020\000\022\b\n\004CORD\020\001\022\020\n\fSTRING_PIECE\020\002*\t\bè\007", "\020\002\"x\n\013EnumOptions\022\031\n\013allow_alias\030\002 \001(\b:\004true\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.UninterpretedOption*\t\bè\007\020\002\"b\n\020EnumValueOptions\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.UninterpretedOption*\t\bè\007\020\002\"`\n\016ServiceOptions\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.UninterpretedOption*\t\bè\007\020\002\"_\n\rMethodOptions\022C\n\024uninterpreted_option\030ç\007 \003(\0132$.google.protobuf.Uninter", "pretedOption*\t\bè\007\020\002\"\002\n\023UninterpretedOption\022;\n\004name\030\002 \003(\0132-.google.protobuf.UninterpretedOption.NamePart\022\030\n\020identifier_value\030\003 \001(\t\022\032\n\022positive_int_value\030\004 \001(\004\022\032\n\022negative_int_value\030\005 \001(\003\022\024\n\fdouble_value\030\006 \001(\001\022\024\n\fstring_value\030\007 \001(\f\022\027\n\017aggregate_value\030\b \001(\t\0323\n\bNamePart\022\021\n\tname_part\030\001 \002(\t\022\024\n\fis_extension\030\002 \002(\b\"±\001\n\016SourceCodeInfo\022:\n\blocation\030\001 \003(\0132(.google.protobuf.SourceCodeInfo.Location\032c\n\bLocat", "ion\022\020\n\004path\030\001 \003(\005B\002\020\001\022\020\n\004span\030\002 \003(\005B\002\020\001\022\030\n\020leading_comments\030\003 \001(\t\022\031\n\021trailing_comments\030\004 \001(\tB)\n\023com.google.protobufB\020DescriptorProtosH\001" };
    
    Descriptors.FileDescriptor.InternalDescriptorAssigner assigner = new Descriptors.FileDescriptor.InternalDescriptorAssigner()
    {
      public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
      {
        DescriptorProtos.access$21602(root);
        DescriptorProtos.access$002((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(0));
        
        DescriptorProtos.access$102(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_FileDescriptorSet_descriptor, new String[] { "File" }));
        
        DescriptorProtos.access$702((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(1));
        
        DescriptorProtos.access$802(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_FileDescriptorProto_descriptor, new String[] { "Name", "Package", "Dependency", "PublicDependency", "WeakDependency", "MessageType", "EnumType", "Service", "Extension", "Options", "SourceCodeInfo" }));
        
        DescriptorProtos.access$2502((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(2));
        
        DescriptorProtos.access$2602(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_DescriptorProto_descriptor, new String[] { "Name", "Field", "Extension", "NestedType", "EnumType", "ExtensionRange", "Options" }));
        
        DescriptorProtos.access$2802((Descriptors.Descriptor)DescriptorProtos.internal_static_google_protobuf_DescriptorProto_descriptor.getNestedTypes().get(0));
        
        DescriptorProtos.access$2902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_DescriptorProto_ExtensionRange_descriptor, new String[] { "Start", "End" }));
        
        DescriptorProtos.access$4802((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(3));
        
        DescriptorProtos.access$4902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_FieldDescriptorProto_descriptor, new String[] { "Name", "Number", "Label", "Type", "TypeName", "Extendee", "DefaultValue", "Options" }));
        
        DescriptorProtos.access$6302((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(4));
        
        DescriptorProtos.access$6402(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_EnumDescriptorProto_descriptor, new String[] { "Name", "Value", "Options" }));
        
        DescriptorProtos.access$7302((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(5));
        
        DescriptorProtos.access$7402(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_EnumValueDescriptorProto_descriptor, new String[] { "Name", "Number", "Options" }));
        
        DescriptorProtos.access$8302((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(6));
        
        DescriptorProtos.access$8402(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_ServiceDescriptorProto_descriptor, new String[] { "Name", "Method", "Options" }));
        
        DescriptorProtos.access$9302((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(7));
        
        DescriptorProtos.access$9402(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_MethodDescriptorProto_descriptor, new String[] { "Name", "InputType", "OutputType", "Options" }));
        
        DescriptorProtos.access$10402((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(8));
        
        DescriptorProtos.access$10502(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_FileOptions_descriptor, new String[] { "JavaPackage", "JavaOuterClassname", "JavaMultipleFiles", "JavaGenerateEqualsAndHash", "OptimizeFor", "GoPackage", "CcGenericServices", "JavaGenericServices", "PyGenericServices", "UninterpretedOption" }));
        
        DescriptorProtos.access$12102((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(9));
        
        DescriptorProtos.access$12202(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_MessageOptions_descriptor, new String[] { "MessageSetWireFormat", "NoStandardDescriptorAccessor", "UninterpretedOption" }));
        
        DescriptorProtos.access$13102((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(10));
        
        DescriptorProtos.access$13202(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_FieldOptions_descriptor, new String[] { "Ctype", "Packed", "Lazy", "Deprecated", "ExperimentalMapKey", "Weak", "UninterpretedOption" }));
        
        DescriptorProtos.access$14502((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(11));
        
        DescriptorProtos.access$14602(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_EnumOptions_descriptor, new String[] { "AllowAlias", "UninterpretedOption" }));
        
        DescriptorProtos.access$15402((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(12));
        
        DescriptorProtos.access$15502(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_EnumValueOptions_descriptor, new String[] { "UninterpretedOption" }));
        
        DescriptorProtos.access$16102((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(13));
        
        DescriptorProtos.access$16202(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_ServiceOptions_descriptor, new String[] { "UninterpretedOption" }));
        
        DescriptorProtos.access$16802((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(14));
        
        DescriptorProtos.access$16902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_MethodOptions_descriptor, new String[] { "UninterpretedOption" }));
        
        DescriptorProtos.access$17502((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(15));
        
        DescriptorProtos.access$17602(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_descriptor, new String[] { "Name", "IdentifierValue", "PositiveIntValue", "NegativeIntValue", "DoubleValue", "StringValue", "AggregateValue" }));
        
        DescriptorProtos.access$17802((Descriptors.Descriptor)DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_descriptor.getNestedTypes().get(0));
        
        DescriptorProtos.access$17902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_UninterpretedOption_NamePart_descriptor, new String[] { "NamePart", "IsExtension" }));
        
        DescriptorProtos.access$19802((Descriptors.Descriptor)DescriptorProtos.getDescriptor().getMessageTypes().get(16));
        
        DescriptorProtos.access$19902(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_descriptor, new String[] { "Location" }));
        
        DescriptorProtos.access$20102((Descriptors.Descriptor)DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_descriptor.getNestedTypes().get(0));
        
        DescriptorProtos.access$20202(new GeneratedMessage.FieldAccessorTable(DescriptorProtos.internal_static_google_protobuf_SourceCodeInfo_Location_descriptor, new String[] { "Path", "Span", "LeadingComments", "TrailingComments" }));
        
        return null;
      }
    };
    Descriptors.FileDescriptor.internalBuildGeneratedFileFrom(descriptorData, new Descriptors.FileDescriptor[0], assigner);
  }
}
