package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlInsertedText;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;

@JsxClass(domClasses={HtmlInsertedText.class})
public class HTMLInsElement
  extends HTMLElement
{
  @JsxGetter
  public String getCite()
  {
    String cite = getDomNodeOrDie().getAttribute("cite");
    return cite;
  }
  
  @JsxSetter
  public void setCite(String cite)
  {
    getDomNodeOrDie().setAttribute("cite", cite);
  }
  
  @JsxGetter
  public String getDateTime()
  {
    String cite = getDomNodeOrDie().getAttribute("datetime");
    return cite;
  }
  
  @JsxSetter
  public void setDateTime(String dateTime)
  {
    getDomNodeOrDie().setAttribute("datetime", dateTime);
  }
  
  public String getDefaultStyleDisplay()
  {
    return "inline";
  }
}
