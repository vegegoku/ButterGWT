package com.google.gwt.dom.builder.shared;

import com.google.gwt.dom.client.Element;
import com.google.gwt.safehtml.shared.SafeHtml;

public abstract class AbstractElementBuilderBase<R extends ElementBuilderBase<?>>
  implements ElementBuilderBase<R>
{
  private final ElementBuilderImpl delegate;
  private final boolean isEndTagForbidden;
  private final R returnBuilder;
  
  protected AbstractElementBuilderBase(ElementBuilderImpl delegate, boolean isEndTagForbidden)
  {
    this.delegate = delegate;
    this.isEndTagForbidden = isEndTagForbidden;
    
    this.returnBuilder = this;
  }
  
  public void end()
  {
    this.delegate.end();
  }
  
  public void end(String tagName)
  {
    this.delegate.end(tagName);
  }
  
  public void endAnchor()
  {
    end("a");
  }
  
  public void endArea()
  {
    end("area");
  }
  
  public void endAudio()
  {
    end("audio");
  }
  
  public void endBase()
  {
    end("base");
  }
  
  public void endBlockQuote()
  {
    end("blockquote");
  }
  
  public void endBody()
  {
    end("body");
  }
  
  public void endBR()
  {
    end("br");
  }
  
  public void endButton()
  {
    end("button");
  }
  
  public void endCanvas()
  {
    end("canvas");
  }
  
  public void endCol()
  {
    end("col");
  }
  
  public void endColGroup()
  {
    end("colgroup");
  }
  
  public void endDiv()
  {
    end("div");
  }
  
  public void endDList()
  {
    end("dl");
  }
  
  public void endFieldSet()
  {
    end("fieldset");
  }
  
  public void endForm()
  {
    end("form");
  }
  
  public void endFrame()
  {
    end("frame");
  }
  
  public void endFrameSet()
  {
    end("frameset");
  }
  
  public void endH1()
  {
    end("h1");
  }
  
  public void endH2()
  {
    end("h2");
  }
  
  public void endH3()
  {
    end("h3");
  }
  
  public void endH4()
  {
    end("h4");
  }
  
  public void endH5()
  {
    end("h5");
  }
  
  public void endH6()
  {
    end("h6");
  }
  
  public void endHead()
  {
    end("head");
  }
  
  public void endHR()
  {
    end("hr");
  }
  
  public void endIFrame()
  {
    end("iframe");
  }
  
  public void endImage()
  {
    end("img");
  }
  
  public void endInput()
  {
    end("input");
  }
  
  public void endLabel()
  {
    end("label");
  }
  
  public void endLegend()
  {
    end("legend");
  }
  
  public void endLI()
  {
    end("li");
  }
  
  public void endLink()
  {
    end("link");
  }
  
  public void endMap()
  {
    end("map");
  }
  
  public void endMeta()
  {
    end("meta");
  }
  
  public void endOList()
  {
    end("ol");
  }
  
  public void endOptGroup()
  {
    end("optgroup");
  }
  
  public void endOption()
  {
    end("option");
  }
  
  public void endParagraph()
  {
    end("p");
  }
  
  public void endParam()
  {
    end("param");
  }
  
  public void endPre()
  {
    end("pre");
  }
  
  public void endQuote()
  {
    end("q");
  }
  
  public void endScript()
  {
    end("script");
  }
  
  public void endSelect()
  {
    end("select");
  }
  
  public void endSource()
  {
    end("source");
  }
  
  public void endSpan()
  {
    end("span");
  }
  
  public void endStyle()
  {
    end("style");
  }
  
  public void endTable()
  {
    end("table");
  }
  
  public void endTableCaption()
  {
    end("caption");
  }
  
  public void endTBody()
  {
    end("tbody");
  }
  
  public void endTD()
  {
    end("td");
  }
  
  public void endTextArea()
  {
    end("textarea");
  }
  
  public void endTFoot()
  {
    end("tfoot");
  }
  
  public void endTH()
  {
    end("th");
  }
  
  public void endTHead()
  {
    end("thead");
  }
  
  public void endTR()
  {
    end("tr");
  }
  
  public void endUList()
  {
    end("ul");
  }
  
  public void endVideo()
  {
    end("video");
  }
  
  public Element finish()
  {
    return this.delegate.finish();
  }
  
  public int getDepth()
  {
    return this.delegate.getDepth();
  }
  
  public R html(SafeHtml html)
  {
    this.delegate.html(html);
    return getReturnBuilder();
  }
  
  public boolean isChildElementSupported()
  {
    return !this.isEndTagForbidden;
  }
  
  public boolean isEndTagForbidden()
  {
    return this.isEndTagForbidden;
  }
  
  public StylesBuilder style()
  {
    return this.delegate.style();
  }
  
  public R text(String text)
  {
    this.delegate.text(text);
    return getReturnBuilder();
  }
  
  protected R getReturnBuilder()
  {
    return this.returnBuilder;
  }
}
