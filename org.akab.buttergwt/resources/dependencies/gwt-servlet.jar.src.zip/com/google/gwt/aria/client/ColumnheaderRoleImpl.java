package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

class ColumnheaderRoleImpl
  extends RoleImpl
  implements ColumnheaderRole
{
  ColumnheaderRoleImpl(String roleName)
  {
    super(roleName);
  }
  
  public String getAriaExpandedState(Element element)
  {
    return State.EXPANDED.get(element);
  }
  
  public String getAriaReadonlyProperty(Element element)
  {
    return Property.READONLY.get(element);
  }
  
  public String getAriaRequiredProperty(Element element)
  {
    return Property.REQUIRED.get(element);
  }
  
  public String getAriaSelectedState(Element element)
  {
    return State.SELECTED.get(element);
  }
  
  public String getAriaSortProperty(Element element)
  {
    return Property.SORT.get(element);
  }
  
  public void removeAriaExpandedState(Element element)
  {
    State.EXPANDED.remove(element);
  }
  
  public void removeAriaReadonlyProperty(Element element)
  {
    Property.READONLY.remove(element);
  }
  
  public void removeAriaRequiredProperty(Element element)
  {
    Property.REQUIRED.remove(element);
  }
  
  public void removeAriaSelectedState(Element element)
  {
    State.SELECTED.remove(element);
  }
  
  public void removeAriaSortProperty(Element element)
  {
    Property.SORT.remove(element);
  }
  
  public void setAriaExpandedState(Element element, ExpandedValue value)
  {
    State.EXPANDED.set(element, new ExpandedValue[] { value });
  }
  
  public void setAriaReadonlyProperty(Element element, boolean value)
  {
    Property.READONLY.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaRequiredProperty(Element element, boolean value)
  {
    Property.REQUIRED.set(element, new Boolean[] { Boolean.valueOf(value) });
  }
  
  public void setAriaSelectedState(Element element, SelectedValue value)
  {
    State.SELECTED.set(element, new SelectedValue[] { value });
  }
  
  public void setAriaSortProperty(Element element, SortValue value)
  {
    Property.SORT.set(element, new SortValue[] { value });
  }
}
