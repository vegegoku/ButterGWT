package com.gargoylesoftware.htmlunit.javascript.host.html;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlCheckBoxInput;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.html.HtmlInput;
import com.gargoylesoftware.htmlunit.html.HtmlRadioButtonInput;
import com.gargoylesoftware.htmlunit.html.HtmlTextInput;
import com.gargoylesoftware.htmlunit.html.InputElementFactory;
import com.gargoylesoftware.htmlunit.html.impl.SelectableTextInput;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxSetter;
import com.gargoylesoftware.htmlunit.javascript.host.Event;
import com.gargoylesoftware.htmlunit.javascript.host.FormField;
import com.gargoylesoftware.htmlunit.javascript.host.MouseEvent;
import java.io.IOException;
import java.util.Locale;
import org.apache.commons.lang3.math.NumberUtils;
import org.xml.sax.helpers.AttributesImpl;

@JsxClass(domClasses={HtmlInput.class})
public class HTMLInputElement
  extends FormField
{
  @JsxSetter
  public void setType(String newType)
  {
    HtmlInput input = getHtmlInputOrDie();
    if (!input.getTypeAttribute().equalsIgnoreCase(newType))
    {
      AttributesImpl attributes = readAttributes(input);
      int index = attributes.getIndex("type");
      attributes.setValue(index, newType);
      
      HtmlInput newInput = (HtmlInput)InputElementFactory.instance.createElement(input.getPage(), "input", attributes);
      if (input.wasCreatedByJavascript()) {
        newInput.markAsCreatedByJavascript();
      }
      if (input.getParentNode() != null) {
        input.getParentNode().replaceChild(newInput, input);
      } else {
        input = newInput;
      }
      input.setScriptObject(null);
      setDomNode(newInput, true);
    }
  }
  
  @JsxSetter
  public void setChecked(boolean checked)
  {
    ((HtmlInput)getDomNodeOrDie()).setChecked(checked);
  }
  
  protected HtmlInput getHtmlInputOrDie()
  {
    return (HtmlInput)getDomNodeOrDie();
  }
  
  @JsxGetter
  public boolean getChecked()
  {
    return ((HtmlInput)getDomNodeOrDie()).isChecked();
  }
  
  @JsxFunction
  public void select()
  {
    HtmlInput input = getHtmlInputOrDie();
    if ((input instanceof HtmlTextInput)) {
      ((HtmlTextInput)getDomNodeOrDie()).select();
    }
  }
  
  public void setAttribute(String name, String value)
  {
    if ("type".equals(name)) {
      setType(value);
    } else {
      super.setAttribute(name, value);
    }
  }
  
  @JsxGetter
  public String getDefaultValue()
  {
    return ((HtmlInput)getDomNodeOrDie()).getDefaultValue();
  }
  
  @JsxSetter
  public void setDefaultValue(String defaultValue)
  {
    ((HtmlInput)getDomNodeOrDie()).setDefaultValue(defaultValue);
  }
  
  @JsxGetter
  public boolean getDefaultChecked()
  {
    return ((HtmlInput)getDomNodeOrDie()).isDefaultChecked();
  }
  
  @JsxSetter
  public void setDefaultChecked(boolean defaultChecked)
  {
    ((HtmlInput)getDomNodeOrDie()).setDefaultChecked(defaultChecked);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getTextLength()
  {
    return getValue().length();
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getSelectionStart()
  {
    return ((SelectableTextInput)getDomNodeOrDie()).getSelectionStart();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSelectionStart(int start)
  {
    ((SelectableTextInput)getDomNodeOrDie()).setSelectionStart(start);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public int getSelectionEnd()
  {
    return ((SelectableTextInput)getDomNodeOrDie()).getSelectionEnd();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSelectionEnd(int end)
  {
    ((SelectableTextInput)getDomNodeOrDie()).setSelectionEnd(end);
  }
  
  protected boolean isAttributeName(String name)
  {
    String nameLC = name.toLowerCase(Locale.ENGLISH);
    if ("maxlength".equals(nameLC)) {
      return "maxLength".equals(name);
    }
    if ("readOnly".equals(nameLC)) {
      return "readOnly".equals(name);
    }
    return super.isAttributeName(name);
  }
  
  @JsxGetter
  public int getMaxLength()
  {
    String attrValue = getDomNodeOrDie().getAttribute("maxLength");
    return NumberUtils.toInt(attrValue, -1);
  }
  
  @JsxSetter
  public void setMaxLength(int length)
  {
    getDomNodeOrDie().setAttribute("maxLength", Integer.toString(length));
  }
  
  @JsxGetter
  public boolean getReadOnly()
  {
    return ((HtmlInput)getDomNodeOrDie()).isReadOnly();
  }
  
  @JsxSetter
  public void setReadOnly(boolean readOnly)
  {
    ((HtmlInput)getDomNodeOrDie()).setReadOnly(readOnly);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setSelectionRange(int start, int end)
  {
    setSelectionStart(start);
    setSelectionEnd(end);
  }
  
  @JsxGetter
  public String getAlt()
  {
    String alt = getDomNodeOrDie().getAttribute("alt");
    return alt;
  }
  
  @JsxSetter
  public void setAlt(String alt)
  {
    getDomNodeOrDie().setAttribute("alt", alt);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public String getBorder()
  {
    String border = getDomNodeOrDie().getAttribute("border");
    return border;
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.IE)})
  public void setBorder(String border)
  {
    getDomNodeOrDie().setAttribute("border", border);
  }
  
  @JsxGetter
  public String getAlign()
  {
    return getAlign(true);
  }
  
  @JsxSetter
  public void setAlign(String align)
  {
    boolean ignoreIfNoError = getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_ALIGN_FOR_INPUT_IGNORES_VALUES);
    setAlign(align, ignoreIfNoError);
  }
  
  @JsxGetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public String getAccessKey()
  {
    return super.getAccessKey();
  }
  
  @JsxSetter({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void setAccessKey(String accessKey)
  {
    super.setAccessKey(accessKey);
  }
  
  @JsxFunction({@com.gargoylesoftware.htmlunit.javascript.configuration.WebBrowser(com.gargoylesoftware.htmlunit.javascript.configuration.BrowserName.FF)})
  public void click()
    throws IOException
  {
    HtmlInput domNode = (HtmlInput)getDomNodeOrDie();
    boolean originalState = domNode.isChecked();
    Event event = new MouseEvent(domNode, "click", false, false, false, 0);
    
    domNode.click(event);
    
    boolean newState = domNode.isChecked();
    if ((originalState != newState) && (((domNode instanceof HtmlRadioButtonInput)) || (((domNode instanceof HtmlCheckBoxInput)) && (!getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_CLICK_CHECKBOX_TRIGGERS_NO_CHANGE_EVENT))))) {
      domNode.fireEvent("change");
    }
  }
  
  @JsxGetter
  public String getType()
  {
    return super.getType();
  }
  
  protected boolean isEndTagForbidden()
  {
    return true;
  }
  
  public String getDefaultStyleDisplay()
  {
    if (getBrowserVersion().hasFeature(BrowserVersionFeatures.CSS_DISPLAY_DEFAULT)) {
      return "inline";
    }
    return "inline-block";
  }
}
