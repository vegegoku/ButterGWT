package com.gargoylesoftware.htmlunit.javascript.regexp;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.RegExpProxy;
import net.sourceforge.htmlunit.corejs.javascript.ScriptRuntime;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;
import net.sourceforge.htmlunit.corejs.javascript.regexp.NativeRegExp;
import net.sourceforge.htmlunit.corejs.javascript.regexp.RegExpImpl;
import net.sourceforge.htmlunit.corejs.javascript.regexp.SubString;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class HtmlUnitRegExpProxy
  extends RegExpImpl
{
  private static final Log LOG = LogFactory.getLog(HtmlUnitRegExpProxy.class);
  private static final Pattern REPLACE_PATTERN = Pattern.compile("\\$\\$");
  private final RegExpProxy wrapped_;
  
  public HtmlUnitRegExpProxy(RegExpProxy wrapped)
  {
    this.wrapped_ = wrapped;
  }
  
  public Object action(Context cx, Scriptable scope, Scriptable thisObj, Object[] args, int actionType)
  {
    try
    {
      return doAction(cx, scope, thisObj, args, actionType);
    }
    catch (StackOverflowError e)
    {
      LOG.warn(e.getMessage(), e);
    }
    return this.wrapped_.action(cx, scope, thisObj, args, actionType);
  }
  
  private Object doAction(Context cx, Scriptable scope, Scriptable thisObj, Object[] args, int actionType)
  {
    if ((2 == actionType) && (args.length == 2) && ((args[1] instanceof String)))
    {
      String thisString = Context.toString(thisObj);
      String replacement = (String)args[1];
      Object arg0 = args[0];
      if ((arg0 instanceof String))
      {
        replacement = REPLACE_PATTERN.matcher(replacement).replaceAll("\\$");
        
        return StringUtils.replaceOnce(thisString, (String)arg0, replacement);
      }
      if ((arg0 instanceof NativeRegExp)) {
        try
        {
          NativeRegExp regexp = (NativeRegExp)arg0;
          RegExpData reData = new RegExpData(regexp);
          String regex = reData.getJavaPattern();
          int flags = reData.getJavaFlags();
          Pattern pattern = Pattern.compile(regex, flags);
          Matcher matcher = pattern.matcher(thisString);
          return doReplacement(thisString, replacement, matcher, reData.hasFlag('g'));
        }
        catch (PatternSyntaxException e)
        {
          LOG.warn(e.getMessage(), e);
        }
      }
    }
    else if ((1 == actionType) || (3 == actionType))
    {
      if (args.length == 0) {
        return null;
      }
      Object arg0 = args[0];
      String thisString = Context.toString(thisObj);
      RegExpData reData;
      RegExpData reData;
      if ((arg0 instanceof NativeRegExp)) {
        reData = new RegExpData((NativeRegExp)arg0);
      } else {
        reData = new RegExpData(Context.toString(arg0));
      }
      Pattern pattern = Pattern.compile(reData.getJavaPattern(), reData.getJavaFlags());
      Matcher matcher = pattern.matcher(thisString);
      
      boolean found = matcher.find();
      if (3 == actionType)
      {
        if (found)
        {
          setProperties(matcher, thisString, matcher.start(), matcher.end());
          return Integer.valueOf(matcher.start());
        }
        return Integer.valueOf(-1);
      }
      if (!found) {
        return null;
      }
      int index = matcher.start(0);
      List<Object> groups = new ArrayList();
      if (reData.hasFlag('g'))
      {
        groups.add(matcher.group(0));
        setProperties(matcher, thisString, matcher.start(0), matcher.end(0));
        while (matcher.find())
        {
          groups.add(matcher.group(0));
          setProperties(matcher, thisString, matcher.start(0), matcher.end(0));
        }
      }
      for (int i = 0; i <= matcher.groupCount(); i++)
      {
        Object group = matcher.group(i);
        if (group == null) {
          group = Context.getUndefinedValue();
        }
        groups.add(group);
      }
      setProperties(matcher, thisString, matcher.start(), matcher.end());
      
      Scriptable response = cx.newArray(scope, groups.toArray());
      
      response.put("index", response, Integer.valueOf(index));
      response.put("input", response, thisString);
      return response;
    }
    return wrappedAction(cx, scope, thisObj, args, actionType);
  }
  
  private String doReplacement(String originalString, String replacement, Matcher matcher, boolean replaceAll)
  {
    StringBuffer sb = new StringBuffer();
    int previousIndex = 0;
    while (matcher.find())
    {
      sb.append(originalString.substring(previousIndex, matcher.start()));
      String localReplacement = replacement;
      if (replacement.contains("$")) {
        localReplacement = computeReplacementValue(replacement, originalString, matcher);
      }
      sb.append(localReplacement);
      previousIndex = matcher.end();
      
      setProperties(matcher, originalString, matcher.start(), previousIndex);
      if (!replaceAll) {
        break;
      }
    }
    sb.append(originalString.substring(previousIndex));
    return sb.toString();
  }
  
  static String computeReplacementValue(String replacement, String originalString, Matcher matcher)
  {
    int lastIndex = 0;
    StringBuilder result = new StringBuilder();
    int i;
    while ((i = replacement.indexOf('$', lastIndex)) > -1)
    {
      if (i > 0) {
        result.append(replacement.substring(lastIndex, i));
      }
      String ss = null;
      if ((i < replacement.length() - 1) && ((i == lastIndex) || (replacement.charAt(i - 1) != '$')))
      {
        char next = replacement.charAt(i + 1);
        if ((next >= '1') && (next <= '9'))
        {
          int num1digit = next - '0';
          char next2 = i + 2 < replacement.length() ? replacement.charAt(i + 2) : 'x';
          int num2digits;
          int num2digits;
          if ((next2 >= '1') && (next2 <= '9')) {
            num2digits = num1digit * 10 + (next2 - '0');
          } else {
            num2digits = Integer.MAX_VALUE;
          }
          if (num2digits <= matcher.groupCount())
          {
            ss = matcher.group(num2digits);
            i++;
          }
          else if (num1digit <= matcher.groupCount())
          {
            ss = StringUtils.defaultString(matcher.group(num1digit));
          }
        }
        else
        {
          switch (next)
          {
          case '&': 
            ss = matcher.group();
            break;
          case '`': 
            ss = originalString.substring(0, matcher.start());
            break;
          case '\'': 
            ss = originalString.substring(matcher.end());
            break;
          case '$': 
            ss = "$";
            break;
          }
        }
      }
      if (ss != null)
      {
        result.append(ss);
        lastIndex = i + 2;
      }
      else
      {
        result.append('$');
        lastIndex = i + 1;
      }
    }
    result.append(replacement.substring(lastIndex));
    
    return result.toString();
  }
  
  private Object wrappedAction(Context cx, Scriptable scope, Scriptable thisObj, Object[] args, int actionType)
  {
    try
    {
      ScriptRuntime.setRegExpProxy(cx, this.wrapped_);
      return this.wrapped_.action(cx, scope, thisObj, args, actionType);
    }
    finally
    {
      ScriptRuntime.setRegExpProxy(cx, this);
    }
  }
  
  private void setProperties(Matcher matcher, String thisString, int startPos, int endPos)
  {
    String match = matcher.group();
    if (match == null) {
      this.lastMatch = new SubString();
    } else {
      this.lastMatch = new FixedSubString(match);
    }
    int count = Math.min(9, matcher.groupCount());
    if (count == 0)
    {
      this.parens = null;
    }
    else
    {
      this.parens = new SubString[count];
      for (int i = 0; i < count; i++)
      {
        String group = matcher.group(i + 1);
        if (group == null) {
          this.parens[i] = SubString.emptySubString;
        } else {
          this.parens[i] = new FixedSubString(group);
        }
      }
    }
    if (matcher.groupCount() > 0)
    {
      String last = matcher.group(matcher.groupCount());
      if (last == null) {
        this.lastParen = new SubString();
      } else {
        this.lastParen = new FixedSubString(last);
      }
    }
    if (startPos > 0) {
      this.leftContext = new FixedSubString(thisString.substring(0, startPos));
    } else {
      this.leftContext = new SubString();
    }
    if (endPos < thisString.length()) {
      this.rightContext = new FixedSubString(thisString.substring(endPos));
    } else {
      this.rightContext = new SubString();
    }
  }
  
  public Object compileRegExp(Context cx, String source, String flags)
  {
    try
    {
      return this.wrapped_.compileRegExp(cx, source, flags);
    }
    catch (Exception e)
    {
      LOG.warn("compileRegExp() threw for >" + source + "<, flags: >" + flags + "<. " + "Replacing with a '####shouldNotFindAnything###'");
    }
    return this.wrapped_.compileRegExp(cx, "####shouldNotFindAnything###", "");
  }
  
  public int find_split(Context cx, Scriptable scope, String target, String separator, Scriptable re, int[] ip, int[] matchlen, boolean[] matched, String[][] parensp)
  {
    return this.wrapped_.find_split(cx, scope, target, separator, re, ip, matchlen, matched, parensp);
  }
  
  public boolean isRegExp(Scriptable obj)
  {
    return this.wrapped_.isRegExp(obj);
  }
  
  public Scriptable wrapRegExp(Context cx, Scriptable scope, Object compiled)
  {
    return this.wrapped_.wrapRegExp(cx, scope, compiled);
  }
  
  private static class RegExpData
  {
    private final String jsSource_;
    private final String jsFlags_;
    
    RegExpData(NativeRegExp re)
    {
      String str = re.toString();
      this.jsSource_ = StringUtils.substringBeforeLast(str.substring(1), "/");
      this.jsFlags_ = StringUtils.substringAfterLast(str, "/");
    }
    
    public RegExpData(String string)
    {
      this.jsSource_ = string;
      this.jsFlags_ = "";
    }
    
    public int getJavaFlags()
    {
      int flags = 0;
      if (this.jsFlags_.contains("i")) {
        flags |= 0x2;
      }
      if (this.jsFlags_.contains("m")) {
        flags |= 0x8;
      }
      return flags;
    }
    
    public String getJavaPattern()
    {
      return HtmlUnitRegExpProxy.jsRegExpToJavaRegExp(this.jsSource_);
    }
    
    boolean hasFlag(char c)
    {
      return this.jsFlags_.indexOf(c) != -1;
    }
  }
  
  static String jsRegExpToJavaRegExp(String re)
  {
    RegExpJsToJavaConverter regExpJsToJavaFSM = new RegExpJsToJavaConverter();
    String tmpNew = regExpJsToJavaFSM.convert(re);
    return tmpNew;
  }
  
  private static class FixedSubString
    extends SubString
  {
    private String value_;
    
    public FixedSubString(String str)
    {
      this.value_ = str;
    }
    
    public String toString()
    {
      return this.value_;
    }
  }
}
