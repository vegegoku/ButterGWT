package com.google.gwt.activity.shared;

import com.google.gwt.event.shared.ResettableEventBus;
import com.google.gwt.event.shared.UmbrellaException;
import com.google.gwt.place.shared.PlaceChangeEvent;
import com.google.gwt.place.shared.PlaceChangeEvent.Handler;
import com.google.gwt.place.shared.PlaceChangeRequestEvent;
import com.google.gwt.place.shared.PlaceChangeRequestEvent.Handler;
import com.google.gwt.user.client.ui.AcceptsOneWidget;
import com.google.gwt.user.client.ui.IsWidget;
import com.google.web.bindery.event.shared.HandlerRegistration;
import java.util.LinkedHashSet;
import java.util.Set;

public class ActivityManager
  implements PlaceChangeEvent.Handler, PlaceChangeRequestEvent.Handler
{
  private class ProtectedDisplay
    implements AcceptsOneWidget
  {
    private final Activity activity;
    
    ProtectedDisplay(Activity activity)
    {
      this.activity = activity;
    }
    
    public void setWidget(IsWidget view)
    {
      if (this.activity == ActivityManager.this.currentActivity)
      {
        ActivityManager.this.startingNext = false;
        ActivityManager.this.showWidget(view);
      }
    }
  }
  
  private static final Activity NULL_ACTIVITY = new AbstractActivity()
  {
    public void start(AcceptsOneWidget panel, com.google.gwt.event.shared.EventBus eventBus) {}
  };
  private final ActivityMapper mapper;
  private final com.google.web.bindery.event.shared.EventBus eventBus;
  private final ResettableEventBus stopperedEventBus;
  private Activity currentActivity = NULL_ACTIVITY;
  private AcceptsOneWidget display;
  private boolean startingNext = false;
  private HandlerRegistration handlerRegistration;
  
  public ActivityManager(ActivityMapper mapper, com.google.web.bindery.event.shared.EventBus eventBus)
  {
    this.mapper = mapper;
    this.eventBus = eventBus;
    this.stopperedEventBus = new ResettableEventBus(eventBus);
  }
  
  public com.google.web.bindery.event.shared.EventBus getActiveEventBus()
  {
    return this.stopperedEventBus;
  }
  
  public void onPlaceChange(PlaceChangeEvent event)
  {
    Activity nextActivity = getNextActivity(event);
    
    Throwable caughtOnStop = null;
    Throwable caughtOnCancel = null;
    Throwable caughtOnStart = null;
    if (nextActivity == null) {
      nextActivity = NULL_ACTIVITY;
    }
    if (this.currentActivity.equals(nextActivity)) {
      return;
    }
    if (this.startingNext)
    {
      caughtOnCancel = tryStopOrCancel(false);
      this.currentActivity = NULL_ACTIVITY;
      this.startingNext = false;
    }
    else if (!this.currentActivity.equals(NULL_ACTIVITY))
    {
      showWidget(null);
      
      this.stopperedEventBus.removeHandlers();
      caughtOnStop = tryStopOrCancel(true);
    }
    this.currentActivity = nextActivity;
    if (this.currentActivity.equals(NULL_ACTIVITY))
    {
      showWidget(null);
    }
    else
    {
      this.startingNext = true;
      caughtOnStart = tryStart();
    }
    if ((caughtOnStart != null) || (caughtOnCancel != null) || (caughtOnStop != null))
    {
      Set<Throwable> causes = new LinkedHashSet();
      if (caughtOnStop != null) {
        causes.add(caughtOnStop);
      }
      if (caughtOnCancel != null) {
        causes.add(caughtOnCancel);
      }
      if (caughtOnStart != null) {
        causes.add(caughtOnStart);
      }
      throw new UmbrellaException(causes);
    }
  }
  
  public void onPlaceChangeRequest(PlaceChangeRequestEvent event)
  {
    event.setWarning(this.currentActivity.mayStop());
  }
  
  public void setDisplay(AcceptsOneWidget display)
  {
    boolean wasActive = null != this.display;
    boolean willBeActive = null != display;
    this.display = display;
    if (wasActive != willBeActive) {
      updateHandlers(willBeActive);
    }
  }
  
  private Activity getNextActivity(PlaceChangeEvent event)
  {
    if (this.display == null) {
      return null;
    }
    return this.mapper.getActivity(event.getNewPlace());
  }
  
  private void showWidget(IsWidget view)
  {
    if (this.display != null) {
      this.display.setWidget(view);
    }
  }
  
  private Throwable tryStart()
  {
    Throwable caughtOnStart = null;
    try
    {
      this.currentActivity.start(new ProtectedDisplay(this.currentActivity), this.stopperedEventBus);
    }
    catch (Throwable t)
    {
      caughtOnStart = t;
    }
    return caughtOnStart;
  }
  
  private Throwable tryStopOrCancel(boolean stop)
  {
    Throwable caughtOnStop = null;
    try
    {
      if (stop) {
        this.currentActivity.onStop();
      } else {
        this.currentActivity.onCancel();
      }
    }
    catch (Throwable t)
    {
      caughtOnStop = t;
    }
    finally
    {
      this.stopperedEventBus.removeHandlers();
    }
    return caughtOnStop;
  }
  
  private void updateHandlers(boolean activate)
  {
    if (activate)
    {
      final HandlerRegistration placeReg = this.eventBus.addHandler(PlaceChangeEvent.TYPE, this);
      final HandlerRegistration placeRequestReg = this.eventBus.addHandler(PlaceChangeRequestEvent.TYPE, this);
      
      this.handlerRegistration = new HandlerRegistration()
      {
        public void removeHandler()
        {
          placeReg.removeHandler();
          placeRequestReg.removeHandler();
        }
      };
    }
    else if (this.handlerRegistration != null)
    {
      this.handlerRegistration.removeHandler();
      this.handlerRegistration = null;
    }
  }
}
