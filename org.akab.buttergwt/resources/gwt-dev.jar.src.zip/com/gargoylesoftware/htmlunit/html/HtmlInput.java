package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.ElementNotFoundException;
import com.gargoylesoftware.htmlunit.Page;
import com.gargoylesoftware.htmlunit.ScriptResult;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebAssert;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.WebWindow;
import com.gargoylesoftware.htmlunit.javascript.JavaScriptEngine;
import com.gargoylesoftware.htmlunit.util.NameValuePair;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;

public abstract class HtmlInput
  extends HtmlElement
  implements DisabledElement, SubmittableElement, FormFieldWithNameHistory
{
  public static final String TAG_NAME = "input";
  private String defaultValue_;
  private String originalName_;
  private Collection<String> previousNames_ = Collections.emptySet();
  private boolean createdByJavascript_ = false;
  private Object valueAtFocus_;
  
  public HtmlInput(SgmlPage page, Map<String, DomAttr> attributes)
  {
    this(null, "input", page, attributes);
  }
  
  public HtmlInput(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    this.defaultValue_ = getValueAttribute();
    this.originalName_ = getNameAttribute();
  }
  
  public Page setValueAttribute(String newValue)
  {
    WebAssert.notNull("newValue", newValue);
    setAttribute("value", newValue);
    
    Page page = executeOnChangeHandlerIfAppropriate(this);
    this.valueAtFocus_ = getInternalValue();
    return page;
  }
  
  public NameValuePair[] getSubmitKeyValuePairs()
  {
    return new NameValuePair[] { new NameValuePair(getNameAttribute(), getValueAttribute()) };
  }
  
  public final String getTypeAttribute()
  {
    return getAttribute("type");
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final String getValueAttribute()
  {
    return getAttribute("value");
  }
  
  public final String getCheckedAttribute()
  {
    return getAttribute("checked");
  }
  
  public final String getDisabledAttribute()
  {
    return getAttribute("disabled");
  }
  
  public final boolean isDisabled()
  {
    return hasAttribute("disabled");
  }
  
  public final String getReadOnlyAttribute()
  {
    return getAttribute("readonly");
  }
  
  public final String getSizeAttribute()
  {
    return getAttribute("size");
  }
  
  public final String getMaxLengthAttribute()
  {
    return getAttribute("maxlength");
  }
  
  protected int getMaxLength()
  {
    String maxLength = getMaxLengthAttribute();
    if (maxLength.isEmpty()) {
      return Integer.MAX_VALUE;
    }
    try
    {
      return Integer.parseInt(maxLength.trim());
    }
    catch (NumberFormatException e) {}
    return Integer.MAX_VALUE;
  }
  
  public final String getSrcAttribute()
  {
    return getAttribute("src");
  }
  
  public final String getAltAttribute()
  {
    return getAttribute("alt");
  }
  
  public final String getUseMapAttribute()
  {
    return getAttribute("usemap");
  }
  
  public final String getTabIndexAttribute()
  {
    return getAttribute("tabindex");
  }
  
  public final String getAccessKeyAttribute()
  {
    return getAttribute("accesskey");
  }
  
  public final String getOnFocusAttribute()
  {
    return getAttribute("onfocus");
  }
  
  public final String getOnBlurAttribute()
  {
    return getAttribute("onblur");
  }
  
  public final String getOnSelectAttribute()
  {
    return getAttribute("onselect");
  }
  
  public final String getOnChangeAttribute()
  {
    return getAttribute("onchange");
  }
  
  public final String getAcceptAttribute()
  {
    return getAttribute("accept");
  }
  
  public final String getAlignAttribute()
  {
    return getAttribute("align");
  }
  
  public void reset()
  {
    setValueAttribute(this.defaultValue_);
  }
  
  public void setDefaultValue(String defaultValue)
  {
    boolean modifyValue = hasFeature(BrowserVersionFeatures.HTMLINPUT_SET_DEFAULT_VALUE_UPDATES_VALUE);
    setDefaultValue(defaultValue, modifyValue);
  }
  
  protected void setDefaultValue(String defaultValue, boolean modifyValue)
  {
    this.defaultValue_ = defaultValue;
    if (modifyValue) {
      setValueAttribute(defaultValue);
    }
  }
  
  public String getDefaultValue()
  {
    return this.defaultValue_;
  }
  
  public void setDefaultChecked(boolean defaultChecked) {}
  
  public boolean isDefaultChecked()
  {
    return false;
  }
  
  public Page setChecked(boolean isChecked)
  {
    return getPage();
  }
  
  public void setReadOnly(boolean isReadOnly)
  {
    if (isReadOnly) {
      setAttribute("readOnly", "readOnly");
    } else {
      removeAttribute("readOnly");
    }
  }
  
  public boolean isChecked()
  {
    return hasAttribute("checked");
  }
  
  public boolean isReadOnly()
  {
    return hasAttribute("readOnly");
  }
  
  public <P extends Page> P click(int x, int y)
    throws IOException, ElementNotFoundException
  {
    return click();
  }
  
  static Page executeOnChangeHandlerIfAppropriate(HtmlElement htmlElement)
  {
    SgmlPage page = htmlElement.getPage();
    
    JavaScriptEngine engine = htmlElement.getPage().getWebClient().getJavaScriptEngine();
    if (engine.isScriptRunning()) {
      return page;
    }
    ScriptResult scriptResult = htmlElement.fireEvent("change");
    if (page.getWebClient().containsWebWindow(page.getEnclosingWindow())) {
      return page.getEnclosingWindow().getEnclosedPage();
    }
    if (scriptResult != null) {
      return scriptResult.getNewPage();
    }
    return page;
  }
  
  public void setAttributeNS(String namespaceURI, String qualifiedName, String attributeValue)
  {
    if ("name".equals(qualifiedName))
    {
      if (this.previousNames_.isEmpty()) {
        this.previousNames_ = new HashSet();
      }
      this.previousNames_.add(attributeValue);
    }
    super.setAttributeNS(namespaceURI, qualifiedName, attributeValue);
  }
  
  public String getOriginalName()
  {
    return this.originalName_;
  }
  
  public Collection<String> getPreviousNames()
  {
    return this.previousNames_;
  }
  
  public void markAsCreatedByJavascript()
  {
    this.createdByJavascript_ = true;
  }
  
  public void unmarkAsCreatedByJavascript()
  {
    this.createdByJavascript_ = false;
  }
  
  public boolean wasCreatedByJavascript()
  {
    return this.createdByJavascript_;
  }
  
  public final void focus()
  {
    super.focus();
    
    this.valueAtFocus_ = getInternalValue();
  }
  
  final void removeFocus()
  {
    super.removeFocus();
    if (!this.valueAtFocus_.equals(getInternalValue())) {
      handleFocusLostValueChanged();
    }
    this.valueAtFocus_ = null;
  }
  
  void handleFocusLostValueChanged()
  {
    executeOnChangeHandlerIfAppropriate(this);
  }
  
  Object getInternalValue()
  {
    return getValueAttribute();
  }
}
