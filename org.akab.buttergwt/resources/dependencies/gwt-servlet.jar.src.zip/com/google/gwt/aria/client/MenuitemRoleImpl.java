package com.google.gwt.aria.client;

class MenuitemRoleImpl
  extends RoleImpl
  implements MenuitemRole
{
  MenuitemRoleImpl(String roleName)
  {
    super(roleName);
  }
}
