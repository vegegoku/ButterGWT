package com.gargoylesoftware.htmlunit.javascript;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.BrowserVersionFeatures;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.html.DomAttr;
import com.gargoylesoftware.htmlunit.html.DomElement;
import com.gargoylesoftware.htmlunit.html.DomNode;
import com.gargoylesoftware.htmlunit.html.HtmlElement;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxClass;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxFunction;
import com.gargoylesoftware.htmlunit.javascript.configuration.JsxGetter;
import com.gargoylesoftware.htmlunit.javascript.host.Attr;
import com.gargoylesoftware.htmlunit.javascript.host.Node;
import net.sourceforge.htmlunit.corejs.javascript.Context;
import net.sourceforge.htmlunit.corejs.javascript.Scriptable;

@JsxClass
public class NamedNodeMap
  extends SimpleScriptable
  implements ScriptableWithFallbackGetter
{
  private final org.w3c.dom.NamedNodeMap attributes_;
  
  public NamedNodeMap()
  {
    this.attributes_ = null;
  }
  
  public NamedNodeMap(DomElement element)
  {
    setParentScope(element.getScriptObject());
    setPrototype(getPrototype(getClass()));
    
    this.attributes_ = element.getAttributes();
    setDomNode(element, false);
  }
  
  public final Object get(int index, Scriptable start)
  {
    NamedNodeMap startMap = (NamedNodeMap)start;
    Object response = startMap.item(index);
    if (response != null) {
      return response;
    }
    return NOT_FOUND;
  }
  
  public Object getWithFallback(String name)
  {
    Object response = getNamedItem(name);
    if (response != null) {
      return response;
    }
    if ((useRecursiveAttributeForIE()) && (isRecursiveAttribute(name))) {
      return getUnspecifiedAttributeNode(name);
    }
    return NOT_FOUND;
  }
  
  public Object getNamedItemWithoutSytheticClassAttr(String name)
  {
    DomNode attr = (DomNode)this.attributes_.getNamedItem(name);
    if (attr != null) {
      return attr.getScriptObject();
    }
    if ((!"className".equals(name)) && (useRecursiveAttributeForIE()) && (isRecursiveAttribute(name))) {
      return getUnspecifiedAttributeNode(name);
    }
    return null;
  }
  
  @JsxFunction
  public Object getNamedItem(String name)
  {
    Object attr = getNamedItemWithoutSytheticClassAttr(name);
    if (null != attr) {
      return attr;
    }
    if (("class".equals(name)) && (useRecursiveAttributeForIE())) {
      return getUnspecifiedAttributeNode(name);
    }
    return null;
  }
  
  @JsxFunction
  public void setNamedItem(Node node)
  {
    this.attributes_.setNamedItem(node.getDomNodeOrDie());
  }
  
  @JsxFunction
  public void removeNamedItem(String name)
  {
    this.attributes_.removeNamedItem(name);
  }
  
  @JsxFunction
  public Object item(int index)
  {
    DomNode attr = (DomNode)this.attributes_.item(index);
    if (attr != null) {
      return attr.getScriptObject();
    }
    if (useRecursiveAttributeForIE())
    {
      index -= this.attributes_.getLength();
      String name = getRecusiveAttributeNameAt(index);
      if (name != null) {
        return getUnspecifiedAttributeNode(name);
      }
    }
    return null;
  }
  
  private boolean useRecursiveAttributeForIE()
  {
    return (getBrowserVersion().hasFeature(BrowserVersionFeatures.JS_ATTRIBUTES_CONTAINS_EMPTY_ATTR_FOR_PROPERTIES)) && ((getDomNodeOrDie() instanceof HtmlElement));
  }
  
  private Attr getUnspecifiedAttributeNode(String attrName)
  {
    HtmlElement domNode = (HtmlElement)getDomNodeOrDie();
    
    DomAttr attr = domNode.getPage().createAttribute(attrName);
    domNode.setAttributeNode(attr);
    return (Attr)attr.getScriptObject();
  }
  
  @JsxGetter
  public int getLength()
  {
    int length = this.attributes_.getLength();
    if (useRecursiveAttributeForIE()) {
      length += getRecursiveAttributesLength();
    }
    return length;
  }
  
  private boolean isRecursiveAttribute(String name)
  {
    for (Scriptable object = getDomNodeOrDie().getScriptObject(); object != null; object = object.getPrototype()) {
      for (Object id : object.getIds()) {
        if (name.equals(Context.toString(id))) {
          return true;
        }
      }
    }
    return false;
  }
  
  private int getRecursiveAttributesLength()
  {
    int length = 0;
    for (Scriptable object = getDomNodeOrDie().getScriptObject(); object != null; object = object.getPrototype()) {
      length += object.getIds().length;
    }
    return length;
  }
  
  private String getRecusiveAttributeNameAt(int index)
  {
    int i = 0;
    for (Scriptable object = getDomNodeOrDie().getScriptObject(); object != null; object = object.getPrototype()) {
      for (Object id : object.getIds())
      {
        if (i == index) {
          return Context.toString(id);
        }
        i++;
      }
    }
    return null;
  }
}
