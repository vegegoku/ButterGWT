package com.google.gwt.core.client.impl;

import com.google.gwt.core.client.JavaScriptObject;

public class UnloadSupport
{
  static native void clearInterval0(int paramInt);
  
  static native void clearTimeout0(int paramInt);
  
  static native int setInterval0(JavaScriptObject paramJavaScriptObject, int paramInt);
  
  static native int setTimeout0(JavaScriptObject paramJavaScriptObject, int paramInt, Disposable paramDisposable);
  
  public void exportUnloadModule() {}
  
  public boolean isUnloadSupported()
  {
    return false;
  }
  
  void clearInterval(int timerId)
  {
    clearInterval0(timerId);
  }
  
  void clearTimeout(int timerId)
  {
    clearTimeout0(timerId);
  }
  
  void dispose(Disposable d)
  {
    if (d != null) {
      d.dispose();
    }
  }
  
  void disposeAll() {}
  
  void scheduleDispose(Disposable d) {}
  
  int setInterval(JavaScriptObject func, int time)
  {
    return setInterval0(func, time);
  }
  
  int setTimeout(JavaScriptObject func, int time)
  {
    return setTimeout0(func, time, null);
  }
}
