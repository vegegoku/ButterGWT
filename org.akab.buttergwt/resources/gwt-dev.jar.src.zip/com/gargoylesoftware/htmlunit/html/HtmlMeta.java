package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.CookieManager;
import com.gargoylesoftware.htmlunit.SgmlPage;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.util.Cookie;
import java.net.URL;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

public class HtmlMeta
  extends HtmlElement
{
  private static final Pattern COOKIES_SPLIT_PATTERN = Pattern.compile("\\s*;\\s*");
  public static final String TAG_NAME = "meta";
  
  HtmlMeta(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
    if ("set-cookie".equalsIgnoreCase(getHttpEquivAttribute())) {
      performSetCookie();
    }
  }
  
  protected void performSetCookie()
  {
    String[] parts = COOKIES_SPLIT_PATTERN.split(getContentAttribute(), 0);
    String name = org.apache.commons.lang3.StringUtils.substringBefore(parts[0], "=");
    String value = org.apache.commons.lang3.StringUtils.substringAfter(parts[0], "=");
    URL url = getPage().getUrl();
    String host = url.getHost();
    boolean secure = "https".equals(url.getProtocol());
    String path = null;
    Date expires = null;
    for (int i = 1; i < parts.length; i++)
    {
      String partName = org.apache.commons.lang3.StringUtils.substringBefore(parts[i], "=").trim().toLowerCase(Locale.ENGLISH);
      String partValue = org.apache.commons.lang3.StringUtils.substringAfter(parts[i], "=").trim();
      if ("path".equals(partName)) {
        path = partValue;
      } else if ("expires".equals(partName)) {
        expires = com.gargoylesoftware.htmlunit.util.StringUtils.parseHttpDate(partValue);
      } else {
        notifyIncorrectness("set-cookie http-equiv meta tag: unknown attribute '" + partName + "'.");
      }
    }
    Cookie cookie = new Cookie(host, name, value, path, expires, secure);
    getPage().getWebClient().getCookieManager().addCookie(cookie);
  }
  
  public boolean mayBeDisplayed()
  {
    return false;
  }
  
  public final String getHttpEquivAttribute()
  {
    return getAttribute("http-equiv");
  }
  
  public final String getNameAttribute()
  {
    return getAttribute("name");
  }
  
  public final String getContentAttribute()
  {
    return getAttribute("content");
  }
  
  public final String getSchemeAttribute()
  {
    return getAttribute("scheme");
  }
}
