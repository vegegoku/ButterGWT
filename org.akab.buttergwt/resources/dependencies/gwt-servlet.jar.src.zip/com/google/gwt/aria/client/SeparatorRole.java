package com.google.gwt.aria.client;

import com.google.gwt.dom.client.Element;

public abstract interface SeparatorRole
  extends StructureRole
{
  public abstract String getAriaExpandedState(Element paramElement);
  
  public abstract String getAriaOrientationProperty(Element paramElement);
  
  public abstract void removeAriaExpandedState(Element paramElement);
  
  public abstract void removeAriaOrientationProperty(Element paramElement);
  
  public abstract void setAriaExpandedState(Element paramElement, ExpandedValue paramExpandedValue);
  
  public abstract void setAriaOrientationProperty(Element paramElement, OrientationValue paramOrientationValue);
}
