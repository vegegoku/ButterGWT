package com.google.gwt.cell.client;

public abstract interface IsCollapsible
{
  public abstract boolean isCollapseLeft();
  
  public abstract boolean isCollapseRight();
  
  public abstract void setCollapseLeft(boolean paramBoolean);
  
  public abstract void setCollapseRight(boolean paramBoolean);
}
