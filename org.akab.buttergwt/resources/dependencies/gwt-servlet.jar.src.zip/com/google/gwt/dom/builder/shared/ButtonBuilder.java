package com.google.gwt.dom.builder.shared;

public abstract interface ButtonBuilder
  extends ElementBuilderBase<ButtonBuilder>
{
  public abstract ButtonBuilder accessKey(String paramString);
  
  public abstract ButtonBuilder disabled();
  
  public abstract ButtonBuilder name(String paramString);
  
  public abstract ButtonBuilder value(String paramString);
}
