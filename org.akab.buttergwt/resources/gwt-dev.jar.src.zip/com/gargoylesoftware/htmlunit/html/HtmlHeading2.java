package com.gargoylesoftware.htmlunit.html;

import com.gargoylesoftware.htmlunit.SgmlPage;
import java.util.Map;

public class HtmlHeading2
  extends HtmlElement
{
  public static final String TAG_NAME = "h2";
  
  HtmlHeading2(String namespaceURI, String qualifiedName, SgmlPage page, Map<String, DomAttr> attributes)
  {
    super(namespaceURI, qualifiedName, page, attributes);
  }
  
  public final String getAlignAttribute()
  {
    return getAttribute("align");
  }
  
  protected boolean isBlock()
  {
    return true;
  }
}
